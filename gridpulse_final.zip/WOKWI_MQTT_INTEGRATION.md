# Wokwi + MQTT Integration

Use `backend/simulation/wokwi/diagram.json` as the virtual sensor topology. The intended telemetry contract is:

```text
gridpulse/telemetry/irradiance
gridpulse/telemetry/ambient_c
gridpulse/telemetry/transformer_oil_c
```

Control topics:

```text
gridpulse/control/bess
gridpulse/control/inverter
gridpulse/control/grid
```

The backend exposes `/api/edge/mqtt` to report bridge availability and connection state.
