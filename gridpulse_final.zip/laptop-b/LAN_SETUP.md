# GRIDPULSE Laptop B — LAN setup

1. From this directory run `npm install`.
2. Copy `.env.example` to `.env.local`.
3. Set `VITE_API_URL` and `VITE_WS_URL` to the FastAPI host.
4. Run `npm run dev -- --host 0.0.0.0`.

Laptop B is Control Center + Solarex + AI assistant. It does not run the circuit simulation.
