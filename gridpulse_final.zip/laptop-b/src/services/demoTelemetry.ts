// GRIDPULSE v1.0.0 - Demo Telemetry Generator
// Provides deterministic electrical data when Laptop A backend is unavailable
// NO Math.random() - all values are deterministic based on time

import { TelemetryState } from '../services/api';

export function generateDemoTelemetry(): TelemetryState {
  const now = new Date();
  const timeOfDay = now.getHours() + now.getMinutes() / 60;

  const pointAt = (d: Date) => {
    const t = d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;
    const solarFactor = Math.max(0, Math.sin((t - 6) * Math.PI / 12));
    let loadFactor: number;
    if (t >= 17 && t < 22) loadFactor = 1.35;
    else if (t >= 6 && t < 9) loadFactor = 0.9;
    else if (t >= 9 && t < 17) loadFactor = 0.62;
    else loadFactor = 0.5;

    const totalLoad = 95 * loadFactor;
    const totalSolar = 105 * solarFactor;
    const surplus = totalSolar - totalLoad;
    const batteryPower = surplus > 0 ? -Math.min(surplus * 0.45, 50) : Math.min((-surplus) * 0.55, 50);
    const gridImport = Math.max(0, totalLoad - totalSolar - Math.max(0, batteryPower));
    const gridExport = Math.max(0, totalSolar - totalLoad + batteryPower);
    const transformerLoading = Math.min(118, Math.abs(totalLoad - totalSolar - batteryPower) / 1.9);
    const voltage = 415 - Math.max(0, transformerLoading - 60) * 0.35 + Math.max(0, 45 - transformerLoading) * 0.03;
    return {
      totalLoad,
      totalSolar,
      batteryPower,
      gridImport,
      gridExport,
      transformerLoading,
      voltage,
    };
  };

  const current = pointAt(now);
  const houses = Array.from({ length: 5 }, (_, i) => {
    const baseLoad = 5 + i * 0.5;
    const share = baseLoad / 20;
    const load = current.totalLoad * share;
    const pv = current.totalSolar * (8 / 105) / 5;
    return {
      id: `HOUSE-${String(i + 1).padStart(2, '0')}`,
      load_kw: load,
      pv_kw: pv,
      net_kw: pv - load,
      voltage_v: current.voltage,
    };
  });

  const tOfDay = (d: Date) => d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;

  const community = {
    id: 'COMMUNITY-01',
    load_kw: current.totalLoad - houses.reduce((sum, h) => sum + h.load_kw, 0),
    pv_kw: current.totalSolar - houses.reduce((sum, h) => sum + h.pv_kw, 0),
    net_kw: 0,
  };
  community.net_kw = community.pv_kw - community.load_kw;

  const history = Array.from({ length: 288 }, (_, i) => {
    const d = new Date(now.getTime() - (287 - i) * 5 * 60_000);
    const h = pointAt(d);
    return {
      timestamp: d.toISOString(),
      solar_kw: Number(h.totalSolar.toFixed(3)),
      load_kw: Number(h.totalLoad.toFixed(3)),
      grid_import_kw: Number(h.gridImport.toFixed(3)),
      grid_export_kw: Number(h.gridExport.toFixed(3)),
      battery_soc: Number(Math.max(20, Math.min(95, 55 + 20 * Math.sin((tOfDay(d) - 6) * Math.PI / 12))).toFixed(3)),
      battery_power_kw: Number(h.batteryPower.toFixed(3)),
      transformer_loading: Number(h.transformerLoading.toFixed(3)),
      voltage_v: Number(h.voltage.toFixed(3)),
      frequency_hz: 50.0,
      transformer_temperature_c: Number((45 + h.transformerLoading * 0.3).toFixed(3)),
      price: 6.25,
    };
  });

  const soc = history[history.length - 1].battery_soc;
  const health = current.transformerLoading > 100 ? 'Critical' : current.transformerLoading > 85 ? 'Warning' : 'Healthy';
  const alarms: TelemetryState['alarms'] = [];
  if (current.transformerLoading > 100) {
    alarms.push({ id: 'DEMO-TX-CRIT', timestamp: now.toISOString(), severity: 'CRITICAL', source: 'TRANSFORMER', message: `Transformer overload: ${current.transformerLoading.toFixed(1)}%`, active: true });
  } else if (current.transformerLoading > 85) {
    alarms.push({ id: 'DEMO-TX-WARN', timestamp: now.toISOString(), severity: 'WARNING', source: 'TRANSFORMER', message: `High transformer loading: ${current.transformerLoading.toFixed(1)}%`, active: true });
  }
  if (current.voltage < 0.95 * 415) {
    alarms.push({ id: 'DEMO-UV', timestamp: now.toISOString(), severity: 'WARNING', source: 'INVERTER', message: `Undervoltage at PCC: ${(current.voltage / 415).toFixed(3)} p.u.`, active: true });
  }
  if (current.voltage > 1.05 * 415) {
    alarms.push({ id: 'DEMO-OV', timestamp: now.toISOString(), severity: 'WARNING', source: 'INVERTER', message: `Overvoltage at PCC: ${(current.voltage / 415).toFixed(3)} p.u.`, active: true });
  }
  if (soc <= 20.5) {
    alarms.push({ id: 'DEMO-BESS-LOW', timestamp: now.toISOString(), severity: 'INFO', source: 'BESS', message: 'Battery at minimum configured SOC boundary.', active: true });
  }

  const voltagePu = current.voltage / 415;
  const thdV = 2.0 + Math.max(0, Math.abs(voltagePu - 1) * 20) + Math.min(2.0, Math.abs(current.batteryPower) / 40);
  const hotspot = 34 + current.transformerLoading * 0.42;
  const aging = Math.exp((15000 / 383) - (15000 / (hotspot + 273.15)));
  const batterySoh = Math.max(99.5, 100 - Math.abs(current.batteryPower) * 0.002);
  const advanced = {
    co_simulation: {
      clock: { sim_time_s: Date.now() / 1000, sequence: Date.now() },
      active_federates: 0,
      synchronization: 'LOCAL_TIME_BARRIER',
      fallback_active: true,
      federates: {
        distribution: { name: 'OpenDSS Distribution Federate', installed: false },
        balanced: { name: 'pandapower Verification Federate', installed: false },
        optimization: { name: 'PyPSA Optimization Federate', installed: false },
        orchestration: { name: 'HELICS Coordinator', installed: false },
        mqtt: { name: 'MQTT Broker Bridge', installed: false },
        edge: { name: 'Wokwi / ESP32 Edge Federate', installed: false },
      },
    },
    transformer_health: {
      ambient_c: 27, load_percent: current.transformerLoading, top_oil_rise_c: Math.max(8, current.transformerLoading * 0.18),
      hotspot_rise_c: Math.max(6, current.transformerLoading * 0.12), hotspot_temperature_c: hotspot,
      aging_acceleration_factor: aging, estimated_insulation_life_loss_percent: 0, health: current.transformerLoading > 100 ? 'CRITICAL' : current.transformerLoading > 85 ? 'WARNING' : 'HEALTHY',
    },
    harmonics: { thd_voltage_percent: thdV, thd_current_percent: 3 + Math.abs(current.batteryPower) / 25, k_factor: 1.2 + Math.abs(current.batteryPower) / 1000, transformer_derating_percent: Math.max(0, thdV - 5) * 2, status: thdV >= 10 ? 'CRITICAL' : thdV >= 5 ? 'WARNING' : 'NORMAL', limit_thd_voltage_percent: 5 },
    battery_health: { soh_percent: batterySoh, capacity_fade_percent: 100 - batterySoh, effective_capacity_kwh: 200 * batterySoh / 100, throughput_kwh: 0, equivalent_full_cycles: 0, average_cycle_depth_percent: 0, c_rate: Math.abs(current.batteryPower) / 200, lcos_estimate_inr_per_kwh: 6.5 },
    smart_inverter: { volt_var_q_kvar: voltagePu > 1.02 ? -(current.totalSolar * 0.25) : voltagePu < 0.98 ? current.totalSolar * 0.25 : 0, volt_watt_curtail_percent: voltagePu > 1.05 ? Math.min(100, (voltagePu - 1.05) / 0.05 * 100) : 0, ride_through: voltagePu >= 0.88 && voltagePu <= 1.10, grid_support: voltagePu > 1.02 ? 'ABSORB_Q' : voltagePu < 0.98 ? 'INJECT_Q' : 'NEUTRAL' },
    microgrid: { mode: 'GRID_CONNECTED', pcc_breaker: 'CLOSED', grid_forming: false, grid_following: true, load_shed_kw: 0, critical_load_served_kw: current.totalLoad, critical_load_fraction: 0.6, resynchronization: 'NOT_REQUIRED', progress_percent: 100 },
    dga: { methane_percent: 58, ethylene_percent: 38, acetylene_percent: 4, duval_region: 'Normal / no dominant fault signature', severity: 'NORMAL' },
    standards: { transformer: ['IEEE C57.91 reference thermal/aging model', 'IEEE C57.110-style harmonic derating'], power_quality: ['IEEE 519-inspired THD monitor'], der: ['IEEE 1547-inspired Volt-VAR / Volt-Watt'], microgrid: ['IEEE 2030.8-inspired islanding/resynchronization workflow'] },
    edge: { wokwi: { status: 'READY' }, mqtt: { status: 'READY' } },
  };

  return {
    timestamp: now.toISOString(),
    sequence: Date.now(),
    frequency: 50.0,
    grid: {
      voltage_kv: 11.0,
      import_kw: current.gridImport,
      export_kw: current.gridExport,
      export_limit_kw: 100,
    },
    transformer: {
      id: 'TX-01',
      rating_kva: 500,
      primary_voltage_kv: 11.0,
      secondary_voltage_v: 415,
      loading_percent: current.transformerLoading,
      temperature_c: 45 + current.transformerLoading * 0.3,
      efficiency: 98.0,
      health,
    },
    buses: [
      { id: 'BUS-11KV', voltage_kv: 11.0, type: 'MV' },
      { id: 'BUS-415V', voltage_v: current.voltage, type: 'LV' },
    ],
    houses,
    community,
    battery: {
      id: 'BESS-01',
      capacity_kwh: 200,
      soc_percent: soc,
      power_kw: current.batteryPower,
      state: current.batteryPower > 0.2 ? 'DISCHARGING' : current.batteryPower < -0.2 ? 'CHARGING' : 'IDLE',
      mode: 'AUTO',
      target_soc: 80,
      min_soc: 20,
      max_soc: 95,
      stored_energy_kwh: Number((200 * soc / 100).toFixed(3)),
      flow_direction: current.batteryPower > 0.2 ? 'BESS_TO_LOAD_GRID' : current.batteryPower < -0.2 ? 'SOLAR_GRID_TO_BESS' : 'IDLE',
      energy_flow: {
        stored_energy_kwh: Number((200 * soc / 100).toFixed(3)),
        pcs_power_kw: Number(Math.abs(current.batteryPower).toFixed(3)),
        to_local_load_kw: Number(Math.max(0, current.batteryPower).toFixed(3)),
        to_grid_kw: Number(Math.max(0, current.batteryPower + current.totalSolar - current.totalLoad).toFixed(3)),
        from_solar_kw: Number(Math.max(0, -current.batteryPower).toFixed(3)),
        from_grid_kw: Number(Math.max(0, -current.batteryPower - Math.max(0, current.totalSolar - current.totalLoad)).toFixed(3)),
        efficiency_percent: 96,
      },
    },
    pcs: {
      id: 'PCS-01',
      enabled: true,
      pwm_frequency_hz: 10000,
      duty_cycle: Math.max(0, Math.min(1, 0.5 + current.batteryPower / 100)),
      power_kw: Math.abs(current.batteryPower),
      efficiency: 96,
      max_power_kw: 100,
      carrier_period_ms: 0.1,
      pulse_on_ms: Number((0.1 * Math.max(0, Math.min(1, 0.5 + current.batteryPower / 100))).toFixed(5)),
      pulse_off_ms: Number((0.1 * (1 - Math.max(0, Math.min(1, 0.5 + current.batteryPower / 100)))).toFixed(5)),
      pulses_per_second: 10000,
      average_power_kw: Math.abs(current.batteryPower),
      direction: current.batteryPower > 0.2 ? 'DISCHARGE' : current.batteryPower < -0.2 ? 'CHARGE' : 'IDLE',
      waveform: Array.from({ length: 32 }, (_, i) => i / 32 < Math.max(0, Math.min(1, 0.5 + current.batteryPower / 100)) ? 1 : 0),
      transfer_model: 'PWM_AVERAGED',
    },
    ems_mode: 'LOCAL_FIRST',
    pricing: {
      import_tariff: 6.25,
      export_tariff: 2.75,
      current_period: 'DAY',
    },
    alarms,
    advanced,
    history,
  };
}
