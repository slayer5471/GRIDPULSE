// Solarex Calculation Engine - Deterministic solar calculations
import {
  SolarexLocation,
  RoofPolygon,
  SolarAssumptions,
  SolarSystem,
  MonthlyGeneration,
  BatteryOption,
  SystemComparison,
} from '../types/solarex';

// Default assumptions for India (Bengaluru region)
export const DEFAULT_ASSUMPTIONS: SolarAssumptions = {
  panel: {
    capacity_w: 450,
    efficiency: 0.20,
    area_sqm: 2.2,
    cost_per_panel: 15000,
  },
  system_loss_percent: 14,
  performance_ratio: 0.86,
  degradation_percent_per_year: 0.5,
  installation_cost_per_kw: 55000,
  tariff_per_kwh: 8.0,
  export_tariff_per_kwh: 4.0,
  emissions_factor_kg_per_kwh: 0.82,
  usable_roof_percent: 75,
  solar_irradiance_kwh_per_m2_per_day: 5.2, // Bengaluru average
};

// Monthly solar factors for Bengaluru (seasonal variation)
const MONTHLY_FACTORS = [
  { month: 'Jan', factor: 0.92 },
  { month: 'Feb', factor: 1.00 },
  { month: 'Mar', factor: 1.05 },
  { month: 'Apr', factor: 1.08 },
  { month: 'May', factor: 1.02 },
  { month: 'Jun', factor: 0.85 },
  { month: 'Jul', factor: 0.78 },
  { month: 'Aug', factor: 0.82 },
  { month: 'Sep', factor: 0.90 },
  { month: 'Oct', factor: 0.95 },
  { month: 'Nov', factor: 0.93 },
  { month: 'Dec', factor: 0.90 },
];

/**
 * Calculate polygon area using geographic coordinates (Haversine-based)
 * Returns area in square meters
 */
export function calculatePolygonArea(coordinates: [number, number][]): number {
  if (coordinates.length < 3) return 0;

  const earthRadius = 6371000; // meters
  let area = 0;

  for (let i = 0; i < coordinates.length; i++) {
    const j = (i + 1) % coordinates.length;
    const lat1 = (coordinates[i][0] * Math.PI) / 180;
    const lat2 = (coordinates[j][0] * Math.PI) / 180;
    const deltaLng =
      ((coordinates[j][1] - coordinates[i][1]) * Math.PI) / 180;

    area +=
      deltaLng *
      (2 + Math.sin(lat1) + Math.sin(lat2));
  }

  area = Math.abs((area * earthRadius * earthRadius) / 2);
  return area;
}

/**
 * Convert square meters to square feet
 */
export function sqmToSqft(sqm: number): number {
  return sqm * 10.7639;
}

/**
 * Convert square feet to square meters
 */
export function sqftToSqm(sqft: number): number {
  return sqft / 10.7639;
}

/**
 * Calculate roof polygon with area
 */
export function createRoofPolygon(
  id: string,
  name: string,
  coordinates: [number, number][],
  usablePercent: number = DEFAULT_ASSUMPTIONS.usable_roof_percent
): RoofPolygon {
  const area_sqm = calculatePolygonArea(coordinates);
  const area_sqft = sqmToSqft(area_sqm);
  const usable_area_sqm = area_sqm * (usablePercent / 100);

  return {
    id,
    name,
    coordinates,
    area_sqm,
    area_sqft,
    usable_percent: usablePercent,
    usable_area_sqm,
    color: '#06b6d4',
  };
}

/**
 * Calculate recommended solar system based on roof area and consumption
 */
export function calculateRecommendedSystem(
  usable_roof_area_sqm: number,
  monthly_consumption_kwh: number,
  assumptions: SolarAssumptions = DEFAULT_ASSUMPTIONS
): SolarSystem {
  const { panel, performance_ratio, solar_irradiance_kwh_per_m2_per_day, installation_cost_per_kw, tariff_per_kwh, emissions_factor_kg_per_kwh } = assumptions;

  // Calculate maximum system size based on roof area
  const panels_per_sqm = 1 / panel.area_sqm;
  const max_panels = Math.floor(usable_roof_area_sqm * panels_per_sqm);
  const max_system_kw = (max_panels * panel.capacity_w) / 1000;

  // Calculate system size based on consumption
  const daily_consumption_kwh = monthly_consumption_kwh / 30;
  const daily_generation_per_kw = solar_irradiance_kwh_per_m2_per_day * performance_ratio;
  const required_system_kw = daily_consumption_kwh / daily_generation_per_kw;

  // Use the smaller of the two (roof-limited or consumption-limited)
  const system_kw = Math.min(max_system_kw, required_system_kw);
  const panel_count = Math.floor((system_kw * 1000) / panel.capacity_w);
  const actual_system_kw = (panel_count * panel.capacity_w) / 1000;

  // Calculate generation
  const daily_generation_kwh = actual_system_kw * daily_generation_per_kw;
  const monthly_generation_kwh = daily_generation_kwh * 30;
  const annual_generation_kwh = daily_generation_kwh * 365;

  // Calculate costs and savings
  const estimated_cost = actual_system_kw * installation_cost_per_kw;
  const annual_savings = annual_generation_kwh * tariff_per_kwh;
  const monthly_savings = annual_savings / 12;
  const payback_years = estimated_cost / annual_savings;

  // Calculate energy coverage
  const energy_coverage_percent = monthly_consumption_kwh > 0
    ? (monthly_generation_kwh / monthly_consumption_kwh) * 100
    : 0;

  // Calculate CO2 reduction
  const annual_co2_reduction_kg = annual_generation_kwh * emissions_factor_kg_per_kwh;
  const lifetime_co2_reduction_kg = annual_co2_reduction_kg * 25; // 25-year lifetime

  // Calculate required roof area
  const required_roof_area_sqm = panel_count * panel.area_sqm;
  const required_roof_area_sqft = sqmToSqft(required_roof_area_sqm);

  return {
    capacity_kw: actual_system_kw,
    panel_count,
    panel_capacity_w: panel.capacity_w,
    required_roof_area_sqm,
    required_roof_area_sqft,
    estimated_cost,
    annual_generation_kwh,
    monthly_generation_kwh,
    daily_generation_kwh,
    energy_coverage_percent: Math.min(energy_coverage_percent, 100),
    annual_savings,
    monthly_savings,
    payback_years,
    annual_co2_reduction_kg,
    lifetime_co2_reduction_kg,
  };
}

/**
 * Calculate monthly generation breakdown
 */
export function calculateMonthlyGeneration(
  system: SolarSystem,
  assumptions: SolarAssumptions = DEFAULT_ASSUMPTIONS
): MonthlyGeneration[] {
  return MONTHLY_FACTORS.map(({ month, factor }) => ({
    month,
    generation_kwh: system.monthly_generation_kwh * factor,
    factor,
  }));
}

/**
 * Calculate system size comparison
 */
export function calculateSystemComparison(
  size_kw: number,
  monthly_consumption_kwh: number,
  assumptions: SolarAssumptions = DEFAULT_ASSUMPTIONS
): SystemComparison {
  const { panel, performance_ratio, solar_irradiance_kwh_per_m2_per_day, installation_cost_per_kw, tariff_per_kwh, emissions_factor_kg_per_kwh } = assumptions;

  const panel_count = Math.floor((size_kw * 1000) / panel.capacity_w);
  const actual_system_kw = (panel_count * panel.capacity_w) / 1000;

  const daily_generation_per_kw = solar_irradiance_kwh_per_m2_per_day * performance_ratio;
  const daily_generation_kwh = actual_system_kw * daily_generation_per_kw;
  const monthly_generation_kwh = daily_generation_kwh * 30;
  const annual_generation_kwh = daily_generation_kwh * 365;

  const estimated_cost = actual_system_kw * installation_cost_per_kw;
  const annual_savings = annual_generation_kwh * tariff_per_kwh;
  const payback_years = estimated_cost / annual_savings;

  const energy_coverage_percent = monthly_consumption_kwh > 0
    ? (monthly_generation_kwh / monthly_consumption_kwh) * 100
    : 0;

  const annual_co2_reduction_kg = annual_generation_kwh * emissions_factor_kg_per_kwh;

  const required_roof_area_sqm = panel_count * panel.area_sqm;
  const required_roof_area_sqft = sqmToSqft(required_roof_area_sqm);

  return {
    system: {
      capacity_kw: actual_system_kw,
      panel_count,
      panel_capacity_w: panel.capacity_w,
      required_roof_area_sqm,
      required_roof_area_sqft,
      estimated_cost,
      annual_generation_kwh,
      monthly_generation_kwh,
      daily_generation_kwh,
      energy_coverage_percent: Math.min(energy_coverage_percent, 100),
      annual_savings,
      monthly_savings: annual_savings / 12,
      payback_years,
      annual_co2_reduction_kg,
      lifetime_co2_reduction_kg: annual_co2_reduction_kg * 25,
    },
    size_label: `${size_kw} kW`,
  };
}

/**
 * Calculate battery option
 */
export function calculateBatteryOption(
  system: SolarSystem,
  monthly_consumption_kwh: number,
  battery_capacity_kwh: number = 10,
  battery_power_kw: number = 5
): BatteryOption {
  const battery_cost = battery_capacity_kwh * 25000; // Rs/kWh
  const backup_hours = battery_capacity_kwh / (monthly_consumption_kwh / 30 / 24);
  const self_consumption_increase = 15; // Typical increase with battery

  return {
    capacity_kwh: battery_capacity_kwh,
    power_kw: battery_power_kw,
    cost: battery_cost,
    backup_hours,
    self_consumption_increase_percent: self_consumption_increase,
  };
}

/**
 * Estimate monthly consumption from bill
 */
export function estimateConsumptionFromBill(
  monthly_bill: number,
  tariff_per_kwh: number = DEFAULT_ASSUMPTIONS.tariff_per_kwh
): number {
  return monthly_bill / tariff_per_kwh;
}

/**
 * Format currency in Indian Rupees
 */
export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Format number with units
 */
export function formatNumber(value: number, decimals: number = 1): string {
  return value.toFixed(decimals);
}

/**
 * Get solar irradiance for location (simplified model)
 * In production, this would use actual solar resource data
 */
export function getSolarIrradiance(latitude: number, longitude: number): number {
  // Simplified model based on latitude
  // Bengaluru (12.97°N) gets about 5.2 kWh/m²/day average
  const baseIrradiance = 5.5;
  const latitudeFactor = 1 - Math.abs(latitude - 12.97) * 0.01;
  return baseIrradiance * Math.max(0.7, latitudeFactor);
}
