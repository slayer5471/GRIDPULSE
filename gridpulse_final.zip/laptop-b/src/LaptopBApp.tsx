// LAPTOP B - Control Center & Solarex (Engineering Control Center)
// This is a completely independent application focused on monitoring and control
import { useState, useEffect } from 'react';
import { useWebSocket, ConnectionStatus } from './hooks/useWebSocket';
import { api, TelemetryState } from './services/api';
import { generateDemoTelemetry } from './services/demoTelemetry';
import ControlCenter from './components/ControlCenter';
import LoginScreen from './components/LoginScreen';
import ConnectionBanner from './components/ConnectionBanner';

// Backend versions can evolve independently of the dashboard. Normalize partial
// telemetry against the deterministic demo shape so one missing optional field
// can never blank the whole operator screen.
function normalizeTelemetry(raw: TelemetryState): TelemetryState {
  const fallback = generateDemoTelemetry();
  const merge = (base: any, value: any): any => {
    if (Array.isArray(base)) return Array.isArray(value) ? value : base;
    if (base && typeof base === 'object') {
      const out: any = { ...base };
      if (value && typeof value === 'object') for (const key of Object.keys(value)) out[key] = merge(base[key], value[key]);
      return out;
    }
    return value ?? base;
  };
  return merge(fallback, raw) as TelemetryState;
}

export default function LaptopBApp() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [userRole, setUserRole] = useState<string>('VIEWER');
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [initialState, setInitialState] = useState<TelemetryState | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  
  // Only use WebSocket if authenticated and not in demo mode
  const shouldConnect = isAuthenticated && !isDemoMode;
  const { state: wsState, status, lastUpdate, reconnect } = useWebSocket(shouldConnect);
  
  // Demo mode state
  const [demoState, setDemoState] = useState<TelemetryState | null>(null);
  
  // Handle demo mode telemetry
  useEffect(() => {
    if (isDemoMode && isAuthenticated) {
      setDemoState(generateDemoTelemetry());
      const interval = setInterval(() => {
        setDemoState(generateDemoTelemetry());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isDemoMode, isAuthenticated]);
  
  // Use demo state, WebSocket state, or initial state
  const rawState = isDemoMode ? demoState : (wsState || initialState);
  const state = rawState ? normalizeTelemetry(rawState) : null;

  const handleLogin = async (username: string, password: string) => {
    try {
      setConnectionError(null);
      const response = await api.login(username, password);
      setIsAuthenticated(true);
      setIsDemoMode(false);
      setUserRole(response.role);
      localStorage.setItem('gridpulse_role', response.role);
      localStorage.removeItem('gridpulse_demo');
      
      // Fetch initial state immediately after authentication
      try {
        const state = await api.getState();
        setInitialState(state);
      } catch (error) {
        console.error('Failed to fetch initial state:', error);
        setConnectionError('Failed to fetch initial state from backend');
      }
    } catch (error: any) {
      setConnectionError(error.message || 'Login failed');
      throw error;
    }
  };

  const handleDemoLogin = () => {
    // Demo mode - explicit user choice, no backend authentication required
    setIsAuthenticated(true);
    setIsDemoMode(true);
    setUserRole('ADMIN');
    localStorage.setItem('gridpulse_role', 'ADMIN');
    localStorage.setItem('gridpulse_demo', 'true');
    setConnectionError(null);
  };

  const handleLogout = () => {
    api.clearToken();
    setIsAuthenticated(false);
    setIsDemoMode(false);
    setUserRole('VIEWER');
    setInitialState(null);
    setDemoState(null);
    setConnectionError(null);
    localStorage.removeItem('gridpulse_role');
    localStorage.removeItem('gridpulse_demo');
  };

  // Check for existing session on mount
  useEffect(() => {
    const token = localStorage.getItem('gridpulse_token');
    const demoMode = localStorage.getItem('gridpulse_demo') === 'true';
    const role = localStorage.getItem('gridpulse_role') || 'VIEWER';
    
    if (token && !demoMode) {
      // Try to restore session with token
      setIsAuthenticated(true);
      setUserRole(role);
      // Fetch initial state
      api.getState()
        .then(state => {
          setInitialState(state);
          setConnectionError(null);
        })
        .catch(error => {
          console.error('Failed to restore session:', error);
          setConnectionError('Session expired. Please login again.');
          handleLogout();
        });
    } else if (demoMode) {
      // Restore demo mode session
      setIsAuthenticated(true);
      setIsDemoMode(true);
      setUserRole(role);
    }
  }, []);

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} onDemoLogin={handleDemoLogin} />;
  }

  if (!state) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600 mx-auto mb-4"></div>
          <p className="text-slate-600 mb-2">
            {isDemoMode ? 'Starting demo mode...' : 'Connecting to GRIDPULSE...'}
          </p>
          {connectionError && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">{connectionError}</p>
              <button
                onClick={handleLogout}
                className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
              >
                Return to Login
              </button>
            </div>
          )}
          {!isDemoMode && !connectionError && (
            <div className="mt-4 space-y-2">
              <p className="text-xs text-slate-500">
                If connection takes too long, you can use demo mode:
              </p>
              <button
                onClick={handleDemoLogin}
                className="px-4 py-2 bg-slate-600 text-white rounded-lg text-sm hover:bg-slate-700"
              >
                Use Demo Mode Instead
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      {status !== 'LIVE' && !isDemoMode && (
        <ConnectionBanner status={status} onReconnect={reconnect} />
      )}
      {isDemoMode && (
        <ConnectionBanner status="DEMO" onReconnect={() => {}} />
      )}
      <ControlCenter
        state={state}
        status={isDemoMode ? 'DEMO' : status}
        userRole={userRole}
        onLogout={handleLogout}
      />
    </div>
  );
}
