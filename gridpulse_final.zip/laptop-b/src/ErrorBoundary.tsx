import React from 'react';

type Props = { children: React.ReactNode };
type State = { error: Error | null };

export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[GRIDPULSE] React render error:', error, info);
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div style={{minHeight:'100vh',display:'grid',placeItems:'center',background:'#f8fafc',fontFamily:'Inter,system-ui,sans-serif',padding:24}}>
        <div style={{maxWidth:720,width:'100%',background:'#fff',border:'1px solid #fecaca',borderRadius:18,padding:24,boxShadow:'0 20px 60px rgba(15,23,42,.10)'}}>
          <div style={{fontSize:12,fontWeight:800,letterSpacing:'.12em',textTransform:'uppercase',color:'#dc2626'}}>GRIDPULSE UI ERROR</div>
          <h1 style={{margin:'8px 0',fontSize:22,color:'#0f172a'}}>The dashboard hit a frontend error.</h1>
          <pre style={{whiteSpace:'pre-wrap',background:'#f8fafc',padding:14,borderRadius:12,color:'#475569',fontSize:12,overflow:'auto'}}>{this.state.error.message}</pre>
          <div style={{display:'flex',gap:10,marginTop:14}}>
            <button onClick={()=>location.reload()} style={{border:0,borderRadius:10,padding:'10px 14px',background:'#0f172a',color:'#fff',cursor:'pointer'}}>Reload</button>
            <button onClick={()=>{localStorage.removeItem('gridpulse_token');localStorage.removeItem('gridpulse_role');localStorage.removeItem('gridpulse_demo');location.reload()}} style={{border:'1px solid #cbd5e1',borderRadius:10,padding:'10px 14px',background:'#fff',color:'#334155',cursor:'pointer'}}>Clear session & reload</button>
          </div>
        </div>
      </div>
    );
  }
}
