// Solarex Types - Solar assessment and planning

export interface SolarexLocation {
  id: string;
  label: string;
  address: string;
  latitude: number;
  longitude: number;
  city?: string;
  state?: string;
  country?: string;
}

export interface RoofPolygon {
  id: string;
  name: string;
  coordinates: [number, number][]; // [lat, lng] pairs
  area_sqm: number;
  area_sqft: number;
  usable_percent: number;
  usable_area_sqm: number;
  color: string;
}

export interface ExclusionPolygon {
  id: string;
  name: string;
  coordinates: [number, number][];
  area_sqm: number;
  area_sqft: number;
  reason: string;
}

export interface PanelAssumption {
  capacity_w: number;
  efficiency: number;
  area_sqm: number;
  cost_per_panel: number;
}

export interface SolarAssumptions {
  panel: PanelAssumption;
  system_loss_percent: number;
  performance_ratio: number;
  degradation_percent_per_year: number;
  installation_cost_per_kw: number;
  tariff_per_kwh: number;
  export_tariff_per_kwh: number;
  emissions_factor_kg_per_kwh: number;
  usable_roof_percent: number;
  solar_irradiance_kwh_per_m2_per_day: number;
}

export interface SolarSystem {
  capacity_kw: number;
  panel_count: number;
  panel_capacity_w: number;
  required_roof_area_sqm: number;
  required_roof_area_sqft: number;
  estimated_cost: number;
  annual_generation_kwh: number;
  monthly_generation_kwh: number;
  daily_generation_kwh: number;
  energy_coverage_percent: number;
  annual_savings: number;
  monthly_savings: number;
  payback_years: number;
  annual_co2_reduction_kg: number;
  lifetime_co2_reduction_kg: number;
}

export interface MonthlyGeneration {
  month: string;
  generation_kwh: number;
  factor: number; // seasonal factor
}

export interface SystemComparison {
  system: SolarSystem;
  size_label: string;
}

export interface BatteryOption {
  capacity_kwh: number;
  power_kw: number;
  cost: number;
  backup_hours: number;
  self_consumption_increase_percent: number;
}

export interface SolarexProject {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
  location: SolarexLocation;
  roof_polygons: RoofPolygon[];
  exclusion_polygons: ExclusionPolygon[];
  total_roof_area_sqm: number;
  usable_roof_area_sqm: number;
  monthly_bill: number;
  monthly_consumption_kwh: number;
  tariff_per_kwh: number;
  assumptions: SolarAssumptions;
  recommended_system: SolarSystem;
  selected_system_size_kw: number;
  battery_option: BatteryOption | null;
  monthly_generation: MonthlyGeneration[];
  comparisons: SystemComparison[];
}

export interface SolarexMapState {
  center: [number, number];
  zoom: number;
  location: SolarexLocation | null;
  roof_polygons: RoofPolygon[];
  exclusion_polygons: ExclusionPolygon[];
  is_drawing: boolean;
  map_type: 'standard' | 'satellite' | 'hybrid';
}
