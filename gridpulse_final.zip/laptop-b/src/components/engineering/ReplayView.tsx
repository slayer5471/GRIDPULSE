import { TelemetryState } from '../../services/api';

interface ReplayViewProps {
  state: TelemetryState;
}

export default function ReplayView({ state }: ReplayViewProps) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Historical Replay</h2>
      
      <div className="bg-slate-50 rounded-lg p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-sm font-medium text-slate-700 mb-2">Time Travel & Replay</h3>
        <p className="text-xs text-slate-500 mb-4">
          Rewind, play, pause, and jump to specific events in historical data
        </p>
        <div className="text-xs text-slate-600 space-y-1">
          <div>• Play/Pause historical telemetry</div>
          <div>• Rewind and fast forward</div>
          <div>• Jump to specific events</div>
          <div>• Inspect network state at any time</div>
        </div>
        <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
          <p className="text-xs text-blue-700">
            <strong>Note:</strong> Replay functionality requires historical data storage from Laptop A backend.
          </p>
        </div>
      </div>
    </div>
  );
}
