import { TelemetryState } from '../../services/api';
import { useState } from 'react';

interface DigitalTwinProps {
  state: TelemetryState;
  selectedAsset: string | null;
  onAssetSelect: (id: string) => void;
}

export default function DigitalTwin({ state, selectedAsset, onAssetSelect }: DigitalTwinProps) {
  const [viewMode, setViewMode] = useState<'operational' | 'health' | 'energy'>('operational');

  const totalSolar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const totalLoad = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;
  const renewableShare = totalLoad > 0 ? (Math.min(totalSolar, totalLoad) / totalLoad) * 100 : 0;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-900">Physical Digital Twin</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode('operational')}
            className={`px-3 py-1.5 text-xs rounded ${
              viewMode === 'operational' ? 'bg-cyan-100 text-cyan-700' : 'bg-slate-100 text-slate-600'
            }`}
          >
            Operational
          </button>
          <button
            onClick={() => setViewMode('health')}
            className={`px-3 py-1.5 text-xs rounded ${
              viewMode === 'health' ? 'bg-cyan-100 text-cyan-700' : 'bg-slate-100 text-slate-600'
            }`}
          >
            Health
          </button>
          <button
            onClick={() => setViewMode('energy')}
            className={`px-3 py-1.5 text-xs rounded ${
              viewMode === 'energy' ? 'bg-cyan-100 text-cyan-700' : 'bg-slate-100 text-slate-600'
            }`}
          >
            Energy Flow
          </button>
        </div>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-4 gap-3 mb-4">
        <div className="bg-emerald-50 rounded p-3 border border-emerald-200">
          <div className="text-[10px] text-emerald-700 uppercase">Renewable Share</div>
          <div className="text-lg font-bold text-emerald-900">{renewableShare.toFixed(0)}%</div>
        </div>
        <div className="bg-blue-50 rounded p-3 border border-blue-200">
          <div className="text-[10px] text-blue-700 uppercase">System Health</div>
          <div className="text-lg font-bold text-blue-900">
            {state.transformer.health === 'HEALTHY' ? 'Good' : 'Warning'}
          </div>
        </div>
        <div className="bg-purple-50 rounded p-3 border border-purple-200">
          <div className="text-[10px] text-purple-700 uppercase">Battery Status</div>
          <div className="text-lg font-bold text-purple-900">{state.battery.state}</div>
        </div>
        <div className="bg-amber-50 rounded p-3 border border-amber-200">
          <div className="text-[10px] text-amber-700 uppercase">Active Alarms</div>
          <div className="text-lg font-bold text-amber-900">{state.alarms.length}</div>
        </div>
      </div>

      {/* Isometric Community View */}
      <div className="bg-gradient-to-br from-sky-50 via-emerald-50 to-amber-50 rounded-lg border border-slate-200 overflow-hidden" style={{ height: '500px' }}>
        <svg width="100%" height="100%" viewBox="0 0 1000 500">
          {/* Ground */}
          <rect x="0" y="0" width="1000" height="500" fill="#f0fdf4"/>
          
          {/* Roads */}
          <rect x="0" y="240" width="1000" height="20" fill="#cbd5e1"/>
          <rect x="480" y="0" width="20" height="500" fill="#cbd5e1"/>
          
          {/* Grid Connection (Left) */}
          <g onClick={() => onAssetSelect('GRID-01')} className="cursor-pointer">
            <rect x="30" y="100" width="80" height="100" fill="#dbeafe" stroke="#2563eb" strokeWidth="2" rx="4"/>
            <text x="70" y="130" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#1e40af">GRID</text>
            <text x="70" y="150" textAnchor="middle" fontSize="10" fill="#3b82f6">11 kV</text>
            <text x="70" y="170" textAnchor="middle" fontSize="9" fill={state.grid.import_kw > 0 ? '#f59e0b' : '#10b981'}>
              {state.grid.import_kw > 0 ? `IMP ${state.grid.import_kw.toFixed(0)}kW` : `EXP ${state.grid.export_kw.toFixed(0)}kW`}
            </text>
            {selectedAsset === 'GRID-01' && <rect x="28" y="98" width="84" height="104" fill="none" stroke="#06b6d4" strokeWidth="3" rx="4"/>}
          </g>

          {/* Transformer Substation */}
          <g onClick={() => onAssetSelect('TX-01')} className="cursor-pointer">
            <rect x="150" y="80" width="100" height="120" fill="#fef3c7" stroke="#d97706" strokeWidth="2" rx="4"/>
            <text x="200" y="110" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#92400e">TRANSFORMER</text>
            <text x="200" y="130" textAnchor="middle" fontSize="10" fill="#d97706">TX-01</text>
            <text x="200" y="150" textAnchor="middle" fontSize="9" fill="#92400e">{state.transformer.rating_kva} kVA</text>
            <text x="200" y="170" textAnchor="middle" fontSize="9" fill={state.transformer.loading_percent > 80 ? '#dc2626' : '#16a34a'}>
              {state.transformer.loading_percent.toFixed(0)}% loaded
            </text>
            <text x="200" y="185" textAnchor="middle" fontSize="8" fill="#92400e">{state.transformer.temperature_c.toFixed(0)}°C</text>
            {selectedAsset === 'TX-01' && <rect x="148" y="78" width="104" height="124" fill="none" stroke="#06b6d4" strokeWidth="3" rx="4"/>}
          </g>

          {/* Connection Lines */}
          <line x1="110" y1="150" x2="150" y2="140" stroke="#64748b" strokeWidth="2"/>
          <line x1="250" y1="140" x2="300" y2="140" stroke="#64748b" strokeWidth="2"/>

          {/* Houses Row 1 */}
          {state.houses.slice(0, 3).map((house, idx) => (
            <g key={house.id} onClick={() => onAssetSelect(house.id)} className="cursor-pointer">
              <rect x={300 + idx * 100} y="100" width="70" height="60" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" rx="3"/>
              <polygon points={`${300 + idx * 100 + 35},80 ${300 + idx * 100},100 ${300 + idx * 100 + 70},100`} fill="#fbbf24" stroke="#d97706" strokeWidth="1.5"/>
              <text x={300 + idx * 100 + 35} y="125" textAnchor="middle" fontSize="9" fontWeight="bold" fill="#92400e">{house.id}</text>
              <text x={300 + idx * 100 + 35} y="140" textAnchor="middle" fontSize="8" fill="#d97706">{house.load_kw.toFixed(1)}kW</text>
              <text x={300 + idx * 100 + 35} y="152" textAnchor="middle" fontSize="7" fill="#16a34a">PV:{house.pv_kw.toFixed(1)}kW</text>
              {selectedAsset === house.id && <rect x={298 + idx * 100} y="78" width="74" height="84" fill="none" stroke="#06b6d4" strokeWidth="3" rx="3"/>}
            </g>
          ))}

          {/* Houses Row 2 */}
          {state.houses.slice(3, 5).map((house, idx) => (
            <g key={house.id} onClick={() => onAssetSelect(house.id)} className="cursor-pointer">
              <rect x={300 + idx * 100} y="280" width="70" height="60" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" rx="3"/>
              <polygon points={`${300 + idx * 100 + 35},260 ${300 + idx * 100},280 ${300 + idx * 100 + 70},280`} fill="#fbbf24" stroke="#d97706" strokeWidth="1.5"/>
              <text x={300 + idx * 100 + 35} y="305" textAnchor="middle" fontSize="9" fontWeight="bold" fill="#92400e">{house.id}</text>
              <text x={300 + idx * 100 + 35} y="320" textAnchor="middle" fontSize="8" fill="#d97706">{house.load_kw.toFixed(1)}kW</text>
              <text x={300 + idx * 100 + 35} y="332" textAnchor="middle" fontSize="7" fill="#16a34a">PV:{house.pv_kw.toFixed(1)}kW</text>
              {selectedAsset === house.id && <rect x={298 + idx * 100} y="258" width="74" height="84" fill="none" stroke="#06b6d4" strokeWidth="3" rx="3"/>}
            </g>
          ))}

          {/* Community Building */}
          <g onClick={() => onAssetSelect('COMMUNITY-01')} className="cursor-pointer">
            <rect x="600" y="80" width="120" height="100" fill="#fef3c7" stroke="#d97706" strokeWidth="2" rx="4"/>
            <text x="660" y="110" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#92400e">COMMUNITY</text>
            <text x="660" y="130" textAnchor="middle" fontSize="10" fill="#d97706">Building</text>
            <text x="660" y="150" textAnchor="middle" fontSize="9" fill="#92400e">{state.community.load_kw.toFixed(1)} kW</text>
            <text x="660" y="165" textAnchor="middle" fontSize="8" fill="#16a34a">PV: {state.community.pv_kw.toFixed(1)} kW</text>
            {selectedAsset === 'COMMUNITY-01' && <rect x="598" y="78" width="124" height="104" fill="none" stroke="#06b6d4" strokeWidth="3" rx="4"/>}
          </g>

          {/* BESS Container */}
          <g onClick={() => onAssetSelect('BESS-01')} className="cursor-pointer">
            <rect x="750" y="100" width="100" height="80" fill="#f3e8ff" stroke="#9333ea" strokeWidth="2" rx="4"/>
            <text x="800" y="125" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#6b21a8">BESS</text>
            <text x="800" y="145" textAnchor="middle" fontSize="10" fill="#7c3aed">{state.battery.capacity_kwh} kWh</text>
            <text x="800" y="160" textAnchor="middle" fontSize="9" fill="#9333ea">{state.battery.soc_percent.toFixed(0)}% SOC</text>
            <text x="800" y="175" textAnchor="middle" fontSize="8" fill={state.battery.power_kw > 0 ? '#16a34a' : '#dc2626'}>
              {state.battery.power_kw > 0 ? 'CHARGING' : 'DISCHARGING'}
            </text>
            {selectedAsset === 'BESS-01' && <rect x="748" y="98" width="104" height="84" fill="none" stroke="#06b6d4" strokeWidth="3" rx="4"/>}
          </g>

          {/* PCS */}
          <g onClick={() => onAssetSelect('PCS-01')} className="cursor-pointer">
            <rect x="750" y="200" width="100" height="60" fill="#fce7f3" stroke="#db2777" strokeWidth="2" rx="4"/>
            <text x="800" y="225" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#9d174d">PCS</text>
            <text x="800" y="245" textAnchor="middle" fontSize="9" fill="#be185d">{state.pcs.power_kw.toFixed(1)} kW</text>
            {selectedAsset === 'PCS-01' && <rect x="748" y="198" width="104" height="64" fill="none" stroke="#06b6d4" strokeWidth="3" rx="4"/>}
          </g>

          {/* PV Array (on community roof) */}
          <g onClick={() => onAssetSelect('PV-01')} className="cursor-pointer">
            <rect x="610" y="60" width="100" height="15" fill="#fef9c3" stroke="#eab308" strokeWidth="1.5"/>
            <text x="660" y="72" textAnchor="middle" fontSize="8" fontWeight="bold" fill="#854d0e">PV {totalSolar.toFixed(0)}kW</text>
            {selectedAsset === 'PV-01' && <rect x="608" y="58" width="104" height="19" fill="none" stroke="#06b6d4" strokeWidth="3"/>}
          </g>

          {/* Energy Flow Lines (when in energy view) */}
          {viewMode === 'energy' && (
            <>
              {/* Solar to loads */}
              {totalSolar > 0 && (
                <line x1="660" y1="75" x2="400" y2="130" stroke="#eab308" strokeWidth="2" strokeDasharray="5,5" opacity="0.6">
                  <animate attributeName="stroke-dashoffset" from="0" to="10" dur="1s" repeatCount="indefinite"/>
                </line>
              )}
              {/* Grid to transformer */}
              {state.grid.import_kw > 0 && (
                <line x1="110" y1="150" x2="150" y2="140" stroke="#f59e0b" strokeWidth="3" opacity="0.7">
                  <animate attributeName="stroke-dashoffset" from="0" to="10" dur="1s" repeatCount="indefinite"/>
                </line>
              )}
              {/* Battery flow */}
              {state.battery.power_kw !== 0 && (
                <line x1="800" y1="180" x2="660" y2="180" stroke="#9333ea" strokeWidth="2" strokeDasharray="5,5" opacity="0.6">
                  <animate attributeName="stroke-dashoffset" from={state.battery.power_kw > 0 ? "0" : "10"} to={state.battery.power_kw > 0 ? "10" : "0"} dur="1s" repeatCount="indefinite"/>
                </line>
              )}
            </>
          )}

          {/* Health indicators (when in health view) */}
          {viewMode === 'health' && (
            <>
              <circle cx="200" cy="90" r="8" fill={state.transformer.health === 'HEALTHY' ? '#10b981' : '#f59e0b'}/>
              <circle cx="800" cy="110" r="8" fill={state.battery.soc_percent > 20 ? '#10b981' : '#f59e0b'}/>
              <circle cx="660" cy="90" r="8" fill="#10b981"/>
            </>
          )}
        </svg>
      </div>

      {/* Asset Details Panel */}
      {selectedAsset && (
        <div className="mt-4 bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Selected Asset: {selectedAsset}</h3>
            <div className="flex gap-2">
              <button 
                onClick={() => onAssetSelect(selectedAsset)}
                className="px-3 py-1 text-xs bg-cyan-100 text-cyan-700 rounded hover:bg-cyan-200"
              >
                View in Engineering
              </button>
              <button 
                onClick={() => onAssetSelect(selectedAsset)}
                className="px-3 py-1 text-xs bg-emerald-100 text-emerald-700 rounded hover:bg-emerald-200"
              >
                Analyze
              </button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <div className="text-slate-600">Status</div>
              <div className="font-bold text-slate-900">
                {selectedAsset === 'TX-01' ? state.transformer.health :
                 selectedAsset === 'BESS-01' ? state.battery.state :
                 selectedAsset === 'PCS-01' ? (state.pcs.enabled ? 'ONLINE' : 'OFFLINE') :
                 'ONLINE'}
              </div>
            </div>
            <div>
              <div className="text-slate-600">Power</div>
              <div className="font-bold text-slate-900">
                {selectedAsset === 'TX-01' ? `${(state.transformer.loading_percent / 100 * state.transformer.rating_kva).toFixed(1)} kW` :
                 selectedAsset === 'BESS-01' ? `${state.battery.power_kw.toFixed(1)} kW` :
                 selectedAsset === 'PCS-01' ? `${state.pcs.power_kw.toFixed(1)} kW` :
                 state.houses.find(h => h.id === selectedAsset)?.load_kw.toFixed(1) + ' kW' || 'N/A'}
              </div>
            </div>
            <div>
              <div className="text-slate-600">Health</div>
              <div className="font-bold text-emerald-600">Good</div>
            </div>
          </div>
        </div>
      )}

      {/* Asset Mapping */}
      <div className="mt-6">
        <h3 className="text-sm font-medium text-slate-700 mb-3">Physical Assets</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {state.houses.map((house: any) => (
            <button
              key={house.id}
              onClick={() => onAssetSelect(house.id)}
              className={`px-3 py-2 text-xs rounded border transition-colors ${
                selectedAsset === house.id
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              🏠 {house.id}
            </button>
          ))}
          <button
            onClick={() => onAssetSelect('COMMUNITY-01')}
            className={`px-3 py-2 text-xs rounded border transition-colors ${
              selectedAsset === 'COMMUNITY-01'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            🏢 Community
          </button>
          <button
            onClick={() => onAssetSelect('TX-01')}
            className={`px-3 py-2 text-xs rounded border transition-colors ${
              selectedAsset === 'TX-01'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            ⚡ Transformer
          </button>
          <button
            onClick={() => onAssetSelect('BESS-01')}
            className={`px-3 py-2 text-xs rounded border transition-colors ${
              selectedAsset === 'BESS-01'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            🔋 BESS
          </button>
        </div>
      </div>
    </div>
  );
}
