import { ArrowDown, ArrowRight, BatteryCharging, BatteryMedium, Gauge, Zap, Radio } from 'lucide-react';
import { TelemetryState } from '../../services/api';

export default function BESSFlowPanel({ state }: { state: TelemetryState }) {
  const battery = state.battery;
  const power = battery.power_kw;
  const stored = battery.stored_energy_kwh ?? ((battery.capacity_kwh * battery.soc_percent) / 100);
  const discharging = power > 0.2;
  const charging = power < -0.2;
  const solar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const load = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;
  const solarSurplus = Math.max(0, solar - load);
  const localSupport = discharging ? Math.min(power, Math.max(0, load - solar)) : 0;
  const gridExport = discharging ? Math.max(0, power - localSupport) : 0;
  const solarCharge = charging ? Math.min(-power, solarSurplus) : 0;
  const gridCharge = charging ? Math.max(0, -power - solarCharge) : 0;
  const pwmDuty = Math.max(0, Math.min(1, state.pcs.duty_cycle || 0));
  const pwmFreq = state.pcs.pwm_frequency_hz || 10000;
  const periodMs = state.pcs.carrier_period_ms ?? (1000 / pwmFreq);
  const onMs = state.pcs.pulse_on_ms ?? periodMs * pwmDuty;
  const offMs = state.pcs.pulse_off_ms ?? periodMs - onMs;
  const pulseEnergy = state.pcs.pulse_energy_wh ?? 0;
  const waveform = state.pcs.waveform?.length ? state.pcs.waveform : Array.from({ length: 20 }, (_, i) => (i / 20 < pwmDuty ? 1 : 0));

  return (
    <aside className="bg-white border border-slate-200 rounded-xl shadow-sm p-4 space-y-4 h-full">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-purple-500 font-semibold">BESS ENERGY PATH</div>
          <h3 className="text-lg font-bold text-slate-900">{battery.id}</h3>
        </div>
        <div className="rounded-xl bg-purple-50 p-2 text-purple-600"><BatteryMedium size={22} /></div>
      </div>

      <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs text-slate-500">Stored energy</span>
          <span className="text-sm font-bold text-purple-700">{stored.toFixed(1)} kWh</span>
        </div>
        <div className="h-3 rounded-full bg-slate-200 overflow-hidden">
          <div className="h-full bg-purple-600 transition-all duration-500" style={{ width: `${Math.max(0, Math.min(100, battery.soc_percent))}%` }} />
        </div>
        <div className="flex justify-between mt-1 text-[10px] text-slate-400">
          <span>{battery.min_soc.toFixed(0)}% min</span>
          <span>{battery.soc_percent.toFixed(1)}% SOC</span>
          <span>{battery.max_soc.toFixed(0)}% max</span>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 p-3">
        <div className="text-[10px] uppercase tracking-wide text-slate-400 mb-2">Current energy transfer</div>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold text-slate-900">{Math.abs(power).toFixed(1)} kW</div>
            <div className="text-xs font-semibold text-slate-600">{charging ? 'Charging' : discharging ? 'Discharging' : 'Idle'}</div>
          </div>
          <div className={`rounded-full p-3 ${charging ? 'bg-emerald-50 text-emerald-600' : discharging ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500'}`}>
            {charging ? <BatteryCharging size={24} /> : <Zap size={24} />}
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-purple-100 bg-purple-50/40 p-3 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio size={14} className="text-purple-600" />
            <span className="text-[10px] uppercase tracking-widest font-semibold text-purple-700">PWM POWER STAGE</span>
          </div>
          <span className="text-[10px] font-semibold text-purple-700">{pwmFreq.toLocaleString()} pulses/s</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500">Duty cycle</span>
          <span className="font-bold text-slate-900">{(pwmDuty * 100).toFixed(1)}%</span>
        </div>
        <div className="h-12 flex items-center gap-[2px] bg-slate-900 rounded-lg px-2 overflow-hidden">
          {waveform.map((bit, i) => (
            <div key={i} className={`flex-1 h-8 rounded-sm transition-opacity ${bit ? 'bg-cyan-400 opacity-100 animate-pulse' : 'bg-slate-700 opacity-60'}`} />
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 text-[10px]">
          <Metric label="Period" value={`${periodMs.toFixed(4)} ms`} />
          <Metric label="ON" value={`${onMs.toFixed(4)} ms`} />
          <Metric label="OFF" value={`${offMs.toFixed(4)} ms`} />
        </div>
        <div className="rounded-md bg-white border border-purple-100 p-2 text-[10px] font-mono text-slate-600">
          P<sub>avg</sub> = P<sub>pulse</sub> × duty = {(state.pcs.max_power_kw ?? 100).toFixed(0)} kW × {(pwmDuty * 100).toFixed(1)}% = {Math.abs(state.pcs.average_power_kw ?? state.pcs.power_kw).toFixed(1)} kW
          <br />E<sub>pulse</sub> = P<sub>pulse</sub> × t<sub>ON</sub> ≈ {pulseEnergy.toFixed(6)} Wh
        </div>
        <div className="text-[10px] leading-relaxed text-slate-500">
          The digital twin represents average BESS transfer as a PWM pulse train: longer ON time = higher average power. Each pulse carries approximately <b>{pulseEnergy.toFixed(6)} Wh</b> at the configured converter limit.
        </div>
      </div>

      <div className="space-y-2">
        <FlowBox label={charging ? 'Solar surplus → BESS' : discharging ? 'Stored energy → PCS' : 'BESS waiting'} value={charging ? solarCharge : discharging ? power : 0} icon={<ArrowDown size={14} />} />
        <div className="flex justify-center text-slate-300"><ArrowDown size={18} /></div>
        <FlowBox label="PCS / inverter" value={Math.abs(power)} icon={<Gauge size={14} />} />
        <div className="flex justify-center text-slate-300"><ArrowDown size={18} /></div>
        <div className="grid grid-cols-2 gap-2">
          <FlowBox label={discharging ? 'Local load support' : 'Solar charging'} value={discharging ? localSupport : solarCharge} compact />
          <FlowBox label={discharging ? 'Grid export' : 'Grid charging'} value={discharging ? gridExport : gridCharge} compact />
        </div>
      </div>

      <div className="rounded-xl bg-slate-50 border border-slate-200 p-3 space-y-2">
        <Row label="PCS power" value={`${Math.abs(state.pcs.power_kw).toFixed(1)} kW`} />
        <Row label="Average transfer" value={`${Math.abs(state.pcs.average_power_kw ?? state.pcs.power_kw).toFixed(1)} kW`} />
        <Row label="PWM duty" value={`${(pwmDuty * 100).toFixed(1)}%`} />
        <Row label="Efficiency" value={`${state.pcs.efficiency.toFixed(1)}%`} />
        <Row label="Mode" value={battery.mode.toUpperCase()} />
      </div>

      <div className="pt-1 text-[10px] text-slate-400 leading-relaxed">
        Positive BESS power means stored energy is delivered through the PCS. Negative BESS power means energy is absorbed into storage. PWM here is a simulated converter-level power-transfer abstraction, not transistor-level switching.
      </div>
    </aside>
  );
}

function FlowBox({ label, value, icon, compact = false }: { label: string; value: number; icon?: React.ReactNode; compact?: boolean }) {
  return <div className={`rounded-lg border border-slate-200 bg-white ${compact ? 'p-2' : 'p-3'}`}>
    <div className="flex items-center gap-2 text-[10px] uppercase tracking-wide text-slate-500">{icon}<span>{label}</span></div>
    <div className={`${compact ? 'text-sm' : 'text-base'} font-bold text-slate-900 mt-1`}>{value.toFixed(1)} kW</div>
  </div>;
}
function Metric({label,value}:{label:string;value:string}){return <div className="bg-white rounded-md border border-slate-200 px-2 py-1"><div className="text-slate-400">{label}</div><div className="font-mono font-semibold text-slate-800">{value}</div></div>}
function Row({ label, value }: { label: string; value: string }) { return <div className="flex items-center justify-between text-xs"><span className="text-slate-500">{label}</span><span className="font-mono font-semibold text-slate-800">{value}</span></div>; }
