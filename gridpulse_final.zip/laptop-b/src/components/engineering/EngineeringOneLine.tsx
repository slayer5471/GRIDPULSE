import { TelemetryState } from '../../services/api';
import { useState } from 'react';

interface EngineeringOneLineProps {
  state: TelemetryState;
  selectedAsset: string | null;
  onAssetSelect: (id: string) => void;
  onCommand: (command: string, target: string, value?: any) => void;
  canControl: boolean;
}

export default function EngineeringOneLine({ state, selectedAsset, onAssetSelect, onCommand, canControl }: EngineeringOneLineProps) {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });

  const totalSolar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const totalLoad = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-900">Engineering One-Line Diagram</h2>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}
            className="px-3 py-1 text-xs bg-slate-100 rounded hover:bg-slate-200"
          >
            Zoom Out
          </button>
          <span className="text-xs text-slate-600">{(zoom * 100).toFixed(0)}%</span>
          <button 
            onClick={() => setZoom(z => Math.min(2, z + 0.1))}
            className="px-3 py-1 text-xs bg-slate-100 rounded hover:bg-slate-200"
          >
            Zoom In
          </button>
          <button 
            onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
            className="px-3 py-1 text-xs bg-slate-100 rounded hover:bg-slate-200"
          >
            Fit
          </button>
        </div>
      </div>

      {/* Power Flow Summary */}
      <div className="grid grid-cols-4 gap-3 mb-4">
        <div className="bg-emerald-50 rounded p-3 border border-emerald-200">
          <div className="text-[10px] text-emerald-700 uppercase">Solar Generation</div>
          <div className="text-lg font-bold text-emerald-900">{totalSolar.toFixed(1)} kW</div>
        </div>
        <div className="bg-blue-50 rounded p-3 border border-blue-200">
          <div className="text-[10px] text-blue-700 uppercase">Total Load</div>
          <div className="text-lg font-bold text-blue-900">{totalLoad.toFixed(1)} kW</div>
        </div>
        <div className="bg-amber-50 rounded p-3 border border-amber-200">
          <div className="text-[10px] text-amber-700 uppercase">Grid Import</div>
          <div className="text-lg font-bold text-amber-900">{state.grid.import_kw.toFixed(1)} kW</div>
        </div>
        <div className="bg-purple-50 rounded p-3 border border-purple-200">
          <div className="text-[10px] text-purple-700 uppercase">Battery</div>
          <div className="text-lg font-bold text-purple-900">{state.battery.soc_percent.toFixed(0)}%</div>
        </div>
      </div>
      
      {/* SVG One-Line Diagram */}
      <div className="bg-slate-50 rounded-lg border border-slate-200 overflow-hidden" style={{ height: '600px' }}>
        <svg 
          width="100%" 
          height="100%" 
          viewBox="0 0 1200 600"
          style={{ transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)` }}
        >
          {/* Grid Background */}
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />

          {/* 11kV GRID */}
          <g 
            onClick={() => onAssetSelect('GRID-01')}
            className="cursor-pointer"
            style={{ opacity: selectedAsset === 'GRID-01' ? 1 : 0.9 }}
          >
            <rect x="50" y="50" width="120" height="60" fill={selectedAsset === 'GRID-01' ? '#dbeafe' : '#f0f9ff'} stroke="#2563eb" strokeWidth="2" rx="4"/>
            <text x="110" y="75" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#1e40af">11 kV GRID</text>
            <text x="110" y="95" textAnchor="middle" fontSize="10" fill="#3b82f6">{state.grid.voltage_kv.toFixed(1)} kV</text>
            {state.grid.import_kw > 0 && (
              <text x="110" y="110" textAnchor="middle" fontSize="9" fill="#f59e0b" fontWeight="bold">
                IMP: {state.grid.import_kw.toFixed(1)} kW
              </text>
            )}
            {state.grid.export_kw > 0 && (
              <text x="110" y="110" textAnchor="middle" fontSize="9" fill="#10b981" fontWeight="bold">
                EXP: {state.grid.export_kw.toFixed(1)} kW
              </text>
            )}
          </g>

          {/* Connection: Grid to Breaker */}
          <line x1="170" y1="80" x2="250" y2="80" stroke="#64748b" strokeWidth="3"/>
          {state.grid.import_kw > 0 && (
            <circle cx="210" cy="80" r="4" fill="#f59e0b">
              <animate attributeName="cx" from="170" to="250" dur="2s" repeatCount="indefinite"/>
            </circle>
          )}

          {/* MAIN BREAKER */}
          <g 
            onClick={() => onAssetSelect('CB-IN-01')}
            className="cursor-pointer"
          >
            <circle cx="280" cy="80" r="20" fill="#dcfce7" stroke="#16a34a" strokeWidth="2"/>
            <text x="280" y="85" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#166534">CB</text>
            <text x="280" y="115" textAnchor="middle" fontSize="9" fill="#16a34a">CLOSED</text>
          </g>

          {/* Connection: Breaker to Transformer */}
          <line x1="300" y1="80" x2="400" y2="80" stroke="#64748b" strokeWidth="3"/>

          {/* TRANSFORMER */}
          <g 
            onClick={() => onAssetSelect('TX-01')}
            className="cursor-pointer"
            style={{ opacity: selectedAsset === 'TX-01' ? 1 : 0.9 }}
          >
            <circle cx="450" cy="60" r="25" fill="none" stroke="#d97706" strokeWidth="3"/>
            <circle cx="450" cy="100" r="25" fill="none" stroke="#d97706" strokeWidth="3"/>
            <text x="450" y="65" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#92400e">11kV</text>
            <text x="450" y="105" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#92400e">415V</text>
            <text x="500" y="85" fontSize="11" fontWeight="bold" fill="#92400e">
              TX-01: {state.transformer.loading_percent.toFixed(0)}%
            </text>
            <text x="500" y="100" fontSize="9" fill="#92400e">
              {state.transformer.temperature_c.toFixed(1)}°C
            </text>
          </g>

          {/* Connection: Transformer to 415V Bus */}
          <line x1="450" y1="125" x2="450" y2="180" stroke="#64748b" strokeWidth="3"/>

          {/* 415V BUS */}
          <g 
            onClick={() => onAssetSelect('BUS-415V')}
            className="cursor-pointer"
          >
            <rect x="200" y="180" width="500" height="8" fill="#3b82f6" stroke="#1e40af" strokeWidth="1"/>
            <text x="450" y="175" textAnchor="middle" fontSize="11" fontWeight="bold" fill="#1e40af">415 V BUS</text>
          </g>

          {/* FEEDER 1 */}
          <line x1="250" y1="188" x2="250" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('FEEDER-01')} className="cursor-pointer">
            <rect x="220" y="250" width="60" height="40" fill="#e0e7ff" stroke="#4f46e5" strokeWidth="2" rx="3"/>
            <text x="250" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#3730a3">FEEDER</text>
            <text x="250" y="285" textAnchor="middle" fontSize="9" fill="#4f46e5">01</text>
          </g>

          {/* Houses on Feeder 1 */}
          {state.houses.slice(0, 2).map((house, idx) => (
            <g key={house.id} onClick={() => onAssetSelect(house.id)} className="cursor-pointer">
              <line x1={230 + idx * 40} y1="290" x2={230 + idx * 40} y2="330" stroke="#64748b" strokeWidth="1"/>
              <rect x={215 + idx * 40} y="330" width="30" height="30" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" rx="2"/>
              <text x={230 + idx * 40} y="350" textAnchor="middle" fontSize="8" fill="#92400e">{house.id}</text>
              <text x={230 + idx * 40} y="375" textAnchor="middle" fontSize="7" fill="#d97706">{house.load_kw.toFixed(1)}kW</text>
            </g>
          ))}

          {/* FEEDER 2 */}
          <line x1="450" y1="188" x2="450" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('FEEDER-02')} className="cursor-pointer">
            <rect x="420" y="250" width="60" height="40" fill="#e0e7ff" stroke="#4f46e5" strokeWidth="2" rx="3"/>
            <text x="450" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#3730a3">FEEDER</text>
            <text x="450" y="285" textAnchor="middle" fontSize="9" fill="#4f46e5">02</text>
          </g>

          {/* Houses on Feeder 2 */}
          {state.houses.slice(2, 4).map((house, idx) => (
            <g key={house.id} onClick={() => onAssetSelect(house.id)} className="cursor-pointer">
              <line x1={430 + idx * 40} y1="290" x2={430 + idx * 40} y2="330" stroke="#64748b" strokeWidth="1"/>
              <rect x={415 + idx * 40} y="330" width="30" height="30" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" rx="2"/>
              <text x={430 + idx * 40} y="350" textAnchor="middle" fontSize="8" fill="#92400e">{house.id}</text>
              <text x={430 + idx * 40} y="375" textAnchor="middle" fontSize="7" fill="#d97706">{house.load_kw.toFixed(1)}kW</text>
            </g>
          ))}

          {/* FEEDER 3 */}
          <line x1="650" y1="188" x2="650" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('FEEDER-03')} className="cursor-pointer">
            <rect x="620" y="250" width="60" height="40" fill="#e0e7ff" stroke="#4f46e5" strokeWidth="2" rx="3"/>
            <text x="650" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#3730a3">FEEDER</text>
            <text x="650" y="285" textAnchor="middle" fontSize="9" fill="#4f46e5">03</text>
          </g>

          {/* Houses on Feeder 3 */}
          {state.houses.slice(4, 5).map((house, idx) => (
            <g key={house.id} onClick={() => onAssetSelect(house.id)} className="cursor-pointer">
              <line x1={630 + idx * 40} y1="290" x2={630 + idx * 40} y2="330" stroke="#64748b" strokeWidth="1"/>
              <rect x={615 + idx * 40} y="330" width="30" height="30" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" rx="2"/>
              <text x={630 + idx * 40} y="350" textAnchor="middle" fontSize="8" fill="#92400e">{house.id}</text>
              <text x={630 + idx * 40} y="375" textAnchor="middle" fontSize="7" fill="#d97706">{house.load_kw.toFixed(1)}kW</text>
            </g>
          ))}

          {/* COMMUNITY */}
          <line x1="750" y1="188" x2="750" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('COMMUNITY-01')} className="cursor-pointer">
            <rect x="710" y="250" width="80" height="50" fill="#fef3c7" stroke="#d97706" strokeWidth="2" rx="3"/>
            <text x="750" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#92400e">COMMUNITY</text>
            <text x="750" y="285" textAnchor="middle" fontSize="9" fill="#d97706">{state.community.load_kw.toFixed(1)} kW</text>
            <text x="750" y="298" textAnchor="middle" fontSize="8" fill="#16a34a">PV: {state.community.pv_kw.toFixed(1)} kW</text>
          </g>

          {/* PV ARRAY */}
          <line x1="850" y1="188" x2="850" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('PV-01')} className="cursor-pointer">
            <rect x="810" y="250" width="80" height="50" fill="#fef9c3" stroke="#eab308" strokeWidth="2" rx="3"/>
            <text x="850" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#854d0e">PV ARRAY</text>
            <text x="850" y="285" textAnchor="middle" fontSize="9" fill="#ca8a04">{state.houses.reduce((s, h) => s + h.pv_kw, 0).toFixed(1)} kW</text>
            <text x="850" y="298" textAnchor="middle" fontSize="8" fill="#854d0e">☀️ Solar</text>
          </g>

          {/* BESS */}
          <line x1="950" y1="188" x2="950" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('BESS-01')} className="cursor-pointer">
            <rect x="910" y="250" width="80" height="60" fill="#f3e8ff" stroke="#9333ea" strokeWidth="2" rx="3"/>
            <rect x="920" y="260" width="60" height={40 * (state.battery.soc_percent / 100)} fill="#9333ea" opacity="0.3"/>
            <text x="950" y="275" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#6b21a8">BESS</text>
            <text x="950" y="290" textAnchor="middle" fontSize="9" fill="#7c3aed">{state.battery.soc_percent.toFixed(0)}%</text>
            <text x="950" y="305" textAnchor="middle" fontSize="8" fill={state.battery.power_kw > 0 ? '#16a34a' : '#dc2626'}>
              {state.battery.power_kw > 0 ? '+' : ''}{state.battery.power_kw.toFixed(1)} kW
            </text>
          </g>

          {/* PCS */}
          <line x1="1050" y1="188" x2="1050" y2="250" stroke="#64748b" strokeWidth="2"/>
          <g onClick={() => onAssetSelect('PCS-01')} className="cursor-pointer">
            <rect x="1010" y="250" width="80" height="50" fill="#fce7f3" stroke="#db2777" strokeWidth="2" rx="3"/>
            <text x="1050" y="270" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#9d174d">PCS</text>
            <text x="1050" y="285" textAnchor="middle" fontSize="9" fill="#be185d">{state.pcs.power_kw.toFixed(1)} kW</text>
            <text x="1050" y="298" textAnchor="middle" fontSize="8" fill="#9d174d">{state.pcs.enabled ? 'ON' : 'OFF'}</text>
          </g>

          {/* Legend */}
          <g transform="translate(50, 450)">
            <text x="0" y="0" fontSize="11" fontWeight="bold" fill="#475569">Legend:</text>
            <rect x="0" y="10" width="15" height="15" fill="#dbeafe" stroke="#2563eb" strokeWidth="1"/>
            <text x="20" y="22" fontSize="9" fill="#475569">Grid</text>
            <rect x="70" y="10" width="15" height="15" fill="#dcfce7" stroke="#16a34a" strokeWidth="1"/>
            <text x="90" y="22" fontSize="9" fill="#475569">Breaker</text>
            <circle cx="157" cy="17" r="7" fill="none" stroke="#d97706" strokeWidth="2"/>
            <text x="170" y="22" fontSize="9" fill="#475569">Transformer</text>
            <rect x="240" y="10" width="15" height="15" fill="#e0e7ff" stroke="#4f46e5" strokeWidth="1"/>
            <text x="260" y="22" fontSize="9" fill="#475569">Feeder</text>
            <rect x="310" y="10" width="15" height="15" fill="#fef3c7" stroke="#d97706" strokeWidth="1"/>
            <text x="330" y="22" fontSize="9" fill="#475569">Load</text>
            <rect x="370" y="10" width="15" height="15" fill="#fef9c3" stroke="#eab308" strokeWidth="1"/>
            <text x="390" y="22" fontSize="9" fill="#475569">PV</text>
            <rect x="420" y="10" width="15" height="15" fill="#f3e8ff" stroke="#9333ea" strokeWidth="1"/>
            <text x="440" y="22" fontSize="9" fill="#475569">Battery</text>
          </g>
        </svg>
      </div>

      {/* Asset Quick Select */}
      <div className="mt-6">
        <h3 className="text-sm font-medium text-slate-700 mb-3">Quick Asset Selection</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <AssetButton id="GRID-01" label="Grid" onClick={onAssetSelect} selected={selectedAsset === 'GRID-01'} />
          <AssetButton id="TX-01" label="Transformer" onClick={onAssetSelect} selected={selectedAsset === 'TX-01'} />
          <AssetButton id="BESS-01" label="Battery" onClick={onAssetSelect} selected={selectedAsset === 'BESS-01'} />
          <AssetButton id="PCS-01" label="PCS" onClick={onAssetSelect} selected={selectedAsset === 'PCS-01'} />
          {state.houses.map((house: any) => (
            <AssetButton 
              key={house.id} 
              id={house.id} 
              label={house.id} 
              onClick={onAssetSelect} 
              selected={selectedAsset === house.id} 
            />
          ))}
          <AssetButton 
            id="COMMUNITY-01" 
            label="Community" 
            onClick={onAssetSelect} 
            selected={selectedAsset === 'COMMUNITY-01'} 
          />
        </div>
      </div>
    </div>
  );
}

function AssetButton({ id, label, onClick, selected }: { 
  id: string; 
  label: string; 
  onClick: (id: string) => void;
  selected: boolean;
}) {
  return (
    <button
      onClick={() => onClick(id)}
      className={`px-3 py-2 text-xs rounded border transition-colors ${
        selected 
          ? 'bg-cyan-50 text-cyan-700 border-cyan-200' 
          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
      }`}
    >
      {label}
    </button>
  );
}
