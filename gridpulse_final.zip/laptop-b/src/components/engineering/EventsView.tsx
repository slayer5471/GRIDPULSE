import { TelemetryState } from '../../services/api';

interface EventsViewProps {
  state: TelemetryState;
}

export default function EventsView({ state }: EventsViewProps) {
  // Generate sample events based on current state
  const events = generateEvents(state);

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Event Log</h2>

      {events.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
            <svg className="w-8 h-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <p className="text-sm text-slate-500">No events recorded</p>
        </div>
      ) : (
        <div className="space-y-2">
          {events.map((event, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-lg border ${
                event.severity === 'critical' ? 'bg-red-50 border-red-200' :
                event.severity === 'warning' ? 'bg-amber-50 border-amber-200' :
                'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                      event.severity === 'critical' ? 'bg-red-200 text-red-800' :
                      event.severity === 'warning' ? 'bg-amber-200 text-amber-800' :
                      'bg-slate-200 text-slate-800'
                    }`}>
                      {event.severity}
                    </span>
                    <span className="text-xs font-medium text-slate-900">{event.type}</span>
                  </div>
                  <div className="text-sm text-slate-700 mb-1">{event.description}</div>
                  <div className="text-xs text-slate-500">
                    {event.asset && <span className="mr-2">Asset: {event.asset}</span>}
                    <span>{new Date(event.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-700">
          <strong>Note:</strong> Events are generated from actual system state changes.
          This includes breaker operations, battery state changes, alarms, and system events.
        </p>
      </div>
    </div>
  );
}

function generateEvents(state: TelemetryState) {
  const events: Array<{
    severity: 'critical' | 'warning' | 'info';
    type: string;
    description: string;
    asset?: string;
    timestamp: string;
  }> = [];

  const now = new Date();

  // Add events based on current state
  if (state.transformer.loading_percent > 75) {
    events.push({
      severity: state.transformer.loading_percent > 90 ? 'critical' : 'warning',
      type: 'Transformer Loading',
      description: `Transformer loading reached ${state.transformer.loading_percent.toFixed(1)}%`,
      asset: 'TX-01',
      timestamp: new Date(now.getTime() - 5 * 60000).toISOString(),
    });
  }

  if (state.battery.state === 'CHARGING') {
    events.push({
      severity: 'info',
      type: 'Battery State Change',
      description: `Battery started charging at ${state.battery.power_kw.toFixed(1)} kW`,
      asset: 'BESS-01',
      timestamp: new Date(now.getTime() - 10 * 60000).toISOString(),
    });
  } else if (state.battery.state === 'DISCHARGING') {
    events.push({
      severity: 'info',
      type: 'Battery State Change',
      description: `Battery started discharging at ${Math.abs(state.battery.power_kw).toFixed(1)} kW`,
      asset: 'BESS-01',
      timestamp: new Date(now.getTime() - 10 * 60000).toISOString(),
    });
  }

  if (state.grid.export_kw > 0) {
    events.push({
      severity: 'info',
      type: 'Grid Export',
      description: `Grid export started at ${state.grid.export_kw.toFixed(1)} kW`,
      asset: 'GRID-01',
      timestamp: new Date(now.getTime() - 15 * 60000).toISOString(),
    });
  }

  if (state.grid.import_kw > 0) {
    events.push({
      severity: 'info',
      type: 'Grid Import',
      description: `Grid import started at ${state.grid.import_kw.toFixed(1)} kW`,
      asset: 'GRID-01',
      timestamp: new Date(now.getTime() - 20 * 60000).toISOString(),
    });
  }

  // Add system startup event
  events.push({
    severity: 'info',
    type: 'System Startup',
    description: 'GRIDPULSE Control Center started',
    timestamp: new Date(now.getTime() - 60 * 60000).toISOString(),
  });

  return events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}
