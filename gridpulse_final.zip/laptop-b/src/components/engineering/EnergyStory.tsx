import { TelemetryState } from '../../services/api';

interface EnergyStoryProps {
  state: TelemetryState;
  assetId: string;
}

export default function EnergyStory({ state, assetId }: EnergyStoryProps) {
  const house = state.houses.find(h => h.id === assetId);
  if (!house) return null;

  const totalSolar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const totalLoad = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;
  
  // Calculate energy sources
  const solarContribution = Math.min(totalSolar, house.load_kw);
  const batteryContribution = state.battery.power_kw < 0 ? Math.abs(state.battery.power_kw) * (house.load_kw / totalLoad) : 0;
  const gridContribution = Math.max(0, house.load_kw - solarContribution - batteryContribution);

  const sources = [
    { name: 'Solar', value: solarContribution, color: '#eab308', icon: '☀️' },
    { name: 'Battery', value: batteryContribution, color: '#9333ea', icon: '🔋' },
    { name: 'Grid', value: gridContribution, color: '#0891b2', icon: '⚡' },
  ].filter(s => s.value > 0);

  const renewablePercent = ((solarContribution + batteryContribution) / house.load_kw) * 100;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-emerald-600">🔋</span>
        Energy Story
      </h3>

      <div className="bg-slate-50 rounded p-3 mb-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Selected Load</div>
        <div className="text-sm font-bold text-slate-900">{house.id}</div>
        <div className="text-xs text-slate-600 mt-1">
          Consuming <span className="font-bold text-blue-600">{house.load_kw.toFixed(1)} kW</span>
        </div>
      </div>

      <div className="mb-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Energy Sources</div>
        <div className="space-y-2">
          {sources.map((source, idx) => (
            <div key={idx} className="bg-slate-50 rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-base">{source.icon}</span>
                  <span className="text-xs font-medium text-slate-900">{source.name}</span>
                </div>
                <span className="text-xs font-bold text-slate-900">{source.value.toFixed(1)} kW</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-1.5">
                <div
                  className="h-1.5 rounded-full"
                  style={{ width: `${(source.value / house.load_kw) * 100}%`, backgroundColor: source.color }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className={`rounded p-3 border ${
        renewablePercent > 50 ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="text-[10px] text-slate-500 uppercase font-bold">Renewable Energy</div>
        <div className={`text-lg font-bold ${renewablePercent > 50 ? 'text-emerald-600' : 'text-slate-700'}`}>
          {renewablePercent.toFixed(1)}%
        </div>
      </div>
    </div>
  );
}
