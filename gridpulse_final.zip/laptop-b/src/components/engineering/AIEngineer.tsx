import { TelemetryState } from '../../services/api';
import { useState } from 'react';

interface AIEngineerProps {
  state: TelemetryState;
}

export default function AIEngineer({ state }: AIEngineerProps) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);

  const handleAsk = () => {
    if (!question.trim()) return;
    
    // Simple rule-based responses based on actual data
    const q = question.toLowerCase();
    
    if (q.includes('tx-01') && q.includes('overload')) {
      setAnswer(`TX-01 is at ${state.transformer.loading_percent.toFixed(1)}% loading. This is ${
        state.transformer.loading_percent > 90 ? 'critically overloaded' :
        state.transformer.loading_percent > 75 ? 'heavily loaded' : 'within normal range'
      }. Total load is ${(state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw).toFixed(1)} kW.`);
    } else if (q.includes('export') && q.includes('zero')) {
      setAnswer(`Grid export is ${state.grid.export_kw.toFixed(1)} kW. ${
        state.grid.export_kw === 0 ? 'No export because load exceeds generation.' :
        `Export is limited to ${state.grid.export_limit_kw} kW.`
      }`);
    } else if (q.includes('voltage') && q.includes('low')) {
      setAnswer(`Bus voltages are within normal range. Current frequency is ${state.frequency.toFixed(2)} Hz.`);
    } else if (q.includes('weakest') || q.includes('lowest')) {
      setAnswer(`Based on current loading, the most stressed component is the transformer at ${state.transformer.loading_percent.toFixed(1)}% loading.`);
    } else if (q.includes('battery') || q.includes('bess')) {
      setAnswer(`Battery SOC is ${state.battery.soc_percent.toFixed(1)}%, ${state.battery.state} at ${state.battery.power_kw.toFixed(1)} kW. Mode: ${state.battery.mode}.`);
    } else {
      setAnswer(`Based on current system state: Solar generation is ${
        (state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw).toFixed(1)
      } kW, total load is ${
        (state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw).toFixed(1)
      } kW, battery is ${state.battery.state} at ${state.battery.power_kw.toFixed(1)} kW.`);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
        <span className="text-purple-600">🤖</span>
        AI Engineer Assistant
      </h2>

      <div className="mb-4">
        <label className="text-xs text-slate-600 block mb-2">Ask a question about the system:</label>
        <div className="flex gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAsk()}
            placeholder="e.g., Why is TX-01 overloaded?"
            className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-cyan-500"
          />
          <button
            onClick={handleAsk}
            className="px-4 py-2 bg-cyan-600 text-white rounded-lg text-sm hover:bg-cyan-700"
          >
            Ask
          </button>
        </div>
      </div>

      {answer && (
        <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
          <div className="text-xs text-purple-700 font-medium mb-2">Answer:</div>
          <div className="text-sm text-slate-700">{answer}</div>
        </div>
      )}

      <div className="mt-4">
        <div className="text-xs text-slate-500 font-medium mb-2">Example questions:</div>
        <div className="flex flex-wrap gap-2">
          {[
            'Why is TX-01 overloaded?',
            'Why is export zero?',
            'What is the weakest bus?',
            'What is battery status?',
          ].map((q, idx) => (
            <button
              key={idx}
              onClick={() => { setQuestion(q); }}
              className="px-2 py-1 text-xs bg-slate-100 text-slate-600 rounded hover:bg-slate-200"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-700">
          <strong>Note:</strong> AI Engineer uses actual system data to answer questions. 
          All answers are based on real telemetry from Laptop A.
        </p>
      </div>
    </div>
  );
}
