import { useMemo } from 'react';
import { TelemetryState } from '../../services/api';

interface ForecastViewProps {
  state: TelemetryState;
}

type Point = {
  hour: number;
  label: string;
  value: number;
  isActual: boolean;
};

function solarShape(hour: number) {
  // Clear sunrise/sunset bell shape: zero outside 06:00–18:00,
  // peaking at noon. This is a normalized production profile.
  if (hour < 6 || hour > 18) return 0;
  return Math.max(0, Math.sin(((hour - 6) * Math.PI) / 12));
}

function loadShape(hour: number) {
  if (hour >= 17 && hour < 22) return 1.0;
  if (hour >= 7 && hour < 10) return 0.82;
  if (hour >= 10 && hour < 17) return 0.68;
  if (hour >= 0 && hour < 6) return 0.46;
  if (hour >= 22) return 0.5;
  return 0.62;
}

function buildProfile(currentHour: number, currentSolar: number, currentLoad: number) {
  const currentSolarShape = solarShape(currentHour + 0.5);
  const solarCapacity = currentSolarShape > 0.08 ? currentSolar / currentSolarShape : Math.max(currentSolar, 1);
  const currentLoadShape = loadShape(currentHour + 0.5);
  const loadBase = currentLoadShape > 0 ? currentLoad / currentLoadShape : currentLoad;

  const points = Array.from({ length: 24 }, (_, hour) => ({
    hour,
    label: `${String(hour).padStart(2, '0')}:00`,
    solar: Math.max(0, solarCapacity * solarShape(hour + 0.5)),
    load: Math.max(0, loadBase * loadShape(hour + 0.5)),
    isActual: hour <= currentHour,
  }));

  return {
    solar: points.map<Point>(p => ({ hour: p.hour, label: p.label, value: p.solar, isActual: p.isActual })),
    load: points.map<Point>(p => ({ hour: p.hour, label: p.label, value: p.load, isActual: p.isActual })),
  };
}

function ForecastRows({ points, kind }: { points: Point[]; kind: 'solar' | 'load' }) {
  const maxValue = Math.max(1, ...points.map(p => p.value));
  return (
    <div className="space-y-1.5">
      {points.map(point => (
        <div key={point.hour} className="grid grid-cols-[44px_minmax(0,1fr)_64px] items-center gap-2 text-xs">
          <span className="text-slate-600 tabular-nums">{point.label}</span>
          <div className={`h-2 overflow-hidden rounded-full ${kind === 'solar' ? 'bg-yellow-100' : 'bg-blue-100'}`}>
            <div
              className={`h-full rounded-full transition-all ${
                kind === 'solar'
                  ? (point.isActual ? 'bg-amber-500' : 'bg-yellow-300')
                  : (point.isActual ? 'bg-blue-500' : 'bg-blue-300')
              }`}
              style={{ width: `${Math.min(100, (point.value / maxValue) * 100)}%` }}
            />
          </div>
          <span className="text-right font-medium text-slate-900 tabular-nums whitespace-nowrap">
            {point.value.toFixed(1)} kW
          </span>
        </div>
      ))}
    </div>
  );
}

export default function ForecastView({ state }: ForecastViewProps) {
  const { solar, load } = useMemo(() => {
    const currentHour = new Date(state.timestamp).getHours();
    const currentSolar = state.houses.reduce((sum, house) => sum + (Number(house.pv_kw) || 0), 0) + (Number(state.community?.pv_kw) || 0);
    const currentLoad = state.houses.reduce((sum, house) => sum + (Number(house.load_kw) || 0), 0) + (Number(state.community?.load_kw) || 0);
    return buildProfile(currentHour, currentSolar, currentLoad);
  }, [state]);

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Forecast</h2>
          <p className="mt-0.5 text-xs text-slate-500">24-hour deterministic operating profile from the live twin.</p>
        </div>
        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-semibold text-slate-600">24 h horizon</span>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <div className="rounded-xl border border-yellow-200 bg-yellow-50/70 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-700">PV Generation</h3>
            <span className="text-[10px] text-slate-500">kW</span>
          </div>
          <ForecastRows points={solar} kind="solar" />
          <div className="mt-3 flex gap-4 text-[11px]">
            <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded bg-amber-500" />Actual</div>
            <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded bg-yellow-300" />Forecast</div>
          </div>
        </div>

        <div className="rounded-xl border border-blue-200 bg-blue-50/70 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-700">Load</h3>
            <span className="text-[10px] text-slate-500">kW</span>
          </div>
          <ForecastRows points={load} kind="load" />
          <div className="mt-3 flex gap-4 text-[11px]">
            <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded bg-blue-500" />Actual</div>
            <div className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded bg-blue-300" />Forecast</div>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
        Actual/forecast is split at the current simulation hour. Future points use the same deterministic daily profile as the demo digital twin; live-backend forecasts can replace this profile when available.
      </div>
    </div>
  );
}
