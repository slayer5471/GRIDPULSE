import { useMemo } from 'react';
import type { ReactNode } from 'react';
import {
  Activity, ArrowDownRight, ArrowUpRight, Battery, BrainCircuit, CloudSun, Gauge,
  GitBranch, Leaf, MapPinned, Network, ShieldCheck, Thermometer, TrendingUp, Waves, Zap
} from 'lucide-react';
import { TelemetryState } from '../../services/api';

type Props = { state: TelemetryState };

const tones = {
  green: 'bg-emerald-50 text-emerald-700 border-emerald-100',
  amber: 'bg-amber-50 text-amber-700 border-amber-100',
  red: 'bg-red-50 text-red-700 border-red-100',
  blue: 'bg-sky-50 text-sky-700 border-sky-100',
  violet: 'bg-violet-50 text-violet-700 border-violet-100',
  slate: 'bg-slate-50 text-slate-600 border-slate-200',
} as const;

function fmt(v: number, digits = 1) {
  return Number.isFinite(Number(v)) ? Number(v).toFixed(digits) : '0.0';
}

function Chip({ label, tone = 'slate' }: { label: string; tone?: keyof typeof tones }) {
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[9px] font-semibold tracking-wide ${tones[tone]}`}>{label}</span>;
}

function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-[22px] border border-slate-200/80 bg-white shadow-[0_14px_45px_rgba(15,23,42,.045)] ${className}`}>{children}</section>;
}

function Metric({ icon, label, value, unit, sub }: { icon: ReactNode; label: string; value: string; unit?: string; sub?: string }) {
  return <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4 transition duration-300 hover:-translate-y-0.5 hover:bg-white hover:shadow-[0_10px_30px_rgba(15,23,42,.05)]">
    <div className="flex items-center gap-2 text-slate-500"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm">{icon}</span><span className="text-[9px] font-semibold uppercase tracking-[.16em]">{label}</span></div>
    <div className="mt-3 flex items-baseline gap-1"><span className="text-[25px] font-semibold tracking-tight text-slate-900">{value}</span>{unit && <span className="text-[10px] text-slate-400">{unit}</span>}</div>
    {sub && <div className="mt-1 text-[9px] text-slate-400">{sub}</div>}
  </div>;
}

export default function GridOptimizationCenter({ state }: Props) {
  const a: any = state.advanced || {};
  const dlr = a.dlr || {};
  const spans: any[] = a.critical_spans || dlr.spans || [];
  const copilot = a.dispatch_copilot || {};
  const topology = a.topology_optimizer || {};
  const carbon = a.carbon || {};
  const tx = a.transformer_health || {};
  const b = a.battery_health || {};
  const inv = a.smart_inverter || {};

  const criticalTone = String(dlr.status) === 'CRITICAL' ? 'red' : String(dlr.status) === 'WARNING' ? 'amber' : 'green';
  const copilotTone = Number(copilot.confidence_percent || 0) >= 85 ? 'green' : Number(copilot.confidence_percent || 0) >= 70 ? 'amber' : 'red';
  const maxSpanRisk = useMemo(() => spans.reduce((m, s) => Math.max(m, Number(s.risk_percent || 0)), 0), [spans]);

  return <div className="space-y-5">
    <Card className="overflow-hidden">
      <div className="relative bg-[radial-gradient(circle_at_8%_10%,rgba(109,93,252,.10),transparent_26%),radial-gradient(circle_at_96%_80%,rgba(14,165,233,.10),transparent_26%)] px-6 py-6 lg:px-7 lg:py-7">
        <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(120deg,transparent_0%,rgba(255,255,255,.72)_36%,transparent_58%)]" />
        <div className="relative flex flex-wrap items-end justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 text-[9px] font-semibold uppercase tracking-[.18em] text-violet-600"><Network size={14} /> Grid Intelligence & Optimization</div>
            <h2 className="mt-1 text-[27px] font-semibold tracking-tight text-slate-900">Operate the network with dynamic constraints, not static limits.</h2>
            <p className="mt-2 max-w-4xl text-[11px] leading-5 text-slate-500">DLR, critical-span inference, degradation-aware dispatch, topology recommendations, smart-inverter support and carbon accounting are presented as one operator decision surface.</p>
          </div>
          <div className="flex flex-wrap gap-2"><Chip label={`${String(copilot.confidence_percent ?? 0)}% Copilot confidence`} tone={copilotTone} /><Chip label={String(dlr.confidence || 'MEDIUM') + ' DLR confidence'} tone="violet" /><Chip label={String(topology.status || 'MONITOR')} tone={String(topology.status) === 'RECOMMENDED' ? 'green' : 'slate'} /></div>
        </div>
      </div>
    </Card>

    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
      <Metric icon={<Gauge size={14} />} label="Dynamic rating" value={fmt(dlr.safe_dynamic_rating_a, 0)} unit="A" sub={`static ${fmt(dlr.static_rating_a, 0)} A`} />
      <Metric icon={<ArrowUpRight size={14} />} label="Spare line capacity" value={fmt(dlr.spare_capacity_a, 0)} unit="A" sub={`${fmt(dlr.dynamic_utilization_percent, 1)}% dynamic utilization`} />
      <Metric icon={<MapPinned size={14} />} label="Critical span" value={String(dlr.critical_span || 'SPAN-03')} sub={`${fmt(maxSpanRisk, 0)}% max risk`} />
      <Metric icon={<Leaf size={14} />} label="Capacity unlocked" value={fmt(carbon.renewable_capacity_unlocked_mwh_today, 2)} unit="MWh" sub={`${fmt(carbon.avoided_today_tco2, 3)} tCO₂ avoided today`} />
    </div>

    <div className="grid gap-4 xl:grid-cols-[1.15fr_.85fr]">
      <Card className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="flex items-center gap-2 text-[12px] font-semibold"><CloudSun size={16} className="text-violet-600" /> Dynamic Line Rating</div><div className="mt-0.5 text-[9px] text-slate-400">Weather-aware ampacity reference • IEEE 738 vs CIGRÉ TB 601</div></div><Chip label={String(dlr.status || 'NORMAL')} tone={criticalTone} /></div>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4"><div className="text-[9px] uppercase tracking-[.15em] text-slate-400">Thermal / weather state</div><div className="mt-3 grid grid-cols-2 gap-3 text-[11px]"><Row label="Conductor temperature" value={`${fmt(dlr.conductor_temperature_c)} °C`} /><Row label="Ambient" value={`${fmt(dlr.ambient_c)} °C`} /><Row label="Wind" value={`${fmt(dlr.wind_mps)} m/s`} /><Row label="Solar irradiance" value={`${fmt(dlr.solar_w_m2, 0)} W/m²`} /></div></div>
          <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4"><div className="text-[9px] uppercase tracking-[.15em] text-slate-400">Model comparison</div><div className="mt-3 grid grid-cols-2 gap-3 text-[11px]"><Row label="IEEE 738" value={`${fmt(dlr.ieee_738_ampacity_a, 0)} A`} /><Row label="CIGRÉ TB 601" value={`${fmt(dlr.cigre_tb_601_ampacity_a, 0)} A`} /><Row label="Safe dynamic" value={`${fmt(dlr.safe_dynamic_rating_a, 0)} A`} /><Row label="Uncertainty" value={`${fmt(dlr.uncertainty_percent)} %`} /></div></div>
        </div>
        <div className="mt-4 rounded-2xl border border-slate-100 bg-white p-4">
          <div className="flex items-center justify-between text-[10px]"><span className="font-semibold text-slate-700">Static vs dynamic utilization</span><Chip label={`${fmt(dlr.dynamic_utilization_percent)}%`} tone={Number(dlr.dynamic_utilization_percent) >= 100 ? 'red' : Number(dlr.dynamic_utilization_percent) >= 85 ? 'amber' : 'green'} /></div>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-gradient-to-r from-violet-500 via-cyan-500 to-emerald-400 transition-all duration-700" style={{ width: `${Math.min(100, Math.max(4, Number(dlr.dynamic_utilization_percent || 0)))}%` }} /></div>
          <div className="mt-2 flex justify-between text-[9px] text-slate-400"><span>Static: {fmt(dlr.static_utilization_percent)}%</span><span>Confidence: {String(dlr.confidence || 'MEDIUM')}</span><span>Spare: {fmt(dlr.spare_capacity_a, 0)} A</span></div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center justify-between"><div><div className="flex items-center gap-2 text-[12px] font-semibold"><BrainCircuit size={16} className="text-violet-600" /> Dispatch Operations Copilot</div><div className="mt-0.5 text-[9px] text-slate-400">Compound grid risk + action recommendations</div></div><Chip label={`${fmt(copilot.confidence_percent, 0)}%`} tone={copilotTone} /></div>
        <div className="mt-4 space-y-2.5">
          {(copilot.actions || []).map((x: any, i: number) => <div key={i} className="group rounded-2xl border border-slate-100 bg-slate-50/70 p-3 transition hover:-translate-y-0.5 hover:bg-white hover:shadow-sm"><div className="flex items-start gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm"><Zap size={14}/></div><div className="min-w-0"><div className="flex items-center gap-2"><span className="rounded-full bg-slate-900 px-2 py-0.5 text-[8px] font-bold text-white">{x.priority}</span><div className="text-[10px] font-semibold text-slate-900">{x.action}</div></div><div className="mt-1 text-[9px] leading-4 text-slate-500">{x.detail}</div></div></div></div>)}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3"><Row label="Uncertainty band" value={`${fmt(copilot.uncertainty_band_percent)} %`} /><Row label="Economic spread" value={`₹${fmt(copilot.economic_spread_inr_per_kwh, 2)}/kWh`} /></div>
      </Card>
    </div>

    <div className="grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
      <Card className="p-5">
        <div className="flex items-center justify-between"><div><div className="flex items-center gap-2 text-[12px] font-semibold"><MapPinned size={16} className="text-violet-600"/> Critical Span Intelligence</div><div className="mt-0.5 text-[9px] text-slate-400">Sparse-sensor / weather-inferred risk surface</div></div><Chip label={`${spans.length} spans modelled`} tone="violet" /></div>
        <div className="mt-4 overflow-hidden rounded-2xl border border-slate-100"><table className="w-full text-left"><thead className="bg-slate-50 text-[8px] uppercase tracking-[.14em] text-slate-400"><tr><th className="px-3 py-2">Span</th><th className="px-3 py-2">Risk</th><th className="px-3 py-2">Rating</th><th className="px-3 py-2">Clearance</th><th className="px-3 py-2">Weather</th></tr></thead><tbody className="divide-y divide-slate-100">{spans.map((x:any)=><tr key={x.id} className="text-[10px] transition hover:bg-slate-50"><td className="px-3 py-2.5 font-semibold">{x.id}{x.id===dlr.critical_span && <span className="ml-2 rounded-full bg-red-50 px-1.5 py-0.5 text-[8px] font-bold text-red-600">CRITICAL</span>}</td><td className="px-3 py-2.5"><div className="flex items-center gap-2"><div className="h-1.5 w-20 rounded-full bg-slate-100"><div className={`${Number(x.risk_percent)>=65?'bg-red-500':Number(x.risk_percent)>=45?'bg-amber-500':'bg-emerald-500'} h-full rounded-full`} style={{width:`${Math.min(100,Number(x.risk_percent||0))}%`}} /></div><span className="font-semibold">{fmt(x.risk_percent,0)}%</span></div></td><td className="px-3 py-2.5">{fmt(x.rating_a,0)} A</td><td className="px-3 py-2.5">{fmt(x.clearance_m,2)} m</td><td className="px-3 py-2.5 text-slate-500">{fmt(x.wind_mps,1)} m/s • {fmt(x.ambient_c,1)}°C</td></tr>)}</tbody></table></div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center gap-2 text-[12px] font-semibold"><GitBranch size={16} className="text-violet-600"/> Autonomous Topology Reconfiguration</div>
        <div className="mt-1 text-[9px] text-slate-400">Constraint-aware switching recommendation</div>
        <div className="mt-5 rounded-2xl border border-slate-100 bg-[linear-gradient(135deg,#fafaff,#f8fafc)] p-4"><div className="flex items-center justify-between"><Chip label={String(topology.status || 'MONITOR')} tone={String(topology.status)==='RECOMMENDED'?'green':String(topology.status)==='BLOCKED'?'red':'slate'} /><span className="text-[9px] text-slate-400">candidate {topology.candidate || '—'}</span></div><p className="mt-3 text-[10px] leading-5 text-slate-600">{topology.reason || 'No topology change required under current constraints.'}</p><div className="mt-4 flex items-center gap-2 rounded-xl bg-white p-3 text-[10px]"><div className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 text-violet-700"><GitBranch size={13}/></div><div><div className="font-semibold">Estimated relief</div><div className="text-slate-400">{fmt(topology.estimated_relief_percent,1)}% of constrained path</div></div></div></div>
      </Card>
    </div>

    <div className="grid gap-4 xl:grid-cols-3">
      <Card className="p-5"><SectionIcon icon={<Battery size={16}/>} title="Degradation-aware BESS" /><div className="mt-4 grid grid-cols-2 gap-3"><Mini label="SOH" value={`${fmt(b.soh_percent)}%`} /><Mini label="Cycle depth" value={`${fmt(b.average_cycle_depth_percent)}%`} /><Mini label="LCOS" value={`₹${fmt(b.lcos_estimate_inr_per_kwh,2)}/kWh`} /><Mini label="Throughput" value={`${fmt(b.throughput_kwh,0)} kWh`} /></div></Card>
      <Card className="p-5"><SectionIcon icon={<Gauge size={16}/>} title="Smart inverter support" /><div className="mt-4 grid grid-cols-2 gap-3"><Mini label="Volt-VAR" value={`${fmt(inv.volt_var_q_kvar)} kVAr`} /><Mini label="Volt-Watt" value={`${fmt(inv.volt_watt_curtail_percent)}%`} /><Mini label="Ride-through" value={inv.ride_through ? 'YES' : 'NO'} /><Mini label="Mode" value={String(inv.grid_support || 'NEUTRAL')} /></div></Card>
      <Card className="p-5"><SectionIcon icon={<Leaf size={16}/>} title="Carbon & renewable value" /><div className="mt-4 grid grid-cols-2 gap-3"><Mini label="Grid intensity" value={`${fmt(carbon.grid_intensity_gco2_per_kwh,0)} gCO₂/kWh`} /><Mini label="Avoided today" value={`${fmt(carbon.avoided_today_tco2,3)} t`} /><Mini label="Unlocked capacity" value={`${fmt(carbon.renewable_capacity_unlocked_mwh_today,2)} MWh`} /><Mini label="Mode" value="ACCOUNTING" /></div></Card>
    </div>

    <div className="flex items-start gap-3 rounded-2xl border border-sky-100 bg-sky-50/70 p-4 text-[9px] text-sky-800"><ShieldCheck size={14} className="mt-0.5 shrink-0" /><div><b>Engineering note:</b> DLR, carbon, topology and predictive control values are reference digital-twin calculations for the SIH demonstration. They should be validated against utility-specific settings, conductor data and standards before field deployment.</div></div>
  </div>;
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex items-center justify-between gap-2"><span className="text-slate-400">{label}</span><span className="font-semibold text-slate-800">{value}</span></div>;
}
function Mini({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-slate-100 bg-slate-50/70 p-3"><div className="text-[8px] uppercase tracking-[.14em] text-slate-400">{label}</div><div className="mt-1 text-[12px] font-semibold text-slate-900">{value}</div></div>;
}
function SectionIcon({ icon, title }: { icon: ReactNode; title: string }) {
  return <div className="flex items-center gap-2 text-[12px] font-semibold"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 text-violet-600">{icon}</span>{title}</div>;
}
