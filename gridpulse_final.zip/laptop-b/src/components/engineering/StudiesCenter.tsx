import { TelemetryState } from '../../services/api';

interface StudiesCenterProps {
  state: TelemetryState;
}

export default function StudiesCenter({ state }: StudiesCenterProps) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Engineering Studies</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <StudyCard 
          title="Power Flow" 
          description="Analyze power distribution and losses"
          icon="⚡"
          status="Ready"
        />
        <StudyCard 
          title="Voltage Profile" 
          description="Check voltage levels across the network"
          icon="📊"
          status="Ready"
        />
        <StudyCard 
          title="Loss Analysis" 
          description="Identify and minimize system losses"
          icon="📉"
          status="Ready"
        />
        <StudyCard 
          title="Short Circuit" 
          description="Calculate fault currents"
          icon="⚠️"
          status="Ready"
        />
        <StudyCard 
          title="N-1 Contingency" 
          description="Test single component failures"
          icon="🔍"
          status="Ready"
        />
        <StudyCard 
          title="What-If Analysis" 
          description="Simulate network modifications"
          icon="💡"
          status="Ready"
        />
        <StudyCard 
          title="Thermal Loading" 
          description="Check equipment thermal limits"
          icon="🌡️"
          status="Ready"
        />
        <StudyCard 
          title="Fault Study" 
          description="Analyze fault conditions"
          icon="🔧"
          status="Ready"
        />
        <StudyCard 
          title="Optimization" 
          description="Optimize network performance"
          icon="⚙️"
          status="Ready"
        />
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <p className="text-sm text-blue-700">
          <strong>Note:</strong> Studies are performed by Laptop A (Pandapower engine). 
          Results are displayed here after computation.
        </p>
      </div>
    </div>
  );
}

function StudyCard({ title, description, icon, status }: {
  title: string;
  description: string;
  icon: string;
  status: string;
}) {
  return (
    <div className="border border-slate-200 rounded-lg p-4 hover:border-cyan-300 hover:shadow-sm transition-all cursor-pointer">
      <div className="flex items-start justify-between mb-2">
        <span className="text-2xl">{icon}</span>
        <span className="text-xs px-2 py-1 bg-emerald-50 text-emerald-700 rounded">{status}</span>
      </div>
      <h3 className="text-sm font-medium text-slate-900 mb-1">{title}</h3>
      <p className="text-xs text-slate-500">{description}</p>
    </div>
  );
}
