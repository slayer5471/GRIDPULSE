import { useState } from 'react';
import { TelemetryState } from '../../services/api';

interface ReportsViewProps {
  state: TelemetryState;
}

type ReportKey =
  | 'topology'
  | 'power-flow'
  | 'voltage'
  | 'transformer'
  | 'feeder'
  | 'pv'
  | 'battery'
  | 'loss'
  | 'alarm';

type ReportDefinition = {
  key: ReportKey;
  title: string;
  description: string;
  icon: string;
};

const REPORTS: ReportDefinition[] = [
  { key: 'topology', title: 'Topology Report', description: 'Network structure and connections', icon: '📋' },
  { key: 'power-flow', title: 'Power Flow Report', description: 'Power distribution analysis', icon: '⚡' },
  { key: 'voltage', title: 'Voltage Report', description: 'Voltage profile across network', icon: '📊' },
  { key: 'transformer', title: 'Transformer Report', description: 'Transformer loading and health', icon: '⚙️' },
  { key: 'feeder', title: 'Feeder Report', description: 'Feeder loading and losses', icon: '🔌' },
  { key: 'pv', title: 'PV Report', description: 'Solar generation analysis', icon: '☀️' },
  { key: 'battery', title: 'Battery Report', description: 'Battery performance and SOC', icon: '🔋' },
  { key: 'loss', title: 'Loss Report', description: 'System losses analysis', icon: '📉' },
  { key: 'alarm', title: 'Alarm Report', description: 'Historical alarm analysis', icon: '🚨' },
];

const safe = (value: unknown, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};

function formatNumber(value: unknown, digits = 2) {
  return safe(value).toFixed(digits);
}

function buildReport(state: TelemetryState, key: ReportKey) {
  const totalSolar = state.houses.reduce((sum, h) => sum + safe(h.pv_kw), 0) + safe(state.community.pv_kw);
  const totalLoad = state.houses.reduce((sum, h) => sum + safe(h.load_kw), 0) + safe(state.community.load_kw);
  const batteryFlow = state.battery.energy_flow;
  const alarmHistory = state.alarm_history ?? [];

  const header = [
    'GRIDPULSE ENGINEERING REPORT',
    '================================',
    `Report: ${REPORTS.find(r => r.key === key)?.title ?? key}`,
    `Generated: ${new Date().toISOString()}`,
    `Telemetry timestamp: ${state.timestamp}`,
    `Telemetry sequence: ${state.sequence}`,
    '',
  ];

  const summary = [
    'CURRENT SYSTEM SUMMARY',
    '-----------------------',
    `Total PV generation : ${formatNumber(totalSolar, 2)} kW`,
    `Total load          : ${formatNumber(totalLoad, 2)} kW`,
    `Grid import         : ${formatNumber(state.grid.import_kw, 2)} kW`,
    `Grid export         : ${formatNumber(state.grid.export_kw, 2)} kW`,
    `Transformer loading : ${formatNumber(state.transformer.loading_percent, 2)} %`,
    `Battery SOC         : ${formatNumber(state.battery.soc_percent, 2)} %`,
    `Frequency           : ${formatNumber(state.frequency, 2)} Hz`,
    `Active alarms       : ${state.alarms.length}`,
    '',
  ];

  let body: string[] = [];

  if (key === 'topology') {
    body = [
      'TOPOLOGY',
      '--------',
      `Grid voltage: ${formatNumber(state.grid.voltage_kv, 3)} kV`,
      `Transformer: ${state.transformer.id}`,
      `Transformer rating: ${formatNumber(state.transformer.rating_kva, 1)} kVA`,
      `Transformer primary: ${formatNumber(state.transformer.primary_voltage_kv, 3)} kV`,
      `Transformer secondary: ${formatNumber(state.transformer.secondary_voltage_v, 1)} V`,
      `Buses: ${state.buses.length}`,
      ...state.buses.map((b) => `  - ${b.id} (${b.type}) ${b.voltage_kv != null ? `${formatNumber(b.voltage_kv, 3)} kV` : `${formatNumber(b.voltage_v, 1)} V`}`),
      `Homes / endpoints: ${state.houses.length}`,
      ...state.houses.map((h) => `  - ${h.id}`),
      `Community endpoint: ${state.community.id}`,
      `Active scenario: ${state.scenario?.name ?? 'None'}`,
    ];
  }

  if (key === 'power-flow') {
    body = [
      'POWER FLOW',
      '----------',
      `PV generation: ${formatNumber(totalSolar)} kW`,
      `Load demand: ${formatNumber(totalLoad)} kW`,
      `Battery power: ${formatNumber(state.battery.power_kw)} kW`,
      `PCS power: ${formatNumber(state.pcs.power_kw)} kW`,
      `Grid import: ${formatNumber(state.grid.import_kw)} kW`,
      `Grid export: ${formatNumber(state.grid.export_kw)} kW`,
      `Battery state: ${state.battery.state}`,
      `EMS mode: ${state.ems_mode}`,
      `Export limit: ${formatNumber(state.grid.export_limit_kw)} kW`,
      `Scenario: ${state.scenario?.name ?? 'None'}`,
      '',
      'Recent history samples:',
      ...state.history.slice(-12).map((h) => `  ${h.timestamp} | PV ${formatNumber(h.solar_kw)} kW | Load ${formatNumber(h.load_kw)} kW | Import ${formatNumber(h.grid_import_kw)} kW | Export ${formatNumber(h.grid_export_kw)} kW | SOC ${formatNumber(h.battery_soc, 1)}%`),
    ];
  }

  if (key === 'voltage') {
    body = [
      'VOLTAGE PROFILE',
      '---------------',
      `Grid: ${formatNumber(state.grid.voltage_kv, 3)} kV`,
      `Transformer primary: ${formatNumber(state.transformer.primary_voltage_kv, 3)} kV`,
      `Transformer secondary: ${formatNumber(state.transformer.secondary_voltage_v, 1)} V`,
      '',
      'Bus voltages:',
      ...state.buses.map((b) => `  - ${b.id}: ${b.voltage_kv != null ? `${formatNumber(b.voltage_kv, 3)} kV` : `${formatNumber(b.voltage_v, 1)} V`} (${b.type})`),
      '',
      'Endpoint voltages:',
      ...state.houses.map((h) => `  - ${h.id}: ${formatNumber(h.voltage_v, 1)} V`),
    ];
  }

  if (key === 'transformer') {
    const efficiencyPct = safe(state.transformer.efficiency) <= 1 ? safe(state.transformer.efficiency) * 100 : safe(state.transformer.efficiency);
    body = [
      'TRANSFORMER',
      '-----------',
      `ID: ${state.transformer.id}`,
      `Rating: ${formatNumber(state.transformer.rating_kva, 1)} kVA`,
      `Primary voltage: ${formatNumber(state.transformer.primary_voltage_kv, 3)} kV`,
      `Secondary voltage: ${formatNumber(state.transformer.secondary_voltage_v, 1)} V`,
      `Loading: ${formatNumber(state.transformer.loading_percent, 2)} %`,
      `Temperature: ${formatNumber(state.transformer.temperature_c, 2)} °C`,
      `Efficiency: ${formatNumber(efficiencyPct, 2)} %`,
      `Health: ${state.transformer.health}`,
      `Advanced health data: ${JSON.stringify(state.advanced?.transformer_health ?? {}, null, 2)}`,
    ];
  }

  if (key === 'feeder') {
    body = [
      'FEEDER / ENDPOINT LOAD',
      '----------------------',
      ...state.houses.map((h) => `  - ${h.id}: load ${formatNumber(h.load_kw)} kW | PV ${formatNumber(h.pv_kw)} kW | net ${formatNumber(h.net_kw)} kW | V ${formatNumber(h.voltage_v, 1)} V`),
      `Community: load ${formatNumber(state.community.load_kw)} kW | PV ${formatNumber(state.community.pv_kw)} kW | net ${formatNumber(state.community.net_kw)} kW`,
      '',
      'Transformer loading:',
      `${formatNumber(state.transformer.loading_percent, 2)} %`,
    ];
  }

  if (key === 'pv') {
    body = [
      'PV GENERATION',
      '-------------',
      `Community PV: ${formatNumber(state.community.pv_kw)} kW`,
      `Total residential PV: ${formatNumber(state.houses.reduce((sum, h) => sum + safe(h.pv_kw), 0))} kW`,
      `Total PV: ${formatNumber(totalSolar)} kW`,
      '',
      'Per endpoint:',
      ...state.houses.map((h) => `  - ${h.id}: ${formatNumber(h.pv_kw)} kW`),
      '',
      `Grid export: ${formatNumber(state.grid.export_kw)} kW`,
      `Export limit: ${formatNumber(state.grid.export_limit_kw)} kW`,
      `Active scenario: ${state.scenario?.name ?? 'None'}`,
    ];
  }

  if (key === 'battery') {
    body = [
      'BATTERY / BESS',
      '--------------',
      `ID: ${state.battery.id}`,
      `Capacity: ${formatNumber(state.battery.capacity_kwh, 2)} kWh`,
      `Stored energy: ${formatNumber(state.battery.stored_energy_kwh ?? (state.battery.capacity_kwh * state.battery.soc_percent / 100), 2)} kWh`,
      `SOC: ${formatNumber(state.battery.soc_percent, 2)} %`,
      `Power: ${formatNumber(state.battery.power_kw)} kW`,
      `State: ${state.battery.state}`,
      `Mode: ${state.battery.mode}`,
      `Flow direction: ${state.battery.flow_direction ?? 'N/A'}`,
      '',
      'Energy flow:',
      `  Stored energy: ${formatNumber(batteryFlow?.stored_energy_kwh)} kWh`,
      `  PCS power: ${formatNumber(batteryFlow?.pcs_power_kw)} kW`,
      `  To local load: ${formatNumber(batteryFlow?.to_local_load_kw)} kW`,
      `  To grid: ${formatNumber(batteryFlow?.to_grid_kw)} kW`,
      `  From solar: ${formatNumber(batteryFlow?.from_solar_kw)} kW`,
      `  From grid: ${formatNumber(batteryFlow?.from_grid_kw)} kW`,
      `  Efficiency: ${formatNumber(batteryFlow?.efficiency_percent)} %`,
      '',
      'PCS / PWM:',
      `  Enabled: ${state.pcs.enabled}`,
      `  PWM frequency: ${formatNumber(state.pcs.pwm_frequency_hz)} Hz`,
      `  Duty cycle: ${formatNumber(state.pcs.duty_cycle * 100)} %`,
      `  Power: ${formatNumber(state.pcs.power_kw)} kW`,
      `  Average power: ${formatNumber(state.pcs.average_power_kw)} kW`,
      `  Pulses/sec: ${formatNumber(state.pcs.pulses_per_second)}`,
      `  Pulse energy: ${formatNumber(state.pcs.pulse_energy_wh)} Wh`,
    ];
  }

  if (key === 'loss') {
    const effPct = safe(state.transformer.efficiency) <= 1 ? safe(state.transformer.efficiency) * 100 : safe(state.transformer.efficiency);
    const lossPct = Math.max(0, 100 - effPct);
    body = [
      'SYSTEM LOSSES',
      '-------------',
      `Transformer efficiency: ${formatNumber(effPct)} %`,
      `Estimated transformer conversion loss: ${formatNumber(lossPct)} %`,
      `Grid import: ${formatNumber(state.grid.import_kw)} kW`,
      `Grid export: ${formatNumber(state.grid.export_kw)} kW`,
      `Battery PCS efficiency: ${formatNumber(state.pcs.efficiency <= 1 ? state.pcs.efficiency * 100 : state.pcs.efficiency)} %`,
      '',
      'Note: Loss values in this report are derived only from telemetry fields exposed by the current digital twin. No unmeasured feeder loss is invented.',
    ];
  }

  if (key === 'alarm') {
    body = [
      'ALARMS',
      '------',
      `Active alarms: ${state.alarms.length}`,
      ...state.alarms.map((a) => `  - [${a.severity}] ${a.source}: ${a.message} | active=${a.active} | acknowledged=${Boolean(a.acknowledged)} | ${a.timestamp}`),
      '',
      `Alarm history entries: ${alarmHistory.length}`,
      ...alarmHistory.map((a) => `  - [${a.severity}] ${a.source}: ${a.message} | active=${a.active} | acknowledged=${Boolean(a.acknowledged)} | ${a.timestamp}`),
    ];
  }

  return [...header, ...summary, ...body, '', 'END OF REPORT', ''].join('\n');
}

function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function ReportsView({ state }: ReportsViewProps) {
  const [generated, setGenerated] = useState<string | null>(null);

  const totalSolar = state.houses.reduce((sum, h) => sum + safe(h.pv_kw), 0) + safe(state.community.pv_kw);
  const totalLoad = state.houses.reduce((sum, h) => sum + safe(h.load_kw), 0) + safe(state.community.load_kw);

  const handleGenerate = (report: ReportDefinition) => {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `GRIDPULSE_${report.key.toUpperCase().replace(/-/g, '_')}_REPORT_${stamp}.txt`;
    downloadText(filename, buildReport(state, report.key));
    setGenerated(report.title);
    window.setTimeout(() => setGenerated(null), 2500);
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Engineering Reports</h2>
          <p className="mt-1 text-xs text-slate-500">Generate downloadable reports directly from the current digital-twin telemetry.</p>
        </div>
        {generated && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-700">
            ✓ {generated} generated
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {REPORTS.map((report) => (
          <ReportCard key={report.key} report={report} onGenerate={() => handleGenerate(report)} />
        ))}
      </div>

      <div className="bg-slate-50 rounded-lg p-4">
        <h3 className="text-sm font-medium text-slate-700 mb-3">Current System Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <div className="text-slate-600">Total Solar</div>
            <div className="font-bold text-emerald-600">{totalSolar.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Total Load</div>
            <div className="font-bold text-blue-600">{totalLoad.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Grid Import</div>
            <div className="font-bold text-amber-600">{state.grid.import_kw.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Grid Export</div>
            <div className="font-bold text-cyan-600">{state.grid.export_kw.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Transformer Loading</div>
            <div className="font-bold text-slate-900">{state.transformer.loading_percent.toFixed(1)}%</div>
          </div>
          <div>
            <div className="text-slate-600">Battery SOC</div>
            <div className="font-bold text-purple-600">{state.battery.soc_percent.toFixed(1)}%</div>
          </div>
          <div>
            <div className="text-slate-600">Frequency</div>
            <div className="font-bold text-slate-900">{state.frequency.toFixed(2)} Hz</div>
          </div>
          <div>
            <div className="text-slate-600">Active Alarms</div>
            <div className="font-bold text-red-600">{state.alarms.length}</div>
          </div>
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-700">
          <strong>Reports:</strong> each Generate button downloads a report immediately using the current system telemetry. This also works in deterministic Demo Mode without the backend.
        </p>
      </div>
    </div>
  );
}

function ReportCard({ report, onGenerate }: { report: ReportDefinition; onGenerate: () => void }) {
  return (
    <div
      className="border border-slate-200 rounded-lg p-4 hover:border-cyan-300 hover:shadow-sm transition-all cursor-pointer"
      onClick={onGenerate}
      role="button"
      tabIndex={0}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onGenerate();
        }
      }}
    >
      <div className="flex items-start justify-between mb-2">
        <span className="text-2xl" aria-hidden="true">{report.icon}</span>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onGenerate();
          }}
          className="text-xs px-2.5 py-1.5 bg-cyan-50 text-cyan-700 rounded hover:bg-cyan-100 font-medium"
        >
          Generate
        </button>
      </div>
      <h3 className="text-sm font-medium text-slate-900 mb-1">{report.title}</h3>
      <p className="text-xs text-slate-500">{report.description}</p>
    </div>
  );
}
