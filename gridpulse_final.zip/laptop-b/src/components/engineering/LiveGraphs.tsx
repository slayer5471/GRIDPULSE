import { useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';
import { TelemetryState } from '../../services/api';

function getLvVoltage(state: TelemetryState) {
  return state.buses?.find((b: any) => b?.type === 'LV' && typeof b?.voltage_v === 'number')?.voltage_v ??
    state.buses?.find((b: any) => typeof b?.voltage_v === 'number')?.voltage_v ?? 415;
}

export default function LiveGraphs({ state }: { state: TelemetryState }) {
  const history = useMemo(() => {
    const raw = Array.isArray(state.history) ? state.history : [];
    return raw.slice(-60).map((p: any, index: number) => ({
      ...p,
      label: new Date(p.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      index,
      voltage_v: typeof p.voltage_v === 'number' ? p.voltage_v : getLvVoltage(state),
      frequency_hz: typeof p.frequency_hz === 'number' ? p.frequency_hz : state.frequency,
      transformer_temperature_c: typeof p.transformer_temperature_c === 'number' ? p.transformer_temperature_c : state.transformer.temperature_c,
    }));
  }, [state.history, state.buses]);

  const fallback = useMemo(() => [{
    label: new Date(state.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    solar_kw: 0,
    load_kw: 0,
    grid_import_kw: state.grid.import_kw,
    grid_export_kw: state.grid.export_kw,
    battery_soc: state.battery.soc_percent,
    battery_power_kw: state.battery.power_kw,
    transformer_loading: state.transformer.loading_percent,
    voltage_v: getLvVoltage(state),
    frequency_hz: state.frequency,
    transformer_temperature_c: state.transformer.temperature_c,
  }], [state]);

  const data = history.length ? history : fallback;

  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900">Live Electrical Trends</h2>
          <p className="text-xs text-slate-500">Actual telemetry history from the Circuit Host.</p>
        </div>
        <span className="text-[10px] uppercase tracking-wider text-slate-400">{data.length} samples</span>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <ChartCard title="Solar vs Load" subtitle="kW">
          <ResponsiveContainer width="100%" height={230}>
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="label" minTickGap={28} tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="solar_kw" name="Solar" stroke="#f59e0b" fill="#fef3c7" strokeWidth={2} />
              <Area type="monotone" dataKey="load_kw" name="Load" stroke="#2563eb" fill="#dbeafe" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Grid Exchange" subtitle="kW">
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="label" minTickGap={28} tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="grid_import_kw" name="Import" stroke="#dc2626" dot={false} strokeWidth={2} />
              <Line type="monotone" dataKey="grid_export_kw" name="Export" stroke="#059669" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="BESS SOC & Power" subtitle="% / kW">
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="label" minTickGap={28} tick={{ fontSize: 10 }} />
              <YAxis yAxisId="soc" domain={[0, 100]} tick={{ fontSize: 10 }} />
              <YAxis yAxisId="power" orientation="right" tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend />
              <Line yAxisId="soc" type="monotone" dataKey="battery_soc" name="SOC %" stroke="#7c3aed" dot={false} strokeWidth={2.5} />
              <Line yAxisId="power" type="monotone" dataKey="battery_power_kw" name="BESS Power kW" stroke="#0891b2" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Transformer Loading & Voltage" subtitle="% / V">
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="label" minTickGap={28} tick={{ fontSize: 10 }} />
              <YAxis yAxisId="loading" domain={[0, 120]} tick={{ fontSize: 10 }} />
              <YAxis yAxisId="voltage" orientation="right" domain={[390, 425]} tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend />
              <Line yAxisId="loading" type="monotone" dataKey="transformer_loading" name="TX Load %" stroke="#ea580c" dot={false} strokeWidth={2.5} />
              <Line yAxisId="voltage" type="monotone" dataKey="voltage_v" name="LV Voltage V" stroke="#0f766e" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </section>
  );
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-semibold text-slate-800">{title}</h3>
        <span className="text-[10px] text-slate-400">{subtitle}</span>
      </div>
      {children}
    </div>
  );
}
