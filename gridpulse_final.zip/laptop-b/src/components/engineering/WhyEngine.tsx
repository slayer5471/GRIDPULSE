import { TelemetryState } from '../../services/api';

interface WhyEngineProps {
  state: TelemetryState;
  assetId: string;
}

export default function WhyEngine({ state, assetId }: WhyEngineProps) {
  const getExplanation = () => {
    if (assetId === 'TX-01') {
      return {
        question: `Why is ${assetId} at ${state.transformer.loading_percent.toFixed(1)}% loading?`,
        answer: `The transformer loading is ${state.transformer.loading_percent.toFixed(1)}% due to current demand from connected loads.`,
        factors: [
          { label: 'Total Load', value: `${state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw} kW` },
          { label: 'Solar Generation', value: `${state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw} kW` },
          { label: 'Battery Power', value: `${state.battery.power_kw} kW` },
        ]
      };
    }
    if (assetId.startsWith('HOUSE-')) {
      const house = state.houses.find(h => h.id === assetId);
      if (house) {
        return {
          question: `Where does energy for ${assetId} come from?`,
          answer: `This load consumes ${house.load_kw.toFixed(1)} kW. Energy is supplied by solar, battery, and grid based on current conditions.`,
          factors: [
            { label: 'Load', value: `${house.load_kw.toFixed(1)} kW` },
            { label: 'PV Generation', value: `${house.pv_kw.toFixed(1)} kW` },
            { label: 'Net Power', value: `${house.net_kw.toFixed(1)} kW` },
          ]
        };
      }
    }
    return null;
  };

  const explanation = getExplanation();
  if (!explanation) return null;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-purple-600">💡</span>
        Why?
      </h3>
      
      <div className="bg-purple-50 rounded p-3 mb-3">
        <div className="text-xs text-purple-700 font-medium mb-1">Question</div>
        <div className="text-sm text-slate-900">{explanation.question}</div>
      </div>

      <div className="bg-slate-50 rounded p-3 mb-3">
        <div className="text-xs text-slate-500 font-medium mb-1">Answer</div>
        <div className="text-xs text-slate-700">{explanation.answer}</div>
      </div>

      <div>
        <div className="text-xs text-slate-500 font-medium mb-2">Contributing Factors</div>
        <div className="space-y-1">
          {explanation.factors.map((factor, idx) => (
            <div key={idx} className="flex justify-between text-xs bg-slate-50 rounded px-2 py-1">
              <span className="text-slate-600">{factor.label}</span>
              <span className="font-medium text-slate-900">{factor.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
