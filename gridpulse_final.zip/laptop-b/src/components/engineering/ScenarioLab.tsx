import { AlertTriangle, BatteryCharging, RotateCcw, Sun, ZapOff } from 'lucide-react';
import { useState } from 'react';
import { api, TelemetryState } from '../../services/api';

const groups = [
  { title: 'Energy balance', items: [
    ['SOLAR_DEFICIT','Solar < Load'], ['SOLAR_MATCH','Solar = Load'], ['SOLAR_SURPLUS','Solar > Load'], ['EVENING_PEAK','Evening Peak'], ['HIGH_SOLAR','High Solar'], ['HIGH_LOAD','High Load'],
  ]},
  { title: 'Grid / asset events', items: [
    ['TRANSFORMER_OVERLOAD','Transformer Overload'], ['GRID_OUTAGE','Grid Outage'], ['VOLTAGE_SAG','Voltage Sag'], ['VOLTAGE_SWELL','Voltage Swell'], ['FEEDER_OUTAGE','Feeder Outage'], ['PV_TRIP','PV Trip'], ['PCS_TRIP','PCS Trip'],
  ]},
  { title: 'BESS / cyber', items: [
    ['BATTERY_CHARGE','Force BESS Charge'], ['BATTERY_DISCHARGE','Force BESS Discharge'], ['BATTERY_LOW','BESS Low SOC'], ['HIGH_HARMONICS','High Harmonics'], ['UNPLANNED_ISLANDING','Unplanned Islanding'], ['FDIA','False Data Injection'],
  ]},
];

export default function ScenarioLab({ state }: { state: TelemetryState }) {
  const [busy, setBusy] = useState<string | null>(null);
  const active = state.scenario?.id || 'NORMAL';
  const apply = async (id: string) => {
    setBusy(id);
    try { await api.applyScenario(id); } finally { setBusy(null); }
  };
  return <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
    <div className="flex items-center justify-between">
      <div><div className="text-[10px] uppercase tracking-widest text-cyan-600 font-semibold">SCENARIO LAB</div><h2 className="text-lg font-bold text-slate-900">Live operating scenarios</h2></div>
      <button onClick={() => apply('NORMAL')} className="px-3 py-2 text-xs rounded-lg border border-slate-200 hover:bg-slate-50 flex items-center gap-2"><RotateCcw size={14}/>Reset</button>
    </div>
    <div className="text-xs text-slate-500">Active: <span className="font-semibold text-slate-800">{state.scenario?.name || active}</span>. Each scenario changes backend state and can trigger real telemetry, power-flow changes and alarms.</div>
    {groups.map(group => <div key={group.title}><div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold mb-2">{group.title}</div><div className="grid grid-cols-2 md:grid-cols-3 gap-2">{group.items.map(([id,label]) => {
      const activeBtn = active === id;
      return <button key={id} disabled={busy!==null} onClick={() => apply(id)} className={`text-left rounded-lg border px-3 py-2 text-xs transition ${activeBtn ? 'border-cyan-400 bg-cyan-50 text-cyan-800' : 'border-slate-200 hover:border-cyan-300 hover:bg-slate-50 text-slate-700'}`}>
        <div className="flex items-center gap-2"><IconFor id={id}/><span className="font-semibold">{busy===id ? 'Applying…' : label}</span></div>
      </button>;
    })}</div></div>)}
    <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-[10px] leading-relaxed text-slate-500">Use <b>Solar &gt; Load</b> to see charging/export, <b>Solar &lt; Load</b> to see local support/import, <b>Evening Peak</b> or <b>Transformer Overload</b> to trigger stress alarms, and <b>Grid Outage</b> to demonstrate BESS-backed islanded support.</div>
  </div>;
}
function IconFor({id}:{id:string}){ if(id.includes('SOLAR')) return <Sun size={13}/>; if(id.includes('BATTERY')) return <BatteryCharging size={13}/>; if(id==='GRID_OUTAGE'||id==='PV_TRIP'||id==='PCS_TRIP'||id==='UNPLANNED_ISLANDING') return <ZapOff size={13}/>; return <AlertTriangle size={13}/>; }
