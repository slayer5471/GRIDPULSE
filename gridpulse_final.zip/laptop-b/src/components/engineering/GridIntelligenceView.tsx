import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { Activity, Battery, BrainCircuit, CloudSun, Cpu, Gauge, LockKeyhole, Network, ShieldCheck, Zap } from 'lucide-react';
import { api, TelemetryState } from '../../services/api';

interface Props {
  state: TelemetryState;
}

export default function GridIntelligenceView({ state }: Props) {
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const data = await api.getIntelligenceSummary();
        if (!cancelled) { setSummary(data); setError(null); }
      } catch (e: any) {
        if (!cancelled) setError(e?.message || 'Backend intelligence service unavailable');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    const timer = setInterval(load, 2500);
    return () => { cancelled = true; clearInterval(timer); };
  }, []);

  const latestForecast = summary?.forecast?.forecast?.slice(0, 6) || [];
  const forecastPeak = useMemo(() => latestForecast.reduce((m: number, x: any) => Math.max(m, Number(x.load_kw || 0)), 0), [latestForecast]);
  const risk = Number(summary?.cyber?.fdia_risk_percent || 0);

  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-cyan-900 text-white p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-300 text-xs font-semibold uppercase tracking-[0.16em]">
              <BrainCircuit size={15} /> Grid Intelligence Fabric
            </div>
            <h2 className="text-xl font-bold mt-1">Physics + Forecast + Optimization + Cyber Safety</h2>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl">Live local decision layer built around the two-laptop GRIDPULSE architecture. No cloud dependency is required for the demo path.</p>
          </div>
          <div className="text-right text-xs text-slate-300">
            <div>Sequence {state.sequence}</div>
            <div className="mt-1 text-emerald-300">{loading ? 'Updating…' : 'ONLINE'}</div>
          </div>
        </div>
      </div>

      {error && <div className="p-3 rounded-xl border border-amber-200 bg-amber-50 text-amber-800 text-xs">{error}</div>}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Metric icon={<Gauge size={16} />} label="Forecast peak" value={`${forecastPeak.toFixed(1)} kW`} sub="next 6 horizons" />
        <Metric icon={<Battery size={16} />} label="AI dispatch" value={`${Number(summary?.dispatch?.recommended_battery_power_kw || 0).toFixed(1)} kW`} sub="+ discharge / − charge" />
        <Metric icon={<Zap size={16} />} label="Volt-VAR" value={`${Number(summary?.inverter?.volt_var_q_kvar || 0).toFixed(1)} kVAr`} sub={`${Number(summary?.inverter?.voltage_pu || 1).toFixed(3)} p.u.`} />
        <Metric icon={<ShieldCheck size={16} />} label="Physics gate" value={summary?.cyber?.status || 'PASS'} sub={`${risk.toFixed(1)}% FDIA risk`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title="Forecasting fabric" icon={<CloudSun size={17} />}>
          <div className="flex items-center justify-between text-xs mb-3">
            <span className="font-semibold text-slate-800">{summary?.forecast?.model || 'TFT-style local surrogate'}</span>
            <span className="text-slate-500">15 min steps</span>
          </div>
          <div className="space-y-2">
            {latestForecast.map((x: any, idx: number) => (
              <div key={idx} className="grid grid-cols-5 gap-2 text-[11px] items-center">
                <div className="text-slate-500">+{idx + 1}</div>
                <div className="font-medium">☀ {Number(x.solar_kw).toFixed(1)}</div>
                <div className="font-medium">⌂ {Number(x.load_kw).toFixed(1)}</div>
                <div className={`${Number(x.net_kw) > 0 ? 'text-amber-700' : 'text-emerald-700'} font-semibold`}>{Number(x.net_kw) > 0 ? 'DEFICIT' : 'SURPLUS'}</div>
                <div className="text-slate-400 text-right">{Math.round(Number(x.confidence) * 100)}%</div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Economic dispatch" icon={<Cpu size={17} />}>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Recommended BESS" value={`${Number(summary?.dispatch?.recommended_battery_power_kw || 0).toFixed(2)} kW`} />
            <Stat label="Projected SoC" value={`${Number(summary?.dispatch?.projected_soc || state.battery.soc_percent).toFixed(1)} %`} />
            <Stat label="Projected import" value={`${Number(summary?.dispatch?.projected_import_kw || 0).toFixed(2)} kW`} />
            <Stat label="Projected TX loading" value={`${Number(summary?.dispatch?.projected_transformer_loading || state.transformer.loading_percent).toFixed(1)} %`} />
          </div>
          <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600">{summary?.dispatch?.reason || 'Economic + degradation + transformer constraints'}</div>
        </Panel>

        <Panel title="Smart inverter" icon={<Activity size={17} />}>
          <div className="space-y-3">
            <Row label="PCC voltage" value={`${Number(summary?.inverter?.voltage_pu || 1).toFixed(3)} p.u.`} />
            <Row label="Volt-VAR response" value={`${Number(summary?.inverter?.volt_var_q_kvar || 0).toFixed(2)} kVAr`} />
            <Row label="Volt-Watt curtailment" value={`${Number(summary?.inverter?.volt_watt_curtail_percent || 0).toFixed(1)} %`} />
            <Row label="Profile" value={summary?.inverter?.standards_profile || 'IEEE 1547-inspired'} />
          </div>
        </Panel>

        <Panel title="Protocol + cyber layer" icon={<Network size={17} />}>
          <div className="space-y-3">
            <Row icon={<Network size={14} />} label="IEEE 2030.5" value={summary?.protocol?.ieee_2030_5?.enabled ? 'FUNCTION SETS READY' : 'OFF'} />
            <Row icon={<LockKeyhole size={14} />} label="Modbus TCP" value={summary?.protocol?.modbus_tcp?.enabled ? 'REGISTER MAP READY' : 'OFF'} />
            <Row icon={<ShieldCheck size={14} />} label="TLS / PKI" value={summary?.cyber?.tls13_ready ? 'READY' : 'OFF'} />
            <Row icon={<ShieldCheck size={14} />} label="FDIA physics gate" value={summary?.cyber?.status || 'PASS'} />
          </div>
        </Panel>
      </div>

      <Panel title="Battery life analytics" icon={<Battery size={17} />}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Stat label="Equivalent full cycles" value={Number(summary?.battery_degradation?.equivalent_full_cycles || 0).toFixed(3)} />
          <Stat label="Average DoD" value={`${Number(summary?.battery_degradation?.average_cycle_depth_percent || 0).toFixed(1)} %`} />
          <Stat label="Damage fraction" value={`${(Number(summary?.battery_degradation?.damage_fraction || 0) * 100).toFixed(3)} %`} />
          <Stat label="Estimated life" value={`${Number(summary?.battery_degradation?.life_percent || 100).toFixed(2)} %`} />
        </div>
      </Panel>
    </div>
  );
}

function Metric({ icon, label, value, sub }: { icon: ReactNode; label: string; value: string; sub: string }) {
  return <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm"><div className="flex items-center gap-2 text-cyan-600 text-xs font-semibold">{icon}{label}</div><div className="text-lg font-bold text-slate-900 mt-1">{value}</div><div className="text-[10px] text-slate-500 mt-1">{sub}</div></div>;
}
function Panel({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm"><div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-4">{icon}{title}</div>{children}</div>;
}
function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-slate-200 bg-slate-50 p-3"><div className="text-[10px] uppercase tracking-wide text-slate-500">{label}</div><div className="font-bold text-slate-900 mt-1">{value}</div></div>;
}
function Row({ icon, label, value }: { icon?: ReactNode; label: string; value: string }) {
  return <div className="flex items-center justify-between gap-3 text-xs"><div className="flex items-center gap-2 text-slate-500">{icon}{label}</div><div className="font-semibold text-slate-800 text-right">{value}</div></div>;
}
