import React from 'react';
import { Activity, Battery, Gauge, Radio, ShieldCheck, Thermometer, Waves, Zap } from 'lucide-react';
import { TelemetryState } from '../../services/api';

type Props = { state: TelemetryState };

const Card = ({children, className='' }: {children: React.ReactNode; className?: string}) =>
  <section className={`rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_7px_24px_rgba(15,23,42,.025)] ${className}`}>{children}</section>;

const Chip = ({label, tone='slate'}:{label:string;tone?:'green'|'amber'|'red'|'violet'|'slate'}) => {
  const c={green:'bg-emerald-50 text-emerald-700',amber:'bg-amber-50 text-amber-700',red:'bg-red-50 text-red-700',violet:'bg-violet-50 text-violet-700',slate:'bg-slate-100 text-slate-600'} as const;
  return <span className={`rounded-full px-2.5 py-1 text-[9px] font-semibold ${c[tone]}`}>{label}</span>;
};

function Metric({label,value,unit,icon}:{label:string;value:string|number;unit?:string;icon:React.ReactNode}){
  return <div className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"><div className="flex items-center gap-2 text-violet-600"><div className="flex h-7 w-7 items-center justify-center rounded-lg bg-white">{icon}</div><span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">{label}</span></div><div className="mt-3 flex items-baseline gap-1"><span className="text-[21px] font-semibold tracking-tight">{value}</span>{unit&&<span className="text-[10px] text-slate-400">{unit}</span>}</div></div>;
}

export default function AdvancedGridIntelligence({state}:Props){
  const a:any=state.advanced||{};
  const tx=a.transformer_health||{};
  const h=a.harmonics||{};
  const b=a.battery_health||{};
  const inv=a.smart_inverter||{};
  const mg=a.microgrid||{};
  const dga=a.dga||{};
  const co=a.co_simulation||{};
  const mode=String(mg.mode||'GRID_CONNECTED');
  const txTone=String(tx.health||'HEALTHY')==='CRITICAL'?'red':String(tx.health||'HEALTHY')==='WARNING'?'amber':'green';
  const hTone=String(h.status||'NORMAL')==='CRITICAL'?'red':String(h.status||'NORMAL')==='WARNING'?'amber':'green';
  const mgTone=mode==='ISLANDED'?'red':mode==='RESYNC'?'amber':'green';
  return <div className="space-y-5">
    <div className="flex items-end justify-between gap-4"><div><h2 className="text-[16px] font-semibold tracking-tight">Advanced Grid Intelligence</h2><p className="mt-0.5 text-[11px] text-slate-400">High-fidelity power-system models, co-simulation readiness and autonomous grid controls.</p></div><div className="flex gap-2"><Chip label={co.fallback_active?'Deterministic fallback':'High-fidelity stack'} tone={co.fallback_active?'amber':'green'}/><Chip label={`${co.active_federates||0} federates`} tone="violet"/></div></div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Metric label="Transformer Hot-Spot" value={Number(tx.hotspot_temperature_c||0).toFixed(1)} unit="°C" icon={<Thermometer size={14}/>}/>
      <Metric label="Aging Acceleration" value={Number(tx.aging_acceleration_factor||0).toFixed(2)} unit="x" icon={<Activity size={14}/>}/>
      <Metric label="Battery SOH" value={Number(b.soh_percent||0).toFixed(1)} unit="%" icon={<Battery size={14}/>}/>
      <Metric label="THD-V" value={Number(h.thd_voltage_percent||0).toFixed(1)} unit="%" icon={<Waves size={14}/>}/>
    </div>
    <div className="grid gap-4 xl:grid-cols-3">
      <Card><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Thermometer size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Transformer Thermal Model</div><div className="text-[9px] text-slate-400">IEEE C57.91 reference model</div></div></div><Chip label={String(tx.health||'HEALTHY')} tone={txTone}/></div><div className="mt-4 grid grid-cols-2 gap-3"><Metric label="Ambient" value={Number(tx.ambient_c||0).toFixed(1)} unit="°C" icon={<Thermometer size={12}/>}/><Metric label="Top-Oil Rise" value={Number(tx.top_oil_rise_c||0).toFixed(1)} unit="°C" icon={<Gauge size={12}/>}/><Metric label="Hotspot Rise" value={Number(tx.hotspot_rise_c||0).toFixed(1)} unit="°C" icon={<Gauge size={12}/>}/><Metric label="Life Loss" value={Number(tx.estimated_insulation_life_loss_percent||0).toFixed(4)} unit="%" icon={<Activity size={12}/>}/></div></Card>
      <Card><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Waves size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Power Quality & Harmonics</div><div className="text-[9px] text-slate-400">THD / K-factor stress monitor</div></div></div><Chip label={String(h.status||'NORMAL')} tone={hTone}/></div><div className="mt-4 grid grid-cols-2 gap-3"><Metric label="THD-V" value={Number(h.thd_voltage_percent||0).toFixed(2)} unit="%" icon={<Waves size={12}/>}/><Metric label="THD-I" value={Number(h.thd_current_percent||0).toFixed(2)} unit="%" icon={<Waves size={12}/>}/><Metric label="K-Factor" value={Number(h.k_factor||0).toFixed(2)} unit="" icon={<Gauge size={12}/>}/><Metric label="Derating" value={Number(h.transformer_derating_percent||0).toFixed(1)} unit="%" icon={<ShieldCheck size={12}/>}/></div></Card>
      <Card><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Battery size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">BESS Degradation</div><div className="text-[9px] text-slate-400">Rainflow + calendar/cycle stress</div></div></div><Chip label={`${Number(b.soh_percent||0).toFixed(1)}% SOH`} tone="green"/></div><div className="mt-4 grid grid-cols-2 gap-3"><Metric label="Fade" value={Number(b.capacity_fade_percent||0).toFixed(2)} unit="%" icon={<TrendingIcon/>}/><Metric label="EFC" value={Number(b.equivalent_full_cycles||0).toFixed(2)} icon={<Activity size={12}/>}/><Metric label="Throughput" value={Number(b.throughput_kwh||0).toFixed(1)} unit="kWh" icon={<Zap size={12}/>}/><Metric label="LCOS" value={Number(b.lcos_estimate_inr_per_kwh||0).toFixed(2)} unit="₹/kWh" icon={<Gauge size={12}/>}/></div></Card>
    </div>
    <div className="grid gap-4 xl:grid-cols-[1.3fr_.7fr]">
      <Card><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Radio size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Co-Simulation Fabric</div><div className="text-[9px] text-slate-400">OpenDSS • pandapower • PyPSA • HELICS • MQTT • Wokwi contract</div></div></div><Chip label={String(co.synchronization||'LOCAL_TIME_BARRIER')} tone="violet"/></div><div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">{Object.entries(co.federates||{}).map(([key,val]:any)=><div key={key} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3"><div className="text-[10px] font-semibold">{val.name}</div><div className="mt-1 text-[9px] text-slate-400">{key}</div><div className="mt-2"><Chip label={val.installed?'INSTALLED':'ADAPTER READY'} tone={val.installed?'green':'amber'}/></div></div>)}</div></Card>
      <Card><div className="flex items-center justify-between"><div className="flex items-center gap-2"><ShieldCheck size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Autonomous Microgrid</div><div className="text-[9px] text-slate-400">Islanding / load priority / resynchronization</div></div></div><Chip label={mode.replace('_',' ')} tone={mgTone}/></div><div className="mt-4 space-y-3 text-[10px]"><div className="flex justify-between"><span className="text-slate-400">PCC breaker</span><b>{mg.pcc_breaker||'CLOSED'}</b></div><div className="flex justify-between"><span className="text-slate-400">Grid-forming</span><b>{mg.grid_forming?'ACTIVE':'OFF'}</b></div><div className="flex justify-between"><span className="text-slate-400">Load shed</span><b>{Number(mg.load_shed_kw||0).toFixed(1)} kW</b></div><div className="flex justify-between"><span className="text-slate-400">Resync</span><b>{mg.resynchronization||'NOT_REQUIRED'}</b></div>{mg.progress_percent!==undefined&&<div><div className="mb-1 flex justify-between text-[9px] text-slate-400"><span>Resync progress</span><span>{Number(mg.progress_percent).toFixed(0)}%</span></div><div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-violet-500" style={{width:`${Math.max(0,Math.min(100,Number(mg.progress_percent)))}%`}}/></div></div>}</div></Card>
    </div>
    <div className="grid gap-4 xl:grid-cols-2">
      <Card><div className="flex items-center gap-2"><Gauge size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Smart Inverter Control</div><div className="text-[9px] text-slate-400">Volt-VAR / Volt-Watt / ride-through</div></div></div><div className="mt-4 grid grid-cols-4 gap-3"><Metric label="Q Support" value={Number(inv.volt_var_q_kvar||0).toFixed(1)} unit="kvar" icon={<Zap size={12}/>}/><Metric label="Curtailment" value={Number(inv.volt_watt_curtail_percent||0).toFixed(1)} unit="%" icon={<Gauge size={12}/>}/><Metric label="Ride Through" value={inv.ride_through?'YES':'NO'} icon={<ShieldCheck size={12}/>}/><Metric label="Grid Support" value={String(inv.grid_support||'NEUTRAL')} icon={<Activity size={12}/>}/></div></Card>
      <Card><div className="flex items-center gap-2"><ShieldCheck size={16} className="text-violet-600"/><div><div className="text-[12px] font-semibold">Transformer DGA / Duval Diagnostic</div><div className="text-[9px] text-slate-400">Simulated gas signature for digital-twin maintenance</div></div></div><div className="mt-4 grid grid-cols-3 gap-3"><Metric label="CH₄" value={Number(dga.methane_percent||0).toFixed(1)} unit="%" icon={<Activity size={12}/>}/><Metric label="C₂H₄" value={Number(dga.ethylene_percent||0).toFixed(1)} unit="%" icon={<Activity size={12}/>}/><Metric label="C₂H₂" value={Number(dga.acetylene_percent||0).toFixed(1)} unit="%" icon={<Activity size={12}/>}/></div><div className="mt-3 rounded-xl bg-slate-50 p-3 text-[10px]"><span className="text-slate-400">Diagnosis</span><div className="mt-1 font-semibold">{dga.duval_region||'Normal / no dominant fault signature'}</div></div></Card>
    </div>
  </div>;
}

function TrendingIcon(){return <Activity size={12}/>}
