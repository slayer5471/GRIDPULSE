import { TelemetryState } from '../../services/api';

interface AnomalyViewProps {
  state: TelemetryState;
  onAssetSelect: (id: string) => void;
}

export default function AnomalyView({ state, onAssetSelect }: AnomalyViewProps) {
  const anomalies = detectAnomalies(state);

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-amber-600">🔍</span>
        Anomaly Detection
      </h3>

      {anomalies.length === 0 ? (
        <div className="text-center py-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-2">
            <span className="text-xl">✓</span>
          </div>
          <p className="text-xs text-slate-600">No anomalies detected</p>
        </div>
      ) : (
        <div className="space-y-2">
          {anomalies.map((anomaly, idx) => (
            <div
              key={idx}
              onClick={() => onAssetSelect(anomaly.asset)}
              className={`rounded p-3 border cursor-pointer hover:shadow-sm transition-shadow ${
                anomaly.severity === 'critical' ? 'bg-red-50 border-red-200' :
                anomaly.severity === 'warning' ? 'bg-amber-50 border-amber-200' :
                'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex items-start justify-between mb-1">
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                  anomaly.severity === 'critical' ? 'bg-red-200 text-red-800' :
                  anomaly.severity === 'warning' ? 'bg-amber-200 text-amber-800' :
                  'bg-blue-200 text-blue-800'
                }`}>
                  {anomaly.severity}
                </span>
                <span className="text-[10px] text-slate-500">{anomaly.asset}</span>
              </div>
              <div className="text-xs font-medium text-slate-900 mb-1">{anomaly.description}</div>
              <div className="text-[10px] text-slate-600">
                <span className="font-medium">{anomaly.metric}:</span> {anomaly.value}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function detectAnomalies(state: TelemetryState) {
  const anomalies: Array<{
    severity: 'critical' | 'warning' | 'info';
    asset: string;
    description: string;
    metric: string;
    value: string;
  }> = [];

  // Check transformer loading
  if (state.transformer.loading_percent > 90) {
    anomalies.push({
      severity: 'critical',
      asset: 'TX-01',
      description: 'Transformer critically overloaded',
      metric: 'Loading',
      value: `${state.transformer.loading_percent.toFixed(1)}%`,
    });
  } else if (state.transformer.loading_percent > 75) {
    anomalies.push({
      severity: 'warning',
      asset: 'TX-01',
      description: 'Transformer heavily loaded',
      metric: 'Loading',
      value: `${state.transformer.loading_percent.toFixed(1)}%`,
    });
  }

  // Check battery SOC
  if (state.battery.soc_percent < 20) {
    anomalies.push({
      severity: 'warning',
      asset: 'BESS-01',
      description: 'Battery SOC low',
      metric: 'SOC',
      value: `${state.battery.soc_percent.toFixed(1)}%`,
    });
  }

  return anomalies;
}
