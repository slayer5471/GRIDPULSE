import { useState } from 'react';
import { Zap } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (username: string, password: string) => Promise<void>;
  onDemoLogin?: () => void;
}

export default function LoginScreen({ onLogin, onDemoLogin }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      await onLogin(username, password);
    } catch (err) {
      setError('Invalid credentials - Backend may be unavailable. Try Demo Mode below.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = () => {
    if (onDemoLogin) {
      onDemoLogin();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-cyan-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 mb-4">
              <Zap size={32} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">GRIDPULSE</h1>
            <p className="text-sm text-slate-500 mt-1">Engineering Control Center</p>
            <p className="text-xs text-slate-400 mt-1">v1.0.0</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
                placeholder="admin, operator, or viewer"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none"
                placeholder="Enter password"
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg font-medium hover:from-cyan-600 hover:to-blue-700 transition-all disabled:opacity-50"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <p className="text-xs text-slate-600 font-medium mb-2">Demo Credentials:</p>
            <div className="space-y-1 text-xs text-slate-500">
              <div>Admin: admin / admin123</div>
              <div>Operator: operator / operator123</div>
              <div>Viewer: viewer / viewer123</div>
            </div>
          </div>

          {onDemoLogin && (
            <div className="mt-4">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-2 bg-white text-slate-500">Or</span>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDemoLogin}
                className="mt-4 w-full py-2.5 bg-gradient-to-r from-slate-600 to-slate-700 text-white rounded-lg font-medium hover:from-slate-700 hover:to-slate-800 transition-all"
              >
                Continue in Demo Mode
              </button>
              <p className="mt-2 text-center text-xs text-slate-500">
                No backend required • Deterministic simulation
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
