// Solarex Results Component - Solar assessment results display
import React from 'react';
import {
  SolarexLocation,
  RoofPolygon,
  SolarSystem,
  MonthlyGeneration,
  SolarAssumptions,
  SystemComparison,
  BatteryOption,
} from '../../types/solarex';
import { formatINR, formatNumber, sqmToSqft } from '../../services/solarexCalculator';
import { Sun, Battery, DollarSign, TrendingUp, Leaf, MapPin, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface SolarexResultsProps {
  location: SolarexLocation;
  roofPolygons: RoofPolygon[];
  usableAreaSqm: number;
  monthlyConsumptionKwh: number;
  tariffPerKwh: number;
  recommendedSystem: SolarSystem;
  monthlyGeneration: MonthlyGeneration[];
  comparisons: SystemComparison[];
  batteryOption: BatteryOption | null;
  assumptions: SolarAssumptions;
  onBack: () => void;
  onSaveProject: () => void;
  onDownloadReport: () => void;
}

export default function SolarexResults({
  location,
  roofPolygons,
  usableAreaSqm,
  monthlyConsumptionKwh,
  tariffPerKwh,
  recommendedSystem,
  monthlyGeneration,
  comparisons,
  batteryOption,
  assumptions,
  onBack,
  onSaveProject,
  onDownloadReport,
}: SolarexResultsProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-cyan-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Your Solar Potential</h1>
            <p className="text-sm text-slate-500 mt-1">
              Based on your roof area and electricity consumption
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={onBack}
              className="px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
            >
              Back to Map
            </button>
            <button
              onClick={onSaveProject}
              className="px-4 py-2 text-sm bg-cyan-600 text-white rounded-lg hover:bg-cyan-700"
            >
              Save Project
            </button>
            <button
              onClick={onDownloadReport}
              className="px-4 py-2 text-sm bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
            >
              Download Report
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl p-8 text-white mb-8 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sun size={24} />
                <span className="text-sm font-medium opacity-90">Recommended System</span>
              </div>
              <div className="text-5xl font-bold">{formatNumber(recommendedSystem.capacity_kw, 1)} kW</div>
              <div className="text-sm opacity-90 mt-1">{recommendedSystem.panel_count} panels</div>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp size={24} />
                <span className="text-sm font-medium opacity-90">Annual Generation</span>
              </div>
              <div className="text-5xl font-bold">{formatNumber(recommendedSystem.annual_generation_kwh / 1000, 1)}k</div>
              <div className="text-sm opacity-90 mt-1">kWh per year</div>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <DollarSign size={24} />
                <span className="text-sm font-medium opacity-90">Monthly Savings</span>
              </div>
              <div className="text-5xl font-bold">{formatINR(recommendedSystem.monthly_savings)}</div>
              <div className="text-sm opacity-90 mt-1">estimated savings</div>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <MetricCard
            icon={<Leaf className="text-emerald-600" size={24} />}
            label="CO2 Reduction"
            value={`${formatNumber(recommendedSystem.annual_co2_reduction_kg / 1000, 1)} tonnes`}
            sublabel="per year"
            color="emerald"
          />
          <MetricCard
            icon={<DollarSign className="text-cyan-600" size={24} />}
            label="Payback Period"
            value={`${formatNumber(recommendedSystem.payback_years, 1)} years`}
            sublabel="estimated"
            color="cyan"
          />
          <MetricCard
            icon={<CheckCircle className="text-blue-600" size={24} />}
            label="Energy Coverage"
            value={`${formatNumber(recommendedSystem.energy_coverage_percent, 0)}%`}
            sublabel="of consumption"
            color="blue"
          />
          <MetricCard
            icon={<MapPin className="text-purple-600" size={24} />}
            label="Roof Utilization"
            value={`${formatNumber((recommendedSystem.required_roof_area_sqm / usableAreaSqm) * 100, 0)}%`}
            sublabel={`${formatNumber(sqmToSqft(recommendedSystem.required_roof_area_sqm), 0)} sq.ft`}
            color="purple"
          />
        </div>

        {/* Location & Roof Info */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Location & Roof Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="text-xs text-slate-500 uppercase mb-1">Location</div>
              <div className="text-sm font-medium text-slate-900">{location.label}</div>
              <div className="text-xs text-slate-500 mt-1">{location.address}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 uppercase mb-1">Roof Areas</div>
              <div className="text-sm font-medium text-slate-900">{roofPolygons.length} area(s) selected</div>
              <div className="text-xs text-slate-500 mt-1">
                Total: {formatNumber(sqmToSqft(usableAreaSqm), 0)} sq.ft usable
              </div>
            </div>
          </div>
        </div>

        {/* System Details */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-4">System Details</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <DetailItem label="System Size" value={`${formatNumber(recommendedSystem.capacity_kw, 1)} kW`} />
            <DetailItem label="Panel Count" value={`${recommendedSystem.panel_count} panels`} />
            <DetailItem label="Panel Capacity" value={`${recommendedSystem.panel_capacity_w} W`} />
            <DetailItem label="Roof Area Required" value={`${formatNumber(sqmToSqft(recommendedSystem.required_roof_area_sqm), 0)} sq.ft`} />
            <DetailItem label="Estimated Cost" value={formatINR(recommendedSystem.estimated_cost)} />
            <DetailItem label="Annual Generation" value={`${formatNumber(recommendedSystem.annual_generation_kwh, 0)} kWh`} />
            <DetailItem label="Annual Savings" value={formatINR(recommendedSystem.annual_savings)} />
            <DetailItem label="Payback Period" value={`${formatNumber(recommendedSystem.payback_years, 1)} years`} />
          </div>
        </div>

        {/* Monthly Generation Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Monthly Generation</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyGeneration}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#64748b" style={{ fontSize: '12px' }} />
                <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="generation_kwh" fill="#06b6d4" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Expected monthly generation based on location and system size
          </p>
        </div>

        {/* System Size Comparison */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Compare System Sizes</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left text-xs font-medium text-slate-500 uppercase py-3">System Size</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Panels</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Annual Generation</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Cost</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Annual Savings</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Payback</th>
                  <th className="text-right text-xs font-medium text-slate-500 uppercase py-3">Coverage</th>
                </tr>
              </thead>
              <tbody>
                {comparisons.map((comp, idx) => (
                  <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3 text-sm font-medium text-slate-900">{comp.size_label}</td>
                    <td className="py-3 text-sm text-right text-slate-700">{comp.system.panel_count}</td>
                    <td className="py-3 text-sm text-right text-slate-700">
                      {formatNumber(comp.system.annual_generation_kwh / 1000, 1)}k kWh
                    </td>
                    <td className="py-3 text-sm text-right text-slate-700">{formatINR(comp.system.estimated_cost)}</td>
                    <td className="py-3 text-sm text-right text-emerald-600 font-medium">
                      {formatINR(comp.system.annual_savings)}
                    </td>
                    <td className="py-3 text-sm text-right text-slate-700">
                      {formatNumber(comp.system.payback_years, 1)} years
                    </td>
                    <td className="py-3 text-sm text-right text-slate-700">
                      {formatNumber(comp.system.energy_coverage_percent, 0)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Battery Option */}
        {batteryOption && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Battery className="text-purple-600" size={20} />
              <h2 className="text-lg font-bold text-slate-900">Battery Option (Optional)</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <DetailItem label="Battery Capacity" value={`${batteryOption.capacity_kwh} kWh`} />
              <DetailItem label="Power Output" value={`${batteryOption.power_kw} kW`} />
              <DetailItem label="Additional Cost" value={formatINR(batteryOption.cost)} />
              <DetailItem label="Backup Duration" value={`${formatNumber(batteryOption.backup_hours, 1)} hours`} />
            </div>
            <p className="text-xs text-slate-500 mt-4">
              Adding a battery can increase self-consumption by approximately {batteryOption.self_consumption_increase_percent}% 
              and provide backup power during outages.
            </p>
          </div>
        )}

        {/* What This Means */}
        <div className="bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-xl border border-emerald-200 p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-3">What This Means</h2>
          <p className="text-sm text-slate-700 leading-relaxed">
            Based on your selected roof area of {formatNumber(sqmToSqft(usableAreaSqm), 0)} sq.ft and estimated 
            electricity consumption of {formatNumber(monthlyConsumptionKwh, 0)} kWh per month, a{' '}
            <strong>{formatNumber(recommendedSystem.capacity_kw, 1)} kW solar system</strong> with{' '}
            {recommendedSystem.panel_count} panels could generate approximately{' '}
            <strong>{formatNumber(recommendedSystem.annual_generation_kwh, 0)} kWh per year</strong> and cover 
            about <strong>{formatNumber(recommendedSystem.energy_coverage_percent, 0)}%</strong> of your estimated 
            annual electricity usage. This could save you approximately{' '}
            <strong>{formatINR(recommendedSystem.annual_savings)} per year</strong> with an estimated payback 
            period of <strong>{formatNumber(recommendedSystem.payback_years, 1)} years</strong>.
          </p>
        </div>

        {/* Assumptions */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Assumptions</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-xs">
            <div>
              <div className="text-slate-500 uppercase mb-1">Panel Efficiency</div>
              <div className="text-slate-900 font-medium">{(assumptions.panel.efficiency * 100).toFixed(0)}%</div>
            </div>
            <div>
              <div className="text-slate-500 uppercase mb-1">System Losses</div>
              <div className="text-slate-900 font-medium">{assumptions.system_loss_percent}%</div>
            </div>
            <div>
              <div className="text-slate-500 uppercase mb-1">Performance Ratio</div>
              <div className="text-slate-900 font-medium">{(assumptions.performance_ratio * 100).toFixed(0)}%</div>
            </div>
            <div>
              <div className="text-slate-500 uppercase mb-1">Tariff</div>
              <div className="text-slate-900 font-medium">{formatINR(assumptions.tariff_per_kwh)}/kWh</div>
            </div>
            <div>
              <div className="text-slate-500 uppercase mb-1">Installation Cost</div>
              <div className="text-slate-900 font-medium">{formatINR(assumptions.installation_cost_per_kw)}/kW</div>
            </div>
            <div>
              <div className="text-slate-500 uppercase mb-1">Emissions Factor</div>
              <div className="text-slate-900 font-medium">{assumptions.emissions_factor_kg_per_kwh} kg CO2/kWh</div>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-4">
            These calculations are estimates based on typical conditions. Actual results may vary based on 
            installation quality, shading, orientation, and other factors.
          </p>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ icon, label, value, sublabel, color }: any) {
  const colors: Record<string, string> = {
    emerald: 'bg-emerald-50 border-emerald-200',
    cyan: 'bg-cyan-50 border-cyan-200',
    blue: 'bg-blue-50 border-blue-200',
    purple: 'bg-purple-50 border-purple-200',
  };

  return (
    <div className={`${colors[color]} border rounded-xl p-4`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-xs font-medium text-slate-600">{label}</span>
      </div>
      <div className="text-2xl font-bold text-slate-900">{value}</div>
      <div className="text-xs text-slate-500 mt-1">{sublabel}</div>
    </div>
  );
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-slate-500 uppercase mb-1">{label}</div>
      <div className="text-sm font-medium text-slate-900">{value}</div>
    </div>
  );
}
