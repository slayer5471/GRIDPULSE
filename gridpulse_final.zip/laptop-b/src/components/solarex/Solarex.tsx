// Solarex Main Component - Complete solar assessment workflow
import React, { useState, useEffect } from 'react';
import {
  SolarexLocation,
  RoofPolygon,
  ExclusionPolygon,
  SolarSystem,
  MonthlyGeneration,
  SolarAssumptions,
  SystemComparison,
  BatteryOption,
  SolarexProject,
} from '../../types/solarex';
import {
  DEFAULT_ASSUMPTIONS,
  calculateRecommendedSystem,
  calculateMonthlyGeneration,
  calculateSystemComparison,
  calculateBatteryOption,
  sqmToSqft,
  formatINR,
} from '../../services/solarexCalculator';
import SolarexMap from './SolarexMap';
import SolarexResults from './SolarexResults';
import { Sun, MapPin, Calculator, ArrowRight, CheckCircle2 } from 'lucide-react';

type SolarexStep = 'landing' | 'map' | 'consumption' | 'results';

export default function Solarex() {
  const [step, setStep] = useState<SolarexStep>('landing');
  const [location, setLocation] = useState<SolarexLocation | null>(null);
  const [roofPolygons, setRoofPolygons] = useState<RoofPolygon[]>([]);
  const [exclusionPolygons, setExclusionPolygons] = useState<ExclusionPolygon[]>([]);
  const [monthlyBill, setMonthlyBill] = useState<number>(3000);
  const [monthlyConsumption, setMonthlyConsumption] = useState<number>(0);
  const [tariffPerKwh, setTariffPerKwh] = useState<number>(DEFAULT_ASSUMPTIONS.tariff_per_kwh);
  const [assumptions, setAssumptions] = useState<SolarAssumptions>(DEFAULT_ASSUMPTIONS);
  const [recommendedSystem, setRecommendedSystem] = useState<SolarSystem | null>(null);
  const [monthlyGeneration, setMonthlyGeneration] = useState<MonthlyGeneration[]>([]);
  const [comparisons, setComparisons] = useState<SystemComparison[]>([]);
  const [batteryOption, setBatteryOption] = useState<BatteryOption | null>(null);
  const [includeBattery, setIncludeBattery] = useState<boolean>(false);

  // Load saved projects
  useEffect(() => {
    const saved = localStorage.getItem('solarex_projects');
    if (saved) {
      try {
        const projects = JSON.parse(saved);
        // Could load most recent project here
      } catch (e) {
        console.error('Failed to load saved projects:', e);
      }
    }
  }, []);

  // Calculate usable area
  const totalRoofArea = roofPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const totalExclusionArea = exclusionPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const usableArea = totalRoofArea - totalExclusionArea;

  // Handle location select
  const handleLocationSelect = (loc: SolarexLocation) => {
    setLocation(loc);
  };

  // Handle roof polygon add
  const handleRoofPolygonAdd = (polygon: RoofPolygon) => {
    setRoofPolygons(prev => [...prev, polygon]);
  };

  // Handle roof polygon update
  const handleRoofPolygonUpdate = (polygon: RoofPolygon) => {
    setRoofPolygons(prev => prev.map(p => p.id === polygon.id ? polygon : p));
  };

  // Handle roof polygon delete
  const handleRoofPolygonDelete = (id: string) => {
    setRoofPolygons(prev => prev.filter(p => p.id !== id));
  };

  // Handle exclusion polygon add
  const handleExclusionPolygonAdd = (polygon: ExclusionPolygon) => {
    setExclusionPolygons(prev => [...prev, polygon]);
  };

  // Handle exclusion polygon delete
  const handleExclusionPolygonDelete = (id: string) => {
    setExclusionPolygons(prev => prev.filter(p => p.id !== id));
  };

  // Calculate solar system
  const calculateSystem = () => {
    if (usableArea <= 0 || monthlyConsumption <= 0) {
      alert('Please ensure you have selected roof area and entered consumption');
      return;
    }

    const system = calculateRecommendedSystem(usableArea, monthlyConsumption, assumptions);
    setRecommendedSystem(system);

    const monthly = calculateMonthlyGeneration(system, assumptions);
    setMonthlyGeneration(monthly);

    // Create comparisons for different system sizes
    const sizes = [3, 5, 7, 10];
    const comps = sizes.map(size => calculateSystemComparison(size, monthlyConsumption, assumptions));
    setComparisons(comps);

    // Calculate battery option if requested
    if (includeBattery) {
      const battery = calculateBatteryOption(system, monthlyConsumption);
      setBatteryOption(battery);
    } else {
      setBatteryOption(null);
    }

    setStep('results');
  };

  // Save project
  const handleSaveProject = () => {
    if (!location || !recommendedSystem) return;

    const project: SolarexProject = {
      id: `project-${Date.now()}`,
      name: `${location.label} - ${recommendedSystem.capacity_kw}kW`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      location,
      roof_polygons: roofPolygons,
      exclusion_polygons: exclusionPolygons,
      total_roof_area_sqm: totalRoofArea,
      usable_roof_area_sqm: usableArea,
      monthly_bill: monthlyBill,
      monthly_consumption_kwh: monthlyConsumption,
      tariff_per_kwh: tariffPerKwh,
      assumptions,
      recommended_system: recommendedSystem,
      selected_system_size_kw: recommendedSystem.capacity_kw,
      battery_option: batteryOption,
      monthly_generation: monthlyGeneration,
      comparisons,
    };

    // Save to localStorage
    const saved = localStorage.getItem('solarex_projects');
    const projects = saved ? JSON.parse(saved) : [];
    projects.push(project);
    localStorage.setItem('solarex_projects', JSON.stringify(projects));

    alert('Project saved successfully!');
  };

  // Download report
  const handleDownloadReport = () => {
    if (!location || !recommendedSystem) return;

    const report = {
      location: location.label,
      address: location.address,
      roof_area_sqft: sqmToSqft(usableArea).toFixed(0),
      system_size_kw: recommendedSystem.capacity_kw,
      panel_count: recommendedSystem.panel_count,
      annual_generation_kwh: recommendedSystem.annual_generation_kwh,
      annual_savings_inr: recommendedSystem.annual_savings,
      payback_years: recommendedSystem.payback_years,
      co2_reduction_kg: recommendedSystem.annual_co2_reduction_kg,
      estimated_cost_inr: recommendedSystem.estimated_cost,
      generated_at: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `solarex-report-${location.label.replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Landing Page
  if (step === 'landing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-cyan-50">
        {/* Hero Section */}
        <div className="max-w-6xl mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 mb-6 shadow-lg">
              <Sun size={40} className="text-white" />
            </div>
            <h1 className="text-5xl font-bold text-slate-900 mb-4">SOLAREX</h1>
            <p className="text-xl text-slate-600 mb-2">Know your solar potential</p>
            <p className="text-sm text-slate-500 max-w-2xl mx-auto">
              Select your location, map your available roof area, and discover how much solar energy 
              your property could generate. Get instant estimates for system size, cost, savings, and payback.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={() => setStep('map')}
              className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
            >
              <Calculator size={20} className="inline mr-2" />
              Calculate My Solar Potential
            </button>
            <button
              onClick={() => {
                const element = document.getElementById('how-it-works');
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-8 py-4 bg-white text-slate-700 text-lg font-semibold rounded-xl shadow-md hover:shadow-lg transition-all border border-slate-200"
            >
              How It Works
            </button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <FeatureCard
              icon={<MapPin className="text-cyan-600" size={32} />}
              title="Select Location"
              description="Search for your property or use your current location. View satellite imagery to identify your roof."
            />
            <FeatureCard
              icon={<Sun className="text-amber-600" size={32} />}
              title="Map Your Roof"
              description="Draw your roof area on the interactive map. Add multiple sections and mark exclusions."
            />
            <FeatureCard
              icon={<Calculator className="text-emerald-600" size={32} />}
              title="Get Instant Results"
              description="Receive detailed solar assessment with system size, cost, savings, payback period, and CO2 reduction."
            />
          </div>

          {/* How It Works */}
          <div id="how-it-works" className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 mb-16">
            <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">How Solarex Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StepCard number="1" title="Choose Location" description="Search for your address or use GPS to find your property" />
              <StepCard number="2" title="Draw Roof Area" description="Use satellite view to outline your roof sections" />
              <StepCard number="3" title="Enter Usage" description="Provide your monthly electricity bill or consumption" />
              <StepCard number="4" title="Get Results" description="Receive comprehensive solar assessment instantly" />
            </div>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-xl border border-emerald-200 p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-3">Financial Benefits</h3>
              <ul className="space-y-2 text-sm text-slate-700">
                <li>✓ Reduce electricity bills by up to 90%</li>
                <li>✓ Payback period typically 3-5 years</li>
                <li>✓ 25+ years of clean energy generation</li>
                <li>✓ Protection against rising electricity costs</li>
                <li>✓ Potential income from excess generation</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border border-blue-200 p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-3">Environmental Impact</h3>
              <ul className="space-y-2 text-sm text-slate-700">
                <li>✓ Reduce carbon footprint significantly</li>
                <li>✓ Clean, renewable energy source</li>
                <li>✓ No air pollution or emissions</li>
                <li>✓ Contribute to sustainable future</li>
                <li>✓ Energy independence</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Map Step
  if (step === 'map') {
    return (
      <div className="h-screen flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-6 py-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-lg font-bold text-slate-900">Select Your Location & Roof Area</h1>
              <p className="text-xs text-slate-500">Search for your property and draw your roof area on the map</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setStep('landing')}
                className="px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
              >
                Back
              </button>
              <button
                onClick={() => {
                  if (!location) { alert('Confirm your property location first.'); return; }
                  if (roofPolygons.length === 0 || usableArea <= 0) { alert('Draw at least one usable roof area before continuing.'); return; }
                  setStep('consumption');
                }}
                className="px-4 py-2 text-sm bg-slate-900 text-white rounded-xl shadow-sm hover:bg-slate-800"
              >
                Confirm & Continue <CheckCircle2 size={14} className="inline ml-1" />
              </button>
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="flex-1">
          <SolarexMap
            location={location}
            roofPolygons={roofPolygons}
            exclusionPolygons={exclusionPolygons}
            onLocationSelect={handleLocationSelect}
            onRoofPolygonAdd={handleRoofPolygonAdd}
            onRoofPolygonUpdate={handleRoofPolygonUpdate}
            onRoofPolygonDelete={handleRoofPolygonDelete}
            onExclusionPolygonAdd={handleExclusionPolygonAdd}
            onExclusionPolygonDelete={handleExclusionPolygonDelete}
            onMapDone={() => {
              if (!location) { alert('Confirm your property location first.'); return; }
              if (roofPolygons.length === 0 || usableArea <= 0) { alert('Draw at least one usable roof area before continuing.'); return; }
              setStep('consumption');
            }}
            onExit={() => setStep('landing')}
          />
        </div>
      </div>
    );
  }

  // Consumption Step
  if (step === 'consumption') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-cyan-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-8 max-w-2xl w-full">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Enter Your Electricity Usage</h2>
          <p className="text-sm text-slate-500 mb-6">
            Provide your monthly electricity bill or consumption to calculate savings
          </p>

          <div className="space-y-6">
            {/* Monthly Bill */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Monthly Electricity Bill (₹)
              </label>
              <input
                type="number"
                value={monthlyBill}
                onChange={(e) => {
                  const bill = parseFloat(e.target.value) || 0;
                  setMonthlyBill(bill);
                  setMonthlyConsumption(bill / tariffPerKwh);
                }}
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-cyan-500"
                placeholder="e.g., 3000"
              />
            </div>

            {/* Tariff */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Electricity Tariff (₹/kWh)
              </label>
              <input
                type="number"
                value={tariffPerKwh}
                onChange={(e) => {
                  const tariff = parseFloat(e.target.value) || 8.0;
                  setTariffPerKwh(tariff);
                  setMonthlyConsumption(monthlyBill / tariff);
                }}
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-cyan-500"
                placeholder="e.g., 8.0"
                step="0.1"
              />
            </div>

            {/* Calculated Consumption */}
            <div className="bg-slate-50 rounded-lg p-4">
              <div className="text-xs text-slate-500 uppercase mb-1">Estimated Monthly Consumption</div>
              <div className="text-2xl font-bold text-slate-900">{monthlyConsumption.toFixed(0)} kWh</div>
              <div className="text-xs text-slate-500 mt-1">
                Based on your bill and tariff
              </div>
            </div>

            {/* Battery Option */}
            <div className="border border-slate-200 rounded-lg p-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeBattery}
                  onChange={(e) => setIncludeBattery(e.target.checked)}
                  className="w-4 h-4 text-cyan-600 rounded focus:ring-cyan-500"
                />
                <div>
                  <div className="text-sm font-medium text-slate-900">Include Battery Storage</div>
                  <div className="text-xs text-slate-500">Add battery option for backup power and increased self-consumption</div>
                </div>
              </label>
            </div>
          </div>

          <div className="flex gap-3 mt-8">
            <button
              onClick={() => setStep('map')}
              className="flex-1 px-6 py-3 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
            >
              Back to Map
            </button>
            <button
              onClick={calculateSystem}
              className="flex-1 px-6 py-3 text-sm bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:shadow-lg transition-all"
            >
              Calculate Solar Potential
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Results Step
  if (step === 'results' && recommendedSystem && location) {
    return (
      <SolarexResults
        location={location}
        roofPolygons={roofPolygons}
        usableAreaSqm={usableArea}
        monthlyConsumptionKwh={monthlyConsumption}
        tariffPerKwh={tariffPerKwh}
        recommendedSystem={recommendedSystem}
        monthlyGeneration={monthlyGeneration}
        comparisons={comparisons}
        batteryOption={batteryOption}
        assumptions={assumptions}
        onBack={() => setStep('consumption')}
        onSaveProject={handleSaveProject}
        onDownloadReport={handleDownloadReport}
      />
    );
  }

  return null;
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-bold text-slate-900 mb-2">{title}</h3>
      <p className="text-sm text-slate-600">{description}</p>
    </div>
  );
}

function StepCard({ number, title, description }: { number: string; title: string; description: string }) {
  return (
    <div className="text-center">
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 text-white text-xl font-bold mb-3">
        {number}
      </div>
      <h3 className="text-sm font-bold text-slate-900 mb-1">{title}</h3>
      <p className="text-xs text-slate-600">{description}</p>
    </div>
  );
}
