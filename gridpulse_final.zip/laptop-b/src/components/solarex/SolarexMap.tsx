// Solarex Map - high-polish location + roof-area selection workflow.
import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Polygon, Marker, useMapEvents, useMap } from 'react-leaflet';
import { Icon, LatLngTuple } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { RoofPolygon, ExclusionPolygon, SolarexLocation } from '../../types/solarex';
import { calculatePolygonArea, sqmToSqft, createRoofPolygon } from '../../services/solarexCalculator';
import {
  Check, Crosshair, Edit3, LocateFixed, Map as MapIcon, MapPin, Minus, Plus, RotateCcw,
  Satellite, Search, Trash2, X, Navigation, Sparkles
} from 'lucide-react';

interface SolarexMapProps {
  location: SolarexLocation | null;
  roofPolygons: RoofPolygon[];
  exclusionPolygons: ExclusionPolygon[];
  onLocationSelect: (location: SolarexLocation) => void;
  onRoofPolygonAdd: (polygon: RoofPolygon) => void;
  onRoofPolygonUpdate: (polygon: RoofPolygon) => void;
  onRoofPolygonDelete: (id: string) => void;
  onExclusionPolygonAdd: (polygon: ExclusionPolygon) => void;
  onExclusionPolygonDelete: (id: string) => void;
  onMapDone?: () => void;
  onExit?: () => void;
}

const locationIcon = new Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeGJvcmRlciI+PHBhdGggZD0iTTEyIDJDOS4xMyAyIDYgNi4xMyA2IDEwYzAgNS4yNSA2IDEyIDYgMTJzNi02Ljc1IDYtMTJjMC0zLjg3LTMuMTMtNy03LTd6bTAgOS41Yy0xLjM4IDAtMi41LTEuMTItMi41LTIuNXMxLjEyLTIuNSAyLjUtMi41IDIuNSAxLjEyIDIuNSAyLjUtMS4xMiAyLjUtMi41IDIuNXoiIGZpbGw9IiM0MzViZWYiLz48L3N2Zz4=',
  iconSize: [34, 34],
  iconAnchor: [17, 34],
});

function MapViewportSync({ location }: { location: SolarexLocation | null }) {
  const map = useMap();
  useEffect(() => {
    if (!location) return;
    map.flyTo([location.latitude, location.longitude], 19, { duration: 0.8, easeLinearity: 0.25 });
  }, [location, map]);
  return null;
}

function MapClickHandler({ isDrawing, onPoint }: { isDrawing: boolean; onPoint: (point: [number, number]) => void }) {
  useMapEvents({ click: (e) => { if (isDrawing) onPoint([e.latlng.lat, e.latlng.lng]); } });
  return null;
}

export default function SolarexMap({
  location, roofPolygons, exclusionPolygons, onLocationSelect,
  onRoofPolygonAdd, onRoofPolygonUpdate, onRoofPolygonDelete,
  onExclusionPolygonAdd, onExclusionPolygonDelete, onMapDone, onExit,
}: SolarexMapProps) {
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('satellite');
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingMode, setDrawingMode] = useState<'roof' | 'exclusion'>('roof');
  const [currentPolygon, setCurrentPolygon] = useState<[number, number][]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [pendingLocation, setPendingLocation] = useState<SolarexLocation | null>(null);
  const [locating, setLocating] = useState(false);

  const mapCenter: LatLngTuple = location ? [location.latitude, location.longitude] : [12.9716, 77.5946];
  const mapZoom = location ? 18 : 12;
  const totalRoofArea = roofPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const totalExclusionArea = exclusionPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const usableArea = Math.max(0, totalRoofArea - totalExclusionArea);
  const canContinue = Boolean(location && roofPolygons.length > 0 && usableArea > 0);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&q=${encodeURIComponent(searchQuery)}&limit=5`, { headers: { 'Accept-Language': 'en' } });
      const data = await response.json();
      setSearchResults(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const toLocation = (result: any): SolarexLocation => ({
    id: `loc-${Date.now()}`,
    label: result.display_name?.split(',')[0] || 'Selected location',
    address: result.display_name || 'Selected location',
    latitude: Number(result.lat), longitude: Number(result.lon),
    city: result.address?.city || result.address?.town || result.address?.village,
    state: result.address?.state, country: result.address?.country,
  });

  const selectSearchResult = (result: any) => {
    setPendingLocation(toLocation(result));
    setSearchResults([]);
    setSearchQuery('');
  };

  const confirmLocation = () => {
    if (!pendingLocation) return;
    onLocationSelect(pendingLocation);
    setPendingLocation(null);
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition((position) => {
      setPendingLocation({
        id: `loc-${Date.now()}`,
        label: 'Current location',
        address: 'Current browser location',
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });
      setLocating(false);
    }, () => {
      setLocating(false);
      alert('Unable to get your location. Please search manually.');
    }, { enableHighAccuracy: true, timeout: 10000 });
  };

  const finishPolygon = () => {
    if (currentPolygon.length < 3) {
      alert('Please add at least 3 points to create an area.');
      return;
    }
    const area_sqm = calculatePolygonArea(currentPolygon);
    const area_sqft = sqmToSqft(area_sqm);
    if (drawingMode === 'roof') {
      onRoofPolygonAdd(createRoofPolygon(`roof-${Date.now()}`, `Roof ${roofPolygons.length + 1}`, currentPolygon));
    } else {
      onExclusionPolygonAdd({ id: `exclusion-${Date.now()}`, name: `Exclusion ${exclusionPolygons.length + 1}`, coordinates: currentPolygon, area_sqm, area_sqft, reason: 'Obstruction' });
    }
    setCurrentPolygon([]);
    setIsDrawing(false);
  };

  const cancelDrawing = () => { setCurrentPolygon([]); setIsDrawing(false); };
  const undoPoint = () => setCurrentPolygon(prev => prev.slice(0, -1));

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-slate-50">
      <div className="relative z-20 border-b border-slate-200/80 bg-white/95 px-4 py-3 shadow-[0_8px_25px_rgba(15,23,42,.04)] backdrop-blur lg:px-5">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex min-w-[190px] flex-1 items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-50 text-violet-600"><MapPinnedIcon /></div>
            <div><div className="text-[11px] font-semibold text-slate-900">Property & Roof Selection</div><div className="text-[9px] text-slate-400">Confirm a location, then outline usable roof areas.</div></div>
          </div>
          <div className="flex min-w-[300px] flex-[2] gap-2">
            <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 focus-within:border-violet-300 focus-within:bg-white">
              <Search size={14} className="shrink-0 text-slate-400" />
              <input aria-label="Search location" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} placeholder="Search address, city or postal code…" className="min-w-0 flex-1 bg-transparent text-[11px] outline-none" />
              {searchQuery && <button onClick={() => setSearchQuery('')} className="rounded-md p-1 text-slate-400 hover:bg-slate-200"><X size={12}/></button>}
            </div>
            <button onClick={handleSearch} disabled={isSearching} className="rounded-xl bg-slate-900 px-3 text-[10px] font-semibold text-white transition hover:bg-slate-800 disabled:opacity-50">{isSearching ? 'Searching…' : 'Search'}</button>
            <button onClick={handleLocateMe} disabled={locating} className="rounded-xl border border-slate-200 bg-white px-3 text-slate-600 hover:bg-slate-50" title="Use my current location"><LocateFixed size={14}/></button>
          </div>
          <div className="flex items-center gap-1 rounded-xl border border-slate-200 bg-slate-50 p-1">
            <button onClick={() => setMapType('standard')} className={`rounded-lg px-2.5 py-1.5 text-[9px] font-semibold ${mapType==='standard'?'bg-white text-violet-700 shadow-sm':'text-slate-500'}`}><MapIcon size={12} className="mr-1 inline"/>Map</button>
            <button onClick={() => setMapType('satellite')} className={`rounded-lg px-2.5 py-1.5 text-[9px] font-semibold ${mapType==='satellite'?'bg-white text-violet-700 shadow-sm':'text-slate-500'}`}><Satellite size={12} className="mr-1 inline"/>Satellite</button>
          </div>
          <button onClick={onExit} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[10px] font-semibold text-slate-600 hover:bg-slate-50">Exit</button>
        </div>

        {searchResults.length > 0 && (
          <div className="absolute left-4 right-4 top-[70px] z-40 max-h-72 overflow-auto rounded-2xl border border-slate-200 bg-white shadow-[0_22px_60px_rgba(15,23,42,.18)] lg:left-[24%] lg:right-[27%]">
            {searchResults.map((result, idx) => <button key={idx} onClick={() => selectSearchResult(result)} className="flex w-full gap-3 border-b border-slate-100 px-4 py-3 text-left last:border-0 hover:bg-slate-50"><div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-600"><MapPin size={13}/></div><div className="min-w-0"><div className="truncate text-[10px] font-semibold text-slate-900">{result.display_name?.split(',')[0]}</div><div className="mt-0.5 line-clamp-2 text-[9px] text-slate-400">{result.display_name}</div></div></button>)}
          </div>
        )}

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            {!isDrawing ? <>
              <button onClick={() => { setIsDrawing(true); setDrawingMode('roof'); }} className="rounded-xl bg-violet-600 px-3 py-2 text-[10px] font-semibold text-white shadow-[0_8px_20px_rgba(109,93,252,.22)] hover:bg-violet-700"><Plus size={13} className="mr-1 inline"/>Draw Roof</button>
              <button onClick={() => { setIsDrawing(true); setDrawingMode('exclusion'); }} className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[10px] font-semibold text-amber-700 hover:bg-amber-100"><Minus size={13} className="mr-1 inline"/>Add Exclusion</button>
            </> : <>
              <button onClick={undoPoint} disabled={currentPolygon.length===0} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[10px] font-semibold text-slate-600 disabled:opacity-40"><RotateCcw size={13} className="mr-1 inline"/>Undo point</button>
              <button onClick={cancelDrawing} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[10px] font-semibold text-slate-600"><X size={13} className="mr-1 inline"/>Cancel drawing</button>
              <button onClick={finishPolygon} className="rounded-xl bg-emerald-600 px-3 py-2 text-[10px] font-semibold text-white shadow-[0_8px_18px_rgba(16,185,129,.2)]"><Check size={13} className="mr-1 inline"/>Finish {drawingMode === 'roof' ? 'roof' : 'exclusion'} ({currentPolygon.length})</button>
            </>}
          </div>
          <div className="flex items-center gap-2">
            <span className={`rounded-full px-2.5 py-1 text-[9px] font-semibold ${location ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>{location ? 'Location confirmed' : 'Location required'}</span>
            <span className={`rounded-full px-2.5 py-1 text-[9px] font-semibold ${roofPolygons.length ? 'bg-cyan-50 text-cyan-700' : 'bg-slate-100 text-slate-500'}`}>{roofPolygons.length} roof area{roofPolygons.length === 1 ? '' : 's'}</span>
          </div>
        </div>
      </div>

      <div className="relative min-h-0 flex-1">
        <MapContainer center={mapCenter} zoom={mapZoom} className="h-full w-full" style={{ height: '100%', width: '100%' }}>
          {mapType === 'satellite' ? <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}" attribution="Tiles © Esri" /> : <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap contributors' />}
          <MapViewportSync location={location || pendingLocation} />
          {location && <Marker position={[location.latitude, location.longitude]} icon={locationIcon} />}
          {pendingLocation && !location && <Marker position={[pendingLocation.latitude, pendingLocation.longitude]} icon={locationIcon} />}
          {roofPolygons.map(p => <Polygon key={p.id} positions={p.coordinates} pathOptions={{ color: p.color || '#6d5dfc', fillColor: p.color || '#6d5dfc', fillOpacity: .22, weight: 3 }} />)}
          {exclusionPolygons.map(p => <Polygon key={p.id} positions={p.coordinates} pathOptions={{ color:'#ef4444', fillColor:'#ef4444', fillOpacity:.18, weight:2, dashArray:'7 6' }} />)}
          {currentPolygon.length > 0 && <Polygon positions={currentPolygon} pathOptions={{ color: drawingMode==='roof' ? '#0ea5c9' : '#ef4444', fillColor: drawingMode==='roof' ? '#0ea5c9' : '#ef4444', fillOpacity:.18, weight:3, dashArray:'6 6' }} />}
          <MapClickHandler isDrawing={isDrawing} onPoint={(p) => setCurrentPolygon(prev => [...prev, p])} />
        </MapContainer>

        <div className="pointer-events-none absolute left-4 top-4 max-w-[280px] rounded-2xl border border-white/70 bg-white/92 p-3 shadow-[0_18px_45px_rgba(15,23,42,.12)] backdrop-blur lg:left-5 lg:top-5">
          <div className="flex items-center gap-2"><div className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-50 text-violet-600"><Sparkles size={13}/></div><div><div className="text-[10px] font-semibold">Precision solar mapping</div><div className="text-[8px] text-slate-400">Use satellite imagery for roof geometry.</div></div></div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center"><MiniMapStat label="Roof" value={String(roofPolygons.length)} /><MiniMapStat label="Usable" value={`${sqmToSqft(usableArea).toFixed(0)} ft²`} /><MiniMapStat label="Excl." value={`${sqmToSqft(totalExclusionArea).toFixed(0)} ft²`} /></div>
        </div>

        <div className="absolute bottom-4 left-1/2 w-[calc(100%-2rem)] max-w-4xl -translate-x-1/2 rounded-2xl border border-white/80 bg-white/95 p-3 shadow-[0_20px_60px_rgba(15,23,42,.16)] backdrop-blur lg:bottom-5">
          <div className="flex flex-wrap items-center gap-3">
            <div className="min-w-[170px] flex-1"><div className="text-[8px] uppercase tracking-[.16em] text-slate-400">Selection summary</div><div className="mt-1 truncate text-[11px] font-semibold text-slate-900">{location?.address || 'Choose a property location first'}</div><div className="mt-0.5 text-[9px] text-slate-400">{sqmToSqft(usableArea).toFixed(0)} ft² usable roof area</div></div>
            <div className="flex items-center gap-2"><button onClick={onExit} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[10px] font-semibold text-slate-600">Cancel / Exit</button><button disabled={!canContinue} onClick={onMapDone} className="rounded-xl bg-slate-900 px-4 py-2 text-[10px] font-semibold text-white shadow-[0_10px_25px_rgba(15,23,42,.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-35"><Navigation size={13} className="mr-1 inline"/>Confirm selection & continue</button></div>
          </div>
        </div>

        {pendingLocation && <div className="absolute left-1/2 top-1/2 z-30 w-[min(92%,420px)] -translate-x-1/2 -translate-y-1/2 rounded-[24px] border border-white/80 bg-white/96 p-5 shadow-[0_24px_80px_rgba(15,23,42,.24)] backdrop-blur"><div className="flex items-start gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-50 text-violet-600"><Crosshair size={18}/></div><div className="min-w-0"><div className="text-[13px] font-semibold text-slate-900">Confirm property location</div><div className="mt-1 text-[10px] leading-5 text-slate-500">We found this location. Confirm it before drawing the roof so the solar assessment stays tied to the right property.</div><div className="mt-3 rounded-xl bg-slate-50 px-3 py-2.5 text-[10px] font-medium text-slate-700">{pendingLocation.address}</div></div></div><div className="mt-4 flex gap-2"><button onClick={() => setPendingLocation(null)} className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[10px] font-semibold text-slate-600">Choose another</button><button onClick={confirmLocation} className="flex-1 rounded-xl bg-violet-600 px-3 py-2.5 text-[10px] font-semibold text-white shadow-[0_10px_24px_rgba(109,93,252,.2)]"><Check size={13} className="mr-1 inline"/>Confirm location</button></div></div>}

        {isDrawing && <div className="absolute right-4 top-4 rounded-2xl border border-white/80 bg-white/94 p-3 text-[9px] shadow-[0_14px_40px_rgba(15,23,42,.12)] backdrop-blur lg:right-5 lg:top-5"><div className="flex items-center gap-2 font-semibold"><Edit3 size={13} className={drawingMode==='roof'?'text-violet-600':'text-amber-600'}/>{drawingMode==='roof'?'Drawing roof area':'Drawing exclusion area'}</div><div className="mt-1 text-slate-400">Click points on the map. Finish when the boundary is closed.</div></div>}

        <div className="absolute right-4 bottom-[92px] rounded-xl border border-white/80 bg-white/94 p-1 shadow-[0_14px_30px_rgba(15,23,42,.12)] backdrop-blur"><div className="px-2 py-1 text-[8px] uppercase tracking-[.16em] text-slate-400">Map state</div><div className="px-2 pb-1 text-[9px] font-semibold text-slate-700">{location ? location.label : 'Bengaluru default'}</div></div>
      </div>
    </div>
  );
}

function MiniMapStat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg bg-slate-50 px-2 py-1.5"><div className="text-[7px] uppercase tracking-[.1em] text-slate-400">{label}</div><div className="mt-0.5 text-[9px] font-semibold text-slate-800">{value}</div></div>;
}
function MapPinnedIcon() { return <MapPin size={15} />; }
