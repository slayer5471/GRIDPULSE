import { ConnectionStatus } from '../hooks/useWebSocket';
import { WifiOff, RefreshCw, AlertCircle } from 'lucide-react';

interface ConnectionBannerProps {
  status: ConnectionStatus;
  onReconnect: () => void;
}

export default function ConnectionBanner({ status, onReconnect }: ConnectionBannerProps) {
  const configs: Record<string, any> = {
    STALE: {
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      text: 'text-amber-700',
      icon: <AlertCircle size={16} />,
      message: 'Telemetry data is stale',
    },
    RECONNECTING: {
      bg: 'bg-blue-50',
      border: 'border-blue-200',
      text: 'text-blue-700',
      icon: <RefreshCw size={16} className="animate-spin" />,
      message: 'Reconnecting...',
    },
    DISCONNECTED: {
      bg: 'bg-red-50',
      border: 'border-red-200',
      text: 'text-red-700',
      icon: <WifiOff size={16} />,
      message: 'Disconnected from Laptop A',
    },
    DEMO: {
      bg: 'bg-purple-50',
      border: 'border-purple-200',
      text: 'text-purple-700',
      icon: <AlertCircle size={16} />,
      message: 'Demo Mode - Deterministic simulation (no backend)',
    },
  };
  
  const config = configs[status] || {
    bg: 'bg-slate-50',
    border: 'border-slate-200',
    text: 'text-slate-700',
    icon: null,
    message: '',
  };

  return (
    <div className={`${config.bg} border-b ${config.border} px-4 py-2`}>
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className={`flex items-center gap-2 ${config.text}`}>
          {config.icon}
          <span className="text-sm font-medium">{config.message}</span>
        </div>
        <button
          onClick={onReconnect}
          className={`px-3 py-1 text-xs font-medium rounded ${config.bg} ${config.text} border ${config.border} hover:opacity-80`}
        >
          Reconnect
        </button>
      </div>
    </div>
  );
}
