import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity, AlertTriangle, BarChart3, Battery, Bell, Brain, CheckCircle2, ChevronRight,
  CloudSun, Cpu, Download, Factory, Gauge, Grid3X3, History, Home, Leaf, LineChart,
  Menu, Network, Power, Radio, RefreshCw, Settings2, ShieldCheck, Sun, Thermometer,
  TimerReset, TrendingDown, TrendingUp, Wifi, X, Zap, Sparkles
} from 'lucide-react';
import {
  AreaChart, Area, LineChart as RLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine
} from 'recharts';
import { TelemetryState } from '../services/api';
import { ConnectionStatus } from '../hooks/useWebSocket';
import { api } from '../services/api';
import Solarex from './solarex/Solarex';
import EngineeringOneLine from './engineering/EngineeringOneLine';
import DigitalTwin from './engineering/DigitalTwin';
import StudiesCenter from './engineering/StudiesCenter';
import WhyEngine from './engineering/WhyEngine';
import AnomalyView from './engineering/AnomalyView';
import EnergyStory from './engineering/EnergyStory';
import ReplayView from './engineering/ReplayView';
import AIEngineer from './engineering/AIEngineer';
import ReportsView from './engineering/ReportsView';
import ForecastView from './engineering/ForecastView';
import EventsView from './engineering/EventsView';
import LiveGraphs from './engineering/LiveGraphs';
import BESSFlowPanel from './engineering/BESSFlowPanel';
import ScenarioLab from './engineering/ScenarioLab';
import AdvancedGridIntelligence from './engineering/AdvancedGridIntelligence';
import GridOptimizationCenter from './engineering/GridOptimizationCenter';
import GridPulseChatbot from './GridPulseChatbot';

type PageId =
  | 'overview' | 'live' | 'community' | 'analytics' | 'battery' | 'protection'
  | 'ai' | 'grid-intelligence' | 'alerts' | 'history' | 'reports' | 'studio';

type StudioPage =
  | 'one-line' | 'digital-twin' | 'scenario' | 'studies' | 'forecast' | 'events'
  | 'replay' | 'grid-intelligence' | 'ai-engineer' | 'anomaly' | 'energy-story' | 'optimization' | 'advanced';

interface ControlCenterProps {
  state: TelemetryState;
  status: ConnectionStatus;
  userRole: string;
  onLogout: () => void;
}

const NAV: Array<{ id: PageId; label: string; icon: any }> = [
  { id: 'overview', label: 'Overview', icon: Activity },
  { id: 'live', label: 'Live Data', icon: Radio },
  { id: 'community', label: 'Live Community', icon: Home },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'battery', label: 'Battery', icon: Battery },
  { id: 'protection', label: 'Protection', icon: ShieldCheck },
  { id: 'ai', label: 'AI Insights', icon: Brain },
  { id: 'grid-intelligence', label: 'Grid Intelligence', icon: Network },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'history', label: 'History', icon: History },
  { id: 'reports', label: 'Reports', icon: Download },
  { id: 'studio', label: 'Engineering Studio', icon: Cpu },
];

const STUDIO_NAV: Array<{ id: StudioPage; label: string }> = [
  { id: 'one-line', label: 'Engineering One-Line' },
  { id: 'digital-twin', label: 'Digital Twin' },
  { id: 'scenario', label: 'Scenario Lab' },
  { id: 'studies', label: 'Studies & What-If' },
  { id: 'forecast', label: 'Forecast' },
  { id: 'events', label: 'Events' },
  { id: 'replay', label: 'Replay' },
  { id: 'grid-intelligence', label: 'Grid Intelligence' },
  { id: 'ai-engineer', label: 'AI Engineer' },
  { id: 'anomaly', label: 'Anomaly Detection' },
  { id: 'energy-story', label: 'Energy Story' },
  { id: 'optimization', label: 'Network Optimization' },
  { id: 'advanced', label: 'Advanced Grid Intelligence' },
];

function num(v: unknown, fallback = 0) {
  const x = Number(v);
  return Number.isFinite(x) ? x : fallback;
}

function formatPower(v: number) {
  const a = Math.abs(v);
  return a >= 1000 ? `${(v / 1000).toFixed(2)} MW` : `${v.toFixed(1)} kW`;
}

function getTotals(state: TelemetryState) {
  const solar = state.houses.reduce((s, h) => s + num(h.pv_kw), 0) + num(state.community.pv_kw);
  const load = state.houses.reduce((s, h) => s + num(h.load_kw), 0) + num(state.community.load_kw);
  return { solar, load };
}

function statusLabel(status: ConnectionStatus) {
  return status === 'LIVE' ? 'Live' : status === 'DEMO' ? 'Demo' : status === 'STALE' ? 'Stale' : status === 'RECONNECTING' ? 'Reconnecting' : 'Offline';
}

export default function ControlCenter({ state, status, userRole, onLogout }: ControlCenterProps) {
  const [page, setPage] = useState<PageId>('overview');
  const [studioPage, setStudioPage] = useState<StudioPage>('one-line');
  const [mobileNav, setMobileNav] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [commandResult, setCommandResult] = useState<{ success: boolean; message: string } | null>(null);
  const [acked, setAcked] = useState<Record<string, string>>({});
  const [theme, setTheme] = useState<'aurora' | 'solar' | 'utility'>('aurora');
  const [themeOpen, setThemeOpen] = useState(false);

  const { solar, load } = getTotals(state);
  const net = solar - load;
  const deficit = Math.max(0, load - solar);
  const renewableShare = load > 0 ? Math.min(100, (solar / load) * 100) : 0;
  const activeCritical = state.alarms.filter(a => String(a.severity).toUpperCase() === 'CRITICAL').length;
  const activeWarnings = state.alarms.filter(a => String(a.severity).toUpperCase() === 'WARNING').length;

  const handleCommand = async (command: string, target: string, value?: any) => {
    try {
      await api.sendCommand(command, target, value);
      setCommandResult({ success: true, message: `Command sent • ${command} → ${target}` });
      setTimeout(() => setCommandResult(null), 2500);
    } catch (error) {
      setCommandResult({ success: false, message: `Command failed • ${String(error)}` });
      setTimeout(() => setCommandResult(null), 3500);
    }
  };

  const ackAlarm = async (id: string) => {
    setAcked(prev => ({ ...prev, [id]: new Date().toISOString() }));
    try {
      if ((api as any).ackAlarm) await (api as any).ackAlarm(id);
    } catch {
      // UI remains acknowledged even if backend is an older version.
    }
  };

  const setPageSafe = (next: PageId) => {
    setPage(next);
    setMobileNav(false);
  };

  return (
    <>
    <div className={`gp-app gp-theme-${theme} min-h-screen bg-[#f5f7fb] text-slate-900`}>
      <div className="flex min-h-screen">
        <aside className={`${mobileNav ? 'fixed inset-y-0 left-0 z-40' : 'hidden'} lg:flex w-[236px] shrink-0 flex-col border-r border-slate-200/80 bg-white shadow-[0_0_32px_rgba(15,23,42,0.04)]`}>
          <div className="px-5 py-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#6d5dfc] text-white shadow-sm">
                <Zap size={19} />
              </div>
              <div>
                <div className="text-[15px] font-bold tracking-tight">GridPulse</div>
                <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400">Control</div>
              </div>
            </div>
          </div>
          <div className="px-3 pb-3">
            {NAV.map(item => {
              const Icon = item.icon;
              const active = page === item.id;
              const badge = item.id === 'alerts' ? state.alarms.length : 0;
              return (
                <button
                  key={item.id}
                  onClick={() => setPageSafe(item.id)}
                  className={`gp-nav w-full ${active ? 'is-active' : ''}`}
                >
                  <span className="flex items-center gap-3"><Icon size={16} strokeWidth={1.9} />{item.label}</span>
                  {badge > 0 && <span className="gp-badge">{badge}</span>}
                </button>
              );
            })}
          </div>
          <div className="mt-auto border-t border-slate-100 p-3">
            <button onClick={() => setPageSafe('studio')} className="gp-studio-link">
              <span className="flex items-center gap-3"><Settings2 size={15} />Open Studio</span>
              <ChevronRight size={15} />
            </button>
            <button onClick={onLogout} className="mt-2 flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-medium text-slate-500 hover:bg-slate-50">
              <span>{userRole}</span><span>Logout</span>
            </button>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 flex h-[66px] items-center justify-between border-b border-slate-200/80 bg-white/95 px-4 backdrop-blur lg:px-7">
            <div className="flex items-center gap-3">
              <button className="lg:hidden rounded-lg border border-slate-200 p-2" onClick={() => setMobileNav(true)}><Menu size={17} /></button>
              <div>
                <h1 className="text-[20px] font-semibold tracking-tight">{page === 'studio' ? 'Engineering Studio' : NAV.find(n => n.id === page)?.label}</h1>
                <div className="text-[11px] text-slate-400">Live digital twin • {new Date(state.timestamp).toLocaleTimeString()}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <StatusPill icon={<span className="h-2 w-2 rounded-full bg-emerald-500" />} label={statusLabel(status)} tone={status === 'LIVE' ? 'green' : status === 'DEMO' ? 'purple' : 'amber'} />
              <StatusPill icon={<Activity size={12} />} label="Running" tone="slate" />
              <StatusPill icon={<Wifi size={12} />} label={status === 'LIVE' ? 'Synced' : 'Stale'} tone={status === 'LIVE' ? 'green' : 'amber'} />
              <div className="relative">
                <button aria-label="Change visual theme" className="relative rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" onClick={() => setThemeOpen(v => !v)}>
                  <Sparkles size={16} />
                </button>
                <AnimatePresence>
                  {themeOpen && <motion.div initial={{opacity:0,y:-6,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:-6,scale:.98}} className="absolute right-0 mt-2 w-44 rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_18px_50px_rgba(15,23,42,.12)]">
                    <div className="px-2 pb-2 pt-1 text-[9px] font-semibold uppercase tracking-[.15em] text-slate-400">Accent theme</div>
                    {[['aurora','Aurora'],['solar','Solar'],['utility','Utility']].map(([id,label]) => <button key={id} onClick={() => { setTheme(id as any); setThemeOpen(false); }} className={`flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-[10px] font-semibold ${theme===id?'bg-slate-900 text-white':'text-slate-600 hover:bg-slate-50'}`}><span>{label}</span><span className={`h-2.5 w-2.5 rounded-full ${id==='aurora'?'bg-violet-500':id==='solar'?'bg-cyan-500':'bg-blue-500'}`} /></button>)}
                  </motion.div>}
                </AnimatePresence>
              </div>
              <button className="relative ml-1 rounded-xl border border-slate-200 p-2 text-slate-500 hover:bg-slate-50" onClick={() => setPageSafe('alerts')}>
                <Bell size={16} />
                {state.alarms.length > 0 && <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-red-500 ring-2 ring-white" />}
              </button>
            </div>
          </header>

          {commandResult && <div className={`border-b px-6 py-2 text-xs font-medium ${commandResult.success ? 'border-emerald-100 bg-emerald-50 text-emerald-700' : 'border-red-100 bg-red-50 text-red-700'}`}>{commandResult.message}</div>}

          <main className="space-y-5 p-4 lg:p-7">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={page} initial={{ opacity: 0, y: 8, filter: 'blur(4px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }} exit={{ opacity: 0, y: -6, filter: 'blur(3px)' }} transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}>
                {page === 'overview' && <Overview state={state} solar={solar} load={load} deficit={deficit} renewableShare={renewableShare} />}
                {page === 'live' && <LiveData state={state} />}
                {page === 'community' && <Community state={state} />}
                {page === 'analytics' && <Analytics state={state} />}
                {page === 'battery' && <BatteryPage state={state} canControl={userRole !== 'VIEWER'} onCommand={handleCommand} />}
                {page === 'protection' && <Protection state={state} />}
                {page === 'ai' && <AIInsights state={state} />}
                {page === 'grid-intelligence' && <GridOptimizationCenter state={state} />}
                {page === 'alerts' && <Alerts state={state} acked={acked} onAck={ackAlarm} />}
                {page === 'history' && <HistoryPage state={state} />}
                {page === 'reports' && <ReportsView state={state} />}
                {page === 'studio' && (
                  <EngineeringStudio
                    state={state}
                    studioPage={studioPage}
                    setStudioPage={setStudioPage}
                    selectedAsset={selectedAsset}
                    setSelectedAsset={setSelectedAsset}
                    onCommand={handleCommand}
                    canControl={userRole !== 'VIEWER'}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
      <GridPulseChatbot state={state} onOpenAlerts={() => setPageSafe('alerts')} />
    </div>
    </>
  );
}

function StatusPill({ icon, label, tone }: { icon: React.ReactNode; label: string; tone: 'green' | 'purple' | 'amber' | 'slate' }) {
  const toneClass = tone === 'green' ? 'bg-emerald-50 text-emerald-700' : tone === 'purple' ? 'bg-violet-50 text-violet-700' : tone === 'amber' ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-600';
  return <span className={`hidden sm:inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold ${toneClass}`}>{icon}{label}</span>;
}

function SectionHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div><h2 className="text-[16px] font-semibold tracking-tight">{title}</h2>{subtitle && <p className="mt-0.5 text-[11px] text-slate-400">{subtitle}</p>}</div>
      {right}
    </div>
  );
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-slate-200/80 bg-white shadow-[0_7px_24px_rgba(15,23,42,0.025)] ${className}`}>{children}</section>;
}

function MetricCard({ icon, label, value, unit, tone = 'violet', trend, status }: { icon: React.ReactNode; label: string; value: string; unit?: string; tone?: 'violet'|'green'|'cyan'|'blue'|'amber'|'red'; trend?: string; status?: string }) {
  const styles = {
    violet: 'bg-violet-50 text-violet-600', green: 'bg-emerald-50 text-emerald-600', cyan: 'bg-cyan-50 text-cyan-600', blue: 'bg-blue-50 text-blue-600', amber: 'bg-amber-50 text-amber-600', red: 'bg-red-50 text-red-600',
  } as const;
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${styles[tone]}`}>{icon}</div>
        {status ? <span className="rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-semibold text-emerald-700">{status}</span> : trend ? <span className="rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-semibold text-emerald-700">{trend}</span> : null}
      </div>
      <div className="mt-3 flex items-baseline gap-1"><span className="text-[24px] font-semibold tracking-tight">{value}</span>{unit && <span className="text-[11px] text-slate-400">{unit}</span>}</div>
      <div className="mt-1 text-[10px] font-medium text-slate-500">{label}</div>
    </Card>
  );
}

function Overview({ state, solar, load, deficit, renewableShare }: { state: TelemetryState; solar: number; load: number; deficit: number; renewableShare: number }) {
  const flow = state.battery.power_kw > 0.2 ? 'discharging' : state.battery.power_kw < -0.2 ? 'charging' : 'idle';
  const transformerTone = state.transformer.loading_percent > 100 ? 'red' : state.transformer.loading_percent > 85 ? 'amber' : 'green';
  const txAdvanced = state.advanced?.transformer_health || {};
  const txRisk = Math.min(100, Math.max(0, Math.round(Math.max(state.transformer.loading_percent, Number(txAdvanced.hotspot_temperature_c || state.transformer.temperature_c) > 90 ? 90 : 0))));
  const subtitle = deficit > 0 ? `Renewable generation is ${deficit.toFixed(1)} kW below current demand. ${flow === 'discharging' ? `BESS is supplying ${Math.abs(state.battery.power_kw).toFixed(1)} kW.` : `Grid import is ${state.grid.import_kw.toFixed(1)} kW.`}` : `Renewable generation currently covers ${renewableShare.toFixed(0)}% of local demand. ${state.grid.export_kw > 0 ? `Grid export is ${state.grid.export_kw.toFixed(1)} kW.` : 'BESS can absorb surplus energy.'}`;
  return <div className="space-y-5">
    <Card className="p-6">
      <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
        <div><div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-violet-500">GridPulse status</div><h2 className="mt-2 text-[25px] font-semibold tracking-tight">{state.alarms.some(a => a.severity === 'CRITICAL') ? 'GridPulse requires operator attention.' : 'GridPulse is operating normally.'}</h2><p className="mt-2 max-w-3xl text-[12px] leading-6 text-slate-500">{subtitle}</p></div>
        <div className="text-right"><div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-slate-400">Current system flow</div><div className="mt-1 text-[34px] font-semibold tracking-tight">{formatPower(solar)}</div><div className="text-[10px] text-slate-400">renewable generation</div></div>
      </div>
    </Card>

    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
      <MetricCard label="Solar Generation" value={formatPower(solar).replace(' kW','').replace(' MW','')} unit={solar >= 1000 ? 'MW' : 'kW'} icon={<Sun size={16} />} tone="green" trend="Live" />
      <MetricCard label="Consumption" value={formatPower(load).replace(' kW','').replace(' MW','')} unit={load >= 1000 ? 'MW' : 'kW'} icon={<Power size={16} />} tone="violet" trend="Live" />
      <MetricCard label="Battery" value={state.battery.soc_percent.toFixed(0)} unit="%" icon={<Battery size={16} />} tone="cyan" status={state.battery.state.toUpperCase()} />
      <MetricCard label={state.grid.import_kw > 0.1 ? 'Grid Import' : 'Grid Export'} value={Math.abs(state.grid.import_kw > 0.1 ? state.grid.import_kw : state.grid.export_kw).toFixed(1)} unit="kW" icon={<Grid3X3 size={16} />} tone="blue" status={state.grid.import_kw > 0.1 ? 'Importing' : 'Exporting'} />
      <MetricCard label="Power Balance" value={Math.abs(netValue(solar, load)).toFixed(1)} unit="kW" icon={<Activity size={16} />} tone={solar >= load ? 'green' : 'amber'} status={solar >= load ? 'Surplus' : 'Deficit'} />
      <MetricCard label="Transformer Risk" value={txRisk.toFixed(0)} unit="%" icon={<Factory size={16} />} tone={transformerTone === 'red' ? 'red' : transformerTone === 'amber' ? 'amber' : 'green'} status={state.transformer.health} />
    </div>

    <div className="grid gap-4 xl:grid-cols-2">
      <TransformerLivePanel state={state} />
      <BESSLivePanel state={state} />
    </div>

    <div className="grid gap-4 xl:grid-cols-[minmax(0,1.6fr)_minmax(320px,0.8fr)]">
      <Card className="p-5">
        <div className="flex items-center justify-between"><div><h3 className="text-[13px] font-semibold">Generation vs Consumption</h3><p className="text-[10px] text-slate-400">Real-time power flow</p></div><div className="flex items-center gap-3 text-[9px]"><span className="flex items-center gap-1.5 text-emerald-600"><span className="h-2 w-2 rounded-full bg-emerald-500" />Generation</span><span className="flex items-center gap-1.5 text-violet-600"><span className="h-2 w-2 rounded-full bg-violet-500" />Consumption</span></div></div>
        <div className="mt-3 h-[280px]"><PowerChart state={state} /></div>
      </Card>
      <GridFlow state={state} solar={solar} load={load} />
    </div>

    <Card className="p-5">
      <SectionHeader title="Component Status" subtitle="Live engineering state from the digital twin" />
      <ComponentStatusGrid state={state} />
    </Card>
  </div>;
}

function netValue(solar: number, load: number) { return solar - load; }

function PowerChart({ state, compact = false }: { state: TelemetryState; compact?: boolean }) {
  const data = state.history.slice(-60).map(h => ({
    t: new Date(h.timestamp).toLocaleTimeString([], { minute: '2-digit', second: '2-digit' }),
    generation: h.solar_kw,
    consumption: h.load_kw,
    import: h.grid_import_kw,
    export: h.grid_export_kw,
    soc: h.battery_soc,
    battery: h.battery_power_kw,
    transformer: h.transformer_loading,
  }));
  if (!data.length) return <EmptyState label="Waiting for telemetry history…" />;
  return <ResponsiveContainer width="100%" height="100%"><AreaChart data={data} margin={{ left: -18, right: 8, top: 8, bottom: 0 }}>
    <defs><linearGradient id="gpGen" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#15b981" stopOpacity={0.18} /><stop offset="100%" stopColor="#15b981" stopOpacity={0.01} /></linearGradient><linearGradient id="gpLoad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#7658ff" stopOpacity={0.16} /><stop offset="100%" stopColor="#7658ff" stopOpacity={0.01} /></linearGradient></defs>
    <CartesianGrid stroke="#eef2f7" strokeDasharray="3 4" vertical={false} /><XAxis dataKey="t" tick={{ fontSize: 9, fill: '#94a3b8' }} axisLine={false} tickLine={false} minTickGap={26} /><YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={30} /><Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 12px 30px rgba(15,23,42,0.08)', fontSize: 11 }} />
    <Area type="monotone" dataKey="generation" stroke="#10b981" fill="url(#gpGen)" strokeWidth={2.1} name="Generation" /><Area type="monotone" dataKey="consumption" stroke="#7658ff" fill="url(#gpLoad)" strokeWidth={2.1} name="Consumption" />
  </AreaChart></ResponsiveContainer>;
}

function TransformerLivePanel({ state }: { state: TelemetryState }) {
  const tx = state.transformer;
  const txAdvanced = state.advanced?.transformer_health || {};
  const load = Math.max(0, Number(tx.loading_percent) || 0);
  const health = String(tx.health || 'UNKNOWN').toUpperCase();
  const healthTone = health === 'CRITICAL' || load > 100 ? 'red' : health === 'WARNING' || load > 85 ? 'amber' : 'green';
  const ratedKw = Math.max(1, tx.rating_kva * 0.98);
  const activeKw = ratedKw * Math.min(load, 125) / 100;
  const primaryCurrent = (activeKw * 1000) / (Math.sqrt(3) * Math.max(tx.primary_voltage_kv, 0.1) * 1000);
  const secondaryCurrent = (activeKw * 1000) / (Math.sqrt(3) * Math.max(tx.secondary_voltage_v, 1));
  const severityClass = healthTone === 'red' ? 'bg-red-50 text-red-700 border-red-100' : healthTone === 'amber' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100';
  const barClass = healthTone === 'red' ? 'bg-red-500' : healthTone === 'amber' ? 'bg-amber-500' : 'bg-emerald-500';

  return <Card className="gp-asset-card overflow-hidden p-0">
    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
      <div className="flex items-center gap-3">
        <div className="gp-transformer-icon" aria-hidden="true">
          <motion.div className="gp-tx-core" animate={{ opacity: [0.45, 1, 0.45], scale: [0.98, 1.02, 0.98] }} transition={{ duration: 1.7, repeat: Infinity, ease: 'easeInOut' }} />
          <motion.div className="gp-tx-coil gp-tx-coil-a" animate={{ x: [-1, 1, -1] }} transition={{ duration: .65, repeat: Infinity, ease: 'easeInOut' }} />
          <motion.div className="gp-tx-coil gp-tx-coil-b" animate={{ x: [1, -1, 1] }} transition={{ duration: .65, repeat: Infinity, ease: 'easeInOut' }} />
          <motion.span className="gp-energy-pulse gp-energy-pulse-a" animate={{ x: [0, 42], opacity: [0, 1, 0] }} transition={{ duration: 1.15, repeat: Infinity, ease: 'linear' }} />
          <motion.span className="gp-energy-pulse gp-energy-pulse-b" animate={{ x: [0, 42], opacity: [0, 1, 0] }} transition={{ duration: 1.15, delay: .57, repeat: Infinity, ease: 'linear' }} />
        </div>
        <div>
          <div className="text-[13px] font-semibold">Distribution Transformer</div>
          <div className="mt-0.5 text-[9px] uppercase tracking-[0.16em] text-slate-400">{tx.id} • live thermal state</div>
        </div>
      </div>
      <span className={`rounded-full border px-2.5 py-1 text-[9px] font-bold ${severityClass}`}><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current align-middle" />{health}</span>
    </div>

    <div className="grid min-w-0 gap-5 p-5 md:grid-cols-[minmax(140px,180px)_minmax(0,1fr)]">
      <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4">
        <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-slate-400">Loading</div>
        <div className="mt-2 flex items-baseline gap-1"><span className="text-[30px] font-semibold tracking-tight">{load.toFixed(1)}</span><span className="text-[11px] text-slate-400">%</span></div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200"><motion.div className={`h-full rounded-full ${barClass}`} animate={{ width: `${Math.min(100, load)}%` }} transition={{ duration: .65, ease: 'easeOut' }} /></div>
        <div className="mt-2 flex justify-between text-[8px] text-slate-400"><span>0%</span><span>85%</span><span>100%</span></div>
        <div className="mt-4 rounded-xl bg-white p-3 shadow-sm"><div className="text-[8px] uppercase tracking-wider text-slate-400">Thermal</div><div className="mt-1 flex items-center gap-2"><Thermometer size={14} className={healthTone === 'red' ? 'text-red-500' : healthTone === 'amber' ? 'text-amber-500' : 'text-emerald-500'} /><span className="text-[15px] font-semibold">{tx.temperature_c.toFixed(1)} °C</span></div></div>
      </div>

      <div className="min-w-0 overflow-hidden">
        <div className="grid min-w-0 grid-cols-2 gap-2 sm:grid-cols-4">
          <AssetStat label="Rating" value={`${tx.rating_kva.toFixed(0)} kVA`} />
          <AssetStat label="Efficiency" value={`${tx.efficiency.toFixed(1)}%`} />
          <AssetStat label="Primary" value={`${tx.primary_voltage_kv.toFixed(1)} kV`} />
          <AssetStat label="Secondary" value={`${tx.secondary_voltage_v.toFixed(0)} V`} />
          <AssetStat label="Power" value={formatPower(activeKw)} />
          <AssetStat label="Primary I" value={`${primaryCurrent.toFixed(1)} A`} />
          <AssetStat label="Secondary I" value={`${secondaryCurrent.toFixed(0)} A`} />
          <AssetStat label="Frequency" value={`${state.frequency.toFixed(2)} Hz`} />
        </div>
        <div className="mt-3 grid min-w-0 grid-cols-2 gap-2 sm:grid-cols-4">
          <AssetStat label="Hotspot" value={`${Number(txAdvanced.hotspot_temperature_c ?? tx.temperature_c).toFixed(1)} °C`} />
          <AssetStat label="Aging factor" value={`${Number(txAdvanced.aging_acceleration_factor ?? 1).toFixed(2)}×`} />
          <AssetStat label="THD-V" value={`${Number(state.advanced?.harmonics?.thd_voltage_percent ?? 0).toFixed(1)}%`} />
          <AssetStat label="DGA" value={String(state.advanced?.dga?.severity ?? 'NORMAL')} />
        </div>
        <div className="mt-3 rounded-xl border border-slate-100 bg-white p-3">
          <div className="flex items-center justify-between text-[9px]"><span className="font-semibold text-slate-500">11 kV → 415 V energy transfer</span><span className="font-semibold text-slate-400">{formatPower(activeKw)}</span></div>
          <div className="mt-2 flex items-center gap-2">
            <span className="rounded-lg bg-blue-50 px-2 py-1 text-[8px] font-bold text-blue-700">MV</span>
            <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-slate-100"><motion.div className={`absolute inset-y-0 left-0 ${barClass}`} animate={{ width: `${Math.min(100, load)}%` }} transition={{ duration: .65 }} /><span className="gp-flow-track" /></div>
            <span className="rounded-lg bg-emerald-50 px-2 py-1 text-[8px] font-bold text-emerald-700">LV</span>
          </div>
        </div>
      </div>
    </div>
  </Card>;
}

function BESSLivePanel({ state }: { state: TelemetryState }) {
  const b = state.battery;
  const charging = Number(b.power_kw) < -0.2;
  const discharging = Number(b.power_kw) > 0.2;
  const soc = Math.max(0, Math.min(100, Number(b.soc_percent) || 0));
  const flow = b.energy_flow;
  const pwm = state.pcs;
  return <Card className="gp-asset-card overflow-hidden p-0">
    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
      <div className="flex items-center gap-3">
        <div className="gp-battery-icon" aria-hidden="true"><motion.div className="gp-battery-fill" animate={{ height: `${soc}%` }} transition={{ duration: .7 }} /><motion.div className="gp-battery-energy" animate={{ y: discharging ? [0, 8, 0] : charging ? [8, 0, 8] : [0, 3, 0] }} transition={{ duration: 1.2, repeat: Infinity }} /></div>
        <div><div className="text-[13px] font-semibold">BESS / PCS</div><div className="mt-0.5 text-[9px] uppercase tracking-[0.16em] text-slate-400">{b.id} • storage & pulse transfer</div></div>
      </div>
      <span className={`rounded-full border px-2.5 py-1 text-[9px] font-bold ${discharging ? 'border-cyan-100 bg-cyan-50 text-cyan-700' : charging ? 'border-violet-100 bg-violet-50 text-violet-700' : 'border-slate-200 bg-slate-50 text-slate-600'}`}><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current align-middle" />{String(b.state).toUpperCase()}</span>
    </div>
    <div className="grid min-w-0 gap-5 p-5 md:grid-cols-[minmax(140px,180px)_minmax(0,1fr)]">
      <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4">
        <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-slate-400">State of charge</div>
        <div className="mt-2 flex items-baseline gap-1"><span className="text-[30px] font-semibold tracking-tight">{soc.toFixed(0)}</span><span className="text-[11px] text-slate-400">%</span></div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200"><motion.div className="h-full rounded-full bg-cyan-500" animate={{ width: `${soc}%` }} transition={{ duration: .7 }} /></div>
        <div className="mt-3 text-[9px] text-slate-500">{(b.stored_energy_kwh ?? (b.capacity_kwh * soc / 100)).toFixed(1)} / {b.capacity_kwh.toFixed(0)} kWh stored</div>
        <div className="mt-3 rounded-xl bg-white p-3 shadow-sm"><div className="text-[8px] uppercase tracking-wider text-slate-400">PCS power</div><div className="mt-1 text-[15px] font-semibold">{Math.abs(b.power_kw).toFixed(1)} kW</div></div>
      </div>
      <div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <AssetStat label="Mode" value={String(b.mode)} />
          <AssetStat label="Capacity" value={`${b.capacity_kwh.toFixed(0)} kWh`} />
          <AssetStat label="Min / Max SOC" value={`${b.min_soc.toFixed(0)} / ${b.max_soc.toFixed(0)}%`} />
          <AssetStat label="PCS efficiency" value={`${pwm.efficiency.toFixed(1)}%`} />
        </div>
        <div className="mt-3 rounded-xl border border-slate-100 bg-white p-3">
          <div className="flex items-center justify-between"><div><div className="text-[9px] font-semibold text-slate-500">Energy provenance</div><div className="mt-0.5 text-[8px] text-slate-400">Stored energy and live destination</div></div><Zap size={14} className="text-cyan-500" /></div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <MiniFlow label="From Solar" value={`${(flow?.from_solar_kw ?? 0).toFixed(1)} kW`} />
            <MiniFlow label="To Load" value={`${(flow?.to_local_load_kw ?? 0).toFixed(1)} kW`} />
            <MiniFlow label="To Grid" value={`${(flow?.to_grid_kw ?? 0).toFixed(1)} kW`} />
          </div>
        </div>
        <div className="mt-3 rounded-xl border border-slate-100 bg-slate-50/70 p-3">
          <div className="flex items-center justify-between text-[9px]"><span className="font-semibold text-slate-500">PWM transfer</span><span className="font-semibold text-violet-600">{(pwm.duty_cycle * 100).toFixed(1)}% duty</span></div>
          <div className="gp-pwm-strip mt-2 min-w-0">{Array.from({ length: 28 }).map((_, i) => <motion.span key={i} animate={{ opacity: i % 4 < Math.max(1, Math.round(pwm.duty_cycle * 4)) ? [0.35, 1, 0.35] : 0.12 }} transition={{ duration: .8, delay: i * .035, repeat: Infinity }} />)}</div>
          <div className="mt-2 flex justify-between text-[8px] text-slate-400"><span>{pwm.pwm_frequency_hz.toFixed(0)} Hz</span><span>{(pwm.average_power_kw ?? pwm.power_kw).toFixed(1)} kW avg</span><span>{pwm.direction || (discharging ? 'DISCHARGE' : charging ? 'CHARGE' : 'IDLE')}</span></div>
        </div>
      </div>
    </div>
  </Card>;
}

function AssetStat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2.5"><div className="text-[8px] uppercase tracking-[0.13em] text-slate-400">{label}</div><div className="mt-1 truncate text-[11px] font-semibold text-slate-700">{value}</div></div>;
}

function MiniFlow({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg bg-slate-50 px-2 py-2"><div className="text-[8px] text-slate-400">{label}</div><div className="mt-1 text-[10px] font-semibold text-slate-700">{value}</div></div>;
}

function GridFlow({ state, solar, load }: { state: TelemetryState; solar: number; load: number }) {
  const items = [
    { label: 'Solar', value: solar, icon: <Sun size={13} />, tone: 'green' },
    { label: 'Wind / Other', value: 0, icon: <CloudSun size={13} />, tone: 'blue' },
    { label: 'Battery', value: Math.max(0, state.battery.power_kw), icon: <Battery size={13} />, tone: 'cyan' },
    { label: 'Grid Import', value: state.grid.import_kw, icon: <TrendingUp size={13} />, tone: 'violet' },
    { label: 'Loads', value: load, icon: <Home size={13} />, tone: 'slate' },
  ];
  return <Card className="p-5"><SectionHeader title="Grid Overview" subtitle="Live energy flow" /><div className="mt-4 space-y-4">{items.map((item, i) => <div key={item.label} className="flex items-center justify-between"><div className="flex items-center gap-3"><div className={`flex h-8 w-8 items-center justify-center rounded-full ${item.tone === 'green' ? 'bg-emerald-50 text-emerald-600' : item.tone === 'blue' ? 'bg-blue-50 text-blue-600' : item.tone === 'cyan' ? 'bg-cyan-50 text-cyan-600' : item.tone === 'violet' ? 'bg-violet-50 text-violet-600' : 'bg-slate-100 text-slate-600'}`}>{item.icon}</div><span className="text-[11px] text-slate-600">{item.label}</span></div><div className="text-[12px] font-semibold">{formatPower(item.value)}</div>{i < items.length - 1 && <></>}</div>)}</div><div className="mt-5 rounded-xl border border-slate-100 bg-slate-50/70 p-3"><div className="flex items-center justify-between text-[10px]"><span className="text-slate-400">Transformer loading</span><span className="font-semibold">{state.transformer.loading_percent.toFixed(1)}%</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200"><div className={`${state.transformer.loading_percent > 100 ? 'bg-red-500' : state.transformer.loading_percent > 85 ? 'bg-amber-500' : 'bg-emerald-500'} h-full rounded-full transition-all duration-500`} style={{ width: `${Math.min(100, state.transformer.loading_percent)}%` }} /></div></div></Card>;
}

function ComponentStatusGrid({ state }: { state: TelemetryState }) {
  const components = [
    { name: 'Main Grid', status: state.grid.import_kw > 0 ? 'Online' : 'Standby', icon: <Grid3X3 size={14} />, power: formatPower(state.grid.import_kw || state.grid.export_kw), value: `${state.grid.voltage_kv.toFixed(2)} kV` },
    { name: 'Distribution Transformer', status: state.transformer.health, icon: <Factory size={14} />, power: formatPower(state.transformer.loading_percent / 100 * state.transformer.rating_kva), value: `${state.transformer.temperature_c.toFixed(1)} °C` },
    { name: 'BESS / PCS', status: state.battery.state.toUpperCase(), icon: <Battery size={14} />, power: formatPower(Math.abs(state.battery.power_kw)), value: `${state.battery.soc_percent.toFixed(1)}% SOC` },
    { name: 'PCC Bus', status: 'Online', icon: <Network size={14} />, power: `${(state.buses?.find((b:any)=>b?.type==='LV' && typeof b?.voltage_v==='number')?.voltage_v ?? 415).toFixed(1)} V`, value: `${state.frequency.toFixed(2)} Hz` },
  ];
  return <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">{components.map(c => <div key={c.name} className="rounded-xl border border-slate-100 bg-slate-50/50 p-4"><div className="flex items-start justify-between"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-violet-600 shadow-sm">{c.icon}</div><div><div className="text-[11px] font-semibold">{c.name}</div><div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-emerald-600"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />{c.status}</div></div></div></div><div className="mt-4 flex items-end justify-between"><div><div className="text-[9px] uppercase tracking-wider text-slate-400">Primary</div><div className="text-[13px] font-semibold">{c.power}</div></div><div className="text-right"><div className="text-[9px] uppercase tracking-wider text-slate-400">Secondary</div><div className="text-[12px] font-medium text-slate-600">{c.value}</div></div></div></div>)}</div>;
}

function LiveData({ state }: { state: TelemetryState }) {
  const history = state.history;
  const metrics = [
    ['Total Generation', formatPower(history.at(-1)?.solar_kw ?? 0), <Zap size={16} />],
    ['Total Consumption', formatPower(history.at(-1)?.load_kw ?? 0), <Power size={16} />],
    ['Battery SOC', `${state.battery.soc_percent.toFixed(1)}%`, <Battery size={16} />],
    ['System Efficiency', `${state.transformer.efficiency.toFixed(1)}%`, <Gauge size={16} />],
  ];
  return <div className="space-y-5"><SectionHeader title="Live Data" subtitle="Real-time telemetry from the digital twin" right={<span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-[10px] font-semibold text-emerald-700"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />Streaming</span>} />
    <div className="grid gap-4 lg:grid-cols-4">{metrics.map(([label, value, icon]) => <MetricCard key={String(label)} label={String(label)} value={String(value).split(' ')[0]} unit={String(value).split(' ').slice(1).join(' ')} icon={icon as React.ReactNode} tone="violet" />)}</div>
    <div className="grid gap-4 xl:grid-cols-2"><Card className="p-5"><SectionHeader title="Power Flow" subtitle="Generation versus consumption" /><div className="mt-3 h-[260px]"><PowerChart state={state} /></div></Card><Card className="p-5"><SectionHeader title="Grid Exchange" subtitle="Import versus export" /><div className="mt-3 h-[260px]"><GridExchangeChart state={state} /></div></Card></div>
    <Card className="p-5"><SectionHeader title="Component Telemetry" subtitle="Selected engineering measurements" /><div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">{state.houses.map(h => <TelemetryCard key={h.id} title={`Home ${h.id}`} status="Online" icon={<Sun size={14} />} rows={[['Power', `${h.net_kw.toFixed(1)} kW`], ['Voltage', `${h.voltage_v.toFixed(1)} V`], ['PV', `${h.pv_kw.toFixed(1)} kW`], ['Load', `${h.load_kw.toFixed(1)} kW`]]} />)}<TelemetryCard title="Transformer" status={state.transformer.health} icon={<Factory size={14} />} rows={[['Loading', `${state.transformer.loading_percent.toFixed(1)} %`], ['Temp', `${state.transformer.temperature_c.toFixed(1)} °C`], ['Efficiency', `${state.transformer.efficiency.toFixed(1)} %`], ['Rating', `${state.transformer.rating_kva.toFixed(0)} kVA`]]} /><TelemetryCard title="BESS / PCS" status={state.battery.state} icon={<Battery size={14} />} rows={[['SOC', `${state.battery.soc_percent.toFixed(1)} %`], ['Power', `${state.battery.power_kw.toFixed(1)} kW`], ['PWM', `${(state.pcs.duty_cycle * 100).toFixed(1)} %`], ['Freq', `${state.pcs.pwm_frequency_hz.toFixed(0)} Hz`]]} /></div></Card>
    <LiveGraphs state={state} />
  </div>;
}

function GridExchangeChart({ state }: { state: TelemetryState }) {
  const data = state.history.slice(-60).map(h => ({ t: new Date(h.timestamp).toLocaleTimeString([], { minute: '2-digit', second: '2-digit' }), import: h.grid_import_kw, export: h.grid_export_kw }));
  return <ResponsiveContainer width="100%" height="100%"><RLineChart data={data} margin={{ left: -18, right: 8, top: 8, bottom: 0 }}><CartesianGrid stroke="#eef2f7" strokeDasharray="3 4" vertical={false} /><XAxis dataKey="t" tick={{ fontSize: 9, fill: '#94a3b8' }} axisLine={false} tickLine={false} minTickGap={26} /><YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={30} /><Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 11 }} /><Line type="monotone" dataKey="import" stroke="#4f8cff" strokeWidth={2} dot={false} name="Import" /><Line type="monotone" dataKey="export" stroke="#f59e0b" strokeWidth={2} dot={false} name="Export" /></RLineChart></ResponsiveContainer>;
}

function TelemetryCard({ title, status, icon, rows }: { title: string; status: string; icon: React.ReactNode; rows: Array<[string,string]> }) { return <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-4"><div className="flex items-start justify-between"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm">{icon}</div><div><div className="text-[11px] font-semibold">{title}</div><div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-emerald-600"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />{status}</div></div></div></div><div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3">{rows.map(([k,v]) => <div key={k}><div className="text-[8px] uppercase tracking-wider text-slate-400">{k}</div><div className="mt-0.5 text-[12px] font-semibold">{v}</div></div>)}</div></div>; }

function Community({ state }: { state: TelemetryState }) {
  const solar = state.houses.reduce((s,h)=>s+h.pv_kw,0)+state.community.pv_kw;
  const load = state.houses.reduce((s,h)=>s+h.load_kw,0)+state.community.load_kw;
  return <div className="space-y-5"><SectionHeader title="Live Community" subtitle="Locality-level digital twin and distributed energy" right={<span className="rounded-full bg-blue-50 px-3 py-1 text-[10px] font-semibold text-blue-700">Bengaluru locality</span>} />
    <div className="grid gap-4 lg:grid-cols-4"><MetricCard label="Homes" value={String(state.houses.length)} icon={<Home size={16} />} tone="blue" /><MetricCard label="Community Solar" value={state.community.pv_kw.toFixed(1)} unit="kW" icon={<Sun size={16} />} tone="green" /><MetricCard label="Community Load" value={state.community.load_kw.toFixed(1)} unit="kW" icon={<Power size={16} />} tone="violet" /><MetricCard label="Renewable Share" value={load ? ((solar/load)*100).toFixed(0) : '0'} unit="%" icon={<Leaf size={16} />} tone="green" /></div>
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(320px,.85fr)]"><Card className="min-h-[390px] overflow-hidden"><div className="flex h-full items-center justify-center bg-[radial-gradient(circle_at_50%_45%,rgba(109,93,252,0.06),transparent_45%)] p-8"><div className="w-full max-w-xl"><div className="text-center text-[10px] font-semibold uppercase tracking-[.18em] text-slate-400">Community energy map</div><div className="relative mx-auto mt-7 h-[280px] rounded-[28px] border border-slate-200 bg-white p-5 shadow-inner"><div className="absolute left-5 right-5 top-5 flex items-center justify-between"><span className="rounded-full bg-violet-50 px-2.5 py-1 text-[9px] font-semibold text-violet-700">Transformer • {state.transformer.loading_percent.toFixed(0)}%</span><span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[9px] font-semibold text-emerald-700">Live</span></div><div className="absolute left-1/2 top-[26%] -translate-x-1/2"><Node label="TX-01" tone="violet" /></div><div className="absolute left-[17%] top-[47%]"><Node label="Solar A" tone="green" /></div><div className="absolute left-[47%] top-[60%]"><Node label="BESS" tone="cyan" /></div><div className="absolute right-[14%] top-[44%]"><Node label="Community" tone="blue" /></div><div className="absolute left-[34%] bottom-[9%]"><Node label="Homes" tone="slate" /></div><div className="absolute left-[24%] top-[49%] h-px w-[22%] bg-violet-200" /><div className="absolute left-[52%] top-[55%] h-px w-[20%] bg-cyan-200" /><div className="absolute left-[48%] top-[32%] h-[28%] w-px bg-violet-200" /><div className="absolute left-[42%] bottom-[31%] h-[20%] w-px bg-slate-200" /></div></div></div></Card><Card className="p-5"><SectionHeader title="Distributed Sources" subtitle="Live component contributions" /><div className="mt-4 space-y-3">{state.houses.map((h,i)=><div key={h.id} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/50 p-3"><div className="flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><Sun size={14} /></div><div><div className="text-[11px] font-semibold">Home {i+1} • Rooftop Solar</div><div className="text-[9px] text-slate-400">{h.load_kw.toFixed(1)} kW load</div></div></div><div className="text-right"><div className="text-[12px] font-semibold">{h.pv_kw.toFixed(1)} kW</div><div className="text-[9px] text-slate-400">PV</div></div></div>)}<div className="rounded-xl border border-blue-100 bg-blue-50/40 p-3"><div className="flex items-center justify-between"><div className="text-[11px] font-semibold text-blue-900">Community source</div><span className="text-[12px] font-semibold text-blue-700">{state.community.pv_kw.toFixed(1)} kW</span></div><div className="mt-1 text-[9px] text-blue-700/70">Shared solar source connected to distribution transformer</div></div></div></Card></div></div>;
}

function Node({ label, tone }: { label: string; tone: 'violet'|'green'|'cyan'|'blue'|'slate' }) { const m:any={violet:'bg-violet-50 border-violet-200 text-violet-700',green:'bg-emerald-50 border-emerald-200 text-emerald-700',cyan:'bg-cyan-50 border-cyan-200 text-cyan-700',blue:'bg-blue-50 border-blue-200 text-blue-700',slate:'bg-slate-50 border-slate-200 text-slate-700'}; return <div className={`rounded-xl border px-3 py-2 text-[9px] font-semibold shadow-sm ${m[tone]}`}>{label}</div>; }

function Analytics({ state }: { state: TelemetryState }) {
  const [range, setRange] = useState<'1h'|'6h'|'24h'>('1h');
  const lvVoltage = state.buses?.find((b:any)=>b?.type==='LV' && typeof b?.voltage_v==='number')?.voltage_v ?? state.buses?.find((b:any)=>typeof b?.voltage_v==='number')?.voltage_v ?? 415;
  const sampleCount = range === '1h' ? 12 : range === '6h' ? 72 : 288;
  const timeSeries = state.history.slice(-sampleCount).map(h=>({ t:new Date(h.timestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}), generation:h.solar_kw, load:h.load_kw, soc:h.battery_soc, import:h.grid_import_kw, export:h.grid_export_kw, voltage:(typeof h.voltage_v==='number' ? h.voltage_v : lvVoltage), frequency:(typeof h.frequency_hz==='number' ? h.frequency_hz : state.frequency), tx:h.transformer_loading }));
  const ranges = ['1h','6h','24h'] as const;
  return <div className="space-y-5"><SectionHeader title="Analytics" subtitle="Historical performance and engineering trends" right={<div className="flex rounded-xl border border-slate-200 bg-white p-1 text-[10px]">{ranges.map(r=><button key={r} onClick={()=>setRange(r)} className={`rounded-lg px-3 py-1.5 font-semibold transition ${range===r?'bg-slate-100 text-slate-800':'text-slate-400 hover:text-slate-600'}`}>{r}</button>)}<span className="px-3 py-1.5 text-slate-300">7d</span><span className="px-3 py-1.5 text-slate-300">30d</span></div>} />
  <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="Generation vs Consumption" icon={<Zap size={14} />}><SimpleLine data={timeSeries} lines={[['generation','#10b981'],['load','#7c5cff']]} names={['Generation','Consumption']} /></ChartCard><ChartCard title="Battery SOC" icon={<Battery size={14} />}><SimpleLine data={timeSeries} lines={[['soc','#11b5d6']]} names={['SOC']} domain={[0,100]} /></ChartCard><ChartCard title="Grid Import / Export" icon={<Grid3X3 size={14} />}><SimpleLine data={timeSeries} lines={[['import','#4f8cff'],['export','#f59e0b']]} names={['Import','Export']} /></ChartCard><ChartCard title="Voltage & Frequency" icon={<Activity size={14} />}><DualLine data={timeSeries} leftKey="voltage" rightKey="frequency" leftName="Voltage (V)" rightName="Frequency (Hz)" leftDomain={[390,425]} rightDomain={[49.5,50.5]} leftColor="#7c5cff" rightColor="#ef4444" /></ChartCard></div></div>;
}

function ChartCard({ title, icon, children }: { title:string; icon:React.ReactNode; children:React.ReactNode }) { return <Card className="p-5"><div className="flex items-center gap-2"><div className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-50 text-violet-600">{icon}</div><div><h3 className="text-[13px] font-semibold">{title}</h3><p className="text-[10px] text-slate-400">Live engineering trend</p></div></div><div className="mt-4 h-[250px]">{children}</div></Card>; }
function SimpleLine({ data, lines, names, domain }: { data:any[]; lines:Array<[string,string]>; names:string[]; domain?:[number,number] }) { return <ResponsiveContainer width="100%" height="100%"><RLineChart data={data} margin={{left:-20,right:10,top:6,bottom:0}}><CartesianGrid stroke="#eef2f7" strokeDasharray="3 4" vertical={false}/><XAxis dataKey="t" tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} minTickGap={30}/><YAxis domain={domain as any} tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} width={32}/><Tooltip contentStyle={{borderRadius:12,border:'1px solid #e2e8f0',fontSize:11}}/><ReferenceLine y={0} stroke="#e2e8f0"/>{lines.map(([key,color],i)=><Line key={key} type="monotone" dataKey={key} name={names[i]||key} stroke={color} strokeWidth={2} dot={false}/>)}</RLineChart></ResponsiveContainer>; }

function DualLine({ data, leftKey, rightKey, leftName, rightName, leftDomain, rightDomain, leftColor, rightColor }: { data:any[]; leftKey:string; rightKey:string; leftName:string; rightName:string; leftDomain:[number,number]; rightDomain:[number,number]; leftColor:string; rightColor:string }) { return <ResponsiveContainer width="100%" height="100%"><RLineChart data={data} margin={{left:-16,right:-8,top:6,bottom:0}}><CartesianGrid stroke="#eef2f7" strokeDasharray="3 4" vertical={false}/><XAxis dataKey="t" tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} minTickGap={30}/><YAxis yAxisId="left" domain={leftDomain as any} tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} width={36}/><YAxis yAxisId="right" orientation="right" domain={rightDomain as any} tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} width={36}/><Tooltip contentStyle={{borderRadius:12,border:'1px solid #e2e8f0',fontSize:11}}/><Legend wrapperStyle={{fontSize:10}}/><Line yAxisId="left" type="monotone" dataKey={leftKey} name={leftName} stroke={leftColor} strokeWidth={2.2} dot={false}/><Line yAxisId="right" type="monotone" dataKey={rightKey} name={rightName} stroke={rightColor} strokeWidth={2} dot={false}/></RLineChart></ResponsiveContainer>; }

function BatteryPage({ state, canControl, onCommand }: { state: TelemetryState; canControl: boolean; onCommand:(c:string,t:string,v?:any)=>void }) {
  const stored = state.battery.stored_energy_kwh ?? state.battery.capacity_kwh * state.battery.soc_percent / 100;
  const charging = state.battery.power_kw < -0.2;
  const discharging = state.battery.power_kw > 0.2;
  return <div className="space-y-5"><SectionHeader title="Battery Management" subtitle="Storage monitoring, energy flow and operator controls" right={<span className="rounded-full bg-cyan-50 px-3 py-1 text-[10px] font-semibold text-cyan-700">{state.battery.state.toUpperCase()}</span>} />
  <div className="grid gap-4 xl:grid-cols-[minmax(340px,.7fr)_minmax(0,1.3fr)]"><Card className="p-7"><div className="flex flex-col items-center justify-center"><div className="relative h-[250px] w-[150px] rounded-[34px] border-[3px] border-slate-200 bg-white p-2 shadow-inner"><div className="absolute left-1/2 -top-4 h-5 w-16 -translate-x-1/2 rounded-t-xl bg-slate-200"/><div className="absolute inset-x-2 bottom-2 rounded-[25px] bg-emerald-50" style={{height:`${Math.max(10,state.battery.soc_percent-3)}%`}}><div className="absolute inset-0 rounded-[25px] bg-gradient-to-t from-emerald-400 to-emerald-300/85"/></div><div className="absolute inset-0 flex items-center justify-center"><div className="text-center"><div className="text-[42px] font-semibold tracking-tight">{state.battery.soc_percent.toFixed(0)}%</div><div className="text-[10px] font-medium text-slate-400">STATE OF CHARGE</div></div></div></div><div className="mt-4 rounded-full bg-slate-50 px-3 py-1 text-[10px] font-semibold text-slate-600">{charging ? 'Charging' : discharging ? 'Discharging' : 'Idle'}</div></div></Card>
  <div className="grid gap-3 sm:grid-cols-2"><MetricCard label="State of Charge" value={state.battery.soc_percent.toFixed(1)} unit="%" icon={<Battery size={16}/>} tone="cyan"/><MetricCard label="State of Health" value="96.0" unit="%" icon={<ShieldCheck size={16}/>} tone="green"/><MetricCard label="Voltage" value="408.8" unit="V" icon={<Zap size={16}/>} tone="blue"/><MetricCard label="Current" value={Math.abs(state.battery.power_kw * 1000 / 408.8).toFixed(1)} unit="A" icon={<Activity size={16}/>} tone="violet"/><MetricCard label="Power" value={Math.abs(state.battery.power_kw).toFixed(1)} unit="kW" icon={<Power size={16}/>} tone={discharging?'amber':charging?'green':'violet'}/><MetricCard label="Capacity" value={(state.battery.capacity_kwh/1000).toFixed(2)} unit="MWh" icon={<Gauge size={16}/>} tone="green"/><MetricCard label="Stored Energy" value={(stored/1000).toFixed(3)} unit="MWh" icon={<Leaf size={16}/>} tone="green"/><MetricCard label="Cycles" value="1240" icon={<TimerReset size={16}/>} tone="amber"/></div></div>
  <div className="grid gap-4 xl:grid-cols-[minmax(0,1.3fr)_minmax(330px,.7fr)]"><Card className="p-5"><SectionHeader title="SOC History" subtitle="Battery operating envelope"/><div className="mt-4 h-[250px]"><ResponsiveContainer width="100%" height="100%"><AreaChart data={state.history.slice(-120)} margin={{left:-20,right:10,top:10,bottom:0}}><defs><linearGradient id="socFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#12bfe0" stopOpacity={.15}/><stop offset="100%" stopColor="#12bfe0" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#eef2f7" strokeDasharray="3 4" vertical={false}/><XAxis dataKey="timestamp" tickFormatter={(v)=>new Date(v).toLocaleTimeString([], {minute:'2-digit',second:'2-digit'})} tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false} minTickGap={25}/><YAxis domain={[0,100]} tick={{fontSize:9,fill:'#94a3b8'}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{borderRadius:12,border:'1px solid #e2e8f0',fontSize:11}}/><Area type="monotone" dataKey="battery_soc" stroke="#0ea5e9" fill="url(#socFill)" strokeWidth={2} name="SOC"/></AreaChart></ResponsiveContainer></div></Card><BatteryControlCard state={state} canControl={canControl} onCommand={onCommand}/></div>
  <BESSFlowPanel state={state}/>
  </div>;
}

function BatteryControlCard({ state, canControl, onCommand }: {state:TelemetryState; canControl:boolean; onCommand:(c:string,t:string,v?:any)=>void}) { return <Card className="p-5"><SectionHeader title="Operator Control" subtitle="Commands are sent Laptop B → FastAPI → Laptop A"/><div className="mt-4 space-y-3"><div><label className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Mode</label><select disabled={!canControl} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs outline-none" value={state.battery.mode.toUpperCase()} onChange={e=>onCommand('battery_mode',state.battery.id,e.target.value)}><option>AUTO</option><option>CHARGE</option><option>DISCHARGE</option><option>IDLE</option><option>MANUAL</option></select></div><div><label className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Target SOC</label><input disabled={!canControl} type="number" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs" value={state.battery.target_soc} onChange={e=>onCommand('set_target_soc',state.battery.id,Number(e.target.value))}/></div><div className="grid grid-cols-3 gap-2"><button disabled={!canControl} onClick={()=>onCommand('battery_charge',state.battery.id,50)} className="rounded-xl bg-emerald-500 px-2 py-2 text-[10px] font-semibold text-white disabled:opacity-40">Charge 50kW</button><button disabled={!canControl} onClick={()=>onCommand('battery_discharge',state.battery.id,50)} className="rounded-xl bg-amber-500 px-2 py-2 text-[10px] font-semibold text-white disabled:opacity-40">Discharge</button><button disabled={!canControl} onClick={()=>onCommand('battery_stop',state.battery.id)} className="rounded-xl bg-slate-700 px-2 py-2 text-[10px] font-semibold text-white disabled:opacity-40">Stop</button></div><div className="rounded-xl bg-slate-50 p-3 text-[10px] text-slate-500">Stored energy <b className="text-slate-800">{(state.battery.stored_energy_kwh ?? 0).toFixed(1)} kWh</b> • PCS <b className="text-slate-800">{state.pcs.direction}</b></div></div></Card>; }

function Protection({ state }: { state: TelemetryState }) { const tx = state.transformer; const alarms = state.alarms; return <div className="space-y-5"><SectionHeader title="Protection" subtitle="Transformer protection circuits, power-quality state and Solarex integration" right={<span className={`rounded-full px-3 py-1 text-[10px] font-semibold ${tx.health === 'Healthy' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>{tx.health}</span>} />
  <Card className="p-5"><SectionHeader title="Power Quality Snapshot" subtitle="Live values affecting system protection"/><div className="mt-4 grid gap-3 md:grid-cols-4"><ProtectionMetric label="Voltage" value={`${(state.buses?.find((b:any)=>b?.type==='LV' && typeof b?.voltage_v==='number')?.voltage_v ?? 415).toFixed(1)} V`} icon={<Zap size={15}/>} /><ProtectionMetric label="Frequency" value={`${state.frequency.toFixed(2)} Hz`} icon={<Activity size={15}/>} /><ProtectionMetric label="Transformer Temperature" value={`${tx.temperature_c.toFixed(1)} °C`} icon={<Thermometer size={15}/>} /><ProtectionMetric label="Solar Irradiance" value="Live twin-derived" icon={<Sun size={15}/>} /></div></Card>
  <Card className="p-5"><SectionHeader title="Hardware Protection Circuits" subtitle="Operator-facing health summary"/><div className="mt-4 grid gap-3 md:grid-cols-2">{[['Snubber Circuit','Voltage spike suppression','Normal','8.8 V clamp'],['EMI Filter','Harmonics & noise reduction','Normal','1.0% THD'],['Flyback Diode','Inductive kickback protection','Normal','0.0 V reverse'],['H-Bridge Circuit','Bidirectional power flow',state.pcs.enabled?'Normal':'Trip',`${state.pcs.efficiency.toFixed(1)}% efficiency`]].map(([title,desc,status,metric])=><div key={title} className="rounded-xl border border-slate-100 bg-slate-50/40 p-4"><div className="flex items-start justify-between"><div><div className="text-[12px] font-semibold">{title}</div><div className="mt-1 text-[10px] text-slate-400">{desc}</div></div><span className="rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-semibold text-emerald-700">{status}</span></div><div className="mt-4 text-[11px] font-semibold text-slate-700">{metric}</div></div>)}</div></Card>
  <Card className="p-5"><SectionHeader title="Transformer Protection" subtitle="Loading and risk indicators"/><div className="mt-4 grid gap-4 lg:grid-cols-[1.2fr_.8fr]"><div><div className="flex items-end justify-between"><div><div className="text-[9px] uppercase tracking-widest text-slate-400">Transformer T1</div><div className="mt-1 text-[28px] font-semibold">{tx.loading_percent.toFixed(1)}%</div></div><div className="text-right"><div className="text-[9px] uppercase tracking-widest text-slate-400">Health</div><div className="mt-1 text-[13px] font-semibold">{tx.health}</div></div></div><div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100"><div className={`${tx.loading_percent > 100 ? 'bg-red-500' : tx.loading_percent > 85 ? 'bg-amber-500' : 'bg-emerald-500'} h-full rounded-full transition-all`} style={{width:`${Math.min(100,tx.loading_percent)}%`}}/></div></div><div className="rounded-xl bg-slate-50 p-4 text-[10px] text-slate-500"><div className="flex justify-between py-1"><span>Rating</span><b className="text-slate-800">{tx.rating_kva.toFixed(0)} kVA</b></div><div className="flex justify-between py-1"><span>Temperature</span><b className="text-slate-800">{tx.temperature_c.toFixed(1)} °C</b></div><div className="flex justify-between py-1"><span>Efficiency</span><b className="text-slate-800">{tx.efficiency.toFixed(1)}%</b></div><div className="flex justify-between py-1"><span>Active alarms</span><b className="text-slate-800">{alarms.length}</b></div></div></div></Card>
  <Solarex />
  </div>; }
function ProtectionMetric({label,value,icon}:{label:string;value:string;icon:React.ReactNode}){return <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-4"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-violet-600 shadow-sm">{icon}</div><div className="mt-3 text-[9px] uppercase tracking-wider text-slate-400">{label}</div><div className="mt-1 text-[14px] font-semibold">{value}</div></div>;}

function AIInsights({ state }: { state: TelemetryState }) { const deficit=state.history.at(-1)?.load_kw! - state.history.at(-1)?.solar_kw!; return <div className="space-y-5"><SectionHeader title="AI Insights" subtitle="Forecasting, anomaly detection and operator recommendations" right={<span className="rounded-full bg-violet-50 px-3 py-1 text-[10px] font-semibold text-violet-700">Powered by GridPulse AI</span>} /><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[['Demand Forecasting','Predict consumption patterns up to 24 hours ahead',<TrendingUp size={16}/>, 'blue'],['Solar Forecasting','Weather-driven renewable generation outlook',<Sun size={16}/>, 'amber'],['Battery Optimization','Charge/discharge scheduling and reserve awareness',<Battery size={16}/>, 'cyan'],['Anomaly Detection','Real-time fault and deviation detection',<AlertTriangle size={16}/>, 'red'],['Peak Prediction','Anticipate demand peaks for load management',<Activity size={16}/>, 'violet'],['Energy Recommendations','Optimize energy mix and operating cost',<Zap size={16}/>, 'green']].map(([t,d,i,c])=><div key={String(t)} className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_7px_24px_rgba(15,23,42,.025)]"><div className={`flex h-9 w-9 items-center justify-center rounded-xl ${c==='green'?'bg-emerald-50 text-emerald-600':c==='red'?'bg-red-50 text-red-600':c==='amber'?'bg-amber-50 text-amber-600':c==='cyan'?'bg-cyan-50 text-cyan-600':c==='blue'?'bg-blue-50 text-blue-600':'bg-violet-50 text-violet-600'}`}>{i}</div><div className="mt-4 text-[12px] font-semibold">{t}</div><div className="mt-1 text-[10px] leading-5 text-slate-400">{d}</div></div>)}</div><Card className="p-5"><SectionHeader title="Live Recommendations" subtitle="Derived from the current power balance and equipment state"/><div className="mt-4 space-y-2">{deficit>0 ? <Recommendation title="Grid Import Optimization" text={`Load currently exceeds solar by ${deficit.toFixed(1)} kW. Consider BESS discharge while preserving configured reserve.`} confidence="87%"/> : <Recommendation title="Solar Surplus Optimization" text={`Solar currently exceeds load by ${Math.abs(deficit).toFixed(1)} kW. Absorb surplus in BESS or export within the configured limit.`} confidence="91%"/>}<Recommendation title="Transformer Watch" text={`Transformer is at ${state.transformer.loading_percent.toFixed(1)}% loading and ${state.transformer.temperature_c.toFixed(1)} °C.`} confidence="84%"/><Recommendation title="PWM Transfer Check" text={`PCS duty is ${(state.pcs.duty_cycle*100).toFixed(1)}% at ${state.pcs.pwm_frequency_hz.toFixed(0)} Hz, transferring ${Math.abs(state.pcs.power_kw).toFixed(1)} kW.`} confidence="96%"/></div></Card><div className="grid gap-4 xl:grid-cols-2"><AIEngineer state={state}/><ForecastView state={state}/></div></div>; }
function Recommendation({title,text,confidence}:{title:string;text:string;confidence:string}){return <div className="flex items-start justify-between gap-4 rounded-xl border border-slate-100 bg-slate-50/60 p-4"><div><div className="flex items-center gap-2 text-[11px] font-semibold"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><Zap size={13}/></span>{title}</div><div className="mt-1 pl-9 text-[10px] leading-5 text-slate-500">{text}</div></div><span className="shrink-0 rounded-full bg-violet-50 px-2.5 py-1 text-[9px] font-semibold text-violet-700">{confidence} confidence</span></div>;}

function Alerts({ state, acked, onAck }: { state:TelemetryState; acked:Record<string,string>; onAck:(id:string)=>void }) { const deduped=useMemo(()=>{const m=new Map<string,TelemetryState['alarms'][number]>(); for(const a of state.alarms){const key=`${a.severity}|${a.source}|${a.message.replace(/\d+(\.\d+)?/g,'#')}`; if(!m.has(key))m.set(key,a);} return [...m.values()];},[state.alarms]); return <div className="space-y-5"><SectionHeader title="Alert Center" subtitle="System notifications and warnings" right={<div className="flex gap-2 text-[10px]"><span className="rounded-full bg-slate-100 px-2.5 py-1.5 font-semibold text-slate-600">{deduped.length} active</span><span className="rounded-full bg-red-50 px-2.5 py-1.5 font-semibold text-red-600">{state.alarms.filter(a=>a.severity==='CRITICAL').length} critical</span></div>} />
  {deduped.length===0 ? <Card className="p-12 text-center"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600"><CheckCircle2 size={25}/></div><div className="mt-4 text-[14px] font-semibold">All systems normal</div><div className="mt-1 text-[11px] text-slate-400">No active alarms detected in the current state.</div></Card> : <div className="space-y-3">{deduped.map(alarm=>{const isAck=Boolean(acked[alarm.id]); const severity=String(alarm.severity).toUpperCase(); const border=severity==='CRITICAL'?'border-red-300':severity==='WARNING'?'border-amber-300':'border-blue-200'; return <Card key={alarm.id} className={`p-4 ${border}`}><div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between"><div className="flex gap-3"><div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${severity==='CRITICAL'?'bg-red-50 text-red-600':severity==='WARNING'?'bg-amber-50 text-amber-600':'bg-blue-50 text-blue-600'}`}>{severity==='CRITICAL'?<AlertTriangle size={14}/>:<AlertTriangle size={14}/>}</div><div><div className="flex items-center gap-2"><h3 className="text-[12px] font-semibold">{alarm.message}</h3><span className={`rounded-full px-2 py-0.5 text-[8px] font-semibold ${severity==='CRITICAL'?'bg-red-50 text-red-700':severity==='WARNING'?'bg-amber-50 text-amber-700':'bg-blue-50 text-blue-700'}`}>{severity}</span></div><div className="mt-1 text-[9px] text-slate-400">Component: {alarm.source} • {new Date(alarm.timestamp).toLocaleString()}</div><div className="mt-3 rounded-xl bg-slate-50 p-3 text-[10px] text-slate-500">Recommendation: {severity==='CRITICAL' ? 'Inspect the affected equipment and follow the active protection response.' : 'Monitor the condition and consider operator intervention if it persists.'}</div>{isAck&&<div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-semibold text-emerald-700"><CheckCircle2 size={11}/>Acknowledged</div>}</div></div><button disabled={isAck} onClick={()=>onAck(alarm.id)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[9px] font-semibold text-slate-600 hover:bg-slate-50 disabled:cursor-default disabled:opacity-60">{isAck?'Acknowledged':'Acknowledge'}</button></div></Card>})}</div>}
  <Card className="p-5"><SectionHeader title="Alarm History" subtitle="Recent system notifications"/><div className="mt-3 space-y-2">{(state.alarm_history||[]).slice(-12).reverse().map(a=><div key={`${a.id}-${a.timestamp}`} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/50 px-3 py-2.5"><div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${a.severity==='CRITICAL'?'bg-red-500':a.severity==='WARNING'?'bg-amber-500':'bg-blue-500'}`}/><span className="text-[10px] font-medium">{a.message}</span></div><span className="text-[9px] text-slate-400">{new Date(a.timestamp).toLocaleTimeString()}</span></div>)}</div></Card>
  </div>; }

function HistoryPage({ state }: { state: TelemetryState }) { const events=(state.alarm_history||[]).slice(-30).reverse(); return <div className="space-y-5"><SectionHeader title="History" subtitle="System events, power trends and operator context" right={<button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-[10px] font-semibold text-slate-600"><Download size={13}/> Export</button>} /><div className="grid gap-4 xl:grid-cols-[1.15fr_.85fr]"><Card className="p-5"><SectionHeader title="Power History" subtitle="Recent telemetry buffer"/><div className="mt-4 h-[300px]"><SimpleLine data={state.history.slice(-120).map(h=>({t:new Date(h.timestamp).toLocaleTimeString([], {minute:'2-digit',second:'2-digit'}), generation:h.solar_kw,load:h.load_kw,import:h.grid_import_kw}))} lines={[['generation','#10b981'],['load','#7c5cff'],['import','#4f8cff']]} names={['Generation','Load','Import']}/></div></Card><Card className="p-5"><SectionHeader title="Event Timeline" subtitle="Recent alarms and system changes"/><div className="mt-4 space-y-4">{events.map((e,i)=><div key={`${e.id}-${i}`} className="flex gap-3"><div className="flex w-4 shrink-0 flex-col items-center"><span className={`mt-1.5 h-2.5 w-2.5 rounded-full ${e.severity==='CRITICAL'?'bg-red-500':e.severity==='WARNING'?'bg-amber-500':'bg-blue-500'}`}/>{i<events.length-1&&<span className="mt-1 h-full w-px bg-slate-200"/>}</div><div className="pb-3"><div className="text-[10px] font-semibold">{e.message}</div><div className="mt-1 text-[9px] text-slate-400">{new Date(e.timestamp).toLocaleString()} • {e.source}</div></div></div>)}{events.length===0&&<EmptyState label="No historical events yet."/>}</div></Card></div></div>; }

function EngineeringStudio({ state, studioPage, setStudioPage, selectedAsset, setSelectedAsset, onCommand, canControl }: { state:TelemetryState;studioPage:StudioPage;setStudioPage:(p:StudioPage)=>void;selectedAsset:string|null;setSelectedAsset:(s:string|null)=>void;onCommand:(c:string,t:string,v?:any)=>void;canControl:boolean }) { return <div className="space-y-5"><div className="flex flex-wrap gap-2 rounded-2xl border border-slate-200/80 bg-white p-2 shadow-[0_7px_24px_rgba(15,23,42,0.025)]">{STUDIO_NAV.map(s=><button key={s.id} onClick={()=>setStudioPage(s.id)} className={`rounded-xl px-3 py-2 text-[10px] font-semibold transition ${studioPage===s.id?'bg-violet-50 text-violet-700':'text-slate-500 hover:bg-slate-50'}`}>{s.label}</button>)}</div>
  <AnimatePresence mode="wait" initial={false}><motion.div key={studioPage} className="min-h-[320px]" initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: 0.2 }}>{studioPage==='one-line'&&<EngineeringOneLine state={state} selectedAsset={selectedAsset} onAssetSelect={setSelectedAsset} onCommand={onCommand} canControl={canControl}/>} {studioPage==='digital-twin'&&<DigitalTwin state={state} selectedAsset={selectedAsset} onAssetSelect={setSelectedAsset}/>} {studioPage==='scenario'&&<ScenarioLab state={state}/>} {studioPage==='studies'&&<StudiesCenter state={state}/>} {studioPage==='forecast'&&<ForecastView state={state}/>} {studioPage==='events'&&<EventsView state={state}/>} {studioPage==='replay'&&<ReplayView state={state}/>} {studioPage==='grid-intelligence'&&<div className="grid gap-4 xl:grid-cols-2"><LiveGraphs state={state}/><AnomalyView state={state} onAssetSelect={setSelectedAsset}/></div>} {studioPage==='ai-engineer'&&<AIEngineer state={state}/>} {studioPage==='anomaly'&&<AnomalyView state={state} onAssetSelect={setSelectedAsset}/>} {studioPage==='advanced'&&<AdvancedGridIntelligence state={state}/>} {studioPage==='optimization'&&<GridOptimizationCenter state={state}/>} {studioPage==='energy-story'&&(selectedAsset ? <div className="grid gap-4 xl:grid-cols-2"><EnergyStory state={state} assetId={selectedAsset}/><WhyEngine state={state} assetId={selectedAsset}/></div> : <EmptyState label="Select an asset in the Digital Twin or One-Line to view its energy story."/> )}</motion.div></AnimatePresence>
  {selectedAsset&&<Card className="p-4"><div className="flex items-center justify-between"><div><div className="text-[10px] uppercase tracking-wider text-slate-400">Selected asset</div><div className="mt-1 text-[13px] font-semibold">{selectedAsset}</div></div><button onClick={()=>setSelectedAsset(null)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-50"><X size={15}/></button></div></Card>}
  </div>; }

function EmptyState({ label }: { label:string }) { return <div className="flex h-full min-h-[180px] items-center justify-center text-center text-[11px] text-slate-400">{label}</div>; }

