import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bot, Send, X, Sparkles, AlertTriangle, Battery, Zap, Thermometer, BookOpen, Activity } from 'lucide-react';
import type { TelemetryState } from '../services/api';
import { retrieveKnowledge } from '../services/gridpulseKnowledge';

interface Props { state: TelemetryState; onOpenAlerts?: () => void; }
type Msg = { role:'user'|'assistant'; text:string };
function n(v:any,d=0){const x=Number(v);return Number.isFinite(x)?x:d;}
function totals(state:TelemetryState){const solar=state.houses.reduce((s:any,h:any)=>s+n(h.pv_kw),0)+n(state.community?.pv_kw);const load=state.houses.reduce((s:any,h:any)=>s+n(h.load_kw),0)+n(state.community?.load_kw);return {solar,load};}

export default function GridPulseChatbot({state,onOpenAlerts}:Props){
 const [open,setOpen]=useState(false),[input,setInput]=useState('');
 const [messages,setMessages]=useState<Msg[]>([{role:'assistant',text:'I’m GridPulse AI. I combine the live grid state with an embedded engineering knowledge library. Ask me technical, operational, protection, BESS, transformer, PV, SCADA, DERMS, cybersecurity, forecasting, Solarex or GRIDPULSE questions.'}]);
 const {solar,load}=useMemo(()=>totals(state),[state]);
 const battery:any=(state as any).battery||(state as any).bess||{}; const transformer:any=(state as any).transformer||{}; const alarms:any[]=Array.isArray(state.alarms)?state.alarms.filter((a:any)=>a.active!==false):[]; const pwm:any=(state as any).pcs||{};
 const answer=(q:string)=>{
   const x=q.toLowerCase(); const soc=n(battery.soc_percent??battery.soc??(state as any).bess_soc); const loading=n(transformer.loading_percent??transformer.loading??(state as any).transformer_loading); const temp=n(transformer.temperature_c??transformer.temperature??(state as any).transformer_temp_c); const net=solar-load;
   const live = x.match(/alarm|warning|battery|bess|soc|transformer|temperature|solar|pv|power flow|pwm|health|status|current|live|telemetry|loading/);
   if(x.includes('alarm')||x.includes('warning')) return alarms.length?`Live alarm state: ${alarms.length} active alarm(s). ${alarms.slice(0,5).map(a=>`${String(a.severity||'ALARM')}: ${a.message||a.name||'Grid event'}`).join(' • ')}`:'Live alarm state: no active alarms are currently reported.';
   if(x.includes('battery')||x.includes('bess')||x.includes('soc')) return `Live BESS: SOC ${soc.toFixed(1)}%, power ${n(battery.power_kw??battery.power).toFixed(1)} kW. ${soc<20?'SOC is low; review discharge limits.':soc>90?'SOC is high; charging headroom is limited.':'SOC is in the normal operating band.'}`;
   if(x.includes('transformer')||x.includes('temperature')) return `Live transformer: loading ${loading.toFixed(1)}%, temperature ${temp.toFixed(1)} °C. ${loading>90?'Overload risk is elevated.':loading>75?'Loading is approaching the warning band.':'Loading is currently moderate.'}`;
   if(x.includes('solar')||x.includes('pv')||x.includes('power flow')) return `Live power flow: solar ${solar.toFixed(1)} kW, load ${load.toFixed(1)} kW, net ${Math.abs(net).toFixed(1)} kW ${net>=0?'surplus':'deficit'}.`;
   if(x.includes('pwm')) return `Live PCS PWM: ${n(pwm.pwm_frequency_hz).toFixed(0)} Hz, ${(n(pwm.duty_cycle)*100).toFixed(1)}% duty cycle, ${n(pwm.average_power_kw??pwm.power_kw).toFixed(1)} kW average transfer power.`;
   if(x.includes('scenario')) return 'Use Engineering Studio → Scenario Lab for Solar < Load, Solar > Load, Evening Peak, BESS charge/discharge, Grid Outage, Transformer Overload, PV Trip, PCS Trip, voltage sag/swell and other scenarios.';
   if(x.includes('solarex')||x.includes('solar calculator')) return 'Solarex estimates PV sizing, savings, payback and carbon impact from locality, monthly electricity bill and roof area.';
   if(x.includes('health')||x==='status') return `Live system summary: ${alarms.length?'attention required':'no active alarms'}; transformer ${loading.toFixed(1)}% loaded; BESS SOC ${soc.toFixed(1)}%; solar ${solar.toFixed(1)} kW; load ${load.toFixed(1)} kW.`;
   const hits=retrieveKnowledge(q,4);
   if(hits.length){ return hits.map((h,i)=>`${i+1}. ${h.title}: ${h.content}`).join('\n\n'); }
   if(live) return 'I could not map that request to a known telemetry field. Ask for a specific asset, measurement, alarm, scenario or engineering topic.';
   return 'I can answer from the GRIDPULSE engineering library and live telemetry. Try SCADA, DERMS, digital twin, power flow, BESS, SOC/SOH, transformer protection, PWM, harmonics, reactive power, PV, forecasting, DLR, topology, N-1, cybersecurity/FDIA, Solarex, carbon, scenarios, or troubleshooting.';
 };
 const send=()=>{const q=input.trim();if(!q)return;setMessages(m=>[...m,{role:'user',text:q},{role:'assistant',text:answer(q)}]);setInput('');};
 return <>
  <button aria-label="Open GridPulse AI" onClick={()=>setOpen(true)} className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-[0_18px_50px_rgba(15,23,42,.25)] transition hover:-translate-y-1 hover:bg-violet-700"><Sparkles size={20}/><span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-white"/></button>
  <AnimatePresence>{open&&<motion.div initial={{opacity:0,y:20,scale:.97}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:20,scale:.97}} className="fixed bottom-5 right-5 z-[60] flex h-[min(700px,calc(100vh-40px))] w-[min(470px,calc(100vw-32px))] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-[0_28px_90px_rgba(15,23,42,.22)]">
   <div className="flex items-center justify-between border-b border-slate-100 bg-slate-950 px-4 py-3 text-white"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600"><Bot size={18}/></div><div><div className="text-sm font-semibold">GridPulse AI</div><div className="text-[10px] text-slate-300">Engineering knowledge + live telemetry</div></div></div><button onClick={()=>setOpen(false)} className="rounded-lg p-2 hover:bg-white/10"><X size={16}/></button></div>
   <div className="flex flex-wrap gap-2 border-b border-slate-100 p-3"><Quick icon={<Zap size={12}/>} text="Power flow" onClick={()=>setInput('What is the power flow?')}/><Quick icon={<Battery size={12}/>} text="BESS" onClick={()=>setInput('Explain BESS SOC and SOH')}/><Quick icon={<Thermometer size={12}/>} text="Transformer" onClick={()=>setInput('Explain transformer protection')}/><Quick icon={<BookOpen size={12}/>} text="SCADA" onClick={()=>setInput('Explain SCADA')}/><Quick icon={<Activity size={12}/>} text="DERMS" onClick={()=>setInput('What is DERMS?')}/><Quick icon={<AlertTriangle size={12}/>} text="Alarms" onClick={()=>setInput('Any alarms?')}/></div>
   <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-slate-50/70 p-4">{messages.map((m,i)=><div key={i} className={`flex ${m.role==='user'?'justify-end':'justify-start'}`}><div className={`max-w-[90%] whitespace-pre-line rounded-2xl px-3.5 py-2.5 text-[11px] leading-5 ${m.role==='user'?'bg-violet-600 text-white':'border border-slate-200 bg-white text-slate-700 shadow-sm'}`}>{m.text}</div></div>)}</div>
   <div className="border-t border-slate-100 bg-white p-3">{onOpenAlerts&&<button onClick={onOpenAlerts} className="mb-2 text-[10px] font-semibold text-violet-600">Open Alerts →</button>}<div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-1.5"><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')send()}} placeholder="Ask any GridPulse engineering question…" className="min-w-0 flex-1 bg-transparent px-2 text-xs outline-none"/><button onClick={send} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-950 text-white"><Send size={14}/></button></div></div>
  </motion.div>}</AnimatePresence>
 </>;
}
function Quick({icon,text,onClick}:{icon:any;text:string;onClick:()=>void}){return <button onClick={onClick} className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1.5 text-[9px] font-semibold text-slate-600 hover:border-violet-200 hover:text-violet-600">{icon}{text}</button>}
