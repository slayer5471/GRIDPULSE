import React from 'react'
import ReactDOM from 'react-dom/client'
import LaptopBApp from './LaptopBApp'
import ErrorBoundary from './ErrorBoundary'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary><LaptopBApp /></ErrorBoundary>
  </React.StrictMode>,
)
