# GRIDPULSE - Running Two Independent Applications

## Overview

GRIDPULSE now consists of **two completely separate applications** that can run on different machines:

- **Laptop A** (Circuit Editor) - Port 3001
- **Laptop B** (Control Center + Solarex) - Port 3002

Each application has its own entry point, build configuration, and can be deployed independently.

---

## Quick Start

### Option 1: Run Laptop A Only

```bash
npm run dev:laptop-a
```

Access: **http://localhost:3001**

This runs only the Circuit Editor application.

### Option 2: Run Laptop B Only

```bash
npm run dev:laptop-b
```

Access: **http://localhost:3002**

This runs only the Control Center + Solarex application.

### Option 3: Run Both Laptops (Development)

```bash
npm run dev:both
```

This runs both applications simultaneously:
- Laptop A: http://localhost:3001
- Laptop B: http://localhost:3002

---

## Building for Production

### Build Laptop A Only

```bash
npm run build:laptop-a
```

Output: `dist-laptop-a/`

Deploy this directory to your Laptop A server.

### Build Laptop B Only

```bash
npm run build:laptop-b
```

Output: `dist-laptop-b/`

Deploy this directory to your Laptop B server.

### Build Both

```bash
npm run build:both
```

This builds both applications sequentially.

---

## Deployment on Two Separate Machines

### Machine A (Laptop A - Circuit Editor)

1. **Build the application:**
   ```bash
   npm run build:laptop-a
   ```

2. **Deploy the `dist-laptop-a/` directory** to Machine A

3. **Serve with a static file server:**
   ```bash
   # Using serve
   serve -s dist-laptop-a -l 3001
   
   # Or using nginx
   # Configure nginx to serve dist-laptop-a on port 3001
   ```

4. **Access:** http://192.168.1.100:3001 (or your Machine A IP)

### Machine B (Laptop B - Control Center)

1. **Build the application:**
   ```bash
   npm run build:laptop-b
   ```

2. **Configure environment variables:**
   ```bash
   export VITE_API_URL=http://192.168.1.100:8000
   export VITE_WS_URL=ws://192.168.1.100:8000/ws/telemetry
   ```
   (Replace 192.168.1.100 with your FastAPI server IP)

3. **Deploy the `dist-laptop-b/` directory** to Machine B

4. **Serve with a static file server:**
   ```bash
   # Using serve
   serve -s dist-laptop-b -l 3002
   
   # Or using nginx
   # Configure nginx to serve dist-laptop-b on port 3002
   ```

5. **Access:** http://192.168.1.101:3002 (or your Machine B IP)

### Machine C (Backend - FastAPI)

1. **Start the FastAPI backend:**
   ```bash
   cd backend
   python main.py
   ```

2. **Access:** http://192.168.1.100:8000 (or your backend server IP)

---

## Architecture

```
┌─────────────────────────────────────┐
│         LAPTOP A (Machine A)        │
│      http://192.168.1.100:3001      │
│                                     │
│   ┌─────────────────────────────┐  │
│   │   Circuit Editor            │  │
│   │   • Canvas                  │  │
│   │   • Components              │  │
│   │   • Power Flow              │  │
│   │   • Validation              │  │
│   └─────────────────────────────┘  │
└─────────────────────────────────────┘
                 ↓
         FastAPI Backend
    http://192.168.1.100:8000
                 ↓
┌─────────────────────────────────────┐
│         LAPTOP B (Machine B)        │
│      http://192.168.1.101:3002      │
│                                     │
│   ┌─────────────────────────────┐  │
│   │   Control Center            │  │
│   │   • Monitoring              │  │
│   │   • Controls                │  │
│   │   • Analytics               │  │
│   │   • Solarex                 │  │
│   └─────────────────────────────┘  │
└─────────────────────────────────────┘
```

---

## File Structure

```
gridpulse/
├── laptop-a.html              # Entry point for Laptop A
├── laptop-b.html              # Entry point for Laptop B
├── vite.config.laptop-a.js    # Build config for Laptop A
├── vite.config.laptop-b.js    # Build config for Laptop B
│
├── src/
│   ├── main-laptop-a.tsx      # React entry for Laptop A
│   ├── main-laptop-b.tsx      # React entry for Laptop B
│   ├── LaptopAApp.tsx         # Laptop A root component
│   ├── LaptopBApp.tsx         # Laptop B root component
│   │
│   ├── components/
│   │   ├── CircuitEditor.tsx  # Laptop A: Circuit editor
│   │   ├── ControlCenter.tsx  # Laptop B: Control center
│   │   ├── circuit/           # Laptop A components
│   │   └── solarex/           # Laptop B: Solarex components
│   │
│   ├── engine/
│   │   └── ElectricalModel.ts # Laptop A: Electrical model
│   │
│   ├── types/
│   │   ├── circuit.ts         # Laptop A: Types
│   │   └── solarex.ts         # Laptop B: Types
│   │
│   ├── hooks/
│   │   └── useWebSocket.ts    # Laptop B: WebSocket
│   │
│   └── services/
│       ├── api.ts             # Laptop B: API client
│       ├── demoTelemetry.ts   # Laptop B: Demo data
│       └── solarexCalculator.ts # Laptop B: Solar calc
│
├── dist-laptop-a/             # Built Laptop A (after build)
├── dist-laptop-b/             # Built Laptop B (after build)
│
└── backend/                   # FastAPI backend
    ├── main.py
    └── requirements.txt
```

---

## Nginx Configuration Examples

### Laptop A (Port 3001)

```nginx
server {
    listen 3001;
    server_name localhost;
    
    root /path/to/dist-laptop-a;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # CORS for FastAPI
    add_header 'Access-Control-Allow-Origin' 'http://192.168.1.101:3002' always;
    add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
    add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization' always;
}
```

### Laptop B (Port 3002)

```nginx
server {
    listen 3002;
    server_name localhost;
    
    root /path/to/dist-laptop-b;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Proxy to FastAPI
    location /api {
        proxy_pass http://192.168.1.100:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    # WebSocket proxy
    location /ws {
        proxy_pass http://192.168.1.100:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

---

## Docker Deployment

### Dockerfile for Laptop A

```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build:laptop-a

FROM nginx:alpine
COPY --from=build /app/dist-laptop-a /usr/share/nginx/html
COPY nginx-laptop-a.conf /etc/nginx/conf.d/default.conf
EXPOSE 3001
CMD ["nginx", "-g", "daemon off;"]
```

### Dockerfile for Laptop B

```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build:laptop-b

FROM nginx:alpine
COPY --from=build /app/dist-laptop-b /usr/share/nginx/html
COPY nginx-laptop-b.conf /etc/nginx/conf.d/default.conf
EXPOSE 3002
CMD ["nginx", "-g", "daemon off;"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  laptop-a:
    build:
      context: .
      dockerfile: Dockerfile.laptop-a
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
  
  laptop-b:
    build:
      context: .
      dockerfile: Dockerfile.laptop-b
    ports:
      - "3002:3002"
    environment:
      - VITE_API_URL=http://backend:8000
      - VITE_WS_URL=ws://backend:8000/ws/telemetry
  
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - FASTAPI_HOST=0.0.0.0
      - FASTAPI_PORT=8000
```

---

## Testing the Separation

### Test 1: Laptop A Independence

```bash
# Start only Laptop A
npm run dev:laptop-a

# Open in browser
http://localhost:3001

# Verify:
✓ Circuit editor loads
✓ Can add components
✓ Can draw wires
✓ Can run power flow
✓ No connection to Laptop B
```

### Test 2: Laptop B Independence

```bash
# Start only Laptop B
npm run dev:laptop-b

# Open in browser
http://localhost:3002

# Click "Use Demo Mode"

# Verify:
✓ Control center loads
✓ Shows demo telemetry
✓ Can use Solarex
✓ No connection to Laptop A
```

### Test 3: Both Together

```bash
# Terminal 1: Start FastAPI
cd backend && python main.py

# Terminal 2: Start Laptop A
npm run dev:laptop-a
# Open: http://localhost:3001

# Terminal 3: Start Laptop B
npm run dev:laptop-b
# Open: http://localhost:3002

# Verify:
✓ Both apps work independently
✓ Laptop B receives telemetry from FastAPI
✓ Commands from Laptop B affect the backend
```

---

## Troubleshooting

### Issue: Port already in use

**Solution:**
```bash
# Find process using port 3001
lsof -i :3001

# Kill the process
kill -9 <PID>

# Or use a different port
npm run dev:laptop-a -- --port 3003
```

### Issue: Laptop B can't connect to FastAPI

**Solution:**
1. Check if FastAPI is running: `curl http://localhost:8000/api/health`
2. Verify VITE_API_URL environment variable
3. Check CORS settings in FastAPI
4. Verify network connectivity

### Issue: Build fails

**Solution:**
```bash
# Clean node_modules
rm -rf node_modules
npm install

# Clear build cache
rm -rf dist-laptop-a dist-laptop-b

# Rebuild
npm run build:both
```

---

## Summary

✅ **Two Completely Separate Applications**
- Laptop A: Circuit Editor (Port 3001)
- Laptop B: Control Center + Solarex (Port 3002)

✅ **Independent Deployment**
- Can run on different machines
- Separate build outputs
- Independent scaling

✅ **Clear Communication**
- FastAPI backend mediates all communication
- WebSocket for real-time telemetry
- REST API for commands

✅ **No Mode Switcher**
- No confusion about which app you're using
- Direct access via URL
- Bookmarkable

---

**GRIDPULSE v1.0.0**  
**Two Independent Applications**  
**Ready for Production Deployment**
