# Blank-screen fix: lucide-react icon compatibility

The runtime error was caused by importing `TriangleAlert` while this project pins `lucide-react` to `0.294.0`.
That version exports `AlertTriangle`, not `TriangleAlert`.

Fixed in:
- `laptop-b/src/components/ControlCenter.tsx`

After updating, clear Vite's optimized dependency cache before starting Laptop B:

```bash
rm -rf node_modules/.vite
npm run dev:laptop-b -- --force
```

Then open `http://localhost:3002`.
