import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    outDir: 'dist-laptop-b',
    rollupOptions: {
      input: {
        'laptop-b': './laptop-b.html',
      },
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]',
      },
    },
  },
  server: {
    host: "0.0.0.0",
    port: 3002,
    strictPort: true,
    hmr: {
      port: 3002,
    },
  },
});
