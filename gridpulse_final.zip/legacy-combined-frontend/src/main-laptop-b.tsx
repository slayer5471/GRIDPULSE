import React from 'react'
import ReactDOM from 'react-dom/client'
import LaptopBApp from './LaptopBApp'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <LaptopBApp />
  </React.StrictMode>,
)
