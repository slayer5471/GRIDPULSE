// LAPTOP A - Circuit Editor (Electrical Engineering Workspace)
// This is a completely independent application focused ONLY on circuit editing
import { useState, useEffect } from 'react';
import CircuitEditor from './components/CircuitEditor';

export default function LaptopAApp() {
  return (
    <div className="h-screen flex flex-col bg-slate-100">
      {/* Laptop A Header - Circuit Editor Only */}
      <header className="bg-white border-b border-slate-200 px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900">GRIDPULSE</h1>
              <p className="text-[10px] text-slate-500">Laptop A • Circuit Editor • v1.0.0</p>
            </div>
          </div>
          <div className="text-xs text-slate-500">
            Electrical Circuit Host • Pandapower Engine
          </div>
        </div>
      </header>

      {/* Circuit Editor - Full Screen */}
      <div className="flex-1 overflow-hidden">
        <CircuitEditor />
      </div>
    </div>
  );
}
