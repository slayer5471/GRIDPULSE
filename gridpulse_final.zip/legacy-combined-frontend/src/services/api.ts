// GRIDPULSE v1.0.0 - API Service
// Connects to FastAPI backend on Laptop A

const API_BASE = (import.meta as any).env?.VITE_API_URL || 'http://localhost:8000';

export interface TelemetryState {
  timestamp: string;
  sequence: number;
  frequency: number;
  grid: {
    voltage_kv: number;
    import_kw: number;
    export_kw: number;
    export_limit_kw: number;
  };
  transformer: {
    id: string;
    rating_kva: number;
    primary_voltage_kv: number;
    secondary_voltage_v: number;
    loading_percent: number;
    temperature_c: number;
    efficiency: number;
    health: string;
  };
  buses: Array<{ id: string; voltage_kv?: number; voltage_v?: number; type: string }>;
  houses: Array<{
    id: string;
    load_kw: number;
    pv_kw: number;
    net_kw: number;
    voltage_v: number;
  }>;
  community: {
    id: string;
    load_kw: number;
    pv_kw: number;
    net_kw: number;
  };
  battery: {
    id: string;
    capacity_kwh: number;
    soc_percent: number;
    power_kw: number;
    state: string;
    mode: string;
    target_soc: number;
    min_soc: number;
    max_soc: number;
  };
  pcs: {
    id: string;
    enabled: boolean;
    pwm_frequency_hz: number;
    duty_cycle: number;
    power_kw: number;
    efficiency: number;
  };
  ems_mode: string;
  pricing: {
    import_tariff: number;
    export_tariff: number;
    current_period: string;
  };
  alarms: Array<{
    id: string;
    timestamp: string;
    severity: string;
    source: string;
    message: string;
    active: boolean;
  }>;
  history: Array<{
    timestamp: string;
    solar_kw: number;
    load_kw: number;
    grid_import_kw: number;
    grid_export_kw: number;
    battery_soc: number;
    battery_power_kw: number;
    transformer_loading: number;
  }>;
}

class ApiService {
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('gridpulse_token', token);
  }

  getToken(): string | null {
    if (!this.token) {
      this.token = localStorage.getItem('gridpulse_token');
    }
    return this.token;
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('gridpulse_token');
  }

  private async request(path: string, options: RequestInit = {}) {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {}),
    };
    
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: 'Request failed' }));
      throw new Error(error.detail || `HTTP ${response.status}`);
    }

    return response.json();
  }

  async login(username: string, password: string) {
    const data = await this.request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    this.setToken(data.token);
    return data;
  }

  async getState(): Promise<TelemetryState> {
    return this.request('/api/state');
  }

  async getHistory() {
    return this.request('/api/history');
  }

  async getAlarms() {
    return this.request('/api/alarms');
  }

  async sendCommand(command: string, target: string, value?: any) {
    return this.request('/api/commands', {
      method: 'POST',
      body: JSON.stringify({ command, target, value }),
    });
  }

  async updateBattery(data: Record<string, any>) {
    return this.request('/api/battery', {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  async updateGrid(data: Record<string, any>) {
    return this.request('/api/grid', {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  async getPricing() {
    return this.request('/api/pricing');
  }

  async getSolarex(locality: string, monthlyBill: number, roofSize: number) {
    return this.request(`/api/solarex?locality=${locality}&monthly_bill=${monthlyBill}&roof_size=${roofSize}`);
  }

  async getForecast() {
    return this.request('/api/forecast');
  }

  async health() {
    return this.request('/api/health');
  }
}

export const api = new ApiService();
