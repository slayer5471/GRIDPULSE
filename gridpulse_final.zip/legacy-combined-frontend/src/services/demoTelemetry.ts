// GRIDPULSE v1.0.0 - Demo Telemetry Generator
// Provides deterministic electrical data when Laptop A backend is unavailable
// NO Math.random() - all values are deterministic based on time

import { TelemetryState } from '../services/api';

export function generateDemoTelemetry(): TelemetryState {
  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();
  const timeOfDay = hour + minute / 60;
  
  // Deterministic solar profile (peaks at noon, zero at night)
  const solarFactor = Math.max(0, Math.sin((timeOfDay - 6) * Math.PI / 12));
  
  // Deterministic load profile
  let loadFactor: number;
  if (timeOfDay >= 17 && timeOfDay < 22) {
    loadFactor = 1.0; // Evening peak
  } else if (timeOfDay >= 6 && timeOfDay < 9) {
    loadFactor = 0.8; // Morning
  } else if (timeOfDay >= 9 && timeOfDay < 17) {
    loadFactor = 0.6; // Daytime
  } else {
    loadFactor = 0.4; // Night
  }

  // Generate 5 houses with deterministic values
  const houses = Array.from({ length: 5 }, (_, i) => {
    const baseLoad = 5 + i * 0.5; // 5.0, 5.5, 6.0, 6.5, 7.0 kW
    const load = baseLoad * loadFactor;
    const pv = 8 * solarFactor; // 8 kW capacity each
    const net = pv - load;
    const voltage = 415 - (load * 0.5); // Voltage drop with load
    
    return {
      id: `HOUSE-${String(i + 1).padStart(2, '0')}`,
      load_kw: load,
      pv_kw: pv,
      net_kw: net,
      voltage_v: voltage,
    };
  });

  // Community building
  const community = {
    id: 'COMMUNITY-01',
    load_kw: 50 * loadFactor,
    pv_kw: 20 * solarFactor,
    net_kw: 20 * solarFactor - 50 * loadFactor,
  };

  // Calculate totals
  const totalSolar = houses.reduce((sum, h) => sum + h.pv_kw, 0) + community.pv_kw;
  const totalLoad = houses.reduce((sum, h) => sum + h.load_kw, 0) + community.load_kw;
  const surplus = totalSolar - totalLoad;

  // Battery logic (deterministic)
  const batteryPower = surplus > 0 ? Math.min(surplus * 0.5, 50) : Math.max(surplus * 0.5, -50);
  const batteryState = batteryPower > 0 ? 'CHARGING' : batteryPower < 0 ? 'DISCHARGING' : 'IDLE';
  
  // Grid exchange
  const gridExport = Math.min(Math.max(0, surplus - batteryPower), 100);
  const gridImport = Math.max(0, -surplus - batteryPower);

  // Transformer loading
  const transformerLoading = (totalLoad / 500) * 100;
  const transformerHealth = transformerLoading > 90 ? 'CRITICAL' : transformerLoading > 75 ? 'WARNING' : 'HEALTHY';

  return {
    timestamp: now.toISOString(),
    sequence: Date.now(),
    frequency: 50.0,
    grid: {
      voltage_kv: 11.0,
      import_kw: gridImport,
      export_kw: gridExport,
      export_limit_kw: 100,
    },
    transformer: {
      id: 'TX-01',
      rating_kva: 500,
      primary_voltage_kv: 11.0,
      secondary_voltage_v: 415,
      loading_percent: transformerLoading,
      temperature_c: 45 + transformerLoading * 0.3,
      efficiency: 0.98,
      health: transformerHealth,
    },
    buses: [
      { id: 'BUS-11KV', voltage_kv: 11.0, type: 'MV' },
      { id: 'BUS-415V', voltage_v: 415 - (totalLoad * 0.01), type: 'LV' },
    ],
    houses,
    community,
    battery: {
      id: 'BESS-01',
      capacity_kwh: 200,
      soc_percent: 50 + surplus * 0.1,
      power_kw: batteryPower,
      state: batteryState,
      mode: 'AUTO',
      target_soc: 80,
      min_soc: 20,
      max_soc: 95,
    },
    pcs: {
      id: 'PCS-01',
      enabled: true,
      pwm_frequency_hz: 10000,
      duty_cycle: 0.5,
      power_kw: Math.abs(batteryPower),
      efficiency: 0.96,
    },
    ems_mode: 'LOCAL_FIRST',
    pricing: {
      import_tariff: 8.0,
      export_tariff: 4.0,
      current_period: 'NORMAL',
    },
    alarms: [],
    history: [],
  };
}
