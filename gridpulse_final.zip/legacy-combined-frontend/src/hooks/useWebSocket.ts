// GRIDPULSE v1.0.0 - WebSocket Hook
import { useEffect, useRef, useState, useCallback } from 'react';
import { TelemetryState } from '../services/api';

const WS_URL = (import.meta as any).env?.VITE_WS_URL || 'ws://localhost:8000/ws/telemetry';

export type ConnectionStatus = 'LIVE' | 'STALE' | 'RECONNECTING' | 'DISCONNECTED' | 'DEMO';

export function useWebSocket(shouldConnect: boolean = true) {
  const [state, setState] = useState<TelemetryState | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>('DISCONNECTED');
  const [lastUpdate, setLastUpdate] = useState<number>(0);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>();
  const reconnectAttemptsRef = useRef(0);
  const staleCheckIntervalRef = useRef<any>();

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    if (!shouldConnect) return;

    setStatus('RECONNECTING');
    
    try {
      // Get authentication token
      const token = localStorage.getItem('gridpulse_token');
      const wsUrl = token ? `${WS_URL}?token=${encodeURIComponent(token)}` : WS_URL;
      
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('[GRIDPULSE] WebSocket connected to Laptop A');
        setStatus('LIVE');
        reconnectAttemptsRef.current = 0;
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          if (message.type === 'telemetry' && message.data) {
            setState(message.data);
            setLastUpdate(Date.now());
          } else if (message.type === 'error') {
            console.error('[GRIDPULSE] WebSocket error:', message.message);
            if (message.code === 'AUTH_FAILED') {
              // Authentication failed, clear token and show login
              localStorage.removeItem('gridpulse_token');
              localStorage.removeItem('gridpulse_role');
              window.location.reload();
            }
          }
        } catch (error) {
          console.error('[GRIDPULSE] Failed to parse message:', error);
        }
      };

      ws.onerror = (error) => {
        console.error('[GRIDPULSE] WebSocket error:', error);
        setStatus('DISCONNECTED');
      };

      ws.onclose = (event) => {
        console.log('[GRIDPULSE] WebSocket closed', event.code, event.reason);
        setStatus('DISCONNECTED');
        
        // Exponential backoff reconnect
        const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
        reconnectAttemptsRef.current++;
        
        reconnectTimeoutRef.current = setTimeout(() => {
          if (shouldConnect) {
            connect();
          }
        }, delay);
      };

      wsRef.current = ws;
    } catch (error) {
      console.error('[GRIDPULSE] Failed to create WebSocket:', error);
      setStatus('DISCONNECTED');
    }
  }, [shouldConnect]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setStatus('DISCONNECTED');
  }, []);

  // Check for stale data
  useEffect(() => {
    if (!lastUpdate) return;
    
    const interval = setInterval(() => {
      const age = Date.now() - lastUpdate;
      if (age > 5000 && status === 'LIVE') {
        setStatus('STALE');
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lastUpdate, status]);

  // Auto-connect on mount (only if shouldConnect is true)
  useEffect(() => {
    if (shouldConnect) {
      connect();
    }
    return () => disconnect();
  }, [connect, disconnect, shouldConnect]);

  return {
    state,
    status,
    lastUpdate,
    reconnect: connect,
    disconnect,
  };
}
