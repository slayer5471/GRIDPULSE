import { TelemetryState } from '../../services/api';

interface ReportsViewProps {
  state: TelemetryState;
}

export default function ReportsView({ state }: ReportsViewProps) {
  const totalSolar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const totalLoad = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Engineering Reports</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <ReportCard title="Topology Report" description="Network structure and connections" icon="📋" />
        <ReportCard title="Power Flow Report" description="Power distribution analysis" icon="⚡" />
        <ReportCard title="Voltage Report" description="Voltage profile across network" icon="📊" />
        <ReportCard title="Transformer Report" description="Transformer loading and health" icon="⚙️" />
        <ReportCard title="Feeder Report" description="Feeder loading and losses" icon="🔌" />
        <ReportCard title="PV Report" description="Solar generation analysis" icon="☀️" />
        <ReportCard title="Battery Report" description="Battery performance and SOC" icon="🔋" />
        <ReportCard title="Loss Report" description="System losses analysis" icon="📉" />
        <ReportCard title="Alarm Report" description="Historical alarm analysis" icon="🚨" />
      </div>

      <div className="bg-slate-50 rounded-lg p-4">
        <h3 className="text-sm font-medium text-slate-700 mb-3">Current System Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <div className="text-slate-600">Total Solar</div>
            <div className="font-bold text-emerald-600">{totalSolar.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Total Load</div>
            <div className="font-bold text-blue-600">{totalLoad.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Grid Import</div>
            <div className="font-bold text-amber-600">{state.grid.import_kw.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Grid Export</div>
            <div className="font-bold text-cyan-600">{state.grid.export_kw.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-600">Transformer Loading</div>
            <div className="font-bold text-slate-900">{state.transformer.loading_percent.toFixed(1)}%</div>
          </div>
          <div>
            <div className="text-slate-600">Battery SOC</div>
            <div className="font-bold text-purple-600">{state.battery.soc_percent.toFixed(1)}%</div>
          </div>
          <div>
            <div className="text-slate-600">Frequency</div>
            <div className="font-bold text-slate-900">{state.frequency.toFixed(2)} Hz</div>
          </div>
          <div>
            <div className="text-slate-600">Active Alarms</div>
            <div className="font-bold text-red-600">{state.alarms.length}</div>
          </div>
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-700">
          <strong>Note:</strong> Reports are generated from actual system data. 
          Click any report card to generate and download the full report.
        </p>
      </div>
    </div>
  );
}

function ReportCard({ title, description, icon }: { title: string; description: string; icon: string }) {
  return (
    <div className="border border-slate-200 rounded-lg p-4 hover:border-cyan-300 hover:shadow-sm transition-all cursor-pointer">
      <div className="flex items-start justify-between mb-2">
        <span className="text-2xl">{icon}</span>
        <button className="text-xs px-2 py-1 bg-cyan-50 text-cyan-700 rounded hover:bg-cyan-100">
          Generate
        </button>
      </div>
      <h3 className="text-sm font-medium text-slate-900 mb-1">{title}</h3>
      <p className="text-xs text-slate-500">{description}</p>
    </div>
  );
}
