import { TelemetryState } from '../../services/api';

interface ForecastViewProps {
  state: TelemetryState;
}

export default function ForecastView({ state }: ForecastViewProps) {
  // Generate deterministic forecast based on current state
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const currentHour = new Date().getHours();
  
  const solarForecast = hours.map(h => {
    const solarFactor = Math.max(0, Math.sin((h - 6) * Math.PI / 12));
    const currentSolar = state.houses.reduce((sum, house) => sum + house.pv_kw, 0) + state.community.pv_kw;
    return {
      hour: h,
      value: currentSolar * solarFactor,
      isActual: h <= currentHour,
    };
  });

  const loadForecast = hours.map(h => {
    let loadFactor: number;
    if (h >= 17 && h < 22) loadFactor = 1.0;
    else if (h >= 6 && h < 9) loadFactor = 0.8;
    else if (h >= 9 && h < 17) loadFactor = 0.6;
    else loadFactor = 0.4;
    
    const currentLoad = state.houses.reduce((sum, house) => sum + house.load_kw, 0) + state.community.load_kw;
    return {
      hour: h,
      value: currentLoad * loadFactor,
      isActual: h <= currentHour,
    };
  });

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Forecast</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Solar Forecast */}
        <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
          <h3 className="text-sm font-medium text-slate-700 mb-3">PV Generation Forecast</h3>
          <div className="space-y-1">
            {solarForecast.map((point, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs">
                <span className="w-12 text-slate-600">{point.hour.toString().padStart(2, '0')}:00</span>
                <div className="flex-1 bg-yellow-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${point.isActual ? 'bg-yellow-500' : 'bg-yellow-300'}`}
                    style={{ width: `${(point.value / 60) * 100}%` }}
                  />
                </div>
                <span className="w-16 text-right font-medium text-slate-900">
                  {point.value.toFixed(1)} kW
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-yellow-500 rounded" />
              <span className="text-slate-600">Actual</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-yellow-300 rounded" />
              <span className="text-slate-600">Forecast</span>
            </div>
          </div>
        </div>

        {/* Load Forecast */}
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <h3 className="text-sm font-medium text-slate-700 mb-3">Load Forecast</h3>
          <div className="space-y-1">
            {loadForecast.map((point, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs">
                <span className="w-12 text-slate-600">{point.hour.toString().padStart(2, '0')}:00</span>
                <div className="flex-1 bg-blue-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${point.isActual ? 'bg-blue-500' : 'bg-blue-300'}`}
                    style={{ width: `${(point.value / 50) * 100}%` }}
                  />
                </div>
                <span className="w-16 text-right font-medium text-slate-900">
                  {point.value.toFixed(1)} kW
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span className="text-slate-600">Actual</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-blue-300 rounded" />
              <span className="text-slate-600">Forecast</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 p-3 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-700">
          <strong>Note:</strong> Forecasts are based on deterministic models using time-of-day patterns.
          Actual values are shown for past hours, forecasts for future hours.
        </p>
      </div>
    </div>
  );
}
