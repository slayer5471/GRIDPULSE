import { TelemetryState } from '../services/api';
import { ConnectionStatus } from '../hooks/useWebSocket';
import { api } from '../services/api';
import { useState } from 'react';
import { 
  Zap, Activity, Battery, Home, Building, Grid3x3, AlertTriangle, Sun, 
  TrendingUp, Thermometer, Power, Settings, BarChart3, Eye, Cpu, 
  FileText, Bell, Clock, Map, Search, HelpCircle, Download
} from 'lucide-react';
import Solarex from './solarex/Solarex';
import EngineeringOneLine from './engineering/EngineeringOneLine';
import DigitalTwin from './engineering/DigitalTwin';
import StudiesCenter from './engineering/StudiesCenter';
import WhyEngine from './engineering/WhyEngine';
import AnomalyView from './engineering/AnomalyView';
import EnergyStory from './engineering/EnergyStory';
import ReplayView from './engineering/ReplayView';
import AIEngineer from './engineering/AIEngineer';
import ReportsView from './engineering/ReportsView';
import ForecastView from './engineering/ForecastView';
import EventsView from './engineering/EventsView';

interface ControlCenterProps {
  state: TelemetryState;
  status: ConnectionStatus;
  userRole: string;
  onLogout: () => void;
}

export default function ControlCenter({ state, status, userRole, onLogout }: ControlCenterProps) {
  const [mainSection, setMainSection] = useState<'engineering' | 'digital-twin' | 'monitoring' | 'studies' | 'analytics' | 'forecast' | 'alarms' | 'events' | 'reports' | 'solarex'>('engineering');
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [commandResult, setCommandResult] = useState<{ success: boolean; message: string } | null>(null);
  
  const totalSolar = state.houses.reduce((sum, h) => sum + h.pv_kw, 0) + state.community.pv_kw;
  const totalLoad = state.houses.reduce((sum, h) => sum + h.load_kw, 0) + state.community.load_kw;
  const renewableShare = totalLoad > 0 ? (Math.min(totalSolar, totalLoad) / totalLoad) * 100 : 0;

  const handleCommand = async (command: string, target: string, value?: any) => {
    try {
      await api.sendCommand(command, target, value);
      setCommandResult({ success: true, message: `Command sent: ${command} → ${target}` });
      setTimeout(() => setCommandResult(null), 3000);
    } catch (error) {
      setCommandResult({ success: false, message: `Command failed: ${error}` });
      setTimeout(() => setCommandResult(null), 3000);
    }
  };

  const handleAssetSelect = (assetId: string) => {
    setSelectedAsset(assetId);
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <Zap size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900">GRIDPULSE</h1>
                <p className="text-xs text-slate-500">Engineering Control Center • v1.0.0</p>
              </div>
            </div>
            
            {/* Communication Health */}
            <div className="flex items-center gap-2 ml-8">
              <div className={`w-2 h-2 rounded-full ${
                status === 'LIVE' ? 'bg-emerald-500 animate-pulse' :
                status === 'DEMO' ? 'bg-purple-500 animate-pulse' :
                status === 'STALE' ? 'bg-amber-500' : 'bg-red-500'
              }`} />
              <span className="text-xs font-medium text-slate-600">{status}</span>
              <span className="text-[10px] text-slate-500">
                {status === 'DEMO' ? 'Demo Mode' : 'Connected to Backend'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-slate-500">Bengaluru, India</div>
              <div className="text-xs text-slate-400">{new Date().toLocaleDateString()}</div>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg">
              <span className="text-xs font-medium text-slate-700">{userRole}</span>
            </div>
            <button
              onClick={onLogout}
              className="px-3 py-1.5 text-xs bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* KPI Strip */}
      <div className="bg-white border-b border-slate-200 px-6 py-3">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          <KPICard label="Solar" value={totalSolar.toFixed(1)} unit="kW" icon={<Sun size={16} />} color="cyan" />
          <KPICard label="Load" value={totalLoad.toFixed(1)} unit="kW" icon={<Activity size={16} />} color="blue" />
          <KPICard label="Import" value={state.grid.import_kw.toFixed(1)} unit="kW" icon={<Grid3x3 size={16} />} color="amber" />
          <KPICard label="Export" value={state.grid.export_kw.toFixed(1)} unit="kW" icon={<Grid3x3 size={16} />} color="emerald" />
          <KPICard label="Battery" value={state.battery.soc_percent.toFixed(0)} unit="%" icon={<Battery size={16} />} color="purple" />
          <KPICard label="TX Load" value={state.transformer.loading_percent.toFixed(0)} unit="%" icon={<Activity size={16} />} color={state.transformer.loading_percent > 80 ? 'red' : 'slate'} />
          <KPICard label="Renewable" value={renewableShare.toFixed(0)} unit="%" icon={<Zap size={16} />} color="emerald" />
          <KPICard label="Frequency" value={state.frequency.toFixed(2)} unit="Hz" icon={<Activity size={16} />} color="cyan" />
        </div>
      </div>

      {/* Command Result */}
      {commandResult && (
        <div className={`px-6 py-2 text-xs ${commandResult.success ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
          {commandResult.message}
        </div>
      )}

      {/* Main Navigation */}
      <div className="bg-white border-b border-slate-200 px-6">
        <div className="flex gap-1 overflow-x-auto">
          <NavButton 
            id="engineering" 
            label="Engineering" 
            icon={<Zap size={16} />} 
            active={mainSection === 'engineering'} 
            onClick={() => setMainSection('engineering')}
          />
          <NavButton 
            id="digital-twin" 
            label="Digital Twin" 
            icon={<Eye size={16} />} 
            active={mainSection === 'digital-twin'} 
            onClick={() => setMainSection('digital-twin')}
          />
          <NavButton 
            id="monitoring" 
            label="Monitoring" 
            icon={<Activity size={16} />} 
            active={mainSection === 'monitoring'} 
            onClick={() => setMainSection('monitoring')}
          />
          <NavButton 
            id="studies" 
            label="Studies" 
            icon={<BarChart3 size={16} />} 
            active={mainSection === 'studies'} 
            onClick={() => setMainSection('studies')}
          />
          <NavButton 
            id="analytics" 
            label="Analytics" 
            icon={<TrendingUp size={16} />} 
            active={mainSection === 'analytics'} 
            onClick={() => setMainSection('analytics')}
          />
          <NavButton 
            id="forecast" 
            label="Forecast" 
            icon={<Clock size={16} />} 
            active={mainSection === 'forecast'} 
            onClick={() => setMainSection('forecast')}
          />
          <NavButton 
            id="alarms" 
            label="Alarms" 
            icon={<Bell size={16} />} 
            active={mainSection === 'alarms'} 
            onClick={() => setMainSection('alarms')}
            badge={state.alarms.length}
          />
          <NavButton 
            id="events" 
            label="Events" 
            icon={<FileText size={16} />} 
            active={mainSection === 'events'} 
            onClick={() => setMainSection('events')}
          />
          <NavButton 
            id="reports" 
            label="Reports" 
            icon={<Download size={16} />} 
            active={mainSection === 'reports'} 
            onClick={() => setMainSection('reports')}
          />
          <div className="w-px bg-slate-200 mx-2" />
          <NavButton 
            id="solarex" 
            label="Solarex" 
            icon={<Sun size={16} />} 
            active={mainSection === 'solarex'} 
            onClick={() => setMainSection('solarex')}
            variant="solarex"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {mainSection === 'solarex' ? (
          <div className="flex-1 overflow-hidden">
            <Solarex />
          </div>
        ) : (
          <>
            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6">
              {mainSection === 'engineering' && (
                <EngineeringOneLine 
                  state={state} 
                  selectedAsset={selectedAsset}
                  onAssetSelect={handleAssetSelect}
                  onCommand={handleCommand}
                  canControl={userRole !== 'VIEWER'}
                />
              )}
              {mainSection === 'digital-twin' && (
                <DigitalTwin 
                  state={state} 
                  selectedAsset={selectedAsset}
                  onAssetSelect={handleAssetSelect}
                />
              )}
              {mainSection === 'monitoring' && (
                <MonitoringView 
                  state={state} 
                  selectedAsset={selectedAsset}
                  onAssetSelect={handleAssetSelect}
                  onCommand={handleCommand}
                  canControl={userRole !== 'VIEWER'}
                />
              )}
              {mainSection === 'studies' && (
                <StudiesCenter state={state} />
              )}
              {mainSection === 'analytics' && (
                <AnalyticsView state={state} />
              )}
              {mainSection === 'forecast' && (
                <ForecastView state={state} />
              )}
              {mainSection === 'alarms' && (
                <AlarmsView state={state} />
              )}
              {mainSection === 'events' && (
                <EventsView state={state} />
              )}
              {mainSection === 'reports' && (
                <ReportsView state={state} />
              )}
            </div>

            {/* Right Panel - Asset Inspector + Tools */}
            {selectedAsset && (mainSection as string) !== 'solarex' && (
              <div className="w-96 bg-white border-l border-slate-200 overflow-y-auto">
                <div className="p-4 space-y-4">
                  <AssetInspector state={state} assetId={selectedAsset} onClose={() => setSelectedAsset(null)} />
                  
                  {/* Context-aware tools */}
                  {state.houses.find(h => h.id === selectedAsset) && (
                    <EnergyStory state={state} assetId={selectedAsset} />
                  )}
                  
                  <WhyEngine state={state} assetId={selectedAsset} />
                </div>
              </div>
            )}

            {/* Right Panel - Anomaly Detection (when no asset selected) */}
            {!selectedAsset && mainSection === 'engineering' && (
              <div className="w-96 bg-white border-l border-slate-200 overflow-y-auto">
                <div className="p-4">
                  <AnomalyView state={state} onAssetSelect={handleAssetSelect} />
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function NavButton({ id, label, icon, active, onClick, badge, variant }: {
  id: string;
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
  badge?: number;
  variant?: 'default' | 'solarex';
}) {
  const baseColor = variant === 'solarex' ? 'amber' : 'cyan';
  
  return (
    <button
      onClick={onClick}
      className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
        active
          ? `border-${baseColor}-500 text-${baseColor}-700`
          : 'border-transparent text-slate-600 hover:text-slate-900'
      }`}
    >
      {icon}
      {label}
      {badge !== undefined && badge > 0 && (
        <span className="px-1.5 py-0.5 text-xs bg-red-100 text-red-700 rounded-full">
          {badge}
        </span>
      )}
    </button>
  );
}

function KPICard({ label, value, unit, icon, color }: any) {
  const colors: Record<string, string> = {
    cyan: 'bg-cyan-50 text-cyan-600 border-cyan-200',
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    amber: 'bg-amber-50 text-amber-600 border-amber-200',
    emerald: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    red: 'bg-red-50 text-red-600 border-red-200',
    slate: 'bg-slate-50 text-slate-600 border-slate-200',
  };

  return (
    <div className={`${colors[color]} border rounded-lg p-3`}>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs opacity-70">{icon}</span>
        <span className="text-[10px] opacity-60 uppercase tracking-wide">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-xl font-bold">{value}</span>
        <span className="text-xs opacity-60">{unit}</span>
      </div>
    </div>
  );
}

// Monitoring View - Battery, Grid, Controls
function MonitoringView({ state, selectedAsset, onAssetSelect, onCommand, canControl }: any) {
  const [selectedTab, setSelectedTab] = useState<'battery' | 'grid' | 'transformer'>('battery');

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <button
          onClick={() => setSelectedTab('battery')}
          className={`px-4 py-2 text-sm rounded-lg ${
            selectedTab === 'battery' ? 'bg-cyan-50 text-cyan-700 border border-cyan-200' : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Battery
        </button>
        <button
          onClick={() => setSelectedTab('grid')}
          className={`px-4 py-2 text-sm rounded-lg ${
            selectedTab === 'grid' ? 'bg-cyan-50 text-cyan-700 border border-cyan-200' : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Grid
        </button>
        <button
          onClick={() => setSelectedTab('transformer')}
          className={`px-4 py-2 text-sm rounded-lg ${
            selectedTab === 'transformer' ? 'bg-cyan-50 text-cyan-700 border border-cyan-200' : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Transformer
        </button>
      </div>

      {selectedTab === 'battery' && (
        <BatteryPanel state={state} onCommand={onCommand} canControl={canControl} />
      )}
      {selectedTab === 'grid' && (
        <GridPanel state={state} onCommand={onCommand} canControl={canControl} />
      )}
      {selectedTab === 'transformer' && (
        <TransformerPanel state={state} />
      )}
    </div>
  );
}

function BatteryPanel({ state, onCommand, canControl }: any) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h3 className="text-lg font-bold text-slate-700 mb-4">Battery Control</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <label className="text-xs text-slate-600 block mb-1">Mode</label>
          <select
            disabled={!canControl}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm disabled:bg-slate-50"
            value={state.battery.mode}
            onChange={e => onCommand('battery_mode', state.battery.id, e.target.value)}
          >
            <option value="AUTO">AUTO</option>
            <option value="MANUAL">MANUAL</option>
            <option value="CHARGE">CHARGE</option>
            <option value="DISCHARGE">DISCHARGE</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-600 block mb-1">Target SOC (%)</label>
          <input
            type="number"
            disabled={!canControl}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm disabled:bg-slate-50"
            value={state.battery.target_soc}
            onChange={e => onCommand('battery_target_soc', state.battery.id, parseFloat(e.target.value))}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-6">
        <button
          disabled={!canControl}
          onClick={() => onCommand('battery_charge', state.battery.id, 50)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 disabled:opacity-50"
        >
          CHARGE 50kW
        </button>
        <button
          disabled={!canControl}
          onClick={() => onCommand('battery_discharge', state.battery.id, 50)}
          className="px-4 py-2 bg-amber-600 text-white rounded-lg text-sm font-medium hover:bg-amber-700 disabled:opacity-50"
        >
          DISCHARGE 50kW
        </button>
        <button
          disabled={!canControl}
          onClick={() => onCommand('battery_stop', state.battery.id)}
          className="px-4 py-2 bg-slate-600 text-white rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50"
        >
          STOP
        </button>
      </div>

      <div className="bg-slate-50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-slate-700 mb-3">Battery Status</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-slate-600">Capacity:</span>
            <span className="ml-2 font-bold">{state.battery.capacity_kwh} kWh</span>
          </div>
          <div>
            <span className="text-slate-600">SOC:</span>
            <span className="ml-2 font-bold">{state.battery.soc_percent.toFixed(1)}%</span>
          </div>
          <div>
            <span className="text-slate-600">Power:</span>
            <span className="ml-2 font-bold">{state.battery.power_kw.toFixed(1)} kW</span>
          </div>
          <div>
            <span className="text-slate-600">State:</span>
            <span className="ml-2 font-bold">{state.battery.state}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function GridPanel({ state, onCommand, canControl }: any) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h3 className="text-lg font-bold text-slate-700 mb-4">Grid Connection</h3>
      
      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
          <div className="text-xs text-emerald-600 mb-1">Grid Import</div>
          <div className="text-2xl font-bold text-emerald-700">{state.grid.import_kw.toFixed(1)} kW</div>
        </div>
        <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
          <div className="text-xs text-amber-600 mb-1">Grid Export</div>
          <div className="text-2xl font-bold text-amber-700">{state.grid.export_kw.toFixed(1)} kW</div>
        </div>
      </div>

      <div className="mb-4">
        <label className="text-xs text-slate-600 block mb-1">Export Limit (kW)</label>
        <input
          type="number"
          disabled={!canControl}
          className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm disabled:bg-slate-50"
          value={state.grid.export_limit_kw}
          onChange={e => onCommand('export_limit', 'grid', parseFloat(e.target.value))}
        />
      </div>

      <div className="bg-slate-50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-slate-700 mb-3">Grid Parameters</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-slate-600">Voltage:</span>
            <span className="ml-2 font-bold">{state.grid.voltage_kv.toFixed(2)} kV</span>
          </div>
          <div>
            <span className="text-slate-600">Frequency:</span>
            <span className="ml-2 font-bold">{state.frequency.toFixed(2)} Hz</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function TransformerPanel({ state }: any) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h3 className="text-lg font-bold text-slate-700 mb-4">Transformer {state.transformer.id}</h3>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-slate-600">Loading</span>
            <span className="font-bold">{state.transformer.loading_percent.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all ${
                state.transformer.loading_percent > 90 ? 'bg-red-500' :
                state.transformer.loading_percent > 75 ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, state.transformer.loading_percent)}%` }}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-slate-600">Temperature:</span>
            <span className="ml-2 font-bold">{state.transformer.temperature_c.toFixed(1)}°C</span>
          </div>
          <div>
            <span className="text-slate-600">Efficiency:</span>
            <span className="ml-2 font-bold">{(state.transformer.efficiency * 100).toFixed(1)}%</span>
          </div>
          <div>
            <span className="text-slate-600">Health:</span>
            <span className={`ml-2 font-bold ${
              state.transformer.health === 'HEALTHY' ? 'text-emerald-600' :
              state.transformer.health === 'WARNING' ? 'text-amber-600' : 'text-red-600'
            }`}>{state.transformer.health}</span>
          </div>
          <div>
            <span className="text-slate-600">Rating:</span>
            <span className="ml-2 font-bold">{state.transformer.rating_kva} kVA</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function AlarmsView({ state }: any) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h3 className="text-lg font-bold text-slate-700 mb-4">Active Alarms</h3>
      
      {state.alarms.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-3">
            <Activity size={24} className="text-emerald-500" />
          </div>
          <p className="text-sm text-slate-500">No active alarms</p>
        </div>
      ) : (
        <div className="space-y-2">
          {state.alarms.map((alarm: any) => (
            <div
              key={alarm.id}
              className={`p-3 rounded-lg border ${
                alarm.severity === 'CRITICAL' ? 'bg-red-50 border-red-200' :
                alarm.severity === 'MAJOR' ? 'bg-amber-50 border-amber-200' :
                'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-700">{alarm.message}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    Source: {alarm.source} • {new Date(alarm.timestamp).toLocaleString()}
                  </div>
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded ${
                  alarm.severity === 'CRITICAL' ? 'bg-red-100 text-red-700' :
                  alarm.severity === 'MAJOR' ? 'bg-amber-100 text-amber-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {alarm.severity}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AnalyticsView({ state }: any) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h3 className="text-lg font-bold text-slate-700 mb-4">Energy Analytics</h3>
      
      <div className="grid grid-cols-4 gap-3 mb-6">
        <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
          <div className="text-[10px] text-emerald-600 uppercase mb-1">Solar Generation</div>
          <div className="text-lg font-bold text-emerald-700">
            {state.houses.reduce((sum: number, h: any) => sum + h.pv_kw, 0) + state.community.pv_kw} kW
          </div>
        </div>
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <div className="text-[10px] text-blue-600 uppercase mb-1">Total Load</div>
          <div className="text-lg font-bold text-blue-700">
            {state.houses.reduce((sum: number, h: any) => sum + h.load_kw, 0) + state.community.load_kw} kW
          </div>
        </div>
        <div className="bg-amber-50 rounded-lg p-3 border border-amber-200">
          <div className="text-[10px] text-amber-600 uppercase mb-1">Grid Import</div>
          <div className="text-lg font-bold text-amber-700">{state.grid.import_kw.toFixed(1)} kW</div>
        </div>
        <div className="bg-purple-50 rounded-lg p-3 border border-purple-200">
          <div className="text-[10px] text-purple-600 uppercase mb-1">Battery SOC</div>
          <div className="text-lg font-bold text-purple-700">{state.battery.soc_percent.toFixed(0)}%</div>
        </div>
      </div>

      <div className="bg-slate-50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-slate-700 mb-3">Energy Distribution</h4>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-600">Solar Self-Consumption</span>
              <span className="font-bold text-emerald-600">
                {Math.min(
                  state.houses.reduce((sum: number, h: any) => sum + h.pv_kw, 0) + state.community.pv_kw,
                  state.houses.reduce((sum: number, h: any) => sum + h.load_kw, 0) + state.community.load_kw
                ).toFixed(1)} kW
              </span>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-600">Battery Charging</span>
              <span className="font-bold text-purple-600">
                {state.battery.power_kw > 0 ? state.battery.power_kw.toFixed(1) : '0.0'} kW
              </span>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-600">Grid Export</span>
              <span className="font-bold text-cyan-600">{state.grid.export_kw.toFixed(1)} kW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AssetInspector({ state, assetId, onClose }: any) {
  const getAssetData = () => {
    if (assetId === 'TX-01') return { type: 'transformer', data: state.transformer };
    if (assetId === 'BESS-01') return { type: 'battery', data: state.battery };
    if (assetId === 'COMMUNITY-01') return { type: 'community', data: state.community };
    if (assetId.startsWith('HOUSE-')) return { type: 'house', data: state.houses.find((h: any) => h.id === assetId) };
    return null;
  };

  const asset = getAssetData();
  if (!asset) return null;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-slate-900">{assetId}</h3>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600">✕</button>
      </div>

      {asset.type === 'transformer' && (
        <div className="space-y-2">
          <InspectorRow label="Rating" value={`${asset.data.rating_kva} kVA`} />
          <InspectorRow label="Loading" value={`${asset.data.loading_percent.toFixed(1)}%`} />
          <InspectorRow label="Temperature" value={`${asset.data.temperature_c.toFixed(1)}°C`} />
          <InspectorRow label="Efficiency" value={`${(asset.data.efficiency * 100).toFixed(1)}%`} />
          <InspectorRow label="Health" value={asset.data.health} />
        </div>
      )}

      {asset.type === 'battery' && (
        <div className="space-y-2">
          <InspectorRow label="Capacity" value={`${asset.data.capacity_kwh} kWh`} />
          <InspectorRow label="SOC" value={`${asset.data.soc_percent.toFixed(1)}%`} />
          <InspectorRow label="Power" value={`${asset.data.power_kw.toFixed(1)} kW`} />
          <InspectorRow label="State" value={asset.data.state} />
          <InspectorRow label="Mode" value={asset.data.mode} />
        </div>
      )}

      {asset.type === 'community' && (
        <div className="space-y-2">
          <InspectorRow label="Load" value={`${asset.data.load_kw.toFixed(1)} kW`} />
          <InspectorRow label="PV" value={`${asset.data.pv_kw.toFixed(1)} kW`} />
          <InspectorRow label="Net" value={`${asset.data.net_kw.toFixed(1)} kW`} />
        </div>
      )}

      {asset.type === 'house' && asset.data && (
        <div className="space-y-2">
          <InspectorRow label="Load" value={`${asset.data.load_kw.toFixed(1)} kW`} />
          <InspectorRow label="PV" value={`${asset.data.pv_kw.toFixed(1)} kW`} />
          <InspectorRow label="Net" value={`${asset.data.net_kw.toFixed(1)} kW`} />
          <InspectorRow label="Voltage" value={`${asset.data.voltage_v.toFixed(1)} V`} />
        </div>
      )}
    </div>
  );
}

function InspectorRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center py-1 border-b border-slate-100">
      <span className="text-xs text-slate-600">{label}</span>
      <span className="text-xs font-mono font-medium text-slate-900">{value}</span>
    </div>
  );
}
