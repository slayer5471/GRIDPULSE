// Solarex Map Component - Interactive Leaflet map for roof selection
import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Polygon, Marker, useMapEvents, useMap } from 'react-leaflet';
import { Icon, LatLngTuple } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { RoofPolygon, ExclusionPolygon, SolarexLocation } from '../../types/solarex';
import { calculatePolygonArea, sqmToSqft, createRoofPolygon } from '../../services/solarexCalculator';
import { Search, MapPin, Satellite, Map as MapIcon, Plus, Trash2, Check, X } from 'lucide-react';

interface SolarexMapProps {
  location: SolarexLocation | null;
  roofPolygons: RoofPolygon[];
  exclusionPolygons: ExclusionPolygon[];
  onLocationSelect: (location: SolarexLocation) => void;
  onRoofPolygonAdd: (polygon: RoofPolygon) => void;
  onRoofPolygonUpdate: (polygon: RoofPolygon) => void;
  onRoofPolygonDelete: (id: string) => void;
  onExclusionPolygonAdd: (polygon: ExclusionPolygon) => void;
  onExclusionPolygonDelete: (id: string) => void;
}

// Custom marker icon
const locationIcon = new Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDOi4xMyAyIDYgNi4xMyA2IDEwYzAgNS4yNSA2IDEyIDYgMTJzNi02Ljc1IDYtMTJjMC0zLjg3LTMuMTMtNy03LTd6bTAgOS41Yy0xLjM4IDAtMi41LTEuMTItMi41LTIuNXMxLjEyLTIuNSAyLjUtMi41IDIuNSAxLjEyIDIuNSAyLjUtMS4xMiAyLjUtMi41IDIuNXoiIGZpbGw9IiMwNjhiZTQiLz4KPC9zdmc+Cg==',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
});

export default function SolarexMap({
  location,
  roofPolygons,
  exclusionPolygons,
  onLocationSelect,
  onRoofPolygonAdd,
  onRoofPolygonUpdate,
  onRoofPolygonDelete,
  onExclusionPolygonAdd,
  onExclusionPolygonDelete,
}: SolarexMapProps) {
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('satellite');
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingMode, setDrawingMode] = useState<'roof' | 'exclusion'>('roof');
  const [currentPolygon, setCurrentPolygon] = useState<[number, number][]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const mapCenter: LatLngTuple = location 
    ? [location.latitude, location.longitude]
    : [12.9716, 77.5946]; // Default: Bengaluru

  const mapZoom = location ? 18 : 12;

  // Handle map clicks for polygon drawing
  function MapClickHandler() {
    const map = useMapEvents({
      click: (e) => {
        if (isDrawing) {
          const newPoint: [number, number] = [e.latlng.lat, e.latlng.lng];
          setCurrentPolygon(prev => [...prev, newPoint]);
        }
      },
    });
    return null;
  }

  // Handle search
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      // Using Nominatim for geocoding (free, no API key required)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=5`
      );
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle location selection from search
  const handleSelectLocation = (result: any) => {
    const newLocation: SolarexLocation = {
      id: `loc-${Date.now()}`,
      label: result.display_name.split(',')[0],
      address: result.display_name,
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon),
      city: result.address?.city || result.address?.town,
      state: result.address?.state,
      country: result.address?.country,
    };
    onLocationSelect(newLocation);
    setSearchResults([]);
    setSearchQuery('');
  };

  // Finish drawing polygon
  const finishPolygon = () => {
    if (currentPolygon.length < 3) {
      alert('Please draw at least 3 points to create a polygon');
      return;
    }

    const area_sqm = calculatePolygonArea(currentPolygon);
    const area_sqft = sqmToSqft(area_sqm);

    if (drawingMode === 'roof') {
      const newPolygon = createRoofPolygon(
        `roof-${Date.now()}`,
        `Roof ${roofPolygons.length + 1}`,
        currentPolygon
      );
      onRoofPolygonAdd(newPolygon);
    } else {
      const newExclusion: ExclusionPolygon = {
        id: `exclusion-${Date.now()}`,
        name: `Exclusion ${exclusionPolygons.length + 1}`,
        coordinates: currentPolygon,
        area_sqm,
        area_sqft,
        reason: 'Obstruction',
      };
      onExclusionPolygonAdd(newExclusion);
    }

    setCurrentPolygon([]);
    setIsDrawing(false);
  };

  // Cancel drawing
  const cancelDrawing = () => {
    setCurrentPolygon([]);
    setIsDrawing(false);
  };

  // Get user location
  const handleLocateMe = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation: SolarexLocation = {
            id: `loc-${Date.now()}`,
            label: 'Current Location',
            address: 'Current Location',
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          onLocationSelect(newLocation);
        },
        (error) => {
          alert('Unable to get your location. Please search manually.');
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
    }
  };

  const totalRoofArea = roofPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const totalExclusionArea = exclusionPolygons.reduce((sum, p) => sum + p.area_sqm, 0);
  const usableArea = totalRoofArea - totalExclusionArea;

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* Map Controls */}
      <div className="bg-white border-b border-slate-200 p-4">
        <div className="flex items-center gap-3 mb-3">
          {/* Search */}
          <div className="flex-1 flex gap-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search location (address, city, postal code)..."
              className="flex-1 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="px-4 py-2 bg-cyan-600 text-white text-sm rounded-lg hover:bg-cyan-700 disabled:opacity-50"
            >
              <Search size={16} />
            </button>
          </div>

          {/* Map Type Toggle */}
          <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
            <button
              onClick={() => setMapType('standard')}
              className={`px-3 py-1.5 text-xs rounded ${
                mapType === 'standard' ? 'bg-white text-cyan-700 shadow-sm' : 'text-slate-600'
              }`}
            >
              <MapIcon size={14} className="inline mr-1" />
              Map
            </button>
            <button
              onClick={() => setMapType('satellite')}
              className={`px-3 py-1.5 text-xs rounded ${
                mapType === 'satellite' ? 'bg-white text-cyan-700 shadow-sm' : 'text-slate-600'
              }`}
            >
              <Satellite size={14} className="inline mr-1" />
              Satellite
            </button>
          </div>

          {/* Locate Me */}
          <button
            onClick={handleLocateMe}
            className="px-3 py-2 bg-slate-100 text-slate-700 text-sm rounded-lg hover:bg-slate-200"
            title="Use my location"
          >
            <MapPin size={16} />
          </button>
        </div>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-lg shadow-lg max-h-64 overflow-y-auto">
            {searchResults.map((result, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectLocation(result)}
                className="w-full px-4 py-3 text-left hover:bg-slate-50 border-b border-slate-100 last:border-0"
              >
                <div className="text-sm font-medium text-slate-900">{result.display_name.split(',')[0]}</div>
                <div className="text-xs text-slate-500 mt-0.5">{result.display_name}</div>
              </button>
            ))}
          </div>
        )}

        {/* Drawing Controls */}
        <div className="flex items-center gap-2">
          {!isDrawing ? (
            <>
              <button
                onClick={() => { setIsDrawing(true); setDrawingMode('roof'); }}
                className="px-3 py-1.5 bg-cyan-600 text-white text-xs rounded hover:bg-cyan-700"
              >
                <Plus size={14} className="inline mr-1" />
                Add Roof Area
              </button>
              <button
                onClick={() => { setIsDrawing(true); setDrawingMode('exclusion'); }}
                className="px-3 py-1.5 bg-amber-600 text-white text-xs rounded hover:bg-amber-700"
              >
                <Plus size={14} className="inline mr-1" />
                Add Exclusion Area
              </button>
            </>
          ) : (
            <>
              <button
                onClick={finishPolygon}
                className="px-3 py-1.5 bg-emerald-600 text-white text-xs rounded hover:bg-emerald-700"
              >
                <Check size={14} className="inline mr-1" />
                Finish ({currentPolygon.length} points)
              </button>
              <button
                onClick={cancelDrawing}
                className="px-3 py-1.5 bg-slate-600 text-white text-xs rounded hover:bg-slate-700"
              >
                <X size={14} className="inline mr-1" />
                Cancel
              </button>
              <span className="text-xs text-slate-600 ml-2">
                Click on map to add points • {drawingMode === 'roof' ? 'Roof' : 'Exclusion'} mode
              </span>
            </>
          )}
        </div>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative">
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          className="w-full h-full"
          style={{ height: '100%', width: '100%' }}
        >
          {/* Tile Layer */}
          {mapType === 'satellite' ? (
            <TileLayer
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              attribution="Tiles &copy; Esri"
            />
          ) : (
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
          )}

          {/* Location Marker */}
          {location && (
            <Marker position={[location.latitude, location.longitude]} icon={locationIcon} />
          )}

          {/* Roof Polygons */}
          {roofPolygons.map((polygon) => (
            <Polygon
              key={polygon.id}
              positions={polygon.coordinates}
              pathOptions={{
                color: polygon.color,
                fillColor: polygon.color,
                fillOpacity: 0.3,
                weight: 2,
              }}
            />
          ))}

          {/* Exclusion Polygons */}
          {exclusionPolygons.map((polygon) => (
            <Polygon
              key={polygon.id}
              positions={polygon.coordinates}
              pathOptions={{
                color: '#ef4444',
                fillColor: '#ef4444',
                fillOpacity: 0.3,
                weight: 2,
                dashArray: '5, 5',
              }}
            />
          ))}

          {/* Current Drawing Polygon */}
          {currentPolygon.length > 0 && (
            <Polygon
              positions={currentPolygon}
              pathOptions={{
                color: drawingMode === 'roof' ? '#06b6d4' : '#ef4444',
                fillColor: drawingMode === 'roof' ? '#06b6d4' : '#ef4444',
                fillOpacity: 0.2,
                weight: 2,
                dashArray: '5, 5',
              }}
            />
          )}

          <MapClickHandler />
        </MapContainer>

        {/* Map Summary Panel */}
        <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg border border-slate-200 p-4 w-64">
          <h3 className="text-sm font-bold text-slate-900 mb-3">Map Summary</h3>
          
          {location && (
            <div className="mb-3">
              <div className="text-[10px] text-slate-500 uppercase">Location</div>
              <div className="text-xs font-medium text-slate-900">{location.label}</div>
            </div>
          )}

          <div className="space-y-2 mb-3">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Roof Areas</div>
              <div className="text-xs font-medium text-slate-900">{roofPolygons.length}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Total Roof Area</div>
              <div className="text-xs font-medium text-slate-900">
                {sqmToSqft(totalRoofArea).toFixed(0)} sq.ft ({totalRoofArea.toFixed(1)} m²)
              </div>
            </div>
            {totalExclusionArea > 0 && (
              <div>
                <div className="text-[10px] text-slate-500 uppercase">Exclusion Area</div>
                <div className="text-xs font-medium text-red-600">
                  -{sqmToSqft(totalExclusionArea).toFixed(0)} sq.ft
                </div>
              </div>
            )}
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Usable Area</div>
              <div className="text-xs font-bold text-emerald-600">
                {sqmToSqft(usableArea).toFixed(0)} sq.ft ({usableArea.toFixed(1)} m²)
              </div>
            </div>
          </div>

          {/* Roof Polygon List */}
          {roofPolygons.length > 0 && (
            <div className="border-t border-slate-200 pt-3">
              <div className="text-[10px] text-slate-500 uppercase mb-2">Roof Areas</div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {roofPolygons.map((polygon) => (
                  <div key={polygon.id} className="flex items-center justify-between text-xs">
                    <span className="text-slate-700">{polygon.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-500">{sqmToSqft(polygon.area_sqm).toFixed(0)} sq.ft</span>
                      <button
                        onClick={() => onRoofPolygonDelete(polygon.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Instructions */}
        {isDrawing && (
          <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg border border-slate-200 p-3">
            <div className="text-xs text-slate-700">
              <div className="font-bold mb-1">Drawing {drawingMode === 'roof' ? 'Roof' : 'Exclusion'} Area</div>
              <div>• Click on map to add points</div>
              <div>• Click "Finish" when done</div>
              <div>• Minimum 3 points required</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
