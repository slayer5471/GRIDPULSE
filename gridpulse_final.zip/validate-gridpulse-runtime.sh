#!/usr/bin/env bash
set -euo pipefail

if grep -RIn --exclude-dir=node_modules 'root\.innerHTML' laptop-b legacy-combined-frontend 2>/dev/null; then
  echo 'FAIL: React root is being mutated through innerHTML.'
  exit 1
fi
if grep -RIn --exclude-dir=node_modules 'TriangleAlert' laptop-b/src 2>/dev/null; then
  echo 'FAIL: TriangleAlert remains in Laptop B source.'
  exit 1
fi
if ! grep -q 'AlertTriangle' laptop-b/src/components/ControlCenter.tsx; then
  echo 'FAIL: AlertTriangle compatibility import missing.'
  exit 1
fi
if ! grep -q 'boot-error' laptop-b/index.html; then
  echo 'FAIL: isolated boot error surface missing.'
  exit 1
fi
printf '%s\n' 'GRIDPULSE runtime static validation: PASS'
