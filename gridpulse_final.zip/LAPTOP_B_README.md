# GRIDPULSE v1.0.0 - Laptop B Engineering Control Center

## Overview

**Laptop B** is the professional engineering control center for the GRIDPULSE community electrical network. It provides real-time visualization, monitoring, analytics, and control capabilities for the electrical system running on Laptop A.

### Key Principles

- **NO local electrical simulation** - All data comes from Laptop A
- **NO Math.random()** - Every value is authoritative from Laptop A
- **Professional engineering interface** - Clean, light-theme, technical UI
- **Real-time WebSocket connection** - Live telemetry from Laptop A
- **Command routing via FastAPI** - All controls go through the API layer

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    LAPTOP B (This Application)              │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Engineering  │  │   Digital    │  │  Monitoring  │     │
│  │   Circuit    │  │    Twin      │  │   & Control  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   Analytics  │  │    Alarms    │  │    Asset     │     │
│  │   & History  │  │   & Events   │  │  Inspector   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│              WebSocket Client (Real-time Telemetry)         │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ ws://laptop-a:8000/ws/telemetry
                         │
┌────────────────────────┴────────────────────────────────────┐
│                      FASTAPI (Port 8000)                     │
│  • WebSocket telemetry streaming                            │
│  • REST API for commands                                    │
│  • Authentication & authorization                           │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ Internal API
                         │
┌────────────────────────┴────────────────────────────────────┐
│                 LAPTOP A (Circuit Host)                      │
│  • Pandapower electrical simulation                         │
│  • Real power flow calculations                             │
│  • Authoritative electrical state                           │
│  • Battery, transformer, PV models                          │
└─────────────────────────────────────────────────────────────┘
```

---

## Features

### 1. Engineering One-Line Diagram

**Primary View** - Professional electrical single-line diagram showing:

- **11 kV Grid Connection** - Import/export metering
- **Incoming Breaker (CB-01)** - Status indicator
- **11 kV Bus** - Voltage measurement
- **11 kV / 415 V Transformer (TX-01)** - Loading, temperature, efficiency
- **415 V Bus** - Distribution busbar
- **3 Distribution Feeders** - Current, power, losses
- **5 Residential Houses** - Load, PV generation, net power
- **Community Building** - Load and PV
- **Solar PV System** - Total generation
- **Battery Energy Storage (BESS-01)** - SOC, power, state
- **Power Conversion System (PCS-01)** - PWM, efficiency

**Features:**
- Click any component to inspect details
- Toggle measurement overlays
- Zoom and pan controls
- Real-time power flow indicators
- Color-coded status (Normal/Warning/Critical)

### 2. Asset Inspector

**Right Panel** - Detailed engineering data for selected asset:

**Grid Inspector:**
- Voltage, frequency
- Import/export power
- Export limit
- Connection status

**Transformer Inspector:**
- Primary/secondary voltage
- HV/LV current
- Loading percentage
- Temperature
- Efficiency
- Health status

**Battery Inspector:**
- Capacity, SOC
- Power (charge/discharge)
- Voltage, current
- Mode, target SOC
- Min/max SOC limits

**PCS Inspector:**
- PWM frequency
- Duty cycle
- Power output
- Efficiency
- Status

**Bus Inspector:**
- Voltage magnitude
- Voltage angle
- Active/reactive power
- Loading

**Feeder Inspector:**
- Voltage, current
- Active/reactive power
- Loading percentage
- Losses

**House Inspector:**
- Load, PV generation
- Net power
- Voltage, current
- Power factor

### 3. Control Center

**Authorized Control Operations:**

**Battery Control:**
- CHARGE 50 kW
- DISCHARGE 50 kW
- STOP
- Commands sent to Laptop A via FastAPI

**EMS Mode Selection:**
- LOCAL_FIRST
- GRID_PRIORITY
- SOLAR_PRIORITY
- BATTERY_PRIORITY

**Grid Control:**
- Set export limit
- Monitor import/export

**PCS Control:**
- Enable/disable
- Commands routed to Laptop A

**Command Confirmation:**
- All control actions require confirmation
- Shows command details before execution
- Displays success/failure result

### 4. Monitoring View

**Real-time System Monitoring:**

- **Power Balance** - Generation vs load vs surplus
- **Transformer Status** - Loading, temperature, health
- **Battery Status** - SOC, power, state
- **Houses Overview** - All 5 houses with load/PV/net
- **Feeders Overview** - All 3 feeders with power/current/loading

### 5. Analytics View

**Energy Analytics:**

- **Time Range Selection** - 1h, 6h, 24h, 7d
- **Summary Cards** - Solar, load, grid import, battery SOC
- **Energy Distribution** - Self-consumption, battery charging, grid export
- **Performance Metrics** - Renewable share, efficiency, losses

*Note: Historical data retrieved from Laptop A database via FastAPI*

### 6. Alarms View

**Alarm Management:**

- **Active Alarms** - Real-time alarms from Laptop A
- **Severity Levels** - Critical, Major, Minor
- **Alarm Details** - Timestamp, source, message
- **Event Log** - Recent system events
- **Statistics** - Count by severity

### 7. Digital Twin View

**Physical Visualization** (Placeholder for future 3D implementation):
- Houses with rooftop solar
- Community building
- Transformer/substation
- BESS containers
- Grid connection
- Distribution infrastructure

### 8. KPI Strip

**Top Status Bar:**
- System Load (kW)
- Solar Generation (kW)
- Grid Import/Export (kW)
- Battery SOC (%)
- Transformer Loading (%)
- Frequency (Hz)
- Transformer Temperature (°C)
- Efficiency (%)

### 9. Connection Status

**Real-time Connection Monitoring:**
- **LIVE** - WebSocket connected, receiving telemetry
- **STALE** - No telemetry for >5 seconds
- **DISCONNECTED** - WebSocket closed
- Auto-reconnect with exponential backoff

### 10. Bottom Status Strip

**System Information:**
- Last telemetry timestamp
- Sequence number
- WebSocket status
- Simulation status
- Active alarm count

---

## Technical Implementation

### State Management

All electrical state comes from Laptop A via WebSocket:

```typescript
interface TelemetryState {
  timestamp: string;
  sequence: number;
  frequency: number;
  grid: { voltage_kv, import_kw, export_kw, ... };
  transformer: { loading_percent, temperature_c, ... };
  buses: Array<{ voltage_v, active_power_kw, ... }>;
  feeders: Array<{ current_a, losses_kw, ... }>;
  houses: Array<{ load_kw, pv_kw, net_kw, ... }>;
  community: { load_kw, pv_kw, ... };
  battery: { soc_percent, power_kw, state, ... };
  pcs: { pwm_frequency_hz, duty_cycle, ... };
  ems_mode: string;
  alarms: Array<{ severity, source, message, ... }>;
  events: Array<{ type, description, ... }>;
}
```

### WebSocket Connection

```typescript
// Connect to Laptop A
const ws = new WebSocket('ws://laptop-a:8000/ws/telemetry');

ws.onmessage = (event) => {
  const telemetry = JSON.parse(event.data);
  setState(telemetry);
};
```

### Command Execution

```typescript
// Send command to Laptop A via FastAPI
const response = await fetch('http://laptop-a:8000/api/commands', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` },
  body: JSON.stringify({
    command: 'battery_charge',
    target: 'BESS-01',
    value: 50
  })
});
```

### Authentication

```typescript
// Login
const response = await fetch('http://laptop-a:8000/api/auth/login', {
  method: 'POST',
  body: JSON.stringify({ username, password })
});
const { token, role } = await response.json();

// Roles: ADMIN, OPERATOR, VIEWER
// VIEWER: read-only
// OPERATOR: operational controls
// ADMIN: full access
```

---

## UI Design

### Light Theme

- **Background**: Slate-100 (#f1f5f9)
- **Cards**: White with slate-200 borders
- **Text**: Slate-900 (primary), slate-600 (secondary)
- **Accents**: Cyan-600 (primary), emerald-600 (success), amber-600 (warning), red-600 (critical)

### Typography

- **Font**: System monospace for technical values
- **Hierarchy**: Bold headers, medium labels, regular values
- **Sizes**: 10px (labels), 12px (values), 14px (headers)

### Status Colors

- **Normal**: Emerald-600
- **Warning**: Amber-600
- **Critical**: Red-600
- **Offline**: Slate-400

### Engineering Diagram Style

- **Clean lines** - Professional electrical symbols
- **Busbars** - Blue horizontal bars
- **Breakers** - Green circles
- **Transformer** - Yellow double-circle
- **Feeders** - Blue rectangles
- **Houses** - Green rectangles
- **Battery** - Purple rectangle
- **Solar** - Yellow rectangle

---

## Data Flow

### Telemetry (Laptop A → Laptop B)

```
Laptop A (Electrical State)
    ↓
FastAPI WebSocket Server
    ↓
WebSocket Message (JSON)
    ↓
Laptop B WebSocket Client
    ↓
React State Update
    ↓
UI Re-render
```

### Commands (Laptop B → Laptop A)

```
User clicks control button
    ↓
Confirmation dialog
    ↓
FastAPI REST POST /api/commands
    ↓
Laptop A Command Handler
    ↓
Electrical State Update
    ↓
New Telemetry via WebSocket
    ↓
Laptop B UI Update
```

---

## Performance

### Optimization Strategies

- **Efficient Re-renders** - Only update changed components
- **WebSocket Throttling** - Handle high-frequency updates
- **Memoization** - Cache expensive calculations
- **Lazy Loading** - Load views on demand
- **Virtual Scrolling** - For long lists (events, alarms)

### Build Size

- **JavaScript**: 201 KB (56 KB gzipped)
- **CSS**: 19 KB (4.5 KB gzipped)
- **Total**: ~61 KB gzipped

---

## Deployment

### Development

```bash
npm install
npm run dev
```

Access at: http://localhost:3000

### Production Build

```bash
npm run build
```

Output in `dist/` directory - serve with nginx or similar.

### Environment Variables

```bash
VITE_API_URL=http://laptop-a:8000
VITE_WS_URL=ws://laptop-a:8000/ws/telemetry
```

---

## Testing

### Manual Testing Checklist

- [ ] WebSocket connects to Laptop A
- [ ] Telemetry updates every second
- [ ] All KPIs display correct values
- [ ] Engineering diagram renders correctly
- [ ] Click component → inspector opens
- [ ] Inspector shows correct data
- [ ] Battery control sends command
- [ ] Command confirmation works
- [ ] EMS mode changes
- [ ] Grid export limit updates
- [ ] Alarms display correctly
- [ ] Events log populates
- [ ] Connection status updates
- [ ] Stale data detection works
- [ ] Auto-reconnect works

### Integration Testing

```bash
# Test WebSocket connection
wscat -c ws://laptop-a:8000/ws/telemetry

# Test API endpoints
curl http://laptop-a:8000/api/health
curl http://laptop-a:8000/api/state

# Test authentication
curl -X POST http://laptop-a:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

---

## Troubleshooting

### Blank Screen

**Problem**: App shows blank screen

**Solution**:
1. Check browser console for errors
2. Verify WebSocket URL is correct
3. Check Laptop A is running
4. Verify CORS settings on FastAPI

### WebSocket Disconnected

**Problem**: Shows "DISCONNECTED" status

**Solution**:
1. Check Laptop A is running
2. Verify network connectivity
3. Check firewall allows WebSocket
4. Review FastAPI logs

### Stale Data

**Problem**: Shows "STALE" status

**Solution**:
1. Check Laptop A simulation is running
2. Verify WebSocket is sending telemetry
3. Check for network latency
4. Review FastAPI WebSocket handler

### Commands Not Working

**Problem**: Control buttons don't work

**Solution**:
1. Verify user has OPERATOR or ADMIN role
2. Check authentication token is valid
3. Review FastAPI command handler
4. Check Laptop A logs for errors

---

## Security

### Authentication

- JWT-based authentication
- Token stored in localStorage
- Sent with every API request
- Automatic logout on token expiry

### Authorization

- **ADMIN**: Full access to all controls
- **OPERATOR**: Operational controls (battery, EMS, grid)
- **VIEWER**: Read-only monitoring

### CORS

Configure FastAPI to allow Laptop B origin:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

---

## Future Enhancements

### Digital Twin 3D View

- Three.js / React Three Fiber
- Realistic 3D models of houses, transformer, BESS
- Interactive camera controls
- Asset highlighting on selection

### Advanced Analytics

- Historical trend charts
- Energy forecasting
- Cost analysis
- Carbon footprint tracking

### Mobile Responsive

- Mobile-optimized layouts
- Touch-friendly controls
- Responsive engineering diagram

### Multi-language Support

- i18n framework
- Language selection
- Translated UI strings

---

## Support

For issues or questions:

1. Check this documentation
2. Review browser console for errors
3. Check Laptop A logs
4. Verify network connectivity
5. Test API endpoints directly

---

## License

Proprietary - TEAM CTRL

---

**GRIDPULSE v1.0.0**  
**Laptop B - Engineering Control Center**  
**Production Ready • Professional • Real-time • Authoritative**
