# GRIDPULSE — Current Quick Start

## 1. Install dependencies

From the repository root:

```bash
npm install
```

For standalone deployment on a separate laptop, run `npm install` inside that app directory too.

## 2. Start Laptop B (default)

```bash
npm run dev
```

Open: **http://localhost:3002**

Laptop B contains the Control Center, Solarex and GridPulse AI chatbot.

To use the UI without a backend, choose **Demo Mode** on the login screen.

## 3. Start Laptop A

```bash
npm run dev:laptop-a
```

Open: **http://localhost:3001**

Laptop A contains the circuit/engineering host only.

## 4. Start the FastAPI backend

Linux/macOS:

```bash
./run_backend.sh
```

Windows:

```powershell
.\run_backend.ps1
```

Or directly:

```bash
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Backend docs: **http://localhost:8000/docs**

## 5. Credentials

- Admin: `admin` / `admin123`
- Operator: `operator` / `operator123`
- Viewer: `viewer` / `viewer123`

## 6. Two-laptop LAN setup

On Laptop B, create `laptop-b/.env.local`:

```text
VITE_API_URL=http://<BACKEND-IP>:8000
VITE_WS_URL=ws://<BACKEND-IP>:8000/ws/telemetry
```

Then start Laptop B with:

```bash
npm run dev:laptop-b -- --host 0.0.0.0
```

## 7. Full stack on one machine

```bash
npm run dev:both
./run_backend.sh
```

Or on Windows:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-gridpulse.ps1
```

## 8. Verification

```bash
PYTHONPATH=backend pytest -q backend
```

Then verify in the browser that:

- Laptop A opens independently.
- Laptop B opens independently.
- Demo Mode produces telemetry.
- Backend mode produces WebSocket telemetry.
- Transformer, BESS and PWM values update together.
- Solarex location confirmation and roof drawing can be completed or cancelled.
- Chatbot answers from current telemetry/active alarms.
