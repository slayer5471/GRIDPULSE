# GRIDPULSE High-Fidelity Stack

The core backend is intentionally offline-capable. For the full optional research stack, install:

```bash
pip install -r backend/requirements-optional.txt
```

Optional integrations:

- OpenDSS / opendssdirect.py — unbalanced distribution/QSTS studies
- pandapower — balanced cross-check/time-series verification
- PyPSA — optimization/economic-dispatch reference model
- HELICS — federated time/message synchronization
- paho-mqtt — Wokwi/ESP32 edge bridge

Even without those packages, the deterministic digital twin keeps the same API contract and exposes `fallback_active=true`.
