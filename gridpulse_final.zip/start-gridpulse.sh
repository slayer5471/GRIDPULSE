#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Starting GRIDPULSE: FastAPI + Laptop A + Laptop B"
exec npm run dev:all
