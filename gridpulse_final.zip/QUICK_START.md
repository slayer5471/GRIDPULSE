# GRIDPULSE - Two Separate Applications

## 🎯 Quick Start

### Run Laptop B (Control Center) - DEFAULT
```bash
npm run dev
```
**Opens:** http://localhost:3002  
**Shows:** Control Center + Solarex only

---

### Run Laptop A (Circuit Editor) - SEPARATE
```bash
npm run dev:laptop-a
```
**Opens:** http://localhost:3001  
**Shows:** Circuit Editor only

---

## 📦 What You Get

### When you run `npm run dev` (Laptop B)
✅ Control Center dashboard  
✅ Real-time monitoring  
✅ Battery & grid controls  
✅ Alarms & events  
✅ Analytics  
✅ Solarex platform  
✅ Interactive map  

❌ NO Circuit Editor  
❌ NO Component Library  
❌ NO Power Flow tools  

---

### When you run `npm run dev:laptop-a` (Laptop A)
✅ Circuit Editor canvas  
✅ Component library (25+ types)  
✅ Property editor  
✅ Power flow analysis  
✅ Validation tools  
✅ What-If Lab  
✅ N-1 Contingency  
✅ Anomaly Detection  

❌ NO Control Center  
❌ NO Solarex  
❌ NO Monitoring dashboard  

---

## 🏗️ Architecture

```
Laptop A (Port 3001)          Laptop B (Port 3002)
┌──────────────────┐          ┌──────────────────┐
│ Circuit Editor   │          │ Control Center   │
│                  │          │ + Solarex        │
│ • Canvas         │          │                  │
│ • Components     │          │ • Monitoring     │
│ • Power Flow     │          │ • Controls       │
│ • Validation     │          │ • Analytics      │
│ • Scenarios      │          │ • Solarex        │
└────────┬─────────┘          └────────┬─────────┘
         │                              │
         └──────────┬───────────────────┘
                    │
            ┌───────┴────────┐
            │   FASTAPI      │
            │   Port 8000    │
            └────────────────┘
```

---

## 🚀 Commands

| Command | What it does | Port |
|---------|--------------|------|
| `npm run dev` | Run Laptop B (Control Center) | 3002 |
| `npm run dev:laptop-a` | Run Laptop A (Circuit Editor) | 3001 |
| `npm run dev:laptop-b` | Run Laptop B (same as `dev`) | 3002 |
| `npm run dev:both` | Run both simultaneously | 3001 + 3002 |

---

## 📦 Build for Production

### Build Laptop A
```bash
npm run build:laptop-a
```
**Output:** `dist-laptop-a/` → Deploy to Machine A

### Build Laptop B
```bash
npm run build
```
or
```bash
npm run build:laptop-b
```
**Output:** `dist-laptop-b/` → Deploy to Machine B

---

## 🌐 Deploy on Two Machines

### Machine A (Laptop A - Circuit Editor)
```bash
# Build
npm run build:laptop-a

# Deploy dist-laptop-a/ to Machine A
# Serve on port 3001
serve -s dist-laptop-a -l 3001
```

**Access:** http://192.168.1.100:3001

---

### Machine B (Laptop B - Control Center)
```bash
# Set environment
export VITE_API_URL=http://192.168.1.100:8000
export VITE_WS_URL=ws://192.168.1.100:8000/ws/telemetry

# Build
npm run build

# Deploy dist-laptop-b/ to Machine B
# Serve on port 3002
serve -s dist-laptop-b -l 3002
```

**Access:** http://192.168.1.101:3002

---

## ✅ What Changed

**Before:**
- ❌ Single app with mode switcher
- ❌ Both laptops in one UI
- ❌ Confusing

**After:**
- ✅ Two completely separate apps
- ✅ Each runs independently
- ✅ Clear separation
- ✅ No mode switcher

---

## 🎯 Demo Mode

When you run `npm run dev` (Laptop B):
1. You'll see the login screen
2. Click **"Continue in Demo Mode"**
3. You'll see **ONLY Laptop B** (Control Center)
4. No Laptop A interface
5. No mode switcher

---

## 📖 Documentation

- **[RUNNING_TWO_LAPTOPS.md](./RUNNING_TWO_LAPTOPS.md)** - Complete deployment guide
- **[COMPLETE_SEPARATION.md](./COMPLETE_SEPARATION.md)** - What was changed
- **[LAPTOP_A_GIGA_UPGRADE.md](./LAPTOP_A_GIGA_UPGRADE.md)** - Laptop A features
- **[LAPTOP_B_FINAL_UPGRADE.md](./LAPTOP_B_FINAL_UPGRADE.md)** - Laptop B features

---

**GRIDPULSE v1.0.0**  
**Two Independent Applications**  
**Run separately on different machines**
