# GRIDPULSE Map constructor fix — 2026-09-29

## Root cause
Laptop B imported the Lucide icon named `Map` into `ControlCenter.tsx` while the same component also used the native JavaScript constructor `new Map(...)` to deduplicate alarms.

The imported Lucide component shadowed the global `Map` constructor, producing:

`Map is not a constructor`

## Fix
Removed the unused Lucide `Map` import from `laptop-b/src/components/ControlCenter.tsx`.

The alert deduplication code now resolves `Map` to the native JavaScript constructor.

## Verified source conditions
- No `Map` icon import remains in `ControlCenter.tsx`.
- The existing `new Map<string, ...>()` alarm deduplication remains intact.
- No other Laptop B TSX file was found with both a Lucide `Map` import and `new Map(...)`.
- Previous Lucide `TriangleAlert` issue remains fixed through `AlertTriangle`.
