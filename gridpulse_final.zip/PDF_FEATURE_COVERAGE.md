# GRIDPULSE PDF Feature Coverage

This file maps the implementation to the master GRIDPULSE engineering specification.

## Scenario execution matrix
The demo now exposes working scenario controls for the five energy-balance cases in the specification plus grid/asset/cyber events. `Solar < Load` exercises BESS/grid support, `Solar = Load` balances locally with BESS idle, `Solar > Load` exercises BESS charging and export, `Evening Peak` exercises discharge/peak shaving, and `Transformer Overload` produces a critical loading alarm. Additional scenarios cover grid outage, voltage sag/swell, PV/PCS trips, feeder outage, BESS low SOC, and FDIA.

## PWM accounting
The PCS uses an explicit simulated average-value PWM model. The configured 10 kHz carrier has a 0.1 ms period. The average BESS transfer is calculated as `Pavg = Ppulse × duty`, and per-pulse energy as `Epulse = Ppulse × t_on / 3600` Wh. The UI renders the 20-sample pulse pattern, duty cycle, ON/OFF time, pulse energy, pulse rate, direction and average power. This is a converter-level digital-twin abstraction; it is not a transistor-level switching simulation.
