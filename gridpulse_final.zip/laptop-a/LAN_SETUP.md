# GRIDPULSE Laptop A — LAN setup

1. From this directory run `npm install`.
2. Run `npm run dev -- --host 0.0.0.0`.

Laptop A is the circuit/engineering host.
