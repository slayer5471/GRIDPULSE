import React from 'react'
import ReactDOM from 'react-dom/client'
import LaptopAApp from './LaptopAApp'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <LaptopAApp />
  </React.StrictMode>,
)
