// GRIDPULSE Laptop A — Circuit Host / Electrical Engineering Studio
import CircuitEditor from './components/CircuitEditor';
import { Activity, Circle, Cpu, Network, ShieldCheck, Zap } from 'lucide-react';

export default function LaptopAApp() {
  return (
    <div className="gp-a-app flex h-screen flex-col bg-[#f3f6fa] text-slate-900">
      <header className="flex h-[62px] shrink-0 items-center justify-between border-b border-slate-200/90 bg-white px-5 shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#6d5dfc] text-white"><Zap size={17}/></div>
          <div>
            <div className="text-[15px] font-bold tracking-tight">GridPulse</div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-slate-400">Circuit Host • Laptop A</div>
          </div>
        </div>
        <div className="hidden items-center gap-2 md:flex">
          <span className="gp-a-pill"><Circle size={9} fill="currentColor"/> Live Engine</span>
          <span className="gp-a-pill"><Activity size={11}/> Power Flow</span>
          <span className="gp-a-pill"><Network size={11}/> FastAPI Sync</span>
          <span className="gp-a-pill"><ShieldCheck size={11}/> Engineering Workspace</span>
          <span className="gp-a-pill"><Cpu size={11}/> Digital Twin</span>
        </div>
      </header>
      <div className="min-h-0 flex-1 overflow-hidden"><CircuitEditor /></div>
    </div>
  );
}
