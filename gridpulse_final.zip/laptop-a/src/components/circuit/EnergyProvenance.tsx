// Energy Provenance - Trace energy sources for a selected load
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { PowerFlowResult } from '../../types/circuit';

interface EnergyProvenanceProps {
  model: ElectricalModel;
  componentId: string;
}

interface EnergySource {
  id: string;
  name: string;
  type: string;
  power_kw: number;
  percentage: number;
  color: string;
  icon: string;
}

export default function EnergyProvenance({ model, componentId }: EnergyProvenanceProps) {
  const network = model.getNetwork();
  const component = network.components[componentId];
  const powerFlowResult = model.runPowerFlow();

  if (!component || component.type !== 'load' || !powerFlowResult) {
    return null;
  }

  const load = component as any;
  const loadPower = load.active_power_kw;

  // Calculate energy sources
  const sources: EnergySource[] = [];

  // Solar contribution
  const totalSolar = powerFlowResult.total_generation_kw;
  if (totalSolar > 0) {
    const solarContribution = Math.min(totalSolar, loadPower);
    sources.push({
      id: 'PV-SYSTEM',
      name: 'Solar PV',
      type: 'pv_array',
      power_kw: solarContribution,
      percentage: (solarContribution / loadPower) * 100,
      color: '#eab308',
      icon: '☀️',
    });
  }

  // Battery contribution
  const batteryDischarge = powerFlowResult.power_balance.battery_discharge_kw;
  if (batteryDischarge > 0) {
    const batteryContribution = Math.min(batteryDischarge, loadPower - (sources[0]?.power_kw || 0));
    if (batteryContribution > 0) {
      sources.push({
        id: 'BESS-01',
        name: 'Battery Storage',
        type: 'bess',
        power_kw: batteryContribution,
        percentage: (batteryContribution / loadPower) * 100,
        color: '#9333ea',
        icon: '🔋',
      });
    }
  }

  // Grid contribution (remainder)
  const remainingLoad = loadPower - sources.reduce((sum, s) => sum + s.power_kw, 0);
  if (remainingLoad > 0) {
    sources.push({
      id: 'GRID-01',
      name: 'Grid Import',
      type: 'grid_source',
      power_kw: remainingLoad,
      percentage: (remainingLoad / loadPower) * 100,
      color: '#0891b2',
      icon: '⚡',
    });
  }

  // Sort by percentage
  sources.sort((a, b) => b.percentage - a.percentage);

  // Calculate renewable percentage
  const renewablePercentage = sources
    .filter(s => s.type === 'pv_array' || s.type === 'bess')
    .reduce((sum, s) => sum + s.percentage, 0);

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-emerald-600">🔋</span>
        Energy Provenance
      </h3>

      {/* Load Info */}
      <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 mb-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Selected Load</div>
        <div className="text-sm font-bold text-slate-900">{component.name}</div>
        <div className="text-xs text-slate-600 mt-1">
          Consuming <span className="font-bold text-blue-600">{loadPower.toFixed(1)} kW</span>
        </div>
      </div>

      {/* Energy Sources */}
      <div className="mb-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Energy Sources</div>
        <div className="space-y-2">
          {sources.map((source, idx) => (
            <div key={idx} className="bg-slate-50 rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-base">{source.icon}</span>
                  <div>
                    <div className="text-xs font-medium text-slate-900">{source.name}</div>
                    <div className="text-[10px] text-slate-500">{source.id}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-900">{source.power_kw.toFixed(1)} kW</div>
                  <div className="text-[10px] text-slate-500">{source.percentage.toFixed(1)}%</div>
                </div>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="h-2 rounded-full transition-all"
                  style={{ width: `${source.percentage}%`, backgroundColor: source.color }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Renewable Summary */}
      <div className={`rounded-lg p-3 border ${
        renewablePercentage > 50 ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-500 uppercase font-bold">Renewable Energy</div>
            <div className={`text-lg font-bold ${renewablePercentage > 50 ? 'text-emerald-600' : 'text-slate-700'}`}>
              {renewablePercentage.toFixed(1)}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-500">Carbon Intensity</div>
            <div className="text-sm font-bold text-slate-700">
              {((100 - renewablePercentage) * 0.82).toFixed(0)} g CO₂/kWh
            </div>
          </div>
        </div>
      </div>

      {/* Energy Flow Diagram */}
      <div className="mt-3 pt-3 border-t border-slate-200">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Energy Flow</div>
        <div className="text-xs text-slate-600 bg-slate-50 rounded p-2 font-mono">
          {sources.map((source, idx) => (
            <React.Fragment key={idx}>
              {idx > 0 && <span className="text-slate-400"> + </span>}
              <span style={{ color: source.color }} className="font-bold">
                {source.name.split(' ')[0]}
              </span>
              <span className="text-slate-500"> ({source.percentage.toFixed(0)}%)</span>
            </React.Fragment>
          ))}
          <span className="text-slate-400"> → </span>
          <span className="font-bold text-blue-600">{component.id}</span>
        </div>
      </div>
    </div>
  );
}
