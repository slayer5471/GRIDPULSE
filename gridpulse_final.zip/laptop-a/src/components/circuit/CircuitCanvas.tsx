// Circuit Canvas - Enhanced with electrical awareness
import React, { useState, useRef } from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { Connection, PowerFlowResult } from '../../types/circuit';
import { ComponentSymbols } from './ComponentSymbols';

interface CircuitCanvasProps {
  model: ElectricalModel;
  onComponentSelect: (id: string | null, multiSelect?: boolean) => void;
  selectedComponentId: string | null;
  showMeasurements: boolean;
  powerFlowResult: PowerFlowResult | null;
  onContextMenu?: (e: React.MouseEvent, componentId: string) => void;
}

export default function CircuitCanvas({
  model,
  onComponentSelect,
  selectedComponentId,
  showMeasurements,
  powerFlowResult,
  onContextMenu,
}: CircuitCanvasProps) {
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, width: 1200, height: 900 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [draggedComponent, setDraggedComponent] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDrawingWire, setIsDrawingWire] = useState(false);
  const [wireStart, setWireStart] = useState<{ componentId: string; terminalId: string } | null>(null);
  const [wireEnd, setWireEnd] = useState<{ x: number; y: number } | null>(null);
  
  const svgRef = useRef<SVGSVGElement>(null);
  const network = model.getNetwork();

  // Handle mouse wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const scale = e.deltaY > 0 ? 1.1 : 0.9;
    const svg = svgRef.current;
    if (!svg) return;

    const rect = svg.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const newX = viewBox.x + (mouseX / rect.width) * viewBox.width * (1 - scale);
    const newY = viewBox.y + (mouseY / rect.height) * viewBox.height * (1 - scale);
    const newWidth = viewBox.width * scale;
    const newHeight = viewBox.height * scale;

    setViewBox({ x: newX, y: newY, width: newWidth, height: newHeight });
  };

  // Handle pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
      setIsPanning(true);
      setPanStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      const dx = (e.clientX - panStart.x) * (viewBox.width / (svgRef.current?.clientWidth || 1));
      const dy = (e.clientY - panStart.y) * (viewBox.height / (svgRef.current?.clientHeight || 1));
      setViewBox(prev => ({ ...prev, x: prev.x - dx, y: prev.y - dy }));
      setPanStart({ x: e.clientX, y: e.clientY });
    }

    if (draggedComponent) {
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * viewBox.width + viewBox.x - dragOffset.x;
      const y = ((e.clientY - rect.top) / rect.height) * viewBox.height + viewBox.y - dragOffset.y;
      model.updateComponent(draggedComponent, { position: { x, y } } as any);
    }

    if (isDrawingWire && wireStart) {
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * viewBox.width + viewBox.x;
      const y = ((e.clientY - rect.top) / rect.height) * viewBox.height + viewBox.y;
      setWireEnd({ x, y });
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
    setDraggedComponent(null);
  };

  // Handle component drag
  const handleComponentMouseDown = (e: React.MouseEvent, componentId: string) => {
    if (e.button === 0 && !e.shiftKey) {
      e.stopPropagation();
      const comp = network.components[componentId];
      const svg = svgRef.current;
      if (!svg || !comp) return;
      
      const rect = svg.getBoundingClientRect();
      const mouseX = ((e.clientX - rect.left) / rect.width) * viewBox.width + viewBox.x;
      const mouseY = ((e.clientY - rect.top) / rect.height) * viewBox.height + viewBox.y;
      
      setDragOffset({ x: mouseX - comp.position.x, y: mouseY - comp.position.y });
      setDraggedComponent(componentId);
      onComponentSelect(componentId, e.shiftKey);
    }
  };

  // Handle terminal click for wire drawing
  const handleTerminalClick = (e: React.MouseEvent, componentId: string, terminalId: string) => {
    e.stopPropagation();
    
    if (!isDrawingWire) {
      setIsDrawingWire(true);
      setWireStart({ componentId, terminalId });
    } else if (wireStart && wireStart.componentId !== componentId) {
      // Complete wire
      const newConnection: Connection = {
        id: `CONN-${Date.now()}`,
        from_component: wireStart.componentId,
        from_terminal: wireStart.terminalId,
        to_component: componentId,
        to_terminal: terminalId,
        wire_type: 'power',
      };
      model.addConnection(newConnection);
      setIsDrawingWire(false);
      setWireStart(null);
      setWireEnd(null);
    }
  };

  // Get terminal position
  const getTerminalPosition = (componentId: string, terminalId: string) => {
    const comp = network.components[componentId];
    if (!comp) return { x: 0, y: 0 };
    
    const terminal = comp.terminals.find(t => t.id === terminalId);
    if (!terminal) return comp.position;
    
    return {
      x: comp.position.x + (terminal.position.x - comp.position.x),
      y: comp.position.y + (terminal.position.y - comp.position.y),
    };
  };

  // Render connection with power flow animation
  const renderConnection = (conn: Connection) => {
    const from = getTerminalPosition(conn.from_component, conn.from_terminal);
    const to = getTerminalPosition(conn.to_component, conn.to_terminal);
    
    // Calculate power flow for this connection
    const fromComp = network.components[conn.from_component];
    const toComp = network.components[conn.to_component];
    
    let powerFlow = 0;
    if (fromComp?.type === 'bus' && toComp?.type === 'line') {
      const lineResult = powerFlowResult?.line_results[toComp.id];
      powerFlow = lineResult?.active_power_kw || 0;
    }
    
    return (
      <g key={conn.id}>
        <line
          x1={from.x}
          y1={from.y}
          x2={to.x}
          y2={to.y}
          stroke="#64748b"
          strokeWidth="2"
          strokeDasharray={powerFlow === 0 ? "5,5" : "none"}
        />
        {powerFlow !== 0 && (
          <circle r="3" fill="#06b6d4">
            <animateMotion
              dur={`${2 / Math.abs(powerFlow)}s`}
              repeatCount="indefinite"
              path={`M${from.x},${from.y} L${to.x},${to.y}`}
            />
          </circle>
        )}
      </g>
    );
  };

  // Render component
  const renderComponent = (comp: any) => {
    const isSelected = selectedComponentId === comp.id;
    const Symbol = ComponentSymbols[comp.type] || ComponentSymbols.default;
    
    // Get telemetry
    let telemetry = null;
    if (comp.type === 'bus') {
      telemetry = powerFlowResult?.bus_results[comp.id];
    } else if (comp.type === 'line') {
      telemetry = powerFlowResult?.line_results[comp.id];
    } else if (comp.type === 'transformer') {
      telemetry = powerFlowResult?.transformer_results[comp.id];
    }
    
    return (
      <g
        key={comp.id}
        transform={`translate(${comp.position.x}, ${comp.position.y})`}
        onMouseDown={(e) => handleComponentMouseDown(e, comp.id)}
        onContextMenu={(e) => onContextMenu?.(e, comp.id)}
        style={{ cursor: 'move' }}
      >
        {/* Selection highlight */}
        {isSelected && (
          <rect
            x="-40"
            y="-40"
            width="80"
            height="80"
            fill="none"
            stroke="#06b6d4"
            strokeWidth="2"
            strokeDasharray="4,4"
            opacity="0.5"
          />
        )}
        
        {/* Component symbol */}
        <Symbol component={comp} telemetry={telemetry} showMeasurements={showMeasurements} />
        
        {/* Component label */}
        <text
          x="0"
          y="35"
          textAnchor="middle"
          fontSize="10"
          fill="#1e293b"
          fontWeight="500"
        >
          {comp.name}
        </text>
        
        {/* Terminals */}
        {comp.terminals.map((terminal: any) => (
          <circle
            key={terminal.id}
            cx={terminal.position.x - comp.position.x}
            cy={terminal.position.y - comp.position.y}
            r="4"
            fill={isDrawingWire && wireStart?.terminalId === terminal.id ? '#06b6d4' : '#94a3b8'}
            stroke="#fff"
            strokeWidth="1.5"
            style={{ cursor: 'crosshair' }}
            onClick={(e) => handleTerminalClick(e, comp.id, terminal.id)}
          />
        ))}
      </g>
    );
  };

  return (
    <svg
      ref={svgRef}
      width="100%"
      height="100%"
      viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      style={{ background: '#f8fafc', cursor: isPanning ? 'grabbing' : 'default' }}
    >
      {/* Grid pattern */}
      <defs>
        <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
          <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#e2e8f0" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />
      
      {/* Connections */}
      {network.connections.map(renderConnection)}
      
      {/* Wire being drawn */}
      {isDrawingWire && wireStart && wireEnd && (
        <line
          x1={getTerminalPosition(wireStart.componentId, wireStart.terminalId).x}
          y1={getTerminalPosition(wireStart.componentId, wireStart.terminalId).y}
          x2={wireEnd.x}
          y2={wireEnd.y}
          stroke="#06b6d4"
          strokeWidth="2"
          strokeDasharray="5,5"
        />
      )}
      
      {/* Components */}
      {Object.values(network.components).map(renderComponent)}
    </svg>
  );
}
