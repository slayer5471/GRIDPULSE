// Property Editor - Component parameter editor
import React from 'react';
import { CircuitComponent } from '../../types/circuit';

interface PropertyEditorProps {
  component: CircuitComponent | null;
  onUpdate: (id: string, updates: Partial<CircuitComponent>) => void;
  onClose: () => void;
}

export default function PropertyEditor({ component, onUpdate, onClose }: PropertyEditorProps) {
  if (!component) {
    return (
      <div className="w-80 bg-white border-l border-slate-200 p-4">
        <p className="text-xs text-slate-500 text-center mt-8">Select a component to edit properties</p>
      </div>
    );
  }

  const handleChange = (field: string, value: any) => {
    onUpdate(component.id, { [field]: value } as any);
  };

  return (
    <div className="w-80 bg-white border-l border-slate-200 flex flex-col">
      <div className="p-3 border-b border-slate-200 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-900">{component.name}</h2>
          <p className="text-[10px] text-slate-500">{component.id} • {component.type}</p>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600">✕</button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-3">
        <div className="space-y-3">
          <PropertyField label="Name" value={component.name} onChange={(v) => handleChange('name', v)} type="text" />
          <PropertySelect label="Status" value={component.status} onChange={(v) => handleChange('status', v)} options={['online', 'offline', 'warning', 'fault', 'maintenance']} />
          
          <div className="border-t border-slate-200 pt-3 mt-3">
            <h3 className="text-xs font-bold text-slate-700 mb-2">Electrical Parameters</h3>
            {component.type === 'transformer' && (
              <>
                <PropertyField label="HV Voltage (kV)" value={(component as any).hv_voltage_kv} onChange={(v) => handleChange('hv_voltage_kv', parseFloat(v))} type="number" />
                <PropertyField label="LV Voltage (V)" value={(component as any).lv_voltage_v} onChange={(v) => handleChange('lv_voltage_v', parseFloat(v))} type="number" />
                <PropertyField label="Rating (kVA)" value={(component as any).rating_kva} onChange={(v) => handleChange('rating_kva', parseFloat(v))} type="number" />
                <PropertyField label="Impedance (%)" value={(component as any).impedance_percent} onChange={(v) => handleChange('impedance_percent', parseFloat(v))} type="number" />
              </>
            )}
            {component.type === 'load' && (
              <>
                <PropertyField label="Active Power (kW)" value={(component as any).active_power_kw} onChange={(v) => handleChange('active_power_kw', parseFloat(v))} type="number" step="0.1" />
                <PropertyField label="Reactive Power (kVAr)" value={(component as any).reactive_power_kvar} onChange={(v) => handleChange('reactive_power_kvar', parseFloat(v))} type="number" step="0.1" />
                <PropertyField label="Power Factor" value={(component as any).power_factor} onChange={(v) => handleChange('power_factor', parseFloat(v))} type="number" step="0.01" />
              </>
            )}
            {component.type === 'breaker' && (
              <>
                <PropertyField label="Rating (A)" value={(component as any).rating_a} onChange={(v) => handleChange('rating_a', parseFloat(v))} type="number" />
                <PropertySelect label="State" value={(component as any).state} onChange={(v) => handleChange('state', v)} options={['open', 'closed']} />
              </>
            )}
            {component.type === 'bess' && (
              <>
                <PropertyField label="Capacity (kWh)" value={(component as any).capacity_kwh} onChange={(v) => handleChange('capacity_kwh', parseFloat(v))} type="number" />
                <PropertyField label="SOC (%)" value={(component as any).soc_percent} onChange={(v) => handleChange('soc_percent', parseFloat(v))} type="number" />
                <PropertySelect label="Mode" value={(component as any).mode} onChange={(v) => handleChange('mode', v)} options={['auto', 'charge', 'discharge', 'idle']} />
              </>
            )}
            {component.type === 'pv_array' && (
              <>
                <PropertyField label="Capacity (kW)" value={(component as any).capacity_kw} onChange={(v) => handleChange('capacity_kw', parseFloat(v))} type="number" />
                <PropertyField label="Efficiency" value={(component as any).efficiency} onChange={(v) => handleChange('efficiency', parseFloat(v))} type="number" step="0.01" />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const PropertyField: React.FC<{ label: string; value: any; onChange: (value: string) => void; type: string; step?: string }> = ({ label, value, onChange, type, step }) => (
  <div className="mb-2">
    <label className="text-[10px] text-slate-600 block mb-1">{label}</label>
    <input type={type} value={value} onChange={(e) => onChange(e.target.value)} step={step} className="w-full px-2 py-1 text-xs border border-slate-200 rounded focus:outline-none focus:border-cyan-500" />
  </div>
);

const PropertySelect: React.FC<{ label: string; value: string; onChange: (value: string) => void; options: string[] }> = ({ label, value, onChange, options }) => (
  <div className="mb-2">
    <label className="text-[10px] text-slate-600 block mb-1">{label}</label>
    <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-2 py-1 text-xs border border-slate-200 rounded focus:outline-none focus:border-cyan-500">
      {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
    </select>
  </div>
);
