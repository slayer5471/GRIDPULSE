// Engineering Table View - Tabular view of all assets
import React, { useState } from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { CircuitComponent } from '../../types/circuit';

interface EngineeringTableProps {
  model: ElectricalModel;
  onAssetSelect: (id: string) => void;
  powerFlowResult: any;
}

export default function EngineeringTable({ model, onAssetSelect, powerFlowResult }: EngineeringTableProps) {
  const [sortBy, setSortBy] = useState<string>('id');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [filterType, setFilterType] = useState<string>('all');

  const network = model.getNetwork();
  
  // Get all components with their telemetry
  const components = Object.values(network.components).map(comp => {
    let telemetry: any = {};
    
    if (comp.type === 'bus' && powerFlowResult?.bus_results) {
      telemetry = powerFlowResult.bus_results[comp.id] || {};
    } else if (comp.type === 'line' && powerFlowResult?.line_results) {
      telemetry = powerFlowResult.line_results[comp.id] || {};
    } else if (comp.type === 'transformer' && powerFlowResult?.transformer_results) {
      telemetry = powerFlowResult.transformer_results[comp.id] || {};
    } else if (comp.type === 'load') {
      telemetry = {
        active_power_kw: (comp as any).active_power_kw,
        reactive_power_kvar: (comp as any).reactive_power_kvar,
      };
    } else if (comp.type === 'pv_array') {
      const pv = comp as any;
      const hour = new Date().getHours();
      const solarFactor = Math.max(0, Math.sin((hour - 6) * Math.PI / 12));
      telemetry = {
        active_power_kw: pv.capacity_kw * solarFactor * pv.efficiency,
        capacity_kw: pv.capacity_kw,
      };
    } else if (comp.type === 'bess') {
      telemetry = {
        soc_percent: (comp as any).soc_percent,
        power_kw: (comp as any).power_kw || 0,
      };
    }

    return { ...comp, telemetry };
  });

  // Filter by type
  const filtered = filterType === 'all' 
    ? components 
    : components.filter(c => c.type === filterType);

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    let aVal: any = (a as any)[sortBy] || '';
    let bVal: any = (b as any)[sortBy] || '';
    
    if (typeof aVal === 'string') {
      return sortDir === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
  });

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDir('asc');
    }
  };

  // Get unique types for filter
  const types = Array.from(new Set(components.map(c => c.type)));

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-emerald-600';
      case 'warning': return 'text-amber-600';
      case 'fault': return 'text-red-600';
      case 'offline': return 'text-slate-400';
      default: return 'text-slate-600';
    }
  };

  // Get loading color
  const getLoadingColor = (loading: number) => {
    if (loading > 90) return 'text-red-600 font-bold';
    if (loading > 75) return 'text-amber-600 font-medium';
    return 'text-slate-700';
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200">
      {/* Toolbar */}
      <div className="p-3 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-bold text-slate-900">Engineering Table</h3>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-2 py-1 text-xs border border-slate-200 rounded"
          >
            <option value="all">All Types ({components.length})</option>
            {types.map(type => (
              <option key={type} value={type}>
                {type.replace('_', ' ')} ({components.filter(c => c.type === type).length})
              </option>
            ))}
          </select>
        </div>
        <div className="text-xs text-slate-500">
          Showing {sorted.length} of {components.length} assets
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th onClick={() => handleSort('id')} className="text-left p-2 font-medium text-slate-600 cursor-pointer hover:bg-slate-100">
                ID {sortBy === 'id' && (sortDir === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('name')} className="text-left p-2 font-medium text-slate-600 cursor-pointer hover:bg-slate-100">
                Name {sortBy === 'name' && (sortDir === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('type')} className="text-left p-2 font-medium text-slate-600 cursor-pointer hover:bg-slate-100">
                Type {sortBy === 'type' && (sortDir === 'asc' ? '↑' : '↓')}
              </th>
              <th className="text-right p-2 font-medium text-slate-600">Voltage</th>
              <th className="text-right p-2 font-medium text-slate-600">Power</th>
              <th className="text-right p-2 font-medium text-slate-600">Current</th>
              <th className="text-right p-2 font-medium text-slate-600">Loading</th>
              <th className="text-center p-2 font-medium text-slate-600">Status</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((comp: any) => (
              <tr
                key={comp.id}
                onClick={() => onAssetSelect(comp.id)}
                className="border-b border-slate-100 hover:bg-cyan-50 cursor-pointer"
              >
                <td className="p-2 font-mono font-medium text-slate-900">{comp.id}</td>
                <td className="p-2 text-slate-700">{comp.name}</td>
                <td className="p-2 text-slate-600 capitalize">{comp.type.replace('_', ' ')}</td>
                <td className="p-2 text-right font-mono text-slate-700">
                  {comp.telemetry?.voltage_v 
                    ? `${comp.telemetry.voltage_v.toFixed(1)} V`
                    : comp.voltage_kv 
                      ? `${comp.voltage_kv} kV`
                      : '—'}
                </td>
                <td className="p-2 text-right font-mono text-slate-700">
                  {comp.telemetry?.active_power_kw !== undefined
                    ? `${comp.telemetry.active_power_kw.toFixed(1)} kW`
                    : '—'}
                </td>
                <td className="p-2 text-right font-mono text-slate-700">
                  {comp.telemetry?.current_a !== undefined
                    ? `${comp.telemetry.current_a.toFixed(1)} A`
                    : comp.telemetry?.lv_current_a
                      ? `${comp.telemetry.lv_current_a.toFixed(1)} A`
                      : '—'}
                </td>
                <td className={`p-2 text-right font-mono ${getLoadingColor(comp.telemetry?.loading_percent || 0)}`}>
                  {comp.telemetry?.loading_percent !== undefined
                    ? `${comp.telemetry.loading_percent.toFixed(1)}%`
                    : '—'}
                </td>
                <td className={`p-2 text-center font-medium ${getStatusColor(comp.status)}`}>
                  {comp.status.toUpperCase()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
