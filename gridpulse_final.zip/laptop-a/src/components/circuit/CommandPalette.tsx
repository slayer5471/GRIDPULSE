// Command Palette - Quick command interface
import React, { useState, useEffect, useRef } from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';

interface CommandPaletteProps {
  model: ElectricalModel;
  onClose: () => void;
  onSelect: (action: any) => void;
}

export default function CommandPalette({ model, onClose, onSelect }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const commands = [
    { id: 'run-powerflow', label: 'Run Power Flow', category: 'Simulation', action: () => model.runPowerFlow() },
    { id: 'validate', label: 'Validate Network', category: 'Validation', action: () => {} },
    { id: 'auto-layout', label: 'Auto Layout', category: 'Layout', action: () => {} },
    { id: 'save-version', label: 'Save Version', category: 'Version', action: () => {} },
    ...model.searchComponents(query).map(comp => ({
      id: `locate-${comp.id}`,
      label: `Locate ${comp.name}`,
      category: 'Components',
      action: () => onSelect({ type: 'locate', componentId: comp.id }),
    })),
  ];

  const filteredCommands = commands.filter(cmd => 
    cmd.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center pt-20 z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[600px] max-h-[500px] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200">
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a command or search..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-200 rounded focus:outline-none focus:border-cyan-500"
          />
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {filteredCommands.map(cmd => (
            <button
              key={cmd.id}
              onClick={() => { cmd.action(); onClose(); }}
              className="w-full px-3 py-2 text-left hover:bg-slate-50 rounded flex items-center justify-between"
            >
              <div>
                <div className="text-sm font-medium text-slate-900">{cmd.label}</div>
                <div className="text-[10px] text-slate-500">{cmd.category}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="p-2 border-t border-slate-200 text-[10px] text-slate-500">
          Press ESC to close
        </div>
      </div>
    </div>
  );
}
