// Scenario Selector - Scenario management
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';

interface ScenarioSelectorProps {
  model: ElectricalModel;
  onClose: () => void;
  onApply: (scenarioId: string) => void;
}

export default function ScenarioSelector({ model, onClose, onApply }: ScenarioSelectorProps) {
  const scenarios = model.getScenarios();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[600px] max-h-[600px] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-lg font-bold text-slate-900">Scenario Selector</h2>
          <p className="text-xs text-slate-500 mt-1">Apply predefined scenarios to test network behavior</p>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {scenarios.map(scenario => (
              <div key={scenario.id} className="p-3 border border-slate-200 rounded-lg hover:border-cyan-300 transition-colors">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{scenario.name}</h3>
                    <p className="text-xs text-slate-500 mt-1">{scenario.description}</p>
                    <p className="text-[10px] text-slate-400 mt-1">Type: {scenario.type}</p>
                  </div>
                  <button
                    onClick={() => onApply(scenario.id)}
                    className="px-3 py-1.5 text-xs bg-cyan-600 text-white rounded hover:bg-cyan-700"
                  >
                    Apply
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="p-4 border-t border-slate-200">
          <button onClick={onClose} className="w-full px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded hover:bg-slate-200">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
