// Explain-Why Engine - Answers engineering questions with evidence
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { PowerFlowResult } from '../../types/circuit';

interface ExplainWhyProps {
  model: ElectricalModel;
  componentId: string;
}

interface Explanation {
  question: string;
  answer: string;
  evidence: Array<{ label: string; value: string; severity?: 'normal' | 'warning' | 'critical' }>;
  contributors: Array<{ id: string; name: string; contribution: string; percentage: number }>;
}

export default function ExplainWhy({ model, componentId }: ExplainWhyProps) {
  const network = model.getNetwork();
  const component = network.components[componentId];
  const powerFlowResult = model.runPowerFlow();

  if (!component || !powerFlowResult) return null;

  const explanation = generateExplanation(model, component, powerFlowResult);

  if (!explanation) return null;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-purple-600">💡</span>
        Explain-Why
      </h3>

      {/* Question */}
      <div className="bg-purple-50 rounded-lg p-3 border border-purple-200 mb-3">
        <div className="text-[10px] text-purple-700 uppercase font-bold mb-1">Question</div>
        <div className="text-sm font-medium text-slate-900">{explanation.question}</div>
      </div>

      {/* Answer */}
      <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 mb-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Answer</div>
        <div className="text-xs text-slate-700 leading-relaxed">{explanation.answer}</div>
      </div>

      {/* Evidence */}
      {explanation.evidence.length > 0 && (
        <div className="mb-3">
          <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Evidence</div>
          <div className="space-y-1">
            {explanation.evidence.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs bg-slate-50 rounded px-2 py-1.5">
                <span className="text-slate-600">{item.label}</span>
                <span className={`font-medium ${
                  item.severity === 'critical' ? 'text-red-600' :
                  item.severity === 'warning' ? 'text-amber-600' :
                  'text-slate-900'
                }`}>
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Contributors */}
      {explanation.contributors.length > 0 && (
        <div>
          <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Contributing Factors</div>
          <div className="space-y-1.5">
            {explanation.contributors.map((contributor, idx) => (
              <div key={idx} className="bg-slate-50 rounded p-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-900">{contributor.name}</span>
                  <span className="text-[10px] text-slate-500">{contributor.id}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-200 rounded-full h-1.5">
                    <div
                      className="bg-cyan-500 h-1.5 rounded-full"
                      style={{ width: `${contributor.percentage}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-600 w-12 text-right">
                    {contributor.percentage.toFixed(0)}%
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">{contributor.contribution}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function generateExplanation(
  model: ElectricalModel,
  component: any,
  powerFlowResult: PowerFlowResult
): Explanation | null {
  const network = model.getNetwork();

  // Transformer explanation
  if (component.type === 'transformer') {
    const txResult = powerFlowResult.transformer_results[component.id];
    if (!txResult) return null;

    const loading = txResult.loading_percent;
    const totalLoad = powerFlowResult.total_load_kw;
    const totalGeneration = powerFlowResult.total_generation_kw;

    // Find contributing loads
    const loads = Object.values(network.components)
      .filter(c => c.type === 'load')
      .map((load: any) => ({
        id: load.id,
        name: load.name,
        contribution: `${load.active_power_kw.toFixed(1)} kW`,
        percentage: (load.active_power_kw / totalLoad) * 100,
      }))
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 5);

    let answer = '';
    let severity: 'normal' | 'warning' | 'critical' = 'normal';

    if (loading > 90) {
      severity = 'critical';
      answer = `The transformer is critically overloaded at ${loading.toFixed(1)}%. This is primarily due to high total load (${totalLoad.toFixed(1)} kW) exceeding the transformer rating (${component.rating_kva} kVA). Immediate load reduction or transformer upgrade is recommended.`;
    } else if (loading > 75) {
      severity = 'warning';
      answer = `The transformer is heavily loaded at ${loading.toFixed(1)}%. While within operational limits, this leaves minimal margin for load growth. Consider monitoring closely or planning for capacity upgrade.`;
    } else if (loading > 50) {
      answer = `The transformer is moderately loaded at ${loading.toFixed(1)}%. This is within normal operating range with adequate margin for load variations.`;
    } else {
      answer = `The transformer is lightly loaded at ${loading.toFixed(1)}%. There is significant spare capacity available for additional loads.`;
    }

    return {
      question: `Why is ${component.id} at ${loading.toFixed(1)}% loading?`,
      answer,
      evidence: [
        { label: 'Transformer Rating', value: `${component.rating_kva} kVA` },
        { label: 'Current Loading', value: `${loading.toFixed(1)}%`, severity },
        { label: 'Total Load', value: `${totalLoad.toFixed(1)} kW` },
        { label: 'Total Generation', value: `${totalGeneration.toFixed(1)} kW` },
        { label: 'Temperature', value: `${txResult.temperature_c.toFixed(1)}°C`, severity: txResult.temperature_c > 70 ? 'warning' : 'normal' },
        { label: 'Efficiency', value: `${txResult.efficiency.toFixed(1)}%` },
      ],
      contributors: loads,
    };
  }

  // Load explanation
  if (component.type === 'load') {
    const totalLoad = powerFlowResult.total_load_kw;
    const totalGeneration = powerFlowResult.total_generation_kw;
    const gridImport = powerFlowResult.grid_result.import_kw;
    const batteryDischarge = powerFlowResult.power_balance.battery_discharge_kw;

    const loadPercentage = (component.active_power_kw / totalLoad) * 100;

    // Determine energy sources
    const contributors = [];
    if (totalGeneration > 0) {
      const solarContribution = Math.min(totalGeneration, component.active_power_kw);
      contributors.push({
        id: 'PV-SYSTEM',
        name: 'Solar PV',
        contribution: `${solarContribution.toFixed(1)} kW`,
        percentage: (solarContribution / component.active_power_kw) * 100,
      });
    }
    if (batteryDischarge > 0) {
      contributors.push({
        id: 'BESS-01',
        name: 'Battery',
        contribution: `${batteryDischarge.toFixed(1)} kW`,
        percentage: (batteryDischarge / component.active_power_kw) * 100,
      });
    }
    if (gridImport > 0) {
      contributors.push({
        id: 'GRID-01',
        name: 'Grid',
        contribution: `${gridImport.toFixed(1)} kW`,
        percentage: (gridImport / component.active_power_kw) * 100,
      });
    }

    return {
      question: `Where does the energy for ${component.id} come from?`,
      answer: `This load consumes ${component.active_power_kw.toFixed(1)} kW, representing ${loadPercentage.toFixed(1)}% of total system load. The energy is supplied by a combination of solar generation, battery discharge, and grid import based on current system conditions.`,
      evidence: [
        { label: 'Load Power', value: `${component.active_power_kw.toFixed(1)} kW` },
        { label: 'Load Share', value: `${loadPercentage.toFixed(1)}% of total` },
        { label: 'Power Factor', value: component.power_factor.toFixed(2) },
        { label: 'Load Type', value: component.load_type },
      ],
      contributors: contributors.sort((a, b) => b.percentage - a.percentage),
    };
  }

  // Bus explanation
  if (component.type === 'bus') {
    const busResult = powerFlowResult.bus_results[component.id];
    if (!busResult) return null;

    const voltageDeviation = Math.abs(busResult.voltage_pu - 1.0) * 100;

    let answer = '';
    let severity: 'normal' | 'warning' | 'critical' = 'normal';

    if (voltageDeviation > 5) {
      severity = 'critical';
      answer = `The bus voltage is significantly deviated at ${busResult.voltage_v.toFixed(1)} V (${voltageDeviation.toFixed(1)}% from nominal). This indicates potential power quality issues. Check upstream supply and load balance.`;
    } else if (voltageDeviation > 2.5) {
      severity = 'warning';
      answer = `The bus voltage shows moderate deviation at ${busResult.voltage_v.toFixed(1)} V (${voltageDeviation.toFixed(1)}% from nominal). Monitor closely and consider voltage regulation.`;
    } else {
      answer = `The bus voltage is within normal range at ${busResult.voltage_v.toFixed(1)} V (${voltageDeviation.toFixed(1)}% deviation). Voltage quality is acceptable.`;
    }

    return {
      question: `Why is ${component.id} voltage at ${busResult.voltage_v.toFixed(1)} V?`,
      answer,
      evidence: [
        { label: 'Nominal Voltage', value: `${component.voltage_kv * 1000} V` },
        { label: 'Actual Voltage', value: `${busResult.voltage_v.toFixed(1)} V`, severity },
        { label: 'Voltage (pu)', value: `${busResult.voltage_pu.toFixed(3)} pu` },
        { label: 'Deviation', value: `${voltageDeviation.toFixed(1)}%`, severity },
        { label: 'Angle', value: `${busResult.angle_deg.toFixed(1)}°` },
      ],
      contributors: [],
    };
  }

  return null;
}
