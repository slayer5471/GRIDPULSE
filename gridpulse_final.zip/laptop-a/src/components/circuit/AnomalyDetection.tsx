// Anomaly Detection - Detect unusual conditions based on real state
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { PowerFlowResult } from '../../types/circuit';

interface AnomalyDetectionProps {
  model: ElectricalModel;
  onAssetSelect: (id: string) => void;
}

interface Anomaly {
  id: string;
  severity: 'info' | 'warning' | 'critical';
  type: string;
  component_id: string;
  component_name: string;
  description: string;
  metric: string;
  value: string;
  threshold: string;
  evidence: string;
}

export default function AnomalyDetection({ model, onAssetSelect }: AnomalyDetectionProps) {
  const network = model.getNetwork();
  const powerFlowResult = model.runPowerFlow();
  
  const anomalies = detectAnomalies(model, powerFlowResult);

  const criticalCount = anomalies.filter(a => a.severity === 'critical').length;
  const warningCount = anomalies.filter(a => a.severity === 'warning').length;
  const infoCount = anomalies.filter(a => a.severity === 'info').length;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-amber-600">🔍</span>
        Anomaly Detection
      </h3>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="bg-red-50 rounded p-2 text-center border border-red-200">
          <div className="text-lg font-bold text-red-600">{criticalCount}</div>
          <div className="text-[10px] text-red-700">Critical</div>
        </div>
        <div className="bg-amber-50 rounded p-2 text-center border border-amber-200">
          <div className="text-lg font-bold text-amber-600">{warningCount}</div>
          <div className="text-[10px] text-amber-700">Warning</div>
        </div>
        <div className="bg-blue-50 rounded p-2 text-center border border-blue-200">
          <div className="text-lg font-bold text-blue-600">{infoCount}</div>
          <div className="text-[10px] text-blue-700">Info</div>
        </div>
      </div>

      {/* Anomalies List */}
      {anomalies.length === 0 ? (
        <div className="text-center py-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-2">
            <span className="text-xl">✓</span>
          </div>
          <p className="text-xs text-slate-600">No anomalies detected</p>
          <p className="text-[10px] text-slate-500 mt-1">System operating within normal parameters</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {anomalies.map(anomaly => (
            <div
              key={anomaly.id}
              onClick={() => onAssetSelect(anomaly.component_id)}
              className={`rounded-lg p-3 border cursor-pointer hover:shadow-sm transition-shadow ${
                anomaly.severity === 'critical' ? 'bg-red-50 border-red-200' :
                anomaly.severity === 'warning' ? 'bg-amber-50 border-amber-200' :
                'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex items-start justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                    anomaly.severity === 'critical' ? 'bg-red-200 text-red-800' :
                    anomaly.severity === 'warning' ? 'bg-amber-200 text-amber-800' :
                    'bg-blue-200 text-blue-800'
                  }`}>
                    {anomaly.severity}
                  </span>
                  <span className="text-[10px] text-slate-500">{anomaly.type}</span>
                </div>
                <span className="text-[10px] text-slate-500">{anomaly.component_id}</span>
              </div>
              <div className="text-xs font-medium text-slate-900 mb-1">{anomaly.description}</div>
              <div className="text-[10px] text-slate-600">
                <span className="font-medium">{anomaly.metric}:</span> {anomaly.value}
                <span className="mx-1">•</span>
                <span>Threshold: {anomaly.threshold}</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1 italic">{anomaly.evidence}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function detectAnomalies(model: ElectricalModel, powerFlowResult: PowerFlowResult): Anomaly[] {
  const anomalies: Anomaly[] = [];
  const network = model.getNetwork();

  // Check transformer loading
  Object.entries(powerFlowResult.transformer_results).forEach(([id, result]) => {
    const comp = network.components[id];
    if (!comp) return;

    if (result.loading_percent > 90) {
      anomalies.push({
        id: `anomaly-tx-overload-${id}`,
        severity: 'critical',
        type: 'Transformer Overload',
        component_id: id,
        component_name: comp.name,
        description: `Transformer ${id} is critically overloaded`,
        metric: 'Loading',
        value: `${result.loading_percent.toFixed(1)}%`,
        threshold: '> 90%',
        evidence: `Current load exceeds 90% of rated capacity (${comp && (comp as any).rating_kva} kVA). Risk of equipment damage.`,
      });
    } else if (result.loading_percent > 75) {
      anomalies.push({
        id: `anomaly-tx-high-${id}`,
        severity: 'warning',
        type: 'High Transformer Loading',
        component_id: id,
        component_name: comp.name,
        description: `Transformer ${id} is heavily loaded`,
        metric: 'Loading',
        value: `${result.loading_percent.toFixed(1)}%`,
        threshold: '> 75%',
        evidence: `Loading exceeds 75% with minimal margin for load growth.`,
      });
    }

    // Check transformer temperature
    if (result.temperature_c > 80) {
      anomalies.push({
        id: `anomaly-tx-temp-${id}`,
        severity: result.temperature_c > 100 ? 'critical' : 'warning',
        type: 'High Temperature',
        component_id: id,
        component_name: comp.name,
        description: `Transformer ${id} temperature is elevated`,
        metric: 'Temperature',
        value: `${result.temperature_c.toFixed(1)}°C`,
        threshold: '> 80°C',
        evidence: `Temperature exceeds safe operating limit. Check cooling and loading.`,
      });
    }
  });

  // Check bus voltages
  Object.entries(powerFlowResult.bus_results).forEach(([id, result]) => {
    const comp = network.components[id];
    if (!comp) return;

    const deviation = Math.abs(result.voltage_pu - 1.0) * 100;
    
    if (deviation > 5) {
      anomalies.push({
        id: `anomaly-voltage-${id}`,
        severity: 'critical',
        type: 'Voltage Deviation',
        component_id: id,
        component_name: comp.name,
        description: `Bus ${id} voltage is significantly deviated`,
        metric: 'Voltage',
        value: `${result.voltage_v.toFixed(1)} V (${result.voltage_pu.toFixed(3)} pu)`,
        threshold: '±5% of nominal',
        evidence: `Voltage deviation of ${deviation.toFixed(1)}% indicates power quality issues.`,
      });
    } else if (deviation > 2.5) {
      anomalies.push({
        id: `anomaly-voltage-warn-${id}`,
        severity: 'warning',
        type: 'Moderate Voltage Deviation',
        component_id: id,
        component_name: comp.name,
        description: `Bus ${id} voltage shows moderate deviation`,
        metric: 'Voltage',
        value: `${result.voltage_v.toFixed(1)} V (${result.voltage_pu.toFixed(3)} pu)`,
        threshold: '±2.5% of nominal',
        evidence: `Voltage deviation of ${deviation.toFixed(1)}% may affect sensitive equipment.`,
      });
    }
  });

  // Check line loading
  Object.entries(powerFlowResult.line_results).forEach(([id, result]) => {
    const comp = network.components[id];
    if (!comp) return;

    if (result.loading_percent > 90) {
      anomalies.push({
        id: `anomaly-line-overload-${id}`,
        severity: 'critical',
        type: 'Line Overload',
        component_id: id,
        component_name: comp.name,
        description: `Line ${id} is critically overloaded`,
        metric: 'Loading',
        value: `${result.loading_percent.toFixed(1)}%`,
        threshold: '> 90%',
        evidence: `Current exceeds 90% of thermal rating. Risk of conductor damage.`,
      });
    } else if (result.loading_percent > 75) {
      anomalies.push({
        id: `anomaly-line-high-${id}`,
        severity: 'warning',
        type: 'High Line Loading',
        component_id: id,
        component_name: comp.name,
        description: `Line ${id} is heavily loaded`,
        metric: 'Loading',
        value: `${result.loading_percent.toFixed(1)}%`,
        threshold: '> 75%',
        evidence: `Loading exceeds 75% of thermal rating.`,
      });
    }

    // Check for abnormal losses
    if (result.losses_kw > 5) {
      anomalies.push({
        id: `anomaly-line-loss-${id}`,
        severity: 'info',
        type: 'High Line Losses',
        component_id: id,
        component_name: comp.name,
        description: `Line ${id} has elevated losses`,
        metric: 'Losses',
        value: `${result.losses_kw.toFixed(2)} kW`,
        threshold: '> 5 kW',
        evidence: `Higher than expected losses may indicate aging conductors or poor connections.`,
      });
    }
  });

  // Check battery SOC
  Object.values(network.components).forEach(comp => {
    if (comp.type === 'bess') {
      const bess = comp as any;
      if (bess.soc_percent < 20) {
        anomalies.push({
          id: `anomaly-bess-low-${comp.id}`,
          severity: 'warning',
          type: 'Low Battery SOC',
          component_id: comp.id,
          component_name: comp.name,
          description: `Battery ${comp.id} SOC is low`,
          metric: 'SOC',
          value: `${bess.soc_percent.toFixed(1)}%`,
          threshold: '< 20%',
          evidence: `Low state of charge reduces available backup capacity.`,
        });
      } else if (bess.soc_percent > 95) {
        anomalies.push({
          id: `anomaly-bess-high-${comp.id}`,
          severity: 'info',
          type: 'High Battery SOC',
          component_id: comp.id,
          component_name: comp.name,
          description: `Battery ${comp.id} is nearly fully charged`,
          metric: 'SOC',
          value: `${bess.soc_percent.toFixed(1)}%`,
          threshold: '> 95%',
          evidence: `Battery approaching full charge. Charging will taper soon.`,
        });
      }
    }
  });

  // Check power balance
  const balance = powerFlowResult.power_balance;
  const balanceError = Math.abs(
    (balance.generation_kw + balance.grid_import_kw + balance.battery_discharge_kw) -
    (balance.load_kw + balance.battery_charge_kw + balance.grid_export_kw + balance.losses_kw)
  );

  if (balanceError > 1) {
    anomalies.push({
      id: 'anomaly-power-balance',
      severity: 'warning',
      type: 'Power Balance Error',
      component_id: 'SYSTEM',
      component_name: 'System',
      description: 'Power balance shows significant mismatch',
      metric: 'Balance Error',
      value: `${balanceError.toFixed(2)} kW`,
      threshold: '< 1 kW',
      evidence: `Supply and demand do not match. Check measurement accuracy.`,
    });
  }

  return anomalies.sort((a, b) => {
    const severityOrder = { critical: 0, warning: 1, info: 2 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });
}
