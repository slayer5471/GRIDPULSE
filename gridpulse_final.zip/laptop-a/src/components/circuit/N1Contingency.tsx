// N-1 Contingency Analysis - Test single component outages
import React, { useState } from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';

interface N1ContingencyProps {
  model: ElectricalModel;
  onClose: () => void;
}

interface ContingencyResult {
  component_id: string;
  component_name: string;
  component_type: string;
  status: 'safe' | 'warning' | 'critical' | 'violation';
  transformer_loading: number;
  min_voltage_pu: number;
  max_loading: number;
  unserved_load_kw: number;
  violations: string[];
}

export default function N1Contingency({ model, onClose }: N1ContingencyProps) {
  const [results, setResults] = useState<ContingencyResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedResult, setSelectedResult] = useState<ContingencyResult | null>(null);

  const network = model.getNetwork();
  const basePowerFlow = model.runPowerFlow();

  // Get critical components to test
  const criticalComponents = Object.values(network.components).filter(c =>
    c.type === 'line' || c.type === 'transformer' || c.type === 'breaker'
  );

  const runContingency = () => {
    setIsRunning(true);
    
    setTimeout(() => {
      const contingencyResults: ContingencyResult[] = criticalComponents.map(comp => {
        // Simulate outage by reducing capacity
        const isLine = comp.type === 'line';
        const isTransformer = comp.type === 'transformer';
        const isBreaker = comp.type === 'breaker';

        // Simplified contingency calculation
        let transformerLoading = basePowerFlow.transformer_results['TX-01']?.loading_percent || 0;
        let minVoltage = 1.0;
        let maxLoading = 0;
        let unservedLoad = 0;
        const violations: string[] = [];

        if (isLine) {
          // Line outage redistributes load to other feeders
          const line = comp as any;
          const redistributedLoad = line.rating_a * 0.415 * 1.732 / 1000; // Approx kW
          transformerLoading += redistributedLoad * 0.3; // 30% goes to transformer
          maxLoading = 80 + Math.random() * 20; // Simulated
          
          if (transformerLoading > 100) {
            violations.push('Transformer overload');
            unservedLoad = (transformerLoading - 100) * 5; // Approx
          }
          if (maxLoading > 100) {
            violations.push('Feeder overload');
          }
          minVoltage = 0.95 - (redistributedLoad * 0.001);
        } else if (isTransformer) {
          // Transformer outage = total loss
          unservedLoad = basePowerFlow.total_load_kw;
          violations.push('Total load loss');
          transformerLoading = 0;
          minVoltage = 0;
        } else if (isBreaker) {
          // Breaker trip isolates section
          const breaker = comp as any;
          if (breaker.id === 'CB-IN-01') {
            unservedLoad = basePowerFlow.total_load_kw;
            violations.push('Grid disconnection');
          } else {
            unservedLoad = basePowerFlow.total_load_kw * 0.33; // One feeder
            violations.push('Feeder disconnection');
          }
          minVoltage = 0.92;
        }

        let status: ContingencyResult['status'] = 'safe';
        if (violations.length > 0) status = 'violation';
        else if (transformerLoading > 90 || minVoltage < 0.93) status = 'critical';
        else if (transformerLoading > 75 || minVoltage < 0.95) status = 'warning';

        return {
          component_id: comp.id,
          component_name: comp.name,
          component_type: comp.type,
          status,
          transformer_loading: transformerLoading,
          min_voltage_pu: minVoltage,
          max_loading: maxLoading,
          unserved_load_kw: unservedLoad,
          violations,
        };
      });

      setResults(contingencyResults);
      setIsRunning(false);
    }, 500);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'safe': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'warning': return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'critical': return 'bg-red-50 text-red-700 border-red-200';
      case 'violation': return 'bg-red-100 text-red-800 border-red-300';
      default: return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const safeCount = results.filter(r => r.status === 'safe').length;
  const warningCount = results.filter(r => r.status === 'warning').length;
  const criticalCount = results.filter(r => r.status === 'critical' || r.status === 'violation').length;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[900px] max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-lg font-bold text-slate-900">N-1 Contingency Analysis</h2>
          <p className="text-xs text-slate-500 mt-1">
            Test single component outages and identify potential violations
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {/* Run Button */}
          {!results.length && (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🔍</span>
              </div>
              <p className="text-sm text-slate-600 mb-4">
                Analyze {criticalComponents.length} critical components for N-1 contingencies
              </p>
              <button
                onClick={runContingency}
                disabled={isRunning}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {isRunning ? 'Running Analysis...' : 'Run N-1 Contingency'}
              </button>
            </div>
          )}

          {/* Results Summary */}
          {results.length > 0 && (
            <>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200 text-center">
                  <div className="text-2xl font-bold text-emerald-600">{safeCount}</div>
                  <div className="text-xs text-emerald-700">Safe</div>
                </div>
                <div className="bg-amber-50 rounded-lg p-3 border border-amber-200 text-center">
                  <div className="text-2xl font-bold text-amber-600">{warningCount}</div>
                  <div className="text-xs text-amber-700">Warning</div>
                </div>
                <div className="bg-red-50 rounded-lg p-3 border border-red-200 text-center">
                  <div className="text-2xl font-bold text-red-600">{criticalCount}</div>
                  <div className="text-xs text-red-700">Critical/Violation</div>
                </div>
              </div>

              {/* Results Table */}
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left p-2 font-medium text-slate-600">Component</th>
                      <th className="text-center p-2 font-medium text-slate-600">Status</th>
                      <th className="text-right p-2 font-medium text-slate-600">TX Loading</th>
                      <th className="text-right p-2 font-medium text-slate-600">Min Voltage</th>
                      <th className="text-right p-2 font-medium text-slate-600">Unserved</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.map((result, idx) => (
                      <tr
                        key={idx}
                        onClick={() => setSelectedResult(result)}
                        className={`border-t border-slate-100 cursor-pointer hover:bg-slate-50 ${
                          selectedResult?.component_id === result.component_id ? 'bg-cyan-50' : ''
                        }`}
                      >
                        <td className="p-2">
                          <div className="font-medium text-slate-900">{result.component_name}</div>
                          <div className="text-[10px] text-slate-500">{result.component_id} • {result.component_type}</div>
                        </td>
                        <td className="p-2 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-medium border ${getStatusColor(result.status)}`}>
                            {result.status.toUpperCase()}
                          </span>
                        </td>
                        <td className={`p-2 text-right font-medium ${
                          result.transformer_loading > 90 ? 'text-red-600' :
                          result.transformer_loading > 75 ? 'text-amber-600' : 'text-slate-700'
                        }`}>
                          {result.transformer_loading.toFixed(1)}%
                        </td>
                        <td className={`p-2 text-right font-medium ${
                          result.min_voltage_pu < 0.93 ? 'text-red-600' :
                          result.min_voltage_pu < 0.95 ? 'text-amber-600' : 'text-slate-700'
                        }`}>
                          {result.min_voltage_pu.toFixed(3)} pu
                        </td>
                        <td className="p-2 text-right font-medium text-slate-700">
                          {result.unserved_load_kw.toFixed(1)} kW
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Selected Result Details */}
              {selectedResult && (
                <div className="mt-4 bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <h3 className="text-sm font-bold text-slate-900 mb-2">
                    {selectedResult.component_name} - Contingency Details
                  </h3>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <div className="text-slate-600">Component Type</div>
                      <div className="font-medium text-slate-900">{selectedResult.component_type}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Status</div>
                      <div className={`font-medium ${
                        selectedResult.status === 'safe' ? 'text-emerald-600' :
                        selectedResult.status === 'warning' ? 'text-amber-600' : 'text-red-600'
                      }`}>
                        {selectedResult.status.toUpperCase()}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-600">Transformer Loading</div>
                      <div className="font-medium text-slate-900">{selectedResult.transformer_loading.toFixed(1)}%</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Minimum Voltage</div>
                      <div className="font-medium text-slate-900">{selectedResult.min_voltage_pu.toFixed(3)} pu</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Unserved Load</div>
                      <div className="font-medium text-slate-900">{selectedResult.unserved_load_kw.toFixed(1)} kW</div>
                    </div>
                  </div>
                  {selectedResult.violations.length > 0 && (
                    <div className="mt-3">
                      <div className="text-[10px] text-red-700 uppercase font-bold mb-1">Violations</div>
                      <ul className="list-disc list-inside text-xs text-red-600">
                        {selectedResult.violations.map((v, i) => (
                          <li key={i}>{v}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <div className="p-4 border-t border-slate-200 flex gap-2">
          {results.length > 0 && (
            <button
              onClick={() => { setResults([]); setSelectedResult(null); }}
              className="px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded hover:bg-slate-200"
            >
              Run Again
            </button>
          )}
          <button onClick={onClose} className="flex-1 px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded hover:bg-slate-200">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
