// Component Symbols - SVG representations
import React from 'react';

interface SymbolProps {
  component: any;
  telemetry?: any;
  showMeasurements: boolean;
}

export const ComponentSymbols: Record<string, React.FC<SymbolProps>> = {
  grid_source: ({ component, telemetry, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="20" fill="#dbeafe" stroke="#2563eb" strokeWidth="2" />
      <path d="M -8,-8 L 8,8 M 8,-8 L -8,8" stroke="#2563eb" strokeWidth="2" />
      {showMeasurements && telemetry && (
        <text x="0" y="-25" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="600">
          {component.voltage_kv} kV
        </text>
      )}
    </g>
  ),
  bus: ({ component, telemetry, showMeasurements }) => (
    <g>
      <rect x="-30" y="-3" width="60" height="6" fill="#3b82f6" stroke="#1e40af" strokeWidth="1" />
      {showMeasurements && telemetry && (
        <text x="0" y="-10" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="600">
          {telemetry.voltage_v?.toFixed(1)} V
        </text>
      )}
    </g>
  ),
  transformer: ({ component, telemetry, showMeasurements }) => (
    <g>
      <circle cx="0" cy="-10" r="12" fill="none" stroke="#d97706" strokeWidth="2" />
      <circle cx="0" cy="10" r="12" fill="none" stroke="#d97706" strokeWidth="2" />
      {showMeasurements && telemetry && (
        <text x="20" y="0" textAnchor="start" fontSize="9" fill="#92400e" fontWeight="600">
          {telemetry.loading_percent?.toFixed(0)}%
        </text>
      )}
    </g>
  ),
  breaker: ({ component }) => {
    const isOpen = component.state === 'open';
    return (
      <g>
        <rect x="-8" y="-15" width="16" height="30" fill={isOpen ? '#fee2e2' : '#dcfce7'} stroke={isOpen ? '#dc2626' : '#16a34a'} strokeWidth="2" rx="2" />
        <line x1="0" y1="-15" x2="0" y2={isOpen ? "-5" : "15"} stroke={isOpen ? '#dc2626' : '#16a34a'} strokeWidth="2" />
        <text x="0" y="25" textAnchor="middle" fontSize="8" fill={isOpen ? '#dc2626' : '#16a34a'} fontWeight="600">
          {isOpen ? 'OPEN' : 'CLOSED'}
        </text>
      </g>
    );
  },
  switch: ({ component }) => {
    const isOpen = component.state === 'open';
    return (
      <g>
        <line x1="0" y1="-15" x2="0" y2="-5" stroke="#64748b" strokeWidth="2" />
        <line x1="0" y1="-5" x2={isOpen ? "10" : "0"} y2={isOpen ? "-15" : "15"} stroke="#64748b" strokeWidth="2" />
        <line x1="0" y1="15" x2="0" y2="5" stroke="#64748b" strokeWidth="2" />
      </g>
    );
  },
  line: ({ component, telemetry, showMeasurements }) => (
    <g>
      <line x1="0" y1="-20" x2="0" y2="20" stroke="#475569" strokeWidth="3" />
      {showMeasurements && telemetry && (
        <text x="10" y="0" textAnchor="start" fontSize="9" fill="#334155" fontWeight="600">
          {telemetry.current_a?.toFixed(1)} A
        </text>
      )}
    </g>
  ),
  load: ({ component, telemetry, showMeasurements }) => (
    <g>
      <polygon points="0,-15 15,10 -15,10" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
      {showMeasurements && (
        <text x="0" y="25" textAnchor="middle" fontSize="9" fill="#92400e" fontWeight="600">
          {component.active_power_kw?.toFixed(1)} kW
        </text>
      )}
    </g>
  ),
  pv_array: ({ component, showMeasurements }) => (
    <g>
      <rect x="-15" y="-15" width="30" height="30" fill="#fef9c3" stroke="#eab308" strokeWidth="2" rx="2" />
      <line x1="-10" y1="-10" x2="10" y2="10" stroke="#eab308" strokeWidth="1" />
      <line x1="10" y1="-10" x2="-10" y2="10" stroke="#eab308" strokeWidth="1" />
      {showMeasurements && (
        <text x="0" y="25" textAnchor="middle" fontSize="9" fill="#854d0e" fontWeight="600">
          {component.capacity_kw?.toFixed(0)} kW
        </text>
      )}
    </g>
  ),
  bess: ({ component }) => (
    <g>
      <rect x="-15" y="-20" width="30" height="40" fill="#f3e8ff" stroke="#9333ea" strokeWidth="2" rx="2" />
      <rect x="-10" y="-15" width="20" height={30 * (component.soc_percent / 100)} fill="#9333ea" opacity="0.3" />
      <text x="0" y="5" textAnchor="middle" fontSize="10" fill="#6b21a8" fontWeight="700">
        {component.soc_percent?.toFixed(0)}%
      </text>
    </g>
  ),
  pcs: ({ component }) => (
    <g>
      <rect x="-15" y="-15" width="30" height="30" fill="#fce7f3" stroke="#db2777" strokeWidth="2" rx="2" />
      <text x="0" y="5" textAnchor="middle" fontSize="10" fill="#9d174d" fontWeight="700">PCS</text>
    </g>
  ),
  generator: ({ component, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="18" fill="#dcfce7" stroke="#16a34a" strokeWidth="2" />
      <text x="0" y="5" textAnchor="middle" fontSize="12" fill="#166534" fontWeight="700">G</text>
      {showMeasurements && (
        <text x="0" y="28" textAnchor="middle" fontSize="9" fill="#166534" fontWeight="600">
          {component.capacity_kw?.toFixed(0)} kW
        </text>
      )}
    </g>
  ),
  cable: ({ component, telemetry, showMeasurements }) => (
    <g>
      <line x1="0" y1="-20" x2="0" y2="20" stroke="#7c3aed" strokeWidth="4" />
      <line x1="-3" y1="-20" x2="-3" y2="20" stroke="#7c3aed" strokeWidth="1" />
      <line x1="3" y1="-20" x2="3" y2="20" stroke="#7c3aed" strokeWidth="1" />
      {showMeasurements && telemetry && (
        <text x="12" y="0" textAnchor="start" fontSize="9" fill="#5b21b6" fontWeight="600">
          {telemetry.current_a?.toFixed(1)} A
        </text>
      )}
    </g>
  ),
  feeder: ({ component, telemetry, showMeasurements }) => (
    <g>
      <rect x="-8" y="-20" width="16" height="40" fill="#e0e7ff" stroke="#4f46e5" strokeWidth="2" rx="2" />
      <line x1="-4" y1="-15" x2="-4" y2="15" stroke="#4f46e5" strokeWidth="1" />
      <line x1="4" y1="-15" x2="4" y2="15" stroke="#4f46e5" strokeWidth="1" />
      {showMeasurements && telemetry && (
        <text x="15" y="0" textAnchor="start" fontSize="9" fill="#3730a3" fontWeight="600">
          {telemetry.loading_percent?.toFixed(0)}%
        </text>
      )}
    </g>
  ),
  junction: ({ component }) => (
    <g>
      <circle cx="0" cy="0" r="8" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
      <circle cx="0" cy="0" r="3" fill="#d97706" />
    </g>
  ),
  disconnector: ({ component }) => {
    const isOpen = component.state === 'open';
    return (
      <g>
        <line x1="0" y1="-15" x2="0" y2="-8" stroke="#64748b" strokeWidth="2" />
        <line x1="0" y1="15" x2="0" y2="8" stroke="#64748b" strokeWidth="2" />
        <line x1="-6" y1="-8" x2="6" y2="-8" stroke="#64748b" strokeWidth="2" />
        <line x1="0" y1="-8" x2={isOpen ? "8" : "0"} y2={isOpen ? "-15" : "8"} stroke={isOpen ? '#dc2626' : '#16a34a'} strokeWidth="2" />
        <text x="0" y="25" textAnchor="middle" fontSize="8" fill={isOpen ? '#dc2626' : '#16a34a'} fontWeight="600">
          {isOpen ? 'OPEN' : 'CLOSED'}
        </text>
      </g>
    );
  },
  protection_relay: ({ component }) => (
    <g>
      <rect x="-12" y="-12" width="24" height="24" fill="#fee2e2" stroke="#dc2626" strokeWidth="2" rx="2" />
      <text x="0" y="0" textAnchor="middle" fontSize="8" fill="#991b1b" fontWeight="700">RELAY</text>
      <text x="0" y="8" textAnchor="middle" fontSize="6" fill="#991b1b">
        {component.relay_type?.substring(0, 3).toUpperCase()}
      </text>
    </g>
  ),
  ct: ({ component, telemetry, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="12" fill="#dbeafe" stroke="#2563eb" strokeWidth="2" />
      <text x="0" y="4" textAnchor="middle" fontSize="10" fill="#1e40af" fontWeight="700">CT</text>
      {showMeasurements && telemetry && (
        <text x="0" y="22" textAnchor="middle" fontSize="8" fill="#1e40af" fontWeight="600">
          {telemetry.current_a?.toFixed(1)} A
        </text>
      )}
    </g>
  ),
  pt: ({ component, telemetry, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="12" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
      <text x="0" y="4" textAnchor="middle" fontSize="10" fill="#92400e" fontWeight="700">PT</text>
      {showMeasurements && telemetry && (
        <text x="0" y="22" textAnchor="middle" fontSize="8" fill="#92400e" fontWeight="600">
          {telemetry.voltage_v?.toFixed(1)} V
        </text>
      )}
    </g>
  ),
  meter: ({ component, telemetry, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="14" fill="#f0fdf4" stroke="#16a34a" strokeWidth="2" />
      <text x="0" y="4" textAnchor="middle" fontSize="10" fill="#166534" fontWeight="700">M</text>
      {showMeasurements && telemetry && (
        <text x="0" y="24" textAnchor="middle" fontSize="8" fill="#166534" fontWeight="600">
          {telemetry.active_power_kw?.toFixed(1)} kW
        </text>
      )}
    </g>
  ),
  measurement_point: ({ component }) => (
    <g>
      <circle cx="0" cy="0" r="10" fill="#ecfdf5" stroke="#10b981" strokeWidth="2" />
      <circle cx="0" cy="0" r="4" fill="#10b981" />
    </g>
  ),
  motor_load: ({ component, showMeasurements }) => (
    <g>
      <circle cx="0" cy="0" r="16" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
      <text x="0" y="5" textAnchor="middle" fontSize="12" fill="#92400e" fontWeight="700">M</text>
      {showMeasurements && (
        <text x="0" y="26" textAnchor="middle" fontSize="9" fill="#92400e" fontWeight="600">
          {component.active_power_kw?.toFixed(1)} kW
        </text>
      )}
    </g>
  ),
  community_load: ({ component, showMeasurements }) => (
    <g>
      <rect x="-18" y="-14" width="36" height="28" fill="#fef3c7" stroke="#d97706" strokeWidth="2" rx="3" />
      <text x="0" y="0" textAnchor="middle" fontSize="8" fill="#92400e" fontWeight="700">COMM</text>
      <text x="0" y="8" textAnchor="middle" fontSize="8" fill="#92400e" fontWeight="700">UNITY</text>
      {showMeasurements && (
        <text x="0" y="24" textAnchor="middle" fontSize="9" fill="#92400e" fontWeight="600">
          {component.active_power_kw?.toFixed(1)} kW
        </text>
      )}
    </g>
  ),
  ev_charger: ({ component, showMeasurements }) => (
    <g>
      <rect x="-14" y="-18" width="28" height="36" fill="#dbeafe" stroke="#2563eb" strokeWidth="2" rx="3" />
      <text x="0" y="-2" textAnchor="middle" fontSize="10" fill="#1e40af" fontWeight="700">EV</text>
      <text x="0" y="8" textAnchor="middle" fontSize="8" fill="#1e40af" fontWeight="700">⚡</text>
      {showMeasurements && (
        <text x="0" y="28" textAnchor="middle" fontSize="9" fill="#1e40af" fontWeight="600">
          {component.rating_kw?.toFixed(0)} kW
        </text>
      )}
    </g>
  ),
  capacitor_bank: ({ component, showMeasurements }) => (
    <g>
      <rect x="-12" y="-16" width="24" height="32" fill="#f3e8ff" stroke="#9333ea" strokeWidth="2" rx="2" />
      <line x1="-8" y1="-6" x2="8" y2="-6" stroke="#9333ea" strokeWidth="2" />
      <line x1="-8" y1="6" x2="8" y2="6" stroke="#9333ea" strokeWidth="2" />
      {showMeasurements && (
        <text x="0" y="26" textAnchor="middle" fontSize="9" fill="#6b21a8" fontWeight="600">
          {component.capacity_kvar?.toFixed(0)} kVAr
        </text>
      )}
    </g>
  ),
  ground: ({ component }) => (
    <g>
      <line x1="0" y1="-10" x2="0" y2="0" stroke="#64748b" strokeWidth="2" />
      <line x1="-10" y1="0" x2="10" y2="0" stroke="#64748b" strokeWidth="2" />
      <line x1="-7" y1="5" x2="7" y2="5" stroke="#64748b" strokeWidth="2" />
      <line x1="-4" y1="10" x2="4" y2="10" stroke="#64748b" strokeWidth="2" />
    </g>
  ),
  default: ({ component }) => (
    <g>
      <circle cx="0" cy="0" r="15" fill="#e0f2fe" stroke="#0284c7" strokeWidth="2" />
      <text x="0" y="5" textAnchor="middle" fontSize="10" fill="#0c4a6e" fontWeight="700">?</text>
    </g>
  ),
};
