// Asset Relationships Panel - Shows upstream/downstream/connected assets
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { CircuitComponent } from '../../types/circuit';

interface AssetRelationshipsProps {
  model: ElectricalModel;
  componentId: string;
  onAssetSelect: (id: string) => void;
}

export default function AssetRelationships({ model, componentId, onAssetSelect }: AssetRelationshipsProps) {
  const network = model.getNetwork();
  const component = network.components[componentId];
  
  if (!component) return null;

  // Find connected assets
  const connections = network.connections.filter(
    conn => conn.from_component === componentId || conn.to_component === componentId
  );

  const upstreamIds = connections
    .filter(conn => conn.to_component === componentId)
    .map(conn => conn.from_component);
  
  const downstreamIds = connections
    .filter(conn => conn.from_component === componentId)
    .map(conn => conn.to_component);

  const upstream = upstreamIds.map(id => network.components[id]).filter(Boolean);
  const downstream = downstreamIds.map(id => network.components[id]).filter(Boolean);

  // Find parent (first upstream)
  const parent = upstream.length > 0 ? upstream[0] : null;
  
  // Find children (all downstream)
  const children = downstream;

  // Get type icon
  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      grid_source: '⚡',
      bus: '━',
      transformer: '⚙️',
      breaker: '⊗',
      switch: '⊘',
      line: '│',
      load: '△',
      pv_array: '☀️',
      bess: '🔋',
      pcs: '⊞',
      ev_charger: '🚗',
    };
    return icons[type] || '●';
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'offline': return 'text-slate-600 bg-slate-50 border-slate-200';
      case 'warning': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'fault': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-blue-600">🔗</span>
        Asset Relationships
      </h3>

      {/* Current Asset */}
      <div className="bg-cyan-50 rounded-lg p-3 border border-cyan-200 mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg">{getTypeIcon(component.type)}</span>
          <div className="flex-1">
            <div className="text-xs font-bold text-slate-900">{component.name}</div>
            <div className="text-[10px] text-slate-500">{component.id} • {component.type}</div>
          </div>
          <span className={`text-[10px] px-2 py-0.5 rounded border ${getStatusColor(component.status)}`}>
            {component.status}
          </span>
        </div>
      </div>

      {/* Parent */}
      {parent && (
        <div className="mb-3">
          <div className="text-[10px] text-slate-500 uppercase font-bold mb-1.5">↑ Upstream (Parent)</div>
          <button
            onClick={() => onAssetSelect(parent.id)}
            className="w-full bg-slate-50 hover:bg-slate-100 rounded p-2 border border-slate-200 transition-colors text-left"
          >
            <div className="flex items-center gap-2">
              <span>{getTypeIcon(parent.type)}</span>
              <div className="flex-1">
                <div className="text-xs font-medium text-slate-900">{parent.name}</div>
                <div className="text-[10px] text-slate-500">{parent.id}</div>
              </div>
            </div>
          </button>
        </div>
      )}

      {/* Children */}
      {children.length > 0 && (
        <div className="mb-3">
          <div className="text-[10px] text-slate-500 uppercase font-bold mb-1.5">↓ Downstream (Children)</div>
          <div className="space-y-1">
            {children.map(child => (
              <button
                key={child.id}
                onClick={() => onAssetSelect(child.id)}
                className="w-full bg-slate-50 hover:bg-slate-100 rounded p-2 border border-slate-200 transition-colors text-left"
              >
                <div className="flex items-center gap-2">
                  <span>{getTypeIcon(child.type)}</span>
                  <div className="flex-1">
                    <div className="text-xs font-medium text-slate-900">{child.name}</div>
                    <div className="text-[10px] text-slate-500">{child.id} • {child.type}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Connected Assets Summary */}
      <div className="border-t border-slate-200 pt-3 mt-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Connections</div>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-50 rounded p-2 text-center">
            <div className="text-lg font-bold text-slate-900">{connections.length}</div>
            <div className="text-[10px] text-slate-500">Total</div>
          </div>
          <div className="bg-emerald-50 rounded p-2 text-center">
            <div className="text-lg font-bold text-emerald-600">{upstream.length}</div>
            <div className="text-[10px] text-slate-500">Upstream</div>
          </div>
          <div className="bg-blue-50 rounded p-2 text-center">
            <div className="text-lg font-bold text-blue-600">{downstream.length}</div>
            <div className="text-[10px] text-slate-500">Downstream</div>
          </div>
        </div>
      </div>

      {/* Electrical Path */}
      <div className="border-t border-slate-200 pt-3 mt-3">
        <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Electrical Path</div>
        <div className="text-xs text-slate-600 bg-slate-50 rounded p-2 font-mono">
          {parent ? `${parent.id} → ` : ''}
          <span className="font-bold text-cyan-700">{component.id}</span>
          {children.length > 0 && ` → ${children.map(c => c.id).join(', ')}`}
        </div>
      </div>
    </div>
  );
}
