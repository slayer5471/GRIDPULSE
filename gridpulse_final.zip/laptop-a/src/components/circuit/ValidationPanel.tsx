// Validation Panel - Network validation display
import React from 'react';
import { ValidationResult } from '../../types/circuit';

interface ValidationPanelProps {
  validation: ValidationResult;
  onClose: () => void;
  onLocate: (componentId: string) => void;
}

export default function ValidationPanel({ validation, onClose, onLocate }: ValidationPanelProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[600px] max-h-[600px] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-lg font-bold text-slate-900">Network Validation</h2>
          <p className="text-xs text-slate-500 mt-1">
            {validation.valid ? '✓ Network is valid' : `✗ ${validation.errors.length} errors, ${validation.warnings.length} warnings`}
          </p>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {validation.errors.length > 0 && (
            <div className="mb-4">
              <h3 className="text-sm font-bold text-red-700 mb-2">Errors ({validation.errors.length})</h3>
              <div className="space-y-2">
                {validation.errors.map((error, idx) => (
                  <div key={idx} className="p-3 bg-red-50 border border-red-200 rounded">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-xs font-bold text-red-900">{error.code}</div>
                        <div className="text-xs text-red-700 mt-1">{error.message}</div>
                        {error.component_id && (
                          <div className="text-[10px] text-red-600 mt-1">Component: {error.component_id}</div>
                        )}
                      </div>
                      {error.component_id && (
                        <button
                          onClick={() => onLocate(error.component_id!)}
                          className="px-2 py-1 text-[10px] bg-red-600 text-white rounded hover:bg-red-700"
                        >
                          Locate
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {validation.warnings.length > 0 && (
            <div>
              <h3 className="text-sm font-bold text-amber-700 mb-2">Warnings ({validation.warnings.length})</h3>
              <div className="space-y-2">
                {validation.warnings.map((warning, idx) => (
                  <div key={idx} className="p-3 bg-amber-50 border border-amber-200 rounded">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-xs font-bold text-amber-900">{warning.code}</div>
                        <div className="text-xs text-amber-700 mt-1">{warning.message}</div>
                        {warning.component_id && (
                          <div className="text-[10px] text-amber-600 mt-1">Component: {warning.component_id}</div>
                        )}
                      </div>
                      {warning.component_id && (
                        <button
                          onClick={() => onLocate(warning.component_id!)}
                          className="px-2 py-1 text-[10px] bg-amber-600 text-white rounded hover:bg-amber-700"
                        >
                          Locate
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {validation.valid && validation.warnings.length === 0 && (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-3">
                <span className="text-3xl">✓</span>
              </div>
              <p className="text-sm text-slate-600">Network validation passed</p>
              <p className="text-xs text-slate-500 mt-1">No errors or warnings found</p>
            </div>
          )}
        </div>
        <div className="p-4 border-t border-slate-200">
          <button onClick={onClose} className="w-full px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded hover:bg-slate-200">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
