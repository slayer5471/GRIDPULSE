// Power Balance Panel - Real-time power balance visualization
import React from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { PowerBalance } from '../../types/circuit';

interface PowerBalancePanelProps {
  model: ElectricalModel;
}

export default function PowerBalancePanel({ model }: PowerBalancePanelProps) {
  const powerFlowResult = model.runPowerFlow();
  const balance = powerFlowResult.power_balance;

  const totalSupply = balance.generation_kw + balance.grid_import_kw + balance.battery_discharge_kw;
  const totalDemand = balance.load_kw + balance.battery_charge_kw + balance.grid_export_kw + balance.losses_kw;
  const balanceError = Math.abs(totalSupply - totalDemand);

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
        <span className="text-cyan-600">⚡</span>
        Power Balance
      </h3>

      <div className="grid grid-cols-2 gap-4 mb-4">
        {/* Supply Side */}
        <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
          <div className="text-[10px] text-emerald-700 uppercase font-bold mb-2">Supply</div>
          <div className="space-y-1.5">
            <BalanceRow
              label="Generation"
              value={balance.generation_kw}
              color="emerald"
            />
            <BalanceRow
              label="Grid Import"
              value={balance.grid_import_kw}
              color="amber"
            />
            <BalanceRow
              label="Battery Discharge"
              value={balance.battery_discharge_kw}
              color="purple"
            />
            <div className="border-t border-emerald-200 pt-1.5 mt-1.5">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-emerald-900">Total Supply</span>
                <span className="text-emerald-900">{totalSupply.toFixed(1)} kW</span>
              </div>
            </div>
          </div>
        </div>

        {/* Demand Side */}
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <div className="text-[10px] text-blue-700 uppercase font-bold mb-2">Demand</div>
          <div className="space-y-1.5">
            <BalanceRow
              label="Load"
              value={balance.load_kw}
              color="blue"
            />
            <BalanceRow
              label="Battery Charge"
              value={balance.battery_charge_kw}
              color="purple"
            />
            <BalanceRow
              label="Grid Export"
              value={balance.grid_export_kw}
              color="cyan"
            />
            <BalanceRow
              label="Losses"
              value={balance.losses_kw}
              color="red"
            />
            <div className="border-t border-blue-200 pt-1.5 mt-1.5">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-blue-900">Total Demand</span>
                <span className="text-blue-900">{totalDemand.toFixed(1)} kW</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Balance Status */}
      <div className={`rounded-lg p-3 border ${
        balanceError < 0.1 
          ? 'bg-emerald-50 border-emerald-200' 
          : 'bg-amber-50 border-amber-200'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`text-lg ${balanceError < 0.1 ? 'text-emerald-600' : 'text-amber-600'}`}>
              {balanceError < 0.1 ? '✓' : '⚠'}
            </span>
            <div>
              <div className="text-xs font-bold text-slate-900">
                {balanceError < 0.1 ? 'Balanced' : 'Imbalance Detected'}
              </div>
              <div className="text-[10px] text-slate-600">
                Difference: {balanceError.toFixed(2)} kW
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-500">Efficiency</div>
            <div className="text-sm font-bold text-slate-900">
              {totalDemand > 0 ? ((1 - balance.losses_kw / totalSupply) * 100).toFixed(1) : '0.0'}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BalanceRow({ label, value, color }: { label: string; value: number; color: string }) {
  const colorClasses: Record<string, string> = {
    emerald: 'text-emerald-700',
    amber: 'text-amber-700',
    purple: 'text-purple-700',
    blue: 'text-blue-700',
    cyan: 'text-cyan-700',
    red: 'text-red-700',
  };

  return (
    <div className="flex justify-between text-xs">
      <span className="text-slate-600">{label}</span>
      <span className={`font-medium ${colorClasses[color]}`}>
        {value > 0 ? '+' : ''}{value.toFixed(1)} kW
      </span>
    </div>
  );
}
