// What-If Lab - Clone network and test modifications
import React, { useState } from 'react';
import { ElectricalModel } from '../../engine/ElectricalModel';
import { CircuitNetwork } from '../../types/circuit';

interface WhatIfLabProps {
  model: ElectricalModel;
  onClose: () => void;
}

interface WhatIfModification {
  id: string;
  type: 'add_load' | 'add_pv' | 'add_bess' | 'modify_transformer' | 'modify_export_limit';
  description: string;
  target_id?: string;
  parameter?: string;
  value: number;
}

export default function WhatIfLab({ model, onClose }: WhatIfLabProps) {
  const [modifications, setModifications] = useState<WhatIfModification[]>([]);
  const [results, setResults] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);

  const currentNetwork = model.getNetwork();
  const currentPowerFlow = model.runPowerFlow();

  const addModification = (type: WhatIfModification['type']) => {
    const newMod: WhatIfModification = {
      id: `mod-${Date.now()}`,
      type,
      description: getModificationDescription(type),
      value: getDefaultValue(type),
    };
    setModifications([...modifications, newMod]);
  };

  const removeModification = (id: string) => {
    setModifications(modifications.filter(m => m.id !== id));
  };

  const updateModification = (id: string, value: number) => {
    setModifications(modifications.map(m => m.id === id ? { ...m, value } : m));
  };

  const runWhatIf = () => {
    setIsRunning(true);
    
    // Clone network
    const clonedNetwork: CircuitNetwork = JSON.parse(JSON.stringify(currentNetwork));
    
    // Apply modifications
    modifications.forEach(mod => {
      switch (mod.type) {
        case 'add_load':
          const loadId = `LOAD-WHATIF-${Date.now()}`;
          clonedNetwork.components[loadId] = {
            id: loadId,
            type: 'load',
            name: 'What-If Load',
            position: { x: 500, y: 500 },
            rotation: 0,
            status: 'online',
            voltage_level: 'lv',
            active_power_kw: mod.value,
            reactive_power_kvar: mod.value * 0.3,
            power_factor: 0.95,
            load_type: 'residential',
            profile: 'residential',
            priority: 1,
            is_controllable: false,
            terminals: [],
          };
          break;
        
        case 'add_pv':
          const pvId = `PV-WHATIF-${Date.now()}`;
          clonedNetwork.components[pvId] = {
            id: pvId,
            type: 'pv_array',
            name: 'What-If PV',
            position: { x: 600, y: 500 },
            rotation: 0,
            status: 'online',
            voltage_level: 'lv',
            capacity_kw: mod.value,
            efficiency: 0.95,
            irradiance_w_m2: 800,
            temperature_c: 25,
            temperature_coefficient: -0.004,
            operating_state: 'online',
            curtailment_percent: 0,
            terminals: [],
          };
          break;
        
        case 'add_bess':
          const bessId = `BESS-WHATIF-${Date.now()}`;
          clonedNetwork.components[bessId] = {
            id: bessId,
            type: 'bess',
            name: 'What-If BESS',
            position: { x: 700, y: 500 },
            rotation: 0,
            status: 'online',
            voltage_level: 'lv',
            capacity_kwh: mod.value,
            soc_percent: 50,
            max_charge_kw: mod.value / 4,
            max_discharge_kw: mod.value / 4,
            efficiency: 0.95,
            mode: 'auto',
            min_soc_percent: 20,
            max_soc_percent: 95,
            cycle_count: 0,
            health_percent: 100,
            terminals: [],
          };
          break;
        
        case 'modify_transformer':
          if (clonedNetwork.components['TX-01']) {
            (clonedNetwork.components['TX-01'] as any).rating_kva = mod.value;
          }
          break;
      }
    });

    // Simulate power flow on cloned network (simplified)
    setTimeout(() => {
      const totalLoad = Object.values(clonedNetwork.components)
        .filter(c => c.type === 'load')
        .reduce((sum, c) => sum + (c as any).active_power_kw, 0);
      
      const totalGeneration = Object.values(clonedNetwork.components)
        .filter(c => c.type === 'pv_array')
        .reduce((sum, c) => sum + (c as any).capacity_kw * 0.8, 0);

      const surplus = totalGeneration - totalLoad;
      const gridImport = Math.max(0, -surplus);
      const gridExport = Math.max(0, surplus);

      const transformerLoading = (totalLoad / (clonedNetwork.components['TX-01'] as any).rating_kva) * 100;

      setResults({
        totalLoad,
        totalGeneration,
        gridImport,
        gridExport,
        transformerLoading,
        surplus,
      });
      setIsRunning(false);
    }, 500);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-[800px] max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-lg font-bold text-slate-900">What-If Lab</h2>
          <p className="text-xs text-slate-500 mt-1">Clone the network and test modifications without affecting the live system</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {/* Current State */}
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 mb-4">
            <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">Current State</div>
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div>
                <div className="text-slate-600">Total Load</div>
                <div className="font-bold text-slate-900">{currentPowerFlow.total_load_kw.toFixed(1)} kW</div>
              </div>
              <div>
                <div className="text-slate-600">Total Generation</div>
                <div className="font-bold text-emerald-600">{currentPowerFlow.total_generation_kw.toFixed(1)} kW</div>
              </div>
              <div>
                <div className="text-slate-600">TX Loading</div>
                <div className="font-bold text-slate-900">
                  {currentPowerFlow.transformer_results['TX-01']?.loading_percent.toFixed(1) || '0'}%
                </div>
              </div>
            </div>
          </div>

          {/* Add Modifications */}
          <div className="mb-4">
            <div className="text-xs font-bold text-slate-700 mb-2">Add Modifications</div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => addModification('add_load')}
                className="px-3 py-2 text-xs bg-blue-50 text-blue-700 rounded border border-blue-200 hover:bg-blue-100"
              >
                + Add Load (kW)
              </button>
              <button
                onClick={() => addModification('add_pv')}
                className="px-3 py-2 text-xs bg-amber-50 text-amber-700 rounded border border-amber-200 hover:bg-amber-100"
              >
                + Add PV (kW)
              </button>
              <button
                onClick={() => addModification('add_bess')}
                className="px-3 py-2 text-xs bg-purple-50 text-purple-700 rounded border border-purple-200 hover:bg-purple-100"
              >
                + Add BESS (kWh)
              </button>
              <button
                onClick={() => addModification('modify_transformer')}
                className="px-3 py-2 text-xs bg-cyan-50 text-cyan-700 rounded border border-cyan-200 hover:bg-cyan-100"
              >
                Modify TX Rating (kVA)
              </button>
            </div>
          </div>

          {/* Modifications List */}
          {modifications.length > 0 && (
            <div className="mb-4">
              <div className="text-xs font-bold text-slate-700 mb-2">Modifications</div>
              <div className="space-y-2">
                {modifications.map(mod => (
                  <div key={mod.id} className="bg-slate-50 rounded p-3 border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-slate-900">{mod.description}</span>
                      <button
                        onClick={() => removeModification(mod.id)}
                        className="text-red-500 hover:text-red-700 text-xs"
                      >
                        Remove
                      </button>
                    </div>
                    <input
                      type="number"
                      value={mod.value}
                      onChange={(e) => updateModification(mod.id, parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 text-xs border border-slate-200 rounded"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Run Button */}
          <button
            onClick={runWhatIf}
            disabled={modifications.length === 0 || isRunning}
            className="w-full px-4 py-2 text-sm bg-cyan-600 text-white rounded hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed mb-4"
          >
            {isRunning ? 'Running...' : 'Run What-If Analysis'}
          </button>

          {/* Results */}
          {results && (
            <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
              <div className="text-xs font-bold text-emerald-900 mb-3">What-If Results</div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="text-slate-600">New Total Load</div>
                  <div className="font-bold text-slate-900">{results.totalLoad.toFixed(1)} kW</div>
                  <div className="text-[10px] text-slate-500">
                    Δ {(results.totalLoad - currentPowerFlow.total_load_kw).toFixed(1)} kW
                  </div>
                </div>
                <div>
                  <div className="text-slate-600">New Generation</div>
                  <div className="font-bold text-emerald-600">{results.totalGeneration.toFixed(1)} kW</div>
                  <div className="text-[10px] text-slate-500">
                    Δ {(results.totalGeneration - currentPowerFlow.total_generation_kw).toFixed(1)} kW
                  </div>
                </div>
                <div>
                  <div className="text-slate-600">Grid Import</div>
                  <div className="font-bold text-amber-600">{results.gridImport.toFixed(1)} kW</div>
                </div>
                <div>
                  <div className="text-slate-600">Grid Export</div>
                  <div className="font-bold text-cyan-600">{results.gridExport.toFixed(1)} kW</div>
                </div>
                <div className="col-span-2">
                  <div className="text-slate-600">Transformer Loading</div>
                  <div className={`font-bold ${results.transformerLoading > 90 ? 'text-red-600' : results.transformerLoading > 75 ? 'text-amber-600' : 'text-emerald-600'}`}>
                    {results.transformerLoading.toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-200">
          <button onClick={onClose} className="w-full px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded hover:bg-slate-200">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

function getModificationDescription(type: string): string {
  switch (type) {
    case 'add_load': return 'Add Load';
    case 'add_pv': return 'Add PV Array';
    case 'add_bess': return 'Add Battery Storage';
    case 'modify_transformer': return 'Modify Transformer Rating';
    default: return 'Modification';
  }
}

function getDefaultValue(type: string): number {
  switch (type) {
    case 'add_load': return 10;
    case 'add_pv': return 20;
    case 'add_bess': return 100;
    case 'modify_transformer': return 630;
    default: return 0;
  }
}
