// Component Library - Drag and drop palette
import React, { useState } from 'react';
import { ComponentType } from '../../types/circuit';

interface ComponentLibraryProps {
  onAddComponent: (type: ComponentType, position: { x: number; y: number }) => void;
}

const libraryItems = [
  // Sources
  { type: 'grid_source' as ComponentType, name: 'Grid Source', category: 'Sources', icon: '⚡' },
  { type: 'pv_array' as ComponentType, name: 'PV Array', category: 'Sources', icon: '☀️' },
  { type: 'generator' as ComponentType, name: 'Generator', category: 'Sources', icon: '⚙' },
  
  // Distribution
  { type: 'bus' as ComponentType, name: 'Bus', category: 'Distribution', icon: '━' },
  { type: 'transformer' as ComponentType, name: 'Transformer', category: 'Distribution', icon: '⚙️' },
  { type: 'line' as ComponentType, name: 'Line', category: 'Distribution', icon: '│' },
  { type: 'cable' as ComponentType, name: 'Cable', category: 'Distribution', icon: '┃' },
  { type: 'feeder' as ComponentType, name: 'Feeder', category: 'Distribution', icon: '╫' },
  { type: 'junction' as ComponentType, name: 'Junction', category: 'Distribution', icon: '◉' },
  
  // Protection
  { type: 'breaker' as ComponentType, name: 'Breaker', category: 'Protection', icon: '⊗' },
  { type: 'switch' as ComponentType, name: 'Switch', category: 'Protection', icon: '⊘' },
  { type: 'disconnector' as ComponentType, name: 'Disconnector', category: 'Protection', icon: '⊖' },
  { type: 'protection_relay' as ComponentType, name: 'Protection Relay', category: 'Protection', icon: '⚠' },
  
  // Measurement
  { type: 'ct' as ComponentType, name: 'Current Transformer', category: 'Measurement', icon: '⊙' },
  { type: 'pt' as ComponentType, name: 'Potential Transformer', category: 'Measurement', icon: '⊚' },
  { type: 'meter' as ComponentType, name: 'Meter', category: 'Measurement', icon: '⊛' },
  { type: 'measurement_point' as ComponentType, name: 'Measurement Point', category: 'Measurement', icon: '⊕' },
  
  // Loads
  { type: 'load' as ComponentType, name: 'Load', category: 'Loads', icon: '△' },
  { type: 'motor_load' as ComponentType, name: 'Motor Load', category: 'Loads', icon: '⊗' },
  { type: 'community_load' as ComponentType, name: 'Community Load', category: 'Loads', icon: '⊞' },
  { type: 'ev_charger' as ComponentType, name: 'EV Charger', category: 'Loads', icon: '⚡' },
  
  // Storage
  { type: 'bess' as ComponentType, name: 'Battery (BESS)', category: 'Storage', icon: '🔋' },
  { type: 'pcs' as ComponentType, name: 'PCS/Inverter', category: 'Storage', icon: '⊞' },
  { type: 'capacitor_bank' as ComponentType, name: 'Capacitor Bank', category: 'Storage', icon: '⊟' },
  
  // Other
  { type: 'ground' as ComponentType, name: 'Ground', category: 'Other', icon: '⏚' },
];

export default function ComponentLibrary({ onAddComponent }: ComponentLibraryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  const categories = ['All', ...Array.from(new Set(libraryItems.map(item => item.category)))];
  
  const filteredItems = libraryItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });
  
  const handleDragStart = (e: React.DragEvent, item: typeof libraryItems[0]) => {
    e.dataTransfer.setData('componentType', item.type);
  };
  
  return (
    <div className="w-64 bg-white border-r border-slate-200 flex flex-col">
      <div className="p-3 border-b border-slate-200">
        <h2 className="text-sm font-bold text-slate-900 mb-2">Component Library</h2>
        <input
          type="text"
          placeholder="Search components..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:outline-none focus:border-cyan-500"
        />
      </div>
      
      <div className="p-2 border-b border-slate-200">
        <div className="flex flex-wrap gap-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2 py-1 text-[10px] rounded ${
                selectedCategory === cat
                  ? 'bg-cyan-50 text-cyan-700 border border-cyan-200'
                  : 'bg-slate-50 text-slate-600 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2">
        {filteredItems.map(item => (
          <div
            key={item.type}
            draggable
            onDragStart={(e) => handleDragStart(e, item)}
            className="p-2 mb-1 bg-slate-50 border border-slate-200 rounded cursor-move hover:bg-cyan-50 hover:border-cyan-200 transition-colors"
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">{item.icon}</span>
              <div className="flex-1">
                <div className="text-xs font-medium text-slate-900">{item.name}</div>
                <div className="text-[10px] text-slate-500">{item.category}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-2 border-t border-slate-200 text-[10px] text-slate-500">
        Drag components onto the canvas
      </div>
    </div>
  );
}
