// GRIDPULSE Laptop A - Enhanced Circuit Editor
import React, { useState, useRef, useEffect } from 'react';
import { ElectricalModel } from '../engine/ElectricalModel';
import { CircuitComponent, ComponentType } from '../types/circuit';
import CircuitCanvas from './circuit/CircuitCanvas';
import ComponentLibrary from './circuit/ComponentLibrary';
import PropertyEditor from './circuit/PropertyEditor';
import CommandPalette from './circuit/CommandPalette';
import ScenarioSelector from './circuit/ScenarioSelector';
import ValidationPanel from './circuit/ValidationPanel';
import PowerBalancePanel from './circuit/PowerBalancePanel';
import AssetRelationships from './circuit/AssetRelationships';
import ExplainWhy from './circuit/ExplainWhy';
import WhatIfLab from './circuit/WhatIfLab';
import N1Contingency from './circuit/N1Contingency';
import EngineeringTable from './circuit/EngineeringTable';
import AnomalyDetection from './circuit/AnomalyDetection';
import EnergyProvenance from './circuit/EnergyProvenance';

export default function CircuitEditor() {
  const [model] = useState(() => new ElectricalModel());
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [selectedComponentIds, setSelectedComponentIds] = useState<Set<string>>(new Set());
  const [simulationRunning, setSimulationRunning] = useState(true);
  const [showMeasurements, setShowMeasurements] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showScenarioSelector, setShowScenarioSelector] = useState(false);
  const [showValidation, setShowValidation] = useState(false);
  const [showWhatIfLab, setShowWhatIfLab] = useState(false);
  const [showN1Contingency, setShowN1Contingency] = useState(false);
  const [showEngineeringTable, setShowEngineeringTable] = useState(false);
  const [rightPanel, setRightPanel] = useState<'properties' | 'relationships' | 'explain' | 'provenance' | 'anomalies'>('properties');
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; componentId: string } | null>(null);
  const [, forceUpdate] = useState({});
  
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const syncNetworkToBackend = async () => {
    try {
      await fetch(`${(import.meta as any).env?.VITE_API_URL || 'http://localhost:8000'}/api/network`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ network: JSON.parse(model.exportNetwork()) }),
      });
    } catch {
      // Retry on the next interval if FastAPI is temporarily unavailable.
    }
  };

  // Force re-render on model changes
  useEffect(() => {
    const interval = setInterval(() => {
      if (simulationRunning) {
        forceUpdate({});
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [simulationRunning]);

  // Laptop A is the authoritative circuit/topology editor. Publish its state to FastAPI
  // continuously so the backend simulation and Laptop B use the same network definition.
  useEffect(() => {
    syncNetworkToBackend();
    const interval = setInterval(syncNetworkToBackend, 1500);
    return () => clearInterval(interval);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      // Ctrl+Z - Undo
      if (e.ctrlKey && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        if (model.undo()) forceUpdate({});
      }
      
      // Ctrl+Y or Ctrl+Shift+Z - Redo
      if ((e.ctrlKey && e.key === 'y') || (e.ctrlKey && e.shiftKey && e.key === 'z')) {
        e.preventDefault();
        if (model.redo()) forceUpdate({});
      }
      
      // Delete or Backspace - Delete selected component(s)
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        if (selectedComponentIds.size > 0) {
          model.deleteComponents(Array.from(selectedComponentIds));
          setSelectedComponentIds(new Set());
          setSelectedComponentId(null);
          forceUpdate({});
        } else if (selectedComponentId) {
          model.removeComponent(selectedComponentId);
          setSelectedComponentId(null);
          forceUpdate({});
        }
      }
      
      // Ctrl+D - Duplicate
      if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        if (selectedComponentId) {
          const duplicate = model.duplicateComponent(selectedComponentId);
          if (duplicate) {
            setSelectedComponentId(duplicate.id);
            forceUpdate({});
          }
        }
      }
      
      // Ctrl+F - Search
      if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        setShowSearch(true);
      }

      // Ctrl+K - Command Palette
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        setShowCommandPalette(true);
      }
      
      // Ctrl+S - Save
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
      
      // Ctrl+O - Open/Load
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        fileInputRef.current?.click();
      }

      // Ctrl+Shift+V - Validate
      if (e.ctrlKey && e.shiftKey && e.key === 'V') {
        e.preventDefault();
        setShowValidation(true);
      }

      // Ctrl+Shift+S - Scenarios
      if (e.ctrlKey && e.shiftKey && e.key === 'S') {
        e.preventDefault();
        setShowScenarioSelector(true);
      }
      
      // Escape - Close panels
      if (e.key === 'Escape') {
        setShowSearch(false);
        setShowCommandPalette(false);
        setShowScenarioSelector(false);
        setShowValidation(false);
        setContextMenu(null);
        setSelectedComponentId(null);
        setSelectedComponentIds(new Set());
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedComponentId, selectedComponentIds, model]);

  // Close context menu on click outside
  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Handle component selection
  const handleComponentSelect = (id: string | null, multiSelect: boolean = false) => {
    if (multiSelect && id) {
      const newSet = new Set(selectedComponentIds);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      setSelectedComponentIds(newSet);
      setSelectedComponentId(id);
    } else {
      setSelectedComponentId(id);
      setSelectedComponentIds(new Set());
    }
  };

  // Save network to JSON file
  const handleSave = () => {
    const json = model.exportNetwork();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gridpulse_network_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Load network from JSON file
  const handleLoad = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = event.target?.result as string;
        model.importNetwork(json);
        setSelectedComponentId(null);
        setSelectedComponentIds(new Set());
        forceUpdate({});
      } catch (err) {
        alert('Failed to load network: Invalid JSON file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Handle delete component
  const handleDelete = () => {
    if (selectedComponentIds.size > 0) {
      model.deleteComponents(Array.from(selectedComponentIds));
      setSelectedComponentIds(new Set());
      setSelectedComponentId(null);
    } else if (selectedComponentId) {
      model.removeComponent(selectedComponentId);
      setSelectedComponentId(null);
    }
    forceUpdate({});
  };

  // Handle duplicate component
  const handleDuplicate = () => {
    if (selectedComponentId) {
      const duplicate = model.duplicateComponent(selectedComponentId);
      if (duplicate) {
        setSelectedComponentId(duplicate.id);
        forceUpdate({});
      }
    }
  };

  // Handle adding new component
  const handleAddComponent = (type: ComponentType, position: { x: number; y: number }) => {
    const id = `${type.toUpperCase()}-${Date.now()}`;
    const newComponent: CircuitComponent = {
      id,
      type,
      name: `${type} ${id}`,
      position,
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      terminals: [
        { id: `${id}-T1`, position: { x: position.x, y: position.y - 30 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
      ],
      ...getDefaultParameters(type),
    } as CircuitComponent;
    
    model.addComponent(newComponent);
    forceUpdate({});
  };

  // Get default parameters for component type
  const getDefaultParameters = (type: ComponentType) => {
    switch (type) {
      case 'grid_source':
        return { voltage_kv: 11, frequency_hz: 50, short_circuit_mva: 250, x_r_ratio: 10 };
      case 'bus':
        return { voltage_kv: 0.415, bus_type: 'pq', nominal_voltage_kv: 0.415, min_voltage_pu: 0.95, max_voltage_pu: 1.05 };
      case 'transformer':
        return { hv_voltage_kv: 11, lv_voltage_v: 415, rating_kva: 250, impedance_percent: 6, x_r_ratio: 8, tap_position: 0, tap_min: -5, tap_max: 5, no_load_loss_kw: 1.5, load_loss_kw: 5.0, temperature_c: 45, health_index: 95 };
      case 'breaker':
        return { rating_a: 400, voltage_kv: 0.415, breaking_capacity_ka: 10, state: 'closed', trip_setting_a: 320 };
      case 'switch':
        return { rating_a: 400, voltage_kv: 0.415, state: 'closed', switch_type: 'load_break' };
      case 'line':
        return { length_km: 0.1, r_ohm_per_km: 0.5, x_ohm_per_km: 0.3, c_nf_per_km: 10, rating_a: 200, conductor_type: 'AL 95mm²', from_bus: '', to_bus: '' };
      case 'load':
        return { active_power_kw: 5, reactive_power_kvar: 1.5, power_factor: 0.95, load_type: 'residential', profile: 'residential', priority: 1, is_controllable: false };
      case 'pv_array':
        return { capacity_kw: 10, efficiency: 0.95, irradiance_w_m2: 800, temperature_c: 25, temperature_coefficient: -0.004, operating_state: 'online', curtailment_percent: 0 };
      case 'bess':
        return { capacity_kwh: 100, soc_percent: 50, max_charge_kw: 50, max_discharge_kw: 50, efficiency: 0.95, mode: 'auto', min_soc_percent: 20, max_soc_percent: 95, cycle_count: 0, health_percent: 100 };
      case 'pcs':
        return { rating_kw: 50, efficiency: 0.96, pwm_frequency_hz: 10000, duty_cycle: 0.5, enabled: true, operating_mode: 'grid_following' };
      default:
        return {};
    }
  };

  // Handle drop on canvas
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData('componentType') as ComponentType;
    if (!type || !canvasContainerRef.current) return;

    const rect = canvasContainerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    handleAddComponent(type, { x: x * 2, y: y * 2 });
  };

  // Handle component update
  const handleComponentUpdate = (id: string, updates: Partial<CircuitComponent>) => {
    model.updateComponent(id, updates);
    forceUpdate({});
  };

  // Get selected component
  const selectedComponent = selectedComponentId ? model.getNetwork().components[selectedComponentId] : null;

  // Power flow results
  const powerFlowResult = model.runPowerFlow();
  const validation = model.validateTopology();

  return (
    <div className="h-full flex flex-col bg-slate-100">
      {/* Top Toolbar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
              {/* Simulation Controls */}
              <button
                onClick={() => setSimulationRunning(!simulationRunning)}
                className={`px-3 py-1.5 text-xs font-medium rounded border ${
                  simulationRunning
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                {simulationRunning ? '▶ RUNNING' : '⏸ PAUSED'}
              </button>
              
              <button
                onClick={() => setShowMeasurements(!showMeasurements)}
                className={`px-3 py-1.5 text-xs font-medium rounded border ${
                  showMeasurements
                    ? 'bg-cyan-50 text-cyan-700 border-cyan-200'
                    : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                📊 Measurements
              </button>

              {/* Divider */}
              <div className="w-px h-6 bg-slate-200"></div>

              {/* Undo/Redo */}
              <button
                onClick={() => { if (model.undo()) forceUpdate({}); }}
                disabled={!model.canUndo()}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
                title="Undo (Ctrl+Z)"
              >
                ↶ Undo
              </button>
              <button
                onClick={() => { if (model.redo()) forceUpdate({}); }}
                disabled={!model.canRedo()}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
                title="Redo (Ctrl+Y)"
              >
                ↷ Redo
              </button>

              {/* Divider */}
              <div className="w-px h-6 bg-slate-200"></div>

              {/* Edit Actions */}
              <button
                onClick={handleDuplicate}
                disabled={!selectedComponentId}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
                title="Duplicate (Ctrl+D)"
              >
                ⊕ Duplicate
              </button>
              <button
                onClick={handleDelete}
                disabled={!selectedComponentId && selectedComponentIds.size === 0}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-red-50 text-red-600 border-red-200 hover:bg-red-100 disabled:opacity-40 disabled:cursor-not-allowed"
                title="Delete (Del)"
              >
                ✕ Delete
              </button>

              {/* Divider */}
              <div className="w-px h-6 bg-slate-200"></div>

              {/* Advanced Features */}
              <button
                onClick={() => setShowCommandPalette(true)}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                title="Command Palette (Ctrl+K)"
              >
                ⌘ Commands
              </button>
              <button
                onClick={() => setShowScenarioSelector(true)}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                title="Scenarios (Ctrl+Shift+S)"
              >
                🎭 Scenarios
              </button>
              <button
                onClick={() => setShowValidation(true)}
                className={`px-2 py-1.5 text-xs font-medium rounded border ${
                  validation.valid
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-red-50 text-red-700 border-red-200'
                }`}
                title="Validate (Ctrl+Shift+V)"
              >
                {validation.valid ? '✓ Valid' : `✗ ${validation.errors.length}`}
              </button>

              {/* Divider */}
              <div className="w-px h-6 bg-slate-200"></div>

              {/* Engineering Studies */}
              <button
                onClick={() => setShowWhatIfLab(true)}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
                title="What-If Lab"
              >
                🔬 What-If
              </button>
              <button
                onClick={() => setShowN1Contingency(true)}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                title="N-1 Contingency Analysis"
              >
                🔍 N-1
              </button>
              <button
                onClick={() => setShowEngineeringTable(!showEngineeringTable)}
                className={`px-2 py-1.5 text-xs font-medium rounded border ${
                  showEngineeringTable
                    ? 'bg-cyan-50 text-cyan-700 border-cyan-200'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
                title="Engineering Table View"
              >
                📋 Table
              </button>

              {/* Divider */}
              <div className="w-px h-6 bg-slate-200"></div>

              {/* Search */}
              <button
                onClick={() => setShowSearch(!showSearch)}
                className={`px-2 py-1.5 text-xs font-medium rounded border ${
                  showSearch
                    ? 'bg-cyan-50 text-cyan-700 border-cyan-200'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
                title="Search (Ctrl+F)"
              >
                🔍 Search
              </button>

              {/* File Operations */}
              <button
                onClick={handleSave}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                title="Save (Ctrl+S)"
              >
                💾 Save
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-2 py-1.5 text-xs font-medium rounded border bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                title="Load (Ctrl+O)"
              >
                📂 Load
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleLoad}
                className="hidden"
              />
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="text-slate-600">
              Components: <span className="font-bold">{Object.keys(model.getNetwork().components).length}</span>
            </div>
            <div className="text-slate-600">
              Connections: <span className="font-bold">{model.getNetwork().connections.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Component Library */}
        <ComponentLibrary onAddComponent={handleAddComponent} />

        {/* Canvas Area */}
        <div
          ref={canvasContainerRef}
          className="flex-1 relative"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          <CircuitCanvas
            model={model}
            onComponentSelect={handleComponentSelect}
            selectedComponentId={selectedComponentId}
            showMeasurements={showMeasurements}
            powerFlowResult={powerFlowResult}
            onContextMenu={(e: React.MouseEvent, componentId: string) => {
              e.preventDefault();
              setContextMenu({ x: e.clientX, y: e.clientY, componentId });
            }}
          />

          {/* Canvas Instructions */}
          <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg border border-slate-200 px-3 py-2 text-[10px] text-slate-600">
            <div className="font-bold mb-1">Controls:</div>
            <div>• Shift + Drag: Pan canvas</div>
            <div>• Scroll: Zoom in/out</div>
            <div>• Click terminal: Start wire</div>
            <div>• Right-click: Context menu</div>
            <div>• Shift + Click: Multi-select</div>
            <div>• Ctrl+K: Command palette</div>
            <div>• Ctrl+Z/Y: Undo/Redo</div>
            <div>• Ctrl+D: Duplicate</div>
            <div>• Del: Delete selected</div>
          </div>

          {/* Power Balance */}
          {powerFlowResult && (
            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg border border-slate-200 px-3 py-2">
              <div className="text-[10px] font-bold text-slate-700 mb-1">Power Balance</div>
              <div className="space-y-0.5 text-[10px]">
                <div className="flex justify-between gap-4">
                  <span className="text-slate-600">Generation:</span>
                  <span className="font-bold text-emerald-600">{powerFlowResult.total_generation_kw.toFixed(1)} kW</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-600">Load:</span>
                  <span className="font-bold text-blue-600">{powerFlowResult.total_load_kw.toFixed(1)} kW</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-600">Grid Import:</span>
                  <span className="font-bold text-amber-600">{powerFlowResult.grid_result.import_kw.toFixed(1)} kW</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-600">Grid Export:</span>
                  <span className="font-bold text-cyan-600">{powerFlowResult.grid_result.export_kw.toFixed(1)} kW</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-slate-600">Losses:</span>
                  <span className="font-bold text-red-600">{powerFlowResult.total_losses_kw.toFixed(2)} kW</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Panel - Tabbed */}
        <div className="w-80 bg-white border-l border-slate-200 flex flex-col overflow-hidden">
          {/* Panel Tabs */}
          <div className="flex border-b border-slate-200 bg-slate-50">
            <button
              onClick={() => setRightPanel('properties')}
              className={`flex-1 px-2 py-2 text-[10px] font-medium ${
                rightPanel === 'properties' ? 'bg-white text-cyan-700 border-b-2 border-cyan-500' : 'text-slate-600'
              }`}
            >
              Properties
            </button>
            <button
              onClick={() => setRightPanel('relationships')}
              className={`flex-1 px-2 py-2 text-[10px] font-medium ${
                rightPanel === 'relationships' ? 'bg-white text-cyan-700 border-b-2 border-cyan-500' : 'text-slate-600'
              }`}
              disabled={!selectedComponentId}
            >
              Relations
            </button>
            <button
              onClick={() => setRightPanel('explain')}
              className={`flex-1 px-2 py-2 text-[10px] font-medium ${
                rightPanel === 'explain' ? 'bg-white text-cyan-700 border-b-2 border-cyan-500' : 'text-slate-600'
              }`}
              disabled={!selectedComponentId}
            >
              Why?
            </button>
            <button
              onClick={() => setRightPanel('provenance')}
              className={`flex-1 px-2 py-2 text-[10px] font-medium ${
                rightPanel === 'provenance' ? 'bg-white text-cyan-700 border-b-2 border-cyan-500' : 'text-slate-600'
              }`}
              disabled={!selectedComponentId || selectedComponent?.type !== 'load'}
            >
              Energy
            </button>
          </div>

          {/* Panel Content */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {rightPanel === 'properties' && (
              <PropertyEditor
                component={selectedComponent}
                onUpdate={handleComponentUpdate}
                onClose={() => setSelectedComponentId(null)}
              />
            )}

            {rightPanel === 'relationships' && selectedComponentId && (
              <AssetRelationships
                model={model}
                componentId={selectedComponentId}
                onAssetSelect={setSelectedComponentId}
              />
            )}

            {rightPanel === 'explain' && selectedComponentId && (
              <ExplainWhy
                model={model}
                componentId={selectedComponentId}
              />
            )}

            {rightPanel === 'provenance' && selectedComponentId && selectedComponent?.type === 'load' && (
              <EnergyProvenance
                model={model}
                componentId={selectedComponentId}
              />
            )}

            {/* Always show Power Balance and Anomaly Detection */}
            <PowerBalancePanel model={model} />
            <AnomalyDetection model={model} onAssetSelect={setSelectedComponentId} />
          </div>
        </div>
      </div>

      {/* Engineering Table View */}
      {showEngineeringTable && (
        <div className="absolute inset-0 bg-slate-100 z-40 p-4 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-slate-900">Engineering Table View</h2>
            <button
              onClick={() => setShowEngineeringTable(false)}
              className="px-4 py-2 text-sm bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              Back to Canvas
            </button>
          </div>
          <EngineeringTable
            model={model}
            onAssetSelect={(id) => {
              setSelectedComponentId(id);
              setShowEngineeringTable(false);
            }}
            powerFlowResult={powerFlowResult}
          />
        </div>
      )}

      {/* Modals */}
      {showCommandPalette && (
        <CommandPalette
          model={model}
          onClose={() => setShowCommandPalette(false)}
          onSelect={(action: any) => {
            setShowCommandPalette(false);
            // Execute action
            if (action.type === 'locate') {
              setSelectedComponentId(action.componentId);
            }
          }}
        />
      )}

      {showScenarioSelector && (
        <ScenarioSelector
          model={model}
          onClose={() => setShowScenarioSelector(false)}
          onApply={(scenarioId: string) => {
            model.applyScenario(scenarioId);
            syncNetworkToBackend();
            const normalized = ({
              'normal-day': 'NORMAL',
              'high-solar': 'HIGH_SOLAR',
              'evening-peak': 'EVENING_PEAK',
              'grid-interruption': 'GRID_OUTAGE',
              'feeder-outage': 'FEEDER_OUTAGE',
              'solar-deficit': 'SOLAR_DEFICIT',
              'solar-match': 'SOLAR_MATCH',
              'solar-surplus': 'SOLAR_SURPLUS',
              'transformer-overload': 'TRANSFORMER_OVERLOAD',
              'voltage-sag': 'VOLTAGE_SAG',
              'voltage-swell': 'VOLTAGE_SWELL',
              'battery-charge': 'BATTERY_CHARGE',
              'battery-discharge': 'BATTERY_DISCHARGE',
            } as Record<string, string>)[scenarioId] || scenarioId.replace(/-/g, '_').toUpperCase();
            fetch(`${(import.meta as any).env?.VITE_API_URL || 'http://localhost:8000'}/api/scenarios/apply`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ scenario_id: normalized }),
            }).catch(() => undefined);
            setShowScenarioSelector(false);
            forceUpdate({});
          }}
        />
      )}

      {showValidation && (
        <ValidationPanel
          validation={validation}
          onClose={() => setShowValidation(false)}
          onLocate={(componentId: string) => {
            setSelectedComponentId(componentId);
            setShowValidation(false);
          }}
        />
      )}

      {showWhatIfLab && (
        <WhatIfLab
          model={model}
          onClose={() => setShowWhatIfLab(false)}
        />
      )}

      {showN1Contingency && (
        <N1Contingency
          model={model}
          onClose={() => setShowN1Contingency(false)}
        />
      )}

      {/* Context Menu */}
      {contextMenu && (
        <div
          className="absolute z-50 bg-white rounded-lg border border-slate-200 shadow-lg py-1 w-48"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => {
              setSelectedComponentId(contextMenu.componentId);
              setContextMenu(null);
            }}
            className="w-full px-3 py-1.5 text-left text-xs hover:bg-slate-50"
          >
            Select Component
          </button>
          <button
            onClick={() => {
              const duplicate = model.duplicateComponent(contextMenu.componentId);
              if (duplicate) setSelectedComponentId(duplicate.id);
              setContextMenu(null);
              forceUpdate({});
            }}
            className="w-full px-3 py-1.5 text-left text-xs hover:bg-slate-50"
          >
            Duplicate
          </button>
          <div className="border-t border-slate-200 my-1"></div>
          <button
            onClick={() => {
              const comp = model.getComponent(contextMenu.componentId);
              if (comp && comp.type === 'breaker') {
                const newState = (comp as any).state === 'open' ? 'closed' : 'open';
                model.updateComponent(contextMenu.componentId, { state: newState } as any);
                forceUpdate({});
              }
              setContextMenu(null);
            }}
            className="w-full px-3 py-1.5 text-left text-xs hover:bg-slate-50"
          >
            Toggle Breaker
          </button>
          <div className="border-t border-slate-200 my-1"></div>
          <button
            onClick={() => {
              model.removeComponent(contextMenu.componentId);
              setSelectedComponentId(null);
              setContextMenu(null);
              forceUpdate({});
            }}
            className="w-full px-3 py-1.5 text-left text-xs text-red-600 hover:bg-red-50"
          >
            Delete
          </button>
        </div>
      )}

      {/* Bottom Status Bar */}
      <footer className="bg-white border-t border-slate-200 px-4 py-1.5">
        <div className="flex items-center justify-between text-[10px] text-slate-600">
          <div className="flex items-center gap-4">
            <span>Network: {model.getNetwork().name}</span>
            <span>Version: {model.getNetwork().version}</span>
            <span>Last Modified: {new Date(model.getNetwork().modified_at).toLocaleTimeString()}</span>
            <span>History: {model.canUndo() ? '✓' : '—'} undo / {model.canRedo() ? '✓' : '—'} redo</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Simulation: {simulationRunning ? 'Running' : 'Paused'}</span>
            <span>Time: {new Date().toLocaleTimeString()}</span>
            {selectedComponentIds.size > 0 && (
              <span className="text-cyan-600 font-medium">{selectedComponentIds.size} selected</span>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
