// Enhanced Circuit Component Types for Laptop A

export type ComponentType = 
  | 'grid_source'
  | 'bus'
  | 'transformer'
  | 'breaker'
  | 'switch'
  | 'disconnector'
  | 'ct'
  | 'pt'
  | 'line'
  | 'cable'
  | 'feeder'
  | 'load'
  | 'pv_array'
  | 'inverter'
  | 'bess'
  | 'pcs'
  | 'generator'
  | 'motor_load'
  | 'community_load'
  | 'ev_charger'
  | 'meter'
  | 'protection_relay'
  | 'capacitor_bank'
  | 'ground'
  | 'junction'
  | 'measurement_point';

export type ComponentStatus = 'online' | 'offline' | 'warning' | 'fault' | 'maintenance';
export type VoltageLevel = 'hv' | 'mv' | 'lv';
export type BreakerState = 'open' | 'closed';
export type BatteryMode = 'auto' | 'charge' | 'discharge' | 'idle';
export type LoadType = 'residential' | 'commercial' | 'industrial' | 'critical' | 'flexible' | 'non-critical';

export interface Terminal {
  id: string;
  position: { x: number; y: number };
  voltage_level: VoltageLevel;
  nominal_voltage_kv: number;
}

export interface BaseComponent {
  id: string;
  type: ComponentType;
  name: string;
  position: { x: number; y: number };
  rotation: number;
  status: ComponentStatus;
  voltage_level: VoltageLevel;
  terminals: Terminal[];
  telemetry?: ComponentTelemetry;
  metadata?: Record<string, any>;
}

export interface GridSource extends BaseComponent {
  type: 'grid_source';
  voltage_kv: number;
  frequency_hz: number;
  short_circuit_mva: number;
  x_r_ratio: number;
}

export interface Bus extends BaseComponent {
  type: 'bus';
  voltage_kv: number;
  bus_type: 'slack' | 'pv' | 'pq';
  nominal_voltage_kv: number;
  min_voltage_pu: number;
  max_voltage_pu: number;
}

export interface Transformer extends BaseComponent {
  type: 'transformer';
  hv_voltage_kv: number;
  lv_voltage_v: number;
  rating_kva: number;
  impedance_percent: number;
  x_r_ratio: number;
  tap_position: number;
  tap_min: number;
  tap_max: number;
  no_load_loss_kw: number;
  load_loss_kw: number;
  temperature_c: number;
  health_index: number;
}

export interface Breaker extends BaseComponent {
  type: 'breaker';
  rating_a: number;
  voltage_kv: number;
  breaking_capacity_ka: number;
  state: BreakerState;
  trip_setting_a: number;
}

export interface Switch extends BaseComponent {
  type: 'switch';
  rating_a: number;
  voltage_kv: number;
  state: BreakerState;
  switch_type: 'load_break' | 'disconnect';
}

export interface Line extends BaseComponent {
  type: 'line';
  length_km: number;
  r_ohm_per_km: number;
  x_ohm_per_km: number;
  c_nf_per_km: number;
  rating_a: number;
  conductor_type: string;
  from_bus: string;
  to_bus: string;
}

export interface Load extends BaseComponent {
  type: 'load';
  active_power_kw: number;
  reactive_power_kvar: number;
  power_factor: number;
  load_type: LoadType;
  profile: string;
  priority: number;
  is_controllable: boolean;
}

export interface PVArray extends BaseComponent {
  type: 'pv_array';
  capacity_kw: number;
  efficiency: number;
  irradiance_w_m2: number;
  temperature_c: number;
  temperature_coefficient: number;
  operating_state: 'online' | 'curtailed' | 'offline';
  curtailment_percent: number;
}

export interface BESS extends BaseComponent {
  type: 'bess';
  capacity_kwh: number;
  soc_percent: number;
  max_charge_kw: number;
  max_discharge_kw: number;
  efficiency: number;
  mode: BatteryMode;
  min_soc_percent: number;
  max_soc_percent: number;
  cycle_count: number;
  health_percent: number;
}

export interface PCS extends BaseComponent {
  type: 'pcs';
  rating_kw: number;
  efficiency: number;
  pwm_frequency_hz: number;
  duty_cycle: number;
  enabled: boolean;
  operating_mode: 'grid_following' | 'grid_forming';
}

export interface EVCharger extends BaseComponent {
  type: 'ev_charger';
  rating_kw: number;
  charging_state: 'idle' | 'charging' | 'scheduled';
  schedule?: Array<{ start: string; end: string; power_kw: number }>;
  vehicle_soc_percent: number;
  target_soc_percent: number;
}

export interface ProtectionRelay extends BaseComponent {
  type: 'protection_relay';
  relay_type: 'overcurrent' | 'undervoltage' | 'overvoltage' | 'differential';
  pickup_setting: number;
  time_dial: number;
  trip_time_s: number;
  monitored_asset: string;
}

export type CircuitComponent = 
  | GridSource
  | Bus
  | Transformer
  | Breaker
  | Switch
  | Line
  | Load
  | PVArray
  | BESS
  | PCS
  | EVCharger
  | ProtectionRelay
  | BaseComponent;

export interface Connection {
  id: string;
  from_component: string;
  from_terminal: string;
  to_component: string;
  to_terminal: string;
  wire_type: 'power' | 'control' | 'measurement';
}

export interface ComponentTelemetry {
  voltage_v: number;
  voltage_pu: number;
  current_a: number;
  active_power_kw: number;
  reactive_power_kvar: number;
  apparent_power_kva: number;
  power_factor: number;
  frequency_hz: number;
  loading_percent: number;
  temperature_c: number;
  losses_kw: number;
}

export interface CircuitNetwork {
  id: string;
  name: string;
  version: string;
  description: string;
  components: Record<string, CircuitComponent>;
  connections: Connection[];
  created_at: string;
  modified_at: string;
  scenario?: string;
}

export interface NetworkVersion {
  id: string;
  name: string;
  description: string;
  timestamp: string;
  network: CircuitNetwork;
  changes: string[];
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

export interface ValidationError {
  code: string;
  message: string;
  component_id?: string;
  severity: 'critical' | 'major';
}

export interface ValidationWarning {
  code: string;
  message: string;
  component_id?: string;
  severity: 'minor' | 'info';
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  type: 'normal' | 'high_solar' | 'low_solar' | 'evening_peak' | 'high_load' | 'grid_import' | 'grid_export' | 'battery_charging' | 'battery_discharging' | 'transformer_overload' | 'grid_interruption' | 'feeder_outage' | 'pv_trip' | 'pcs_trip';
  modifications: ScenarioModification[];
}

export interface ScenarioModification {
  type: 'set_load' | 'set_generation' | 'set_battery' | 'open_breaker' | 'close_breaker' | 'set_transformer' | 'trip_component';
  target_id: string;
  parameter?: string;
  value: any;
}

export interface PowerFlowResult {
  converged: boolean;
  iterations: number;
  mismatch_kva: number;
  bus_results: Record<string, BusResult>;
  line_results: Record<string, LineResult>;
  transformer_results: Record<string, TransformerResult>;
  generation_results: Record<string, GenerationResult>;
  load_results: Record<string, LoadResult>;
  battery_results: Record<string, BatteryResult>;
  grid_result: GridResult;
  total_losses_kw: number;
  total_generation_kw: number;
  total_load_kw: number;
  power_balance: PowerBalance;
}

export interface BusResult {
  voltage_pu: number;
  voltage_v: number;
  angle_deg: number;
  active_power_kw: number;
  reactive_power_kvar: number;
  loading_percent: number;
}

export interface LineResult {
  current_a: number;
  active_power_kw: number;
  reactive_power_kvar: number;
  losses_kw: number;
  loading_percent: number;
  voltage_drop_percent: number;
}

export interface TransformerResult {
  loading_percent: number;
  hv_current_a: number;
  lv_current_a: number;
  losses_kw: number;
  efficiency: number;
  temperature_c: number;
  health_index: number;
}

export interface GenerationResult {
  active_power_kw: number;
  reactive_power_kvar: number;
  availability_percent: number;
}

export interface LoadResult {
  active_power_kw: number;
  reactive_power_kvar: number;
  power_factor: number;
}

export interface BatteryResult {
  soc_percent: number;
  power_kw: number;
  state: string;
  efficiency: number;
}

export interface GridResult {
  import_kw: number;
  export_kw: number;
  power_factor: number;
  voltage_kv: number;
  frequency_hz: number;
}

export interface PowerBalance {
  generation_kw: number;
  grid_import_kw: number;
  battery_discharge_kw: number;
  load_kw: number;
  battery_charge_kw: number;
  grid_export_kw: number;
  losses_kw: number;
  balance_kw: number;
}

export interface SimulationState {
  running: boolean;
  time_step_s: number;
  simulation_time_s: number;
  speed_multiplier: number;
  power_flow_result: PowerFlowResult | null;
  last_update: string;
}
