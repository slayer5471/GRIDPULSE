// Enhanced Electrical Model Engine for Laptop A
import { 
  CircuitNetwork, CircuitComponent, Connection, PowerFlowResult, 
  ValidationResult, ValidationError, ValidationWarning,
  Scenario, ScenarioModification, NetworkVersion, SimulationState,
  BusResult, LineResult, TransformerResult, PowerBalance
} from '../types/circuit';

export class ElectricalModel {
  private network: CircuitNetwork;
  private history: CircuitNetwork[] = [];
  private historyIndex: number = -1;
  private maxHistorySize: number = 50;
  private versions: NetworkVersion[] = [];
  private simulationState: SimulationState;
  private scenarios: Scenario[];

  constructor() {
    this.network = this.createDefaultNetwork();
    this.saveToHistory();
    this.simulationState = {
      running: true,
      time_step_s: 1.0,
      simulation_time_s: 0,
      speed_multiplier: 1,
      power_flow_result: null,
      last_update: new Date().toISOString(),
    };
    this.scenarios = this.createDefaultScenarios();
  }

  private createDefaultScenarios(): Scenario[] {
    return [
      {
        id: 'normal-day',
        name: 'Normal Day',
        description: 'Standard operating conditions',
        type: 'normal',
        modifications: [],
      },
      {
        id: 'high-solar',
        name: 'High Solar',
        description: 'Maximum solar generation',
        type: 'high_solar',
        modifications: [
          { type: 'set_generation', target_id: 'PV-01', parameter: 'irradiance_w_m2', value: 1000 },
        ],
      },
      {
        id: 'evening-peak',
        name: 'Evening Peak',
        description: 'High evening load demand',
        type: 'evening_peak',
        modifications: [
          { type: 'set_load', target_id: 'LOAD-11', parameter: 'active_power_kw', value: 8 },
          { type: 'set_load', target_id: 'LOAD-12', parameter: 'active_power_kw', value: 8 },
        ],
      },
      {
        id: 'grid-interruption',
        name: 'Grid Interruption',
        description: 'Grid supply failure',
        type: 'grid_interruption',
        modifications: [
          { type: 'open_breaker', target_id: 'CB-IN-01', value: true },
        ],
      },
      {
        id: 'feeder-outage',
        name: 'Feeder Outage',
        description: 'Feeder 02 outage',
        type: 'feeder_outage',
        modifications: [
          { type: 'open_breaker', target_id: 'CB-FEEDER-02', value: true },
        ],
      },
      { id: 'solar-deficit', name: 'Solar < Load', description: 'Solar generation below demand.', type: 'high_load', modifications: [] },
      { id: 'solar-match', name: 'Solar = Load', description: 'Solar approximately matches local demand.', type: 'normal', modifications: [] },
      { id: 'solar-surplus', name: 'Solar > Load', description: 'Solar surplus charges storage and/or exports.', type: 'high_solar', modifications: [] },
      { id: 'transformer-overload', name: 'Transformer Overload', description: 'Force high loading to exercise alarms.', type: 'transformer_overload', modifications: [] },
      { id: 'voltage-sag', name: 'Voltage Sag', description: 'Exercise undervoltage alarm.', type: 'grid_import', modifications: [] },
      { id: 'voltage-swell', name: 'Voltage Swell', description: 'Exercise overvoltage alarm.', type: 'grid_export', modifications: [] },
      { id: 'battery-charge', name: 'BESS Charging', description: 'Force BESS charging.', type: 'battery_charging', modifications: [] },
      { id: 'battery-discharge', name: 'BESS Discharge', description: 'Force BESS discharge.', type: 'battery_discharging', modifications: [] },
    ];
  }
  
  private createDefaultNetwork(): CircuitNetwork {
    const network: CircuitNetwork = {
      id: 'grid-default',
      name: 'GRIDPULSE Community Network',
      version: '1.0.0',
      description: 'Indian community distribution network - 11kV/415V',
      components: {},
      connections: [],
      created_at: new Date().toISOString(),
      modified_at: new Date().toISOString(),
    };
    
    // 11 kV Grid Source
    network.components['GRID-01'] = {
      id: 'GRID-01',
      type: 'grid_source',
      name: '11 kV Grid',
      position: { x: 100, y: 100 },
      rotation: 0,
      status: 'online',
      voltage_level: 'hv',
      voltage_kv: 11,
      frequency_hz: 50,
      short_circuit_mva: 250,
      x_r_ratio: 10,
      terminals: [{ id: 'GRID-01-T1', position: { x: 150, y: 100 }, voltage_level: 'hv', nominal_voltage_kv: 11 }],
    };
    
    // Incoming Breaker
    network.components['CB-IN-01'] = {
      id: 'CB-IN-01',
      type: 'breaker',
      name: 'Incoming Breaker',
      position: { x: 100, y: 200 },
      rotation: 0,
      status: 'online',
      voltage_level: 'hv',
      rating_a: 630,
      voltage_kv: 11,
      breaking_capacity_ka: 25,
      state: 'closed',
      trip_setting_a: 500,
      terminals: [
        { id: 'CB-IN-01-T1', position: { x: 100, y: 170 }, voltage_level: 'hv', nominal_voltage_kv: 11 },
        { id: 'CB-IN-01-T2', position: { x: 100, y: 230 }, voltage_level: 'hv', nominal_voltage_kv: 11 },
      ],
    };
    
    // CT/PT
    network.components['CT-01'] = {
      id: 'CT-01',
      type: 'ct',
      name: 'Current Transformer',
      position: { x: 100, y: 250 },
      rotation: 0,
      status: 'online',
      voltage_level: 'hv',
      terminals: [
        { id: 'CT-01-T1', position: { x: 100, y: 240 }, voltage_level: 'hv', nominal_voltage_kv: 11 },
        { id: 'CT-01-T2', position: { x: 100, y: 260 }, voltage_level: 'hv', nominal_voltage_kv: 11 },
      ],
    } as any;
    
    // 11 kV Bus
    network.components['BUS-11KV'] = {
      id: 'BUS-11KV',
      type: 'bus',
      name: '11 kV Bus',
      position: { x: 100, y: 300 },
      rotation: 0,
      status: 'online',
      voltage_level: 'hv',
      voltage_kv: 11,
      bus_type: 'slack',
      nominal_voltage_kv: 11,
      min_voltage_pu: 0.95,
      max_voltage_pu: 1.05,
      terminals: [{ id: 'BUS-11KV-T1', position: { x: 100, y: 300 }, voltage_level: 'hv', nominal_voltage_kv: 11 }],
    };
    
    // Distribution Transformer
    network.components['TX-01'] = {
      id: 'TX-01',
      type: 'transformer',
      name: 'Distribution Transformer',
      position: { x: 100, y: 400 },
      rotation: 0,
      status: 'online',
      voltage_level: 'mv',
      hv_voltage_kv: 11,
      lv_voltage_v: 415,
      rating_kva: 500,
      impedance_percent: 6,
      x_r_ratio: 8,
      tap_position: 0,
      tap_min: -5,
      tap_max: 5,
      no_load_loss_kw: 1.5,
      load_loss_kw: 5.0,
      temperature_c: 45,
      health_index: 95,
      terminals: [
        { id: 'TX-01-HV', position: { x: 100, y: 370 }, voltage_level: 'hv', nominal_voltage_kv: 11 },
        { id: 'TX-01-LV', position: { x: 100, y: 430 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
      ],
    };
    
    // 415 V Bus
    network.components['BUS-415V'] = {
      id: 'BUS-415V',
      type: 'bus',
      name: '415 V Bus',
      position: { x: 100, y: 500 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      voltage_kv: 0.415,
      bus_type: 'pq',
      nominal_voltage_kv: 0.415,
      min_voltage_pu: 0.95,
      max_voltage_pu: 1.05,
      terminals: [{ id: 'BUS-415V-T1', position: { x: 100, y: 500 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
    };
    
    // 3 Feeders with loads
    for (let i = 1; i <= 3; i++) {
      const feederX = 100 + (i - 1) * 200;
      
      // Feeder breaker
      network.components[`CB-FEEDER-0${i}`] = {
        id: `CB-FEEDER-0${i}`,
        type: 'breaker',
        name: `Feeder ${i} Breaker`,
        position: { x: feederX, y: 550 },
        rotation: 0,
        status: 'online',
        voltage_level: 'lv',
        rating_a: 200,
        voltage_kv: 0.415,
        breaking_capacity_ka: 10,
        state: 'closed',
        trip_setting_a: 160,
        terminals: [
          { id: `CB-FEEDER-0${i}-T1`, position: { x: feederX, y: 530 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
          { id: `CB-FEEDER-0${i}-T2`, position: { x: feederX, y: 570 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
        ],
      };
      
      // Feeder line
      network.components[`FEEDER-0${i}`] = {
        id: `FEEDER-0${i}`,
        type: 'line',
        name: `Feeder ${i}`,
        position: { x: feederX, y: 600 },
        rotation: 0,
        status: 'online',
        voltage_level: 'lv',
        length_km: 0.25,
        r_ohm_per_km: 0.5,
        x_ohm_per_km: 0.3,
        c_nf_per_km: 10,
        rating_a: 200,
        conductor_type: 'AL 95mm²',
        from_bus: 'BUS-415V',
        to_bus: `BUS-FEEDER-0${i}`,
        terminals: [
          { id: `FEEDER-0${i}-T1`, position: { x: feederX, y: 570 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
          { id: `FEEDER-0${i}-T2`, position: { x: feederX, y: 630 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 },
        ],
      };
      
      // Feeder bus
      network.components[`BUS-FEEDER-0${i}`] = {
        id: `BUS-FEEDER-0${i}`,
        type: 'bus',
        name: `Feeder ${i} Bus`,
        position: { x: feederX, y: 700 },
        rotation: 0,
        status: 'online',
        voltage_level: 'lv',
        voltage_kv: 0.415,
        bus_type: 'pq',
        nominal_voltage_kv: 0.415,
        min_voltage_pu: 0.95,
        max_voltage_pu: 1.05,
        terminals: [{ id: `BUS-FEEDER-0${i}-T1`, position: { x: feederX, y: 700 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
      };
      
      // Add 2 loads per feeder
      for (let j = 1; j <= 2; j++) {
        const loadId = `LOAD-${i}${j}`;
        network.components[loadId] = {
          id: loadId,
          type: 'load',
          name: `House ${i}-${j}`,
          position: { x: feederX + (j - 1) * 80, y: 800 },
          rotation: 0,
          status: 'online',
          voltage_level: 'lv',
          active_power_kw: 5 + (i + j) * 0.5,
          reactive_power_kvar: 1.5,
          power_factor: 0.95,
          load_type: 'residential',
          profile: 'residential',
          priority: 1,
          is_controllable: false,
          terminals: [{ id: `${loadId}-T1`, position: { x: feederX + (j - 1) * 80, y: 770 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
        };
      }
    }
    
    // PV Array
    network.components['PV-01'] = {
      id: 'PV-01',
      type: 'pv_array',
      name: 'Solar PV System',
      position: { x: 700, y: 500 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      capacity_kw: 60,
      efficiency: 0.95,
      irradiance_w_m2: 800,
      temperature_c: 25,
      temperature_coefficient: -0.004,
      operating_state: 'online',
      curtailment_percent: 0,
      terminals: [{ id: 'PV-01-T1', position: { x: 700, y: 470 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
    };
    
    // BESS
    network.components['BESS-01'] = {
      id: 'BESS-01',
      type: 'bess',
      name: 'Battery Storage',
      position: { x: 850, y: 500 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      capacity_kwh: 200,
      soc_percent: 50,
      max_charge_kw: 50,
      max_discharge_kw: 50,
      efficiency: 0.95,
      mode: 'auto',
      min_soc_percent: 20,
      max_soc_percent: 95,
      cycle_count: 150,
      health_percent: 98,
      terminals: [{ id: 'BESS-01-T1', position: { x: 850, y: 470 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
    };
    
    // PCS
    network.components['PCS-01'] = {
      id: 'PCS-01',
      type: 'pcs',
      name: 'Power Conversion System',
      position: { x: 850, y: 600 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      rating_kw: 50,
      efficiency: 0.96,
      pwm_frequency_hz: 10000,
      duty_cycle: 0.5,
      enabled: true,
      operating_mode: 'grid_following',
      terminals: [{ id: 'PCS-01-T1', position: { x: 850, y: 570 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
    };
    
    // EV Charger
    network.components['EV-01'] = {
      id: 'EV-01',
      type: 'ev_charger',
      name: 'EV Charger',
      position: { x: 1000, y: 500 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      rating_kw: 22,
      charging_state: 'idle',
      vehicle_soc_percent: 60,
      target_soc_percent: 80,
      terminals: [{ id: 'EV-01-T1', position: { x: 1000, y: 470 }, voltage_level: 'lv', nominal_voltage_kv: 0.415 }],
    } as any;
    
    // Protection Relay
    network.components['RELAY-01'] = {
      id: 'RELAY-01',
      type: 'protection_relay',
      name: 'Feeder Protection',
      position: { x: 300, y: 550 },
      rotation: 0,
      status: 'online',
      voltage_level: 'lv',
      relay_type: 'overcurrent',
      pickup_setting: 160,
      time_dial: 0.5,
      trip_time_s: 0.2,
      monitored_asset: 'FEEDER-01',
      terminals: [],
    } as any;
    
    // Create connections
    network.connections = [
      { id: 'CONN-1', from_component: 'GRID-01', from_terminal: 'GRID-01-T1', to_component: 'CB-IN-01', to_terminal: 'CB-IN-01-T1', wire_type: 'power' },
      { id: 'CONN-2', from_component: 'CB-IN-01', from_terminal: 'CB-IN-01-T2', to_component: 'CT-01', to_terminal: 'CT-01-T1', wire_type: 'power' },
      { id: 'CONN-3', from_component: 'CT-01', from_terminal: 'CT-01-T2', to_component: 'BUS-11KV', to_terminal: 'BUS-11KV-T1', wire_type: 'power' },
      { id: 'CONN-4', from_component: 'BUS-11KV', from_terminal: 'BUS-11KV-T1', to_component: 'TX-01', to_terminal: 'TX-01-HV', wire_type: 'power' },
      { id: 'CONN-5', from_component: 'TX-01', from_terminal: 'TX-01-LV', to_component: 'BUS-415V', to_terminal: 'BUS-415V-T1', wire_type: 'power' },
      { id: 'CONN-6', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'CB-FEEDER-01', to_terminal: 'CB-FEEDER-01-T1', wire_type: 'power' },
      { id: 'CONN-7', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'CB-FEEDER-02', to_terminal: 'CB-FEEDER-02-T1', wire_type: 'power' },
      { id: 'CONN-8', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'CB-FEEDER-03', to_terminal: 'CB-FEEDER-03-T1', wire_type: 'power' },
      { id: 'CONN-9', from_component: 'CB-FEEDER-01', from_terminal: 'CB-FEEDER-01-T2', to_component: 'FEEDER-01', to_terminal: 'FEEDER-01-T1', wire_type: 'power' },
      { id: 'CONN-10', from_component: 'CB-FEEDER-02', from_terminal: 'CB-FEEDER-02-T2', to_component: 'FEEDER-02', to_terminal: 'FEEDER-02-T1', wire_type: 'power' },
      { id: 'CONN-11', from_component: 'CB-FEEDER-03', from_terminal: 'CB-FEEDER-03-T2', to_component: 'FEEDER-03', to_terminal: 'FEEDER-03-T1', wire_type: 'power' },
      { id: 'CONN-12', from_component: 'FEEDER-01', from_terminal: 'FEEDER-01-T2', to_component: 'BUS-FEEDER-01', to_terminal: 'BUS-FEEDER-01-T1', wire_type: 'power' },
      { id: 'CONN-13', from_component: 'FEEDER-02', from_terminal: 'FEEDER-02-T2', to_component: 'BUS-FEEDER-02', to_terminal: 'BUS-FEEDER-02-T1', wire_type: 'power' },
      { id: 'CONN-14', from_component: 'FEEDER-03', from_terminal: 'FEEDER-03-T2', to_component: 'BUS-FEEDER-03', to_terminal: 'BUS-FEEDER-03-T1', wire_type: 'power' },
      { id: 'CONN-15', from_component: 'BUS-FEEDER-01', from_terminal: 'BUS-FEEDER-01-T1', to_component: 'LOAD-11', to_terminal: 'LOAD-11-T1', wire_type: 'power' },
      { id: 'CONN-16', from_component: 'BUS-FEEDER-01', from_terminal: 'BUS-FEEDER-01-T1', to_component: 'LOAD-12', to_terminal: 'LOAD-12-T1', wire_type: 'power' },
      { id: 'CONN-17', from_component: 'BUS-FEEDER-02', from_terminal: 'BUS-FEEDER-02-T1', to_component: 'LOAD-21', to_terminal: 'LOAD-21-T1', wire_type: 'power' },
      { id: 'CONN-18', from_component: 'BUS-FEEDER-02', from_terminal: 'BUS-FEEDER-02-T1', to_component: 'LOAD-22', to_terminal: 'LOAD-22-T1', wire_type: 'power' },
      { id: 'CONN-19', from_component: 'BUS-FEEDER-03', from_terminal: 'BUS-FEEDER-03-T1', to_component: 'LOAD-31', to_terminal: 'LOAD-31-T1', wire_type: 'power' },
      { id: 'CONN-20', from_component: 'BUS-FEEDER-03', from_terminal: 'BUS-FEEDER-03-T1', to_component: 'LOAD-32', to_terminal: 'LOAD-32-T1', wire_type: 'power' },
      { id: 'CONN-21', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'PV-01', to_terminal: 'PV-01-T1', wire_type: 'power' },
      { id: 'CONN-22', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'BESS-01', to_terminal: 'BESS-01-T1', wire_type: 'power' },
      { id: 'CONN-23', from_component: 'BESS-01', from_terminal: 'BESS-01-T1', to_component: 'PCS-01', to_terminal: 'PCS-01-T1', wire_type: 'power' },
      { id: 'CONN-24', from_component: 'BUS-415V', from_terminal: 'BUS-415V-T1', to_component: 'EV-01', to_terminal: 'EV-01-T1', wire_type: 'power' },
    ];
    
    return network;
  }
  
  // History management
  private saveToHistory(): void {
    if (this.historyIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.historyIndex + 1);
    }
    this.history.push(JSON.parse(JSON.stringify(this.network)));
    this.historyIndex = this.history.length - 1;
    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
      this.historyIndex--;
    }
  }
  
  undo(): boolean {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.network = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      return true;
    }
    return false;
  }
  
  redo(): boolean {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.network = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
      return true;
    }
    return false;
  }
  
  canUndo(): boolean { return this.historyIndex > 0; }
  canRedo(): boolean { return this.historyIndex < this.history.length - 1; }

  // Network operations
  getNetwork(): CircuitNetwork { return this.network; }
  
  addComponent(component: CircuitComponent): void {
    this.network.components[component.id] = component;
    this.network.modified_at = new Date().toISOString();
    this.saveToHistory();
  }
  
  removeComponent(id: string): void {
    delete this.network.components[id];
    this.network.connections = this.network.connections.filter(
      conn => conn.from_component !== id && conn.to_component !== id
    );
    this.network.modified_at = new Date().toISOString();
    this.saveToHistory();
  }
  
  updateComponent(id: string, updates: Partial<CircuitComponent>): void {
    if (this.network.components[id]) {
      this.network.components[id] = { ...this.network.components[id], ...updates } as CircuitComponent;
      this.network.modified_at = new Date().toISOString();
      this.saveToHistory();
    }
  }
  
  addConnection(connection: Connection): void {
    this.network.connections.push(connection);
    this.network.modified_at = new Date().toISOString();
    this.saveToHistory();
  }
  
  removeConnection(id: string): void {
    this.network.connections = this.network.connections.filter(conn => conn.id !== id);
    this.network.modified_at = new Date().toISOString();
    this.saveToHistory();
  }

  // Duplicate component
  duplicateComponent(id: string): CircuitComponent | null {
    const original = this.network.components[id];
    if (!original) return null;
    
    const newId = `${original.type.toUpperCase()}-${Date.now()}`;
    const duplicate: CircuitComponent = {
      ...JSON.parse(JSON.stringify(original)),
      id: newId,
      name: `${original.name} (copy)`,
      position: { x: original.position.x + 50, y: original.position.y + 50 },
      terminals: original.terminals.map((t, i) => ({
        ...t,
        id: `${newId}-T${i + 1}`,
        position: { x: t.position.x + 50, y: t.position.y + 50 },
      })),
    };
    
    this.addComponent(duplicate);
    return duplicate;
  }

  // Delete multiple components
  deleteComponents(ids: string[]): void {
    ids.forEach(id => {
      delete this.network.components[id];
      this.network.connections = this.network.connections.filter(
        conn => conn.from_component !== id && conn.to_component !== id
      );
    });
    this.network.modified_at = new Date().toISOString();
    this.saveToHistory();
  }

  // Enhanced validation
  validateTopology(): ValidationResult {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];
    
    // Check for grid source
    const hasGridSource = Object.values(this.network.components).some(c => c.type === 'grid_source');
    if (!hasGridSource) {
      errors.push({
        code: 'NO_GRID_SOURCE',
        message: 'No grid source found in network',
        severity: 'critical',
      });
    }
    
    // Check for isolated buses
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'bus') {
        const hasConnection = this.network.connections.some(
          conn => conn.from_component === comp.id || conn.to_component === comp.id
        );
        if (!hasConnection) {
          errors.push({
            code: 'ISOLATED_BUS',
            message: `Bus ${comp.id} is isolated (no connections)`,
            component_id: comp.id,
            severity: 'major',
          });
        }
      }
    });
    
    // Check for open breakers in critical paths
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'breaker') {
        const breaker = comp as any;
        if (breaker.state === 'open' && breaker.id === 'CB-IN-01') {
          warnings.push({
            code: 'GRID_DISCONNECTED',
            message: 'Incoming breaker is open - network is disconnected from grid',
            component_id: comp.id,
            severity: 'minor',
          });
        }
      }
    });

    // Check voltage compatibility
    this.network.connections.forEach(conn => {
      const fromComp = this.network.components[conn.from_component];
      const toComp = this.network.components[conn.to_component];
      if (fromComp && toComp) {
        const fromTerminal = fromComp.terminals.find(t => t.id === conn.from_terminal);
        const toTerminal = toComp.terminals.find(t => t.id === conn.to_terminal);
        if (fromTerminal && toTerminal) {
          if (fromTerminal.nominal_voltage_kv !== toTerminal.nominal_voltage_kv) {
            // Check if there's a transformer in between
            const hasTransformer = this.network.connections.some(c => 
              (c.from_component === conn.from_component || c.to_component === conn.from_component) &&
              this.network.components[c.from_component]?.type === 'transformer' ||
              this.network.components[c.to_component]?.type === 'transformer'
            );
            if (!hasTransformer && fromComp.type !== 'transformer' && toComp.type !== 'transformer') {
              warnings.push({
                code: 'VOLTAGE_MISMATCH',
                message: `Voltage mismatch: ${fromComp.id} (${fromTerminal.nominal_voltage_kv}kV) to ${toComp.id} (${toTerminal.nominal_voltage_kv}kV)`,
                component_id: conn.from_component,
                severity: 'minor',
              });
            }
          }
        }
      }
    });
    
    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  // Enhanced power flow calculation
  runPowerFlow(): PowerFlowResult {
    const result: PowerFlowResult = {
      converged: true,
      iterations: 3,
      mismatch_kva: 0.1,
      bus_results: {},
      line_results: {},
      transformer_results: {},
      generation_results: {},
      load_results: {},
      battery_results: {},
      grid_result: {
        import_kw: 0,
        export_kw: 0,
        power_factor: 0.98,
        voltage_kv: 11,
        frequency_hz: 50,
      },
      total_losses_kw: 0,
      total_generation_kw: 0,
      total_load_kw: 0,
      power_balance: {
        generation_kw: 0,
        grid_import_kw: 0,
        battery_discharge_kw: 0,
        load_kw: 0,
        battery_charge_kw: 0,
        grid_export_kw: 0,
        losses_kw: 0,
        balance_kw: 0,
      },
    };
    
    // Calculate total load
    let totalLoadKW = 0;
    let totalLoadKVar = 0;
    
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'load') {
        const load = comp as any;
        totalLoadKW += load.active_power_kw;
        totalLoadKVar += load.reactive_power_kvar;
        result.load_results[load.id] = {
          active_power_kw: load.active_power_kw,
          reactive_power_kvar: load.reactive_power_kvar,
          power_factor: load.power_factor,
        };
      }
    });
    result.total_load_kw = totalLoadKW;
    
    // Calculate PV generation (deterministic based on time)
    const hour = new Date().getHours();
    const solarFactor = Math.max(0, Math.sin((hour - 6) * Math.PI / 12));
    let totalPVGeneration = 0;
    
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'pv_array') {
        const pv = comp as any;
        const generation = pv.capacity_kw * solarFactor * pv.efficiency * (1 - pv.curtailment_percent / 100);
        totalPVGeneration += generation;
        result.generation_results[pv.id] = {
          active_power_kw: generation,
          reactive_power_kvar: 0,
          availability_percent: 100,
        };
      }
    });
    result.total_generation_kw = totalPVGeneration;
    
    // Calculate BESS power
    let bessPower = 0;
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'bess') {
        const bess = comp as any;
        const surplus = totalPVGeneration - totalLoadKW;
        
        if (bess.mode === 'auto') {
          if (surplus > 0) {
            bessPower = Math.min(surplus, bess.max_charge_kw);
          } else {
            bessPower = Math.max(surplus, -bess.max_discharge_kw);
          }
        } else if (bess.mode === 'charge') {
          bessPower = bess.max_charge_kw;
        } else if (bess.mode === 'discharge') {
          bessPower = -bess.max_discharge_kw;
        }
        
        result.battery_results[bess.id] = {
          soc_percent: bess.soc_percent,
          power_kw: bessPower,
          state: bessPower > 0 ? 'CHARGING' : bessPower < 0 ? 'DISCHARGING' : 'IDLE',
          efficiency: bess.efficiency,
        };
      }
    });
    
    // Calculate grid exchange
    const netPower = totalLoadKW - totalPVGeneration - bessPower;
    const gridImport = Math.max(0, netPower);
    const gridExport = Math.max(0, -netPower);
    
    result.grid_result = {
      import_kw: gridImport,
      export_kw: gridExport,
      power_factor: 0.98,
      voltage_kv: 11,
      frequency_hz: 50,
    };
    
    // Calculate bus voltages
    const slackVoltage = 1.0;
    const voltageDrop = (totalLoadKW * 0.0001);
    
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'bus') {
        const bus = comp as any;
        let voltage_pu = slackVoltage;
        
        if (bus.id === 'BUS-415V' || bus.id.startsWith('BUS-FEEDER')) {
          voltage_pu = slackVoltage - voltageDrop;
        }
        
        const voltage_v = voltage_pu * bus.voltage_kv * 1000;
        
        result.bus_results[bus.id] = {
          voltage_pu,
          voltage_v,
          angle_deg: -1.2 * (1 - voltage_pu),
          active_power_kw: bus.id === 'BUS-11KV' ? gridImport - gridExport : totalLoadKW,
          reactive_power_kvar: totalLoadKVar,
          loading_percent: (totalLoadKW / 500) * 100,
        };
      }
    });
    
    // Line results
    let totalLosses = 0;
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'line') {
        const line = comp as any;
        const current = totalLoadKW / (3 * 0.415 * 1000) / 3;
        const losses = current * current * line.r_ohm_per_km * line.length_km / 1000;
        const loading = (current / line.rating_a) * 100;
        totalLosses += losses;
        
        result.line_results[line.id] = {
          current_a: current,
          active_power_kw: totalLoadKW / 3,
          reactive_power_kvar: totalLoadKVar / 3,
          losses_kw: losses,
          loading_percent: loading,
          voltage_drop_percent: (voltageDrop * 100),
        };
      }
    });
    result.total_losses_kw = totalLosses;
    
    // Transformer results
    Object.values(this.network.components).forEach(comp => {
      if (comp.type === 'transformer') {
        const tx = comp as any;
        const loading = (totalLoadKW / tx.rating_kva) * 100;
        const hvCurrent = totalLoadKW / (1.732 * tx.hv_voltage_kv);
        const lvCurrent = totalLoadKW / (1.732 * tx.lv_voltage_v / 1000);
        const losses = totalLoadKW * 0.02;
        const efficiency = ((totalLoadKW - losses) / totalLoadKW) * 100;
        
        result.transformer_results[tx.id] = {
          loading_percent: loading,
          hv_current_a: hvCurrent,
          lv_current_a: lvCurrent,
          losses_kw: losses,
          efficiency,
          temperature_c: 45 + loading * 0.3,
          health_index: loading > 90 ? 70 : loading > 75 ? 85 : 95,
        };
      }
    });
    
    // Power balance
    result.power_balance = {
      generation_kw: totalPVGeneration,
      grid_import_kw: gridImport,
      battery_discharge_kw: bessPower < 0 ? -bessPower : 0,
      load_kw: totalLoadKW,
      battery_charge_kw: bessPower > 0 ? bessPower : 0,
      grid_export_kw: gridExport,
      losses_kw: totalLosses,
      balance_kw: totalPVGeneration + gridImport + (bessPower < 0 ? -bessPower : 0) - totalLoadKW - (bessPower > 0 ? bessPower : 0) - gridExport - totalLosses,
    };
    
    return result;
  }

  // Search components
  searchComponents(query: string): CircuitComponent[] {
    const lowerQuery = query.toLowerCase();
    return Object.values(this.network.components).filter(comp =>
      comp.id.toLowerCase().includes(lowerQuery) ||
      comp.name.toLowerCase().includes(lowerQuery) ||
      comp.type.toLowerCase().includes(lowerQuery)
    );
  }

  // Get component
  getComponent(id: string): CircuitComponent | undefined {
    return this.network.components[id];
  }

  // Get components by type
  getComponentsByType(type: string): CircuitComponent[] {
    return Object.values(this.network.components).filter(c => c.type === type);
  }

  // Get connections for component
  getConnectionsForComponent(componentId: string): Connection[] {
    return this.network.connections.filter(
      conn => conn.from_component === componentId || conn.to_component === componentId
    );
  }

  // Get statistics
  getStatistics() {
    const components = Object.values(this.network.components);
    return {
      totalComponents: components.length,
      totalConnections: this.network.connections.length,
      byType: components.reduce((acc, comp) => {
        acc[comp.type] = (acc[comp.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
    };
  }

  // Export/Import
  exportNetwork(): string {
    return JSON.stringify(this.network, null, 2);
  }
  
  importNetwork(json: string): void {
    try {
      this.network = JSON.parse(json);
      this.history = [];
      this.historyIndex = -1;
      this.saveToHistory();
    } catch (e) {
      throw new Error('Invalid network JSON');
    }
  }

  // Version management
  saveVersion(name: string, description: string): NetworkVersion {
    const version: NetworkVersion = {
      id: `v${this.versions.length + 1}`,
      name,
      description,
      timestamp: new Date().toISOString(),
      network: JSON.parse(JSON.stringify(this.network)),
      changes: [],
    };
    this.versions.push(version);
    return version;
  }

  getVersions(): NetworkVersion[] {
    return this.versions;
  }

  loadVersion(versionId: string): boolean {
    const version = this.versions.find(v => v.id === versionId);
    if (version) {
      this.network = JSON.parse(JSON.stringify(version.network));
      this.saveToHistory();
      return true;
    }
    return false;
  }

  // Scenario management
  getScenarios(): Scenario[] {
    return this.scenarios;
  }

  applyScenario(scenarioId: string): boolean {
    const scenario = this.scenarios.find(s => s.id === scenarioId);
    if (!scenario) return false;

    scenario.modifications.forEach(mod => {
      const comp = this.network.components[mod.target_id];
      if (!comp) return;

      switch (mod.type) {
        case 'set_load':
          if (comp.type === 'load' && mod.parameter) {
            (comp as any)[mod.parameter] = mod.value;
          }
          break;
        case 'set_generation':
          if (comp.type === 'pv_array' && mod.parameter) {
            (comp as any)[mod.parameter] = mod.value;
          }
          break;
        case 'set_battery':
          if (comp.type === 'bess' && mod.parameter) {
            (comp as any)[mod.parameter] = mod.value;
          }
          break;
        case 'open_breaker':
          if (comp.type === 'breaker') {
            (comp as any).state = 'open';
          }
          break;
        case 'close_breaker':
          if (comp.type === 'breaker') {
            (comp as any).state = 'closed';
          }
          break;
      }
    });

    this.network.modified_at = new Date().toISOString();
    this.network.scenario = scenarioId;
    this.saveToHistory();
    return true;
  }

  // Simulation control
  getSimulationState(): SimulationState {
    return this.simulationState;
  }

  setSimulationRunning(running: boolean): void {
    this.simulationState.running = running;
  }

  setSimulationSpeed(multiplier: number): void {
    this.simulationState.speed_multiplier = multiplier;
  }

  stepSimulation(): void {
    this.simulationState.simulation_time_s += this.simulationState.time_step_s;
    this.simulationState.last_update = new Date().toISOString();
  }
}
