# GRIDPULSE

GRIDPULSE is a two-application energy digital twin connected through a FastAPI backend.

```text
Laptop A (Circuit Host) ──> FastAPI <── Laptop B (Control Center)
       :3001                         :3002
```

## Current launch model

### Laptop B only
```bash
npm install
npm run dev
```
Open **http://localhost:3002**. This is the default command and launches only the Control Center + Solarex + GridPulse AI chatbot.

### Laptop A only
```bash
npm install
npm run dev:laptop-a
```
Open **http://localhost:3001**. This launches only the editable circuit/engineering host.

### Both frontends
```bash
npm run dev:both
```

### Backend
```bash
./run_backend.sh
```
Open **http://localhost:8000/docs**. On Windows use `run_backend.ps1`.

### Windows full stack
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-gridpulse.ps1
```

Ports are fixed to:
- Laptop A: `3001`
- Laptop B: `3002`
- FastAPI: `8000`

## Two-laptop LAN mode

Laptop A remains the authoritative circuit host/backend machine. Laptop B is the monitoring/control client.

Create `laptop-b/.env.local` from `laptop-b/.env.example` and set:

```text
VITE_API_URL=http://<BACKEND-LAN-IP>:8000
VITE_WS_URL=ws://<BACKEND-LAN-IP>:8000/ws/telemetry
```

Telemetry flow:

```text
Laptop A / FastAPI → WebSocket → Laptop B
Laptop B → REST command → FastAPI → engine
```

## Laptop B features

- Live overview and power balance
- Dedicated animated Transformer and BESS/PCS asset panels
- PWM frequency, duty cycle and waveform telemetry
- Transformer thermal/aging, THD and DGA indicators
- Alarms, acknowledgement, history and reports
- Analytics, forecast, replay and engineering studies
- Solarex roof/location workflow with confirmation/cancel controls
- GridPulse AI chatbot using live telemetry and active alarms

## Laptop A features

- Editable electrical one-line/circuit workspace
- Engineering components and power-flow logic
- Scenarios, validation, studies and digital-twin state
- Authoritative simulation state for the two-laptop architecture

## Verification

Backend regression tests live in `backend/test_*.py`. Before a release, run:

```bash
PYTHONPATH=backend pytest -q backend
```

Frontend production builds use the standard Vite workflow:

```bash
npm run build:laptop-a
npm run build:laptop-b
```

The bundled apps are independent; the legacy combined frontend is retained only under `legacy-combined-frontend/` and is not used by the current launch commands.
