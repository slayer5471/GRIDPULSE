$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'GRIDPULSE — full two-laptop stack' -ForegroundColor Cyan
Write-Host '1) Backend : 8000' -ForegroundColor Green
Write-Host '2) Laptop A: 3000' -ForegroundColor Green
Write-Host '3) Laptop B: 3001' -ForegroundColor Green
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\backend'; python -m uvicorn main:app --host 0.0.0.0 --port 8000"
Start-Sleep -Seconds 1
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\laptop-a'; npm install; npm run dev -- --host 0.0.0.0 --port 3000"
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\laptop-b'; npm install; npm run dev -- --host 0.0.0.0 --port 3001"
Write-Host 'Open Laptop A on :3000 and Laptop B on :3001.' -ForegroundColor Cyan
