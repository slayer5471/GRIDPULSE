# GRIDPULSE removeChild runtime fix

## Root cause
The Laptop B HTML installed a global `window.error` handler that replaced `#root` with `root.innerHTML = ...`. React owns `#root` and was still trying to reconcile/unmount its children. That can produce:

`NotFoundError: Failed to execute 'removeChild' on 'Node': The node to be removed is not a child of this node.`

React documents that external DOM mutations can conflict with React's DOM bookkeeping and lead to crashes. The error reporter is now rendered outside `#root`, and it uses `textContent` rather than replacing React's DOM tree.

## What changed
- Fixed `laptop-b/index.html`.
- `#root` is now exclusively managed by React.
- Boot errors are shown in a separate `#boot-error` element.
- Unhandled promise rejections are reported without mutating `#root`.
- Existing `AlertTriangle` compatibility fix remains included.

## Clean start
From the project root:

```bash
rm -rf node_modules/.vite
npm install
npm run dev:laptop-b -- --force
```

Open `http://localhost:3002`.
