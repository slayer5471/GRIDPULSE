# GRIDPULSE — Physically Separate Laptop A / Laptop B Folders

The project is now organized as two independent frontend applications:

```text
gridpulse/
├── laptop-a/
│   ├── src/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── tsconfig.json
├── laptop-b/
│   ├── src/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── tsconfig.json
├── backend/
└── run_backend.sh
```

## Same physical laptop

Install once at project root:

```bash
npm ci
chmod +x run_backend.sh start-gridpulse.sh
```

Start everything:

```bash
npm run dev
```

Or:

```bash
./start-gridpulse.sh
```

Then open:

- Laptop A: http://localhost:3001
- Laptop B: http://localhost:3002
- FastAPI: http://localhost:8000

## Separate terminals

Backend:

```bash
./run_backend.sh
```

Laptop A:

```bash
npm run dev:laptop-a
```

Laptop B:

```bash
npm run dev:laptop-b
```

## Build separately

```bash
npm run build:laptop-a
npm run build:laptop-b
```

Outputs:

```text
laptop-a/dist/
laptop-b/dist/
```

Laptop A contains only the Circuit Host frontend modules.
Laptop B contains only the Control Center / Solarex frontend modules.
The FastAPI backend remains shared because it is the communication backbone between the two logical nodes.
