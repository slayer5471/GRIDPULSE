from __future__ import annotations

import importlib.util
import copy


def module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ModuleNotFoundError):
        return False
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CoSimulationOrchestrator:
    """Tracks the multi-domain co-simulation stack.

    The suite is operational even when optional engines are unavailable. When the
    corresponding packages are installed, their availability is reflected here and
    adapters can be activated without changing the dashboard contract.
    """

    def __init__(self) -> None:
        self.sequence = 0
        self.sim_time_s = 0.0
        self.wall_time = now_iso()
        self.last_sync: Dict[str, Any] = {}
        self.federates = {
            "distribution": {"name": "OpenDSS Distribution Federate", "package": "opendssdirect", "installed": module_available("opendssdirect")},
            "balanced": {"name": "pandapower Verification Federate", "package": "pandapower", "installed": module_available("pandapower")},
            "optimization": {"name": "PyPSA Optimization Federate", "package": "pypsa", "installed": module_available("pypsa")},
            "orchestration": {"name": "HELICS Coordinator", "package": "helics", "installed": module_available("helics")},
            "communication": {"name": "Cyber / Network Federate", "package": "ns3", "installed": False},
            "edge": {"name": "Wokwi / ESP32 Edge Federate", "package": "wokwi", "installed": False},
            "mqtt": {"name": "MQTT Broker Bridge", "package": "paho.mqtt", "installed": module_available("paho.mqtt")},
        }
        self.fallback_active = True

    def step(self, dt_s: float, *, load_kw: float, pv_kw: float, battery_kw: float, voltage_pu: float, frequency_hz: float) -> Dict[str, Any]:
        self.sequence += 1
        self.sim_time_s += max(0.0, dt_s)
        self.wall_time = now_iso()
        # A deterministic local synchronizer mirrors HELICS' federate contract even
        # when HELICS itself is not installed on the demo machine.
        self.last_sync = {
            "time_s": round(self.sim_time_s, 3),
            "requested_dt_s": round(dt_s, 3),
            "load_kw": round(load_kw, 3),
            "pv_kw": round(pv_kw, 3),
            "battery_kw": round(battery_kw, 3),
            "voltage_pu": round(voltage_pu, 5),
            "frequency_hz": round(frequency_hz, 5),
        }
        active_federates = sum(1 for x in self.federates.values() if x.get("installed"))
        # Keep the deterministic twin authoritative until explicit external solvers
        # are configured. This prevents an absent optional package from breaking SIH.
        self.fallback_active = active_federates < 4
        return {
            "clock": {"sim_time_s": round(self.sim_time_s, 3), "sequence": self.sequence, "wall_time": self.wall_time},
            "federates": self.federates,
            "active_federates": active_federates,
            "synchronization": "HELICS" if self.federates["orchestration"]["installed"] else "LOCAL_TIME_BARRIER",
            "fallback_active": self.fallback_active,
            "last_exchange": self.last_sync,
            "message_bus": {
                "telemetry": "MQTT/JSON ready",
                "commands": "IEEE 2030.5-style DERControl ready",
                "edge": "Wokwi/ESP32 adapter ready",
            },
        }


@dataclass
class TransformerThermalModel:
    ambient_c: float = 27.0
    top_oil_rise_c: float = 17.0
    hotspot_rise_c: float = 12.0
    hot_spot_c: float = 56.0
    aging_acceleration: float = 0.12
    life_loss_percent: float = 0.0
    _oil_state: float = 17.0

    def update(self, load_percent: float, ambient_c: Optional[float] = None, dt_s: float = 1.0, harmonic_k: float = 1.0) -> Dict[str, Any]:
        if ambient_c is not None:
            self.ambient_c = float(ambient_c)
        load_pu = max(0.0, load_percent / 100.0)
        # Reference-model parameters are intentionally explicit rather than hidden.
        ultimate_oil = 34.0 * max(load_pu, 0.05) ** 1.6
        oil_tau_s = 900.0
        self._oil_state += (ultimate_oil - self._oil_state) * clamp(dt_s / oil_tau_s, 0.0, 1.0)
        base_hs = 22.0 * max(load_pu, 0.05) ** 2.0
        harmonic_penalty = max(0.0, harmonic_k - 1.0) * 7.0
        self.top_oil_rise_c = self._oil_state
        self.hotspot_rise_c = base_hs + harmonic_penalty
        self.hot_spot_c = self.ambient_c + self.top_oil_rise_c + self.hotspot_rise_c
        # IEEE C57.91-style Arrhenius reference factor normalized around 110 C.
        self.aging_acceleration = math.exp((15000.0 / 383.0) - (15000.0 / (self.hot_spot_c + 273.15)))
        # Integrate a small life-loss estimate; this is an engineering reference model,
        # not a certification calculation.
        self.life_loss_percent += self.aging_acceleration * max(dt_s, 0.0) / (365.25 * 24 * 3600.0) * 100.0 * 0.0003
        health = "CRITICAL" if self.hot_spot_c >= 120 else ("WARNING" if self.hot_spot_c >= 105 else "HEALTHY")
        return {
            "ambient_c": round(self.ambient_c, 2),
            "load_percent": round(load_percent, 3),
            "load_pu": round(load_pu, 4),
            "top_oil_rise_c": round(self.top_oil_rise_c, 2),
            "hotspot_rise_c": round(self.hotspot_rise_c, 2),
            "hotspot_temperature_c": round(self.hot_spot_c, 2),
            "aging_acceleration_factor": round(self.aging_acceleration, 4),
            "estimated_insulation_life_loss_percent": round(self.life_loss_percent, 6),
            "health": health,
            "model": "IEEE C57.91 reference thermal model",
        }


class HarmonicsMonitor:
    def __init__(self) -> None:
        self.thd_v = 2.1
        self.thd_i = 3.0
        self.k_factor = 1.15
        self.derating_percent = 0.0

    def update(self, *, voltage_pu: float, battery_kw: float, loading_percent: float, scenario: str) -> Dict[str, Any]:
        base_v = 2.0 + abs(voltage_pu - 1.0) * 40.0 + min(2.5, abs(battery_kw) / 30.0)
        base_i = 2.8 + min(4.0, abs(battery_kw) / 25.0)
        if scenario == "HIGH_HARMONICS":
            base_v += 5.8
            base_i += 7.0
        self.thd_v = base_v
        self.thd_i = base_i
        # Normalized harmonic spectrum for K-factor demonstration.
        harmonics = {3: self.thd_i * 0.55, 5: self.thd_i * 0.28, 7: self.thd_i * 0.12, 11: self.thd_i * 0.05}
        numerator = 1.0
        denominator = 1.0
        for order, pct in harmonics.items():
            current = pct / 100.0
            numerator += (order ** 2) * (current ** 2)
            denominator += current ** 2
        self.k_factor = numerator / max(denominator, 1e-9)
        self.derating_percent = clamp(max(0.0, self.k_factor - 1.0) * 3.0 + max(0.0, self.thd_v - 5.0) * 2.0, 0.0, 25.0)
        status = "CRITICAL" if self.thd_v >= 10 else ("WARNING" if self.thd_v >= 5 else "NORMAL")
        return {
            "thd_voltage_percent": round(self.thd_v, 3),
            "thd_current_percent": round(self.thd_i, 3),
            "k_factor": round(self.k_factor, 3),
            "transformer_derating_percent": round(self.derating_percent, 3),
            "status": status,
            "limit_thd_voltage_percent": 5.0,
            "spectrum": {str(k): round(v, 3) for k, v in harmonics.items()},
            "model": "IEEE 519-inspired PCC monitor + C57.110-style K-factor derating",
        }


class BatteryDegradationModel:
    def __init__(self) -> None:
        self.soh_percent = 100.0
        self.capacity_fade_percent = 0.0
        self.throughput_kwh = 0.0
        self.calendar_age_days = 0.0
        self.lcos_estimate_inr_per_kwh = 6.8

    def update(self, *, nominal_capacity_kwh: float, soc_percent: float, power_kw: float, ambient_c: float, dt_s: float, rainflow: Dict[str, Any], import_tariff: float, export_tariff: float) -> Dict[str, Any]:
        cap = max(1.0, nominal_capacity_kwh)
        throughput = abs(power_kw) * max(dt_s, 0.0) / 3600.0
        self.throughput_kwh += throughput
        self.calendar_age_days += max(dt_s, 0.0) / 86400.0
        c_rate = abs(power_kw) / cap
        temp_stress = math.exp(max(0.0, ambient_c - 25.0) / 35.0)
        cycle_damage = (max(0.0, rainflow.get("equivalent_full_cycles", 0.0)) * 0.00002) + throughput / max(cap * 4000.0, 1.0)
        calendar_damage = self.calendar_age_days / 365.25 * 0.012 * temp_stress
        c_rate_damage = max(0.0, c_rate - 0.25) * dt_s / (3600.0 * 24000.0)
        self.capacity_fade_percent = clamp(100.0 * (cycle_damage + calendar_damage + c_rate_damage), 0.0, 35.0)
        self.soh_percent = clamp(100.0 - self.capacity_fade_percent, 65.0, 100.0)
        effective_capacity = cap * self.soh_percent / 100.0
        # A lightweight LCOS indicator that moves with degradation and current tariff spread.
        arbitrage_value = max(0.0, import_tariff - export_tariff)
        self.lcos_estimate_inr_per_kwh = 6.5 + self.capacity_fade_percent * 0.08 - min(1.0, arbitrage_value / 10.0)
        return {
            "soh_percent": round(self.soh_percent, 3),
            "capacity_fade_percent": round(self.capacity_fade_percent, 4),
            "effective_capacity_kwh": round(effective_capacity, 3),
            "throughput_kwh": round(self.throughput_kwh, 3),
            "equivalent_full_cycles": round(float(rainflow.get("equivalent_full_cycles", 0.0)), 4),
            "average_cycle_depth_percent": round(float(rainflow.get("average_cycle_depth_percent", 0.0)), 2),
            "c_rate": round(c_rate, 4),
            "temperature_stress_factor": round(temp_stress, 4),
            "lcos_estimate_inr_per_kwh": round(self.lcos_estimate_inr_per_kwh, 3),
            "model": "Rainflow + calendar/cycle stress reference model",
        }


class SmartInverterController:
    def update(self, *, voltage_pu: float, available_kw: float, battery_kw: float, enabled: bool = True) -> Dict[str, Any]:
        if not enabled:
            return {"volt_var_q_kvar": 0.0, "volt_watt_curtail_percent": 0.0, "ride_through": False, "mode": "DISABLED"}
        q_limit = max(5.0, available_kw * 0.44)
        if voltage_pu <= 0.92:
            q = q_limit
        elif voltage_pu < 0.98:
            q = q_limit * (0.98 - voltage_pu) / 0.06
        elif voltage_pu <= 1.02:
            q = 0.0
        elif voltage_pu < 1.08:
            q = -q_limit * (voltage_pu - 1.02) / 0.06
        else:
            q = -q_limit
        curtail = 0.0
        if voltage_pu > 1.05:
            curtail = clamp((voltage_pu - 1.05) / 0.05 * 100.0, 0.0, 100.0)
        ride_through = 0.88 <= voltage_pu <= 1.10
        return {
            "volt_var_q_kvar": round(q, 3),
            "volt_watt_curtail_percent": round(curtail, 3),
            "available_power_kw": round(available_kw, 3),
            "active_power_after_curtail_kw": round(available_kw * (1.0 - curtail / 100.0), 3),
            "ride_through": ride_through,
            "grid_support": "ABSORB_Q" if q < 0 else ("INJECT_Q" if q > 0 else "NEUTRAL"),
            "profile": "IEEE 1547-inspired Volt-VAR / Volt-Watt",
        }


@dataclass
class MicrogridController:
    mode: str = "GRID_CONNECTED"
    transition_count: int = 0
    resync_progress_percent: float = 0.0
    last_reason: str = "Normal grid-tied operation"
    critical_fraction: float = 0.60
    _restore_counter: int = 0

    def update(self, *, grid_available: bool, load_kw: float, local_generation_kw: float, bess_discharge_kw: float, frequency_hz: float, voltage_pu: float, dt_s: float) -> Dict[str, Any]:
        local_available = max(0.0, local_generation_kw + max(0.0, bess_discharge_kw))
        if not grid_available:
            if self.mode == "GRID_CONNECTED":
                self.mode = "ISLANDING"
                self.transition_count += 1
                self.last_reason = "Utility feed lost; opening PCC and establishing local reference."
            elif self.mode == "ISLANDING":
                self.mode = "ISLANDED"
                self.last_reason = "Local microgrid established in islanded mode."
            self._restore_counter = 0
            deficit = max(0.0, load_kw - local_available)
            max_noncritical = max(0.0, load_kw * (1.0 - self.critical_fraction))
            shed = min(deficit, max_noncritical)
            critical_served = max(0.0, min(load_kw - shed, local_available))
            return {
                "mode": self.mode,
                "pcc_breaker": "OPEN",
                "grid_forming": True,
                "grid_following": False,
                "load_shed_kw": round(shed, 3),
                "critical_load_served_kw": round(critical_served, 3),
                "critical_load_fraction": self.critical_fraction,
                "resynchronization": "BLOCKED",
                "reason": self.last_reason,
            }
        if self.mode in {"ISLANDING", "ISLANDED"}:
            if self.mode != "RESYNC":
                self.mode = "RESYNC"
                self.transition_count += 1
                self.resync_progress_percent = 0.0
            # 2 second engineering transition in demo time.
            self._restore_counter += 1
            self.resync_progress_percent = clamp(self._restore_counter * 25.0, 0.0, 100.0)
            synced = abs(frequency_hz - 50.0) <= 0.08 and abs(voltage_pu - 1.0) <= 0.015 and self.resync_progress_percent >= 100.0
            if synced:
                self.mode = "GRID_CONNECTED"
                self.last_reason = "Voltage, phase/frequency proxy and protection checks passed; PCC reclosed."
                self.resync_progress_percent = 100.0
            return {
                "mode": self.mode,
                "pcc_breaker": "CLOSING" if self.mode == "RESYNC" else "CLOSED",
                "grid_forming": self.mode in {"RESYNC"},
                "grid_following": self.mode == "GRID_CONNECTED",
                "load_shed_kw": 0.0,
                "critical_load_served_kw": round(load_kw, 3),
                "critical_load_fraction": self.critical_fraction,
                "resynchronization": "IN_PROGRESS" if self.mode == "RESYNC" else "COMPLETE",
                "progress_percent": round(self.resync_progress_percent, 1),
                "reason": self.last_reason,
            }
        return {
            "mode": "GRID_CONNECTED",
            "pcc_breaker": "CLOSED",
            "grid_forming": False,
            "grid_following": True,
            "load_shed_kw": 0.0,
            "critical_load_served_kw": round(load_kw, 3),
            "critical_load_fraction": self.critical_fraction,
            "resynchronization": "NOT_REQUIRED",
            "progress_percent": 100.0,
            "reason": "Normal grid-tied operation",
        }


class DGADiagnostic:
    def update(self, *, hotspot_c: float, loading_percent: float, scenario: str) -> Dict[str, Any]:
        methane = clamp(50.0 + max(0.0, hotspot_c - 80.0) * 0.7, 5.0, 95.0)
        ethylene = clamp(18.0 + max(0.0, hotspot_c - 90.0) * 0.8, 2.0, 85.0)
        acetylene = 2.0
        if scenario in {"TRANSFORMER_OVERLOAD", "HIGH_HARMONICS", "VOLTAGE_SAG"}:
            ethylene += 10.0
        if hotspot_c >= 120:
            acetylene += 10.0
        total = methane + ethylene + acetylene
        ch4 = methane / total * 100.0
        c2h4 = ethylene / total * 100.0
        c2h2 = acetylene / total * 100.0
        if c2h2 > 15:
            fault = "High-energy arcing signature"
            severity = "CRITICAL"
        elif c2h4 > 35:
            fault = "Thermal fault signature"
            severity = "WARNING"
        else:
            fault = "Normal / no dominant fault signature"
            severity = "NORMAL"
        return {
            "methane_percent": round(ch4, 2),
            "ethylene_percent": round(c2h4, 2),
            "acetylene_percent": round(c2h2, 2),
            "duval_region": fault,
            "severity": severity,
            "method": "Duval Triangle reference diagnostic",
            "note": "Simulated dissolved-gas values for digital-twin diagnostics.",
        }


class DynamicLineRatingModel:
    """Deterministic reference model for dynamic line rating and critical-span risk.

    This is a simulation/education model, not a certified IEEE 738 or CIGRE TB 601
    compliance implementation. It exposes the same engineering variables so the
    dashboard can demonstrate weather-aware ampacity, confidence bounds, sag risk,
    and spare capacity.
    """

    def __init__(self) -> None:
        self.static_rating_a = 500.0
        self.conductor_temp_c = 65.0
        self.critical_span = "SPAN-03"
        self.last = {}

    @staticmethod
    def _clamp(v: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, v))

    def _method_rating(self, ambient_c: float, wind_mps: float, solar_w_m2: float, conductor_temp_c: float, method: str) -> float:
        # Normalized heat-balance surrogate: resistive + solar heating versus
        # convective + radiative cooling. The coefficients are intentionally
        # explicit and deterministic for a local digital-twin demonstration.
        delta_t = max(1.0, conductor_temp_c - ambient_c)
        conv_factor = 0.82 if method == "IEEE_738" else 0.92
        albedo = 0.05 if method == "IEEE_738" else 0.15
        q_joule_budget = 1.0
        q_solar = (0.55 + albedo * 0.45) * (solar_w_m2 / 1000.0)
        q_conv = conv_factor * (1.0 + 2.4 * math.sqrt(max(0.0, wind_mps))) * (delta_t / 40.0) ** 0.72
        q_rad = 0.18 * ((conductor_temp_c + 273.15) / 338.15) ** 4 - 0.18 * ((ambient_c + 273.15) / 303.15) ** 4
        cooling_margin = max(0.18, q_conv + q_rad + 0.22 - q_solar)
        temp_factor = self._clamp(1.12 - 0.0045 * (ambient_c - 25.0), 0.78, 1.15)
        wind_factor = self._clamp(0.72 + 0.30 * math.sqrt(max(0.0, wind_mps) + 0.05), 0.72, 1.35)
        thermal_factor = self._clamp(math.sqrt(cooling_margin / q_joule_budget), 0.75, 1.35)
        return self.static_rating_a * temp_factor * wind_factor * thermal_factor

    def update(self, *, current_a: float, ambient_c: float, wind_mps: float, solar_w_m2: float, humidity_percent: float = 55.0, span_weather: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        conductor_temp = 42.0 + (current_a / self.static_rating_a) ** 2 * 45.0 - min(10.0, wind_mps * 1.8)
        conductor_temp = self._clamp(conductor_temp, ambient_c + 8.0, 105.0)
        ieee = self._method_rating(ambient_c, wind_mps, solar_w_m2, conductor_temp, "IEEE_738")
        cigre = self._method_rating(ambient_c, wind_mps, solar_w_m2, conductor_temp, "CIGRE_TB_601")
        lower = min(ieee, cigre)
        upper = max(ieee, cigre)
        uncertainty = self._clamp(0.035 + abs(ieee - cigre) / max(upper, 1.0) * 0.8 + max(0.0, 0.55 - wind_mps) * 0.035, 0.025, 0.18)
        confidence_low = lower * (1.0 - uncertainty)
        confidence_high = upper * (1.0 + uncertainty)
        safe_operating = confidence_low
        utilization = current_a / max(safe_operating, 1.0)
        static_utilization = current_a / self.static_rating_a

        spans = span_weather or [
            {"id":"SPAN-01","wind_mps":wind_mps*1.18,"ambient_c":ambient_c-1.0,"slope_deg":0.8,"clearance_m":9.2},
            {"id":"SPAN-02","wind_mps":max(0.3,wind_mps*0.74),"ambient_c":ambient_c+2.5,"slope_deg":1.3,"clearance_m":8.7},
            {"id":"SPAN-03","wind_mps":max(0.2,wind_mps*0.48),"ambient_c":ambient_c+4.0,"slope_deg":2.7,"clearance_m":7.9},
            {"id":"SPAN-04","wind_mps":wind_mps*0.92,"ambient_c":ambient_c+0.5,"slope_deg":1.1,"clearance_m":9.5},
        ]
        critical = []
        for span in spans:
            local_ieee = self._method_rating(float(span.get("ambient_c", ambient_c)), float(span.get("wind_mps", wind_mps)), solar_w_m2, conductor_temp, "IEEE_738")
            local_cigre = self._method_rating(float(span.get("ambient_c", ambient_c)), float(span.get("wind_mps", wind_mps)), solar_w_m2, conductor_temp, "CIGRE_TB_601")
            rating = min(local_ieee, local_cigre)
            clearance = float(span.get("clearance_m", 9.0))
            sag_risk = self._clamp((8.5 - clearance) / 2.0 * 100.0 + max(0.0, conductor_temp - 70.0) * 1.4, 0.0, 100.0)
            thermal_risk = self._clamp((current_a / max(rating,1.0) - 0.78) * 280.0, 0.0, 100.0)
            combined = self._clamp(0.52 * thermal_risk + 0.30 * sag_risk + 0.18 * max(0.0, 1.0 - float(span.get("wind_mps",wind_mps))/8.0) * 100.0, 0.0, 100.0)
            critical.append({
                "id": span["id"],
                "rating_a": round(rating,1),
                "wind_mps": round(float(span.get("wind_mps",wind_mps)),2),
                "ambient_c": round(float(span.get("ambient_c",ambient_c)),1),
                "clearance_m": round(clearance,2),
                "sag_risk_percent": round(sag_risk,1),
                "thermal_risk_percent": round(thermal_risk,1),
                "risk_percent": round(combined,1),
                "critical": combined >= 65.0,
            })
        critical.sort(key=lambda x: x["risk_percent"], reverse=True)
        self.critical_span = critical[0]["id"]

        extra_capacity_a = max(0.0, safe_operating - current_a)
        unlocked_mwh_today = extra_capacity_a / max(self.static_rating_a, 1.0) * 3.2
        confidence_label = "HIGH" if uncertainty < 0.07 else ("MEDIUM" if uncertainty < 0.12 else "LOW")
        status = "CRITICAL" if utilization >= 1.0 else ("WARNING" if utilization >= 0.85 else "NORMAL")
        self.conductor_temp_c = conductor_temp
        self.last = {
            "static_rating_a": round(self.static_rating_a,1),
            "current_a": round(current_a,1),
            "ambient_c": round(ambient_c,1),
            "wind_mps": round(wind_mps,2),
            "solar_w_m2": round(solar_w_m2,1),
            "humidity_percent": round(humidity_percent,1),
            "conductor_temperature_c": round(conductor_temp,1),
            "ieee_738_ampacity_a": round(ieee,1),
            "cigre_tb_601_ampacity_a": round(cigre,1),
            "confidence_low_a": round(confidence_low,1),
            "confidence_high_a": round(confidence_high,1),
            "safe_dynamic_rating_a": round(safe_operating,1),
            "uncertainty_percent": round(uncertainty*100.0,2),
            "confidence": confidence_label,
            "static_utilization_percent": round(static_utilization*100.0,1),
            "dynamic_utilization_percent": round(utilization*100.0,1),
            "spare_capacity_a": round(extra_capacity_a,1),
            "critical_span": self.critical_span,
            "unlocked_renewable_capacity_mwh_today": round(unlocked_mwh_today,3),
            "status": status,
            "spans": critical,
            "model": "IEEE 738 / CIGRÉ TB 601 reference DLR surrogate",
        }
        return copy.deepcopy(self.last)


class DispatchOperationsCopilot:
    def recommend(self, *, load_kw: float, pv_kw: float, grid_import_kw: float, bess_soc: float, transformer_loading: float, dlr: Dict[str, Any], scenario: str) -> Dict[str, Any]:
        actions: List[Dict[str, Any]] = []
        deficit = load_kw - pv_kw
        if transformer_loading >= 90.0:
            actions.append({"priority":"P1","action":"Reduce transformer stress","detail":"Use BESS discharge and/or export curtailment before sustained overload.","expected_effect_kw":round(min(50.0,max(0.0,grid_import_kw)),1)})
        if deficit > 10.0 and bess_soc > 35.0:
            actions.append({"priority":"P1","action":"Dispatch BESS","detail":"Peak-support discharge is available while preserving reserve.","expected_effect_kw":round(min(50.0,deficit),1)})
        if pv_kw > load_kw and dlr.get("spare_capacity_a",0.0) <= 0:
            actions.append({"priority":"P1","action":"Curtail or store surplus","detail":"Dynamic line margin is exhausted; route surplus to BESS before export.","expected_effect_kw":round(max(0.0,pv_kw-load_kw),1)})
        elif pv_kw > load_kw:
            actions.append({"priority":"P2","action":"Use dynamic headroom","detail":"DLR indicates additional transfer capacity; export can increase within the dynamic limit.","expected_effect_kw":round(max(0.0,pv_kw-load_kw),1)})
        if transformer_loading < 70 and dlr.get("spare_capacity_a",0.0) > 80:
            actions.append({"priority":"P3","action":"Accept renewable transfer","detail":"Healthy transformer and line headroom available.","expected_effect_kw":round(dlr.get("spare_capacity_a",0.0),1)})
        if scenario == "GRID_OUTAGE":
            actions.insert(0,{"priority":"P0","action":"Islanding protocol","detail":"Open PCC, establish grid-forming reference and protect critical loads."})
        if not actions:
            actions.append({"priority":"P3","action":"Hold state","detail":"No immediate constraint breach; continue monitoring."})
        spread = max(0.0, 6.25 - 2.75)
        confidence = self._confidence(transformer_loading, dlr.get("uncertainty_percent",10.0), bess_soc)
        return {"mode":"AUTONOMOUS_ADVISORY","confidence_percent":round(confidence,1),"actions":actions[:4],"uncertainty_band_percent":round(min(25.0, dlr.get("uncertainty_percent",10.0)+2.0),1),"economic_spread_inr_per_kwh":round(spread,2)}

    @staticmethod
    def _confidence(tx_loading: float, dlr_uncertainty: float, soc: float) -> float:
        return max(55.0, min(98.0, 96.0 - max(0.0, tx_loading-80.0)*0.35 - dlr_uncertainty*0.8 - max(0.0,35.0-soc)*0.15))


class TopologyOptimizer:
    def recommend(self, *, transformer_loading: float, dlr: Dict[str, Any], grid_available: bool) -> Dict[str, Any]:
        alternate = next((s for s in dlr.get("spans",[]) if s.get("id") != dlr.get("critical_span") and s.get("risk_percent",100) < 55), None)
        if not grid_available:
            return {"status":"BLOCKED","reason":"Grid outage; topology change is deferred to islanding controls.","candidate":None}
        if transformer_loading >= 90 and alternate:
            return {"status":"RECOMMENDED","reason":"Shift a portion of transfer through lower-risk corridor before curtailment.","candidate":alternate["id"],"estimated_relief_percent":round(min(18.0, max(4.0, 100.0-alternate["risk_percent"])) ,1)}
        return {"status":"MONITOR","reason":"No topology change required under current constraints.","candidate":alternate["id"] if alternate else None,"estimated_relief_percent":0.0}




class HighFidelitySuite:
    """All advanced roadmap calculations exposed as one stable state contract."""

    def __init__(self) -> None:
        self.cosim = CoSimulationOrchestrator()
        self.transformer = TransformerThermalModel()
        self.harmonics = HarmonicsMonitor()
        self.battery = BatteryDegradationModel()
        self.inverter = SmartInverterController()
        self.microgrid = MicrogridController()
        self.dga = DGADiagnostic()
        self.dlr = DynamicLineRatingModel()
        self.copilot = DispatchOperationsCopilot()
        self.topology = TopologyOptimizer()

    def update(self, *, load_kw: float, pv_kw: float, battery_kw: float, soc_percent: float,
               voltage_pu: float, frequency_hz: float, loading_percent: float,
               capacity_kwh: float, ambient_c: float, dt_s: float,
               rainflow: Dict[str, Any], import_tariff: float, export_tariff: float,
               grid_available: bool, scenario: str,
               wind_mps: Optional[float] = None, solar_w_m2: Optional[float] = None) -> Dict[str, Any]:
        ambient_value = 27.0 if ambient_c is None else float(ambient_c)
        wind_value = 2.4 if wind_mps is None else float(wind_mps)
        solar_value = 650.0 if solar_w_m2 is None else float(solar_w_m2)
        harmonics = self.harmonics.update(voltage_pu=voltage_pu, battery_kw=battery_kw, loading_percent=loading_percent, scenario=scenario)
        transformer = self.transformer.update(load_percent=loading_percent, ambient_c=ambient_value, dt_s=dt_s, harmonic_k=harmonics["k_factor"])
        batt = self.battery.update(nominal_capacity_kwh=capacity_kwh, soc_percent=soc_percent, power_kw=battery_kw, ambient_c=ambient_value, dt_s=dt_s, rainflow=rainflow, import_tariff=import_tariff, export_tariff=export_tariff)
        inverter = self.inverter.update(voltage_pu=voltage_pu, available_kw=max(0.0, pv_kw), battery_kw=battery_kw)
        microgrid = self.microgrid.update(grid_available=grid_available, load_kw=load_kw, local_generation_kw=pv_kw, bess_discharge_kw=max(0.0, battery_kw), frequency_hz=frequency_hz, voltage_pu=voltage_pu, dt_s=dt_s)
        dga = self.dga.update(hotspot_c=transformer["hotspot_temperature_c"], loading_percent=loading_percent, scenario=scenario)
        line_current = max(10.0, (load_kw + abs(battery_kw)) / (0.415 * math.sqrt(3.0)))
        dlr = self.dlr.update(current_a=line_current, ambient_c=ambient_value, wind_mps=wind_value, solar_w_m2=solar_value, humidity_percent=55.0)
        copilot = self.copilot.recommend(load_kw=load_kw, pv_kw=pv_kw, grid_import_kw=max(0.0, load_kw-pv_kw-battery_kw), bess_soc=soc_percent, transformer_loading=loading_percent, dlr=dlr, scenario=scenario)
        topology = self.topology.recommend(transformer_loading=loading_percent, dlr=dlr, grid_available=grid_available)
        carbon_intensity = max(0.0, 620.0 - 2.2 * max(0.0, pv_kw) + 0.4 * max(0.0, battery_kw))
        carbon_avoided_today = max(0.0, pv_kw) * 0.72 / 1000.0 + max(0.0, dlr.get("unlocked_renewable_capacity_mwh_today",0.0)) * 0.42
        carbon = {
            "grid_intensity_gco2_per_kwh": round(carbon_intensity,2),
            "avoided_today_tco2": round(carbon_avoided_today,4),
            "renewable_capacity_unlocked_mwh_today": round(dlr.get("unlocked_renewable_capacity_mwh_today",0.0),3),
            "method": "Scenario accounting; replace with jurisdictional emissions factors for deployment",
        }
        co = self.cosim.step(dt_s, load_kw=load_kw, pv_kw=pv_kw, battery_kw=battery_kw, voltage_pu=voltage_pu, frequency_hz=frequency_hz)
        return {
            "co_simulation": co,
            "transformer_health": transformer,
            "harmonics": harmonics,
            "battery_health": batt,
            "smart_inverter": inverter,
            "microgrid": microgrid,
            "dga": dga,
            "dlr": dlr,
            "critical_spans": dlr.get("spans", []),
            "dispatch_copilot": copilot,
            "topology_optimizer": topology,
            "carbon": carbon,
            "standards": {
                "transformer": ["IEEE C57.91 reference thermal/aging model", "IEEE C57.110-style harmonic derating"],
                "power_quality": ["IEEE 519-inspired THD monitor"],
                "der": ["IEEE 1547-inspired Volt-VAR / Volt-Watt"],
                "microgrid": ["IEEE 2030.8-inspired islanding/resynchronization workflow"],
                "communications": ["IEEE 2030.5-style DERControl/Metering", "Modbus register emulator", "MQTT edge bridge"],
            },
            "edge": {
                "wokwi": {"status": "READY", "telemetry": ["irradiance", "ambient_temperature", "transformer_oil_temperature"], "transport": "MQTT/WebSocket"},
                "mqtt": {"status": "READY", "topics": ["gridpulse/telemetry/#", "gridpulse/control/#", "gridpulse/events/#"]},
            },
        }
