from __future__ import annotations

import asyncio
import copy
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from .simulation.helics_adapter import federation_contract, availability as helics_availability
    from .simulation.mqtt_bridge import MQTTBridge
    from .simulation.pandapower_adapter import solve_reference as solve_pandapower_reference
    from .simulation.pypsa_adapter import solve_reference as solve_pypsa_reference
    from .simulation.opendss_adapter import OpenDSSAdapter
except ImportError:
    from simulation.helics_adapter import federation_contract, availability as helics_availability
    from simulation.mqtt_bridge import MQTTBridge
    from simulation.pandapower_adapter import solve_reference as solve_pandapower_reference
    from simulation.pypsa_adapter import solve_reference as solve_pypsa_reference
    from simulation.opendss_adapter import OpenDSSAdapter

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

try:
    from .engine import GridTwin
except ImportError:  # supports `uvicorn main:app` from backend/
    from engine import GridTwin


APP_VERSION = "2.0.0-engineering"
app = FastAPI(title="GRIDPULSE Digital Twin Backend", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    # Authentication uses an Authorization header, not browser cookies.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

twin = GridTwin()
clients: set[WebSocket] = set()
opendss_adapter = OpenDSSAdapter()
mqtt_bridge = MQTTBridge()

USERS = {
    "admin": ("admin123", "ADMIN"),
    "operator": ("operator123", "OPERATOR"),
    "viewer": ("viewer123", "VIEWER"),
}


class LoginRequest(BaseModel):
    username: str
    password: str


class CommandRequest(BaseModel):
    command: str
    target: str
    value: Any = None


class AlarmAckRequest(BaseModel):
    alarm_id: str


class BatteryPatch(BaseModel):
    mode: Optional[str] = None
    target_soc: Optional[float] = None
    power_kw: Optional[float] = None
    capacity_kwh: Optional[float] = Field(default=None, gt=0)


class GridPatch(BaseModel):
    enabled: Optional[bool] = None
    import_tariff: Optional[float] = Field(default=None, ge=0)
    export_tariff: Optional[float] = Field(default=None, ge=0)


class NetworkEnvelope(BaseModel):
    network: Dict[str, Any]


class CyberVerifyRequest(BaseModel):
    voltage_v: Optional[float] = None
    power_kw: Optional[float] = None
    battery_power_kw: Optional[float] = None


@app.get("/")
def root() -> Dict[str, Any]:
    return {
        "name": "GRIDPULSE Digital Twin Backend",
        "version": APP_VERSION,
        "architecture": "Laptop A → FastAPI → Laptop B",
        "status": "online",
        "docs": "/docs",
    }


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "version": APP_VERSION,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "sequence": twin.sequence,
        "clients": len(clients),
    }


@app.post("/api/auth/login")
def login(req: LoginRequest) -> Dict[str, Any]:
    record = USERS.get(req.username.lower())
    if not record or record[0] != req.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    # Demo/local LAN token. It is deliberately explicit in the source and should be
    # replaced with proper JWT/PKI for public deployment.
    token = f"gridpulse:{req.username.lower()}:{APP_VERSION}"
    return {"token": token, "role": record[1], "username": req.username.lower()}


@app.get("/api/state")
def get_state() -> Dict[str, Any]:
    return twin.step()


@app.get("/api/history")
def get_history() -> List[Dict[str, Any]]:
    return list(twin.history)


@app.get("/api/alarms")
def get_alarms() -> List[Dict[str, Any]]:
    return list(twin.alarms)


@app.post("/api/alarms/ack")
def acknowledge_alarm(req: AlarmAckRequest) -> Dict[str, Any]:
    alarm_id = str(req.alarm_id)
    twin.acknowledged_alarms.add(alarm_id)
    for alarm in twin.active_alarms:
        if alarm.get("id") == alarm_id:
            alarm["acknowledged"] = True
    for alarm in twin.alarms:
        if alarm.get("id") == alarm_id:
            alarm["acknowledged"] = True
    return {"accepted": True, "alarm_id": alarm_id}


@app.get("/api/scenarios")
def get_scenarios() -> Dict[str, Any]:
    return twin.scenario_status()


class ScenarioRequest(BaseModel):
    scenario_id: str


@app.post("/api/scenarios/apply")
def apply_scenario(req: ScenarioRequest) -> Dict[str, Any]:
    try:
        state = twin.apply_scenario(req.scenario_id)
        return {"accepted": True, "scenario": twin.scenario_status(), "state": state}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/scenarios/reset")
def reset_scenario() -> Dict[str, Any]:
    state = twin.apply_scenario("NORMAL")
    return {"accepted": True, "scenario": twin.scenario_status(), "state": state}


@app.post("/api/commands")
def command(req: CommandRequest) -> Dict[str, Any]:
    try:
        return twin.apply_command(req.command, req.target, req.value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.patch("/api/battery")
def battery_patch(req: BatteryPatch) -> Dict[str, Any]:
    if req.capacity_kwh is not None:
        twin.state["battery"]["capacity_kwh"] = req.capacity_kwh
    if req.mode is not None:
        twin.control["battery_mode"] = req.mode.upper()
    if req.target_soc is not None:
        twin.control["battery_target_soc"] = max(20.0, min(95.0, req.target_soc))
    if req.power_kw is not None:
        twin.control["battery_manual_power_kw"] = req.power_kw
        twin.control["battery_mode"] = "MANUAL"
    return twin.step(force=True)


@app.patch("/api/grid")
def grid_patch(req: GridPatch) -> Dict[str, Any]:
    if req.enabled is not None:
        twin.control["grid_enabled"] = req.enabled
    if req.import_tariff is not None:
        twin.control["import_tariff"] = req.import_tariff
    if req.export_tariff is not None:
        twin.control["export_tariff"] = req.export_tariff
    return twin.step(force=True)


@app.get("/api/pricing")
def pricing() -> Dict[str, Any]:
    return copy.deepcopy(twin.state["pricing"])


@app.get("/api/solarex")
def solarex(locality: str, monthly_bill: float, roof_size: float) -> Dict[str, Any]:
    # Local planning calculation, intentionally deterministic and independent of external APIs.
    specific_yield = 1350.0  # kWh/kWp/year planning assumption
    system_kw = max(0.5, roof_size * 0.18)
    annual_generation = system_kw * specific_yield
    monthly_generation = annual_generation / 12.0
    unit_cost = 65000.0  # INR/kWp planning assumption
    installed_cost = system_kw * unit_cost
    monthly_savings = min(max(monthly_bill, 0.0), monthly_generation * twin.control["import_tariff"])
    payback = installed_cost / max(monthly_savings * 12.0, 1.0)
    return {
        "locality": locality,
        "roof_size_m2": roof_size,
        "system_kw": round(system_kw, 2),
        "panels": int(round(system_kw / 0.55)),
        "annual_generation_kwh": round(annual_generation, 1),
        "monthly_generation_kwh": round(monthly_generation, 1),
        "installed_cost_inr": round(installed_cost),
        "monthly_savings_inr": round(monthly_savings),
        "payback_years": round(payback, 2),
        "co2_saved_kg_per_year": round(annual_generation * 0.72),
        "planning_note": "Offline planning estimate; verify current utility rules before real deployment.",
    }


@app.get("/api/forecast")
def forecast(horizon: int = Query(default=12, ge=1, le=48)) -> Dict[str, Any]:
    return twin.forecast(horizon)


@app.get("/api/intelligence/summary")
def intelligence_summary() -> Dict[str, Any]:
    twin.step()
    return twin.advanced_intelligence()


@app.get("/api/protocol/status")
def protocol_status() -> Dict[str, Any]:
    return twin.protocol_status()


@app.get("/api/cyber/status")
def cyber_status() -> Dict[str, Any]:
    return twin.cyber_status()


@app.post("/api/cyber/verify")
def cyber_verify(req: CyberVerifyRequest) -> Dict[str, Any]:
    current_v = twin.state["buses"][0].get("voltage_v", 415.0) if req.voltage_v is None else req.voltage_v
    measured_p = twin.history[-1]["load_kw"] if twin.history else 0.0
    if req.power_kw is not None:
        measured_p = req.power_kw
    expected_v = twin.state["buses"][0].get("voltage_v", 415.0)
    residual_v = abs(current_v - expected_v)
    risk = min(100.0, residual_v / 12.0)
    return {
        "verified": risk < 30.0,
        "risk_percent": round(risk, 2),
        "measured_voltage_v": round(current_v, 3),
        "reference_voltage_v": round(expected_v, 3),
        "message": "Telemetry accepted by local physics gate." if risk < 30.0 else "Telemetry rejected for physics inconsistency.",
        "fdia": risk >= 60.0,
    }



@app.get("/api/ieee2030_5/der-control")
def ieee_der_control() -> Response:
    """Local XML representation of a 2030.5-style DER control payload."""
    batt = twin.state["battery"]
    xml = f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<DERControl xmlns=\"urn:gridpulse:ieee2030.5\">
  <opModConnect>true</opModConnect>
  <rampTms>1000</rampTms>
  <WMaxLimPct>100</WMaxLimPct>
  <WMinLimPct>0</WMinLimPct>
  <storageControl>
    <targetSocPct>{batt['target_soc']:.2f}</targetSocPct>
    <chargeDischargePowerKw>{batt['power_kw']:.3f}</chargeDischargePowerKw>
  </storageControl>
</DERControl>"""
    return Response(content=xml, media_type="application/xml")


@app.get("/api/ieee2030_5/metering")
def ieee_metering() -> Response:
    st = twin.state
    xml = f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<MirrorMeterReading xmlns=\"urn:gridpulse:ieee2030.5\">
  <voltageV>{st['buses'][0].get('voltage_v', 415.0):.3f}</voltageV>
  <frequencyHz>{st['frequency']:.4f}</frequencyHz>
  <gridImportKw>{st['grid']['import_kw']:.3f}</gridImportKw>
  <gridExportKw>{st['grid']['export_kw']:.3f}</gridExportKw>
  <transformerLoadingPct>{st['transformer']['loading_percent']:.3f}</transformerLoadingPct>
  <transformerTemperatureC>{st['transformer']['temperature_c']:.3f}</transformerTemperatureC>
</MirrorMeterReading>"""
    return Response(content=xml, media_type="application/xml")


@app.get("/api/ieee2030_5/pricing")
def ieee_pricing() -> Response:
    p = twin.state["pricing"]
    xml = f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<PriceResponse xmlns=\"urn:gridpulse:ieee2030.5\">
  <importTariffInrPerKwh>{p['import_tariff']:.4f}</importTariffInrPerKwh>
  <exportTariffInrPerKwh>{p['export_tariff']:.4f}</exportTariffInrPerKwh>
  <currentPeriod>{p['current_period']}</currentPeriod>
</PriceResponse>"""
    return Response(content=xml, media_type="application/xml")

@app.get("/api/studies/ndz")
def ndz(mismatch_kw: float = 0.0, mismatch_kvar: float = 0.0) -> Dict[str, Any]:
    return twin.ndz_test(mismatch_kw, mismatch_kvar)


@app.post("/api/network")
def upload_network(envelope: NetworkEnvelope) -> Dict[str, Any]:
    twin.set_network(envelope.network)
    return {"accepted": True, "component_count": len(envelope.network.get("components", {})), "sequence": twin.sequence}


@app.get("/api/network")
def get_network() -> Dict[str, Any]:
    return twin.network



@app.get("/api/high-fidelity")
def high_fidelity() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}))


@app.get("/api/co-simulation/status")
def co_simulation_status() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("co_simulation", {}))


@app.get("/api/transformer/health")
def transformer_health() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("transformer_health", {}))


@app.get("/api/battery/health")
def battery_health() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("battery_health", {}))


@app.get("/api/power-quality")
def power_quality() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("harmonics", {}))


@app.get("/api/microgrid/status")
def microgrid_status() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("microgrid", {}))


@app.get("/api/dga/status")
def dga_status() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("dga", {}))


@app.get("/api/dlr/status")
def dlr_status() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("dlr", {}))


@app.get("/api/optimization/copilot")
def optimization_copilot() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("dispatch_copilot", {}))


@app.get("/api/topology/recommendation")
def topology_recommendation() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("topology_optimizer", {}))


@app.get("/api/carbon/status")
def carbon_status() -> Dict[str, Any]:
    twin.step()
    return copy.deepcopy(twin.state.get("advanced", {}).get("carbon", {}))


@app.get("/api/simulation/opendss")
def run_opendss(steps: int = Query(default=1, ge=1, le=60)) -> Dict[str, Any]:
    return opendss_adapter.solve_qsts(steps)


@app.get("/api/simulation/pandapower")
def run_pandapower() -> Dict[str, Any]:
    return solve_pandapower_reference()


@app.get("/api/simulation/pypsa")
def run_pypsa() -> Dict[str, Any]:
    return solve_pypsa_reference()


@app.get("/api/simulation/helics")
def helics_status() -> Dict[str, Any]:
    return federation_contract()


@app.get("/api/edge/mqtt")
def mqtt_status() -> Dict[str, Any]:
    return mqtt_bridge.status()


async def broadcast_state() -> None:
    if not clients:
        twin.step()
        return
    payload = {"type": "telemetry", "data": twin.step()}
    dead: List[WebSocket] = []
    for ws in list(clients):
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)


@app.websocket("/ws/telemetry")
async def telemetry_socket(ws: WebSocket, token: Optional[str] = None) -> None:
    # The local SIH demo permits a token or no token; LAN deployment remains the trust boundary.
    await ws.accept()
    clients.add(ws)
    try:
        await ws.send_json({"type": "telemetry", "data": twin.step()})
        while True:
            try:
                message = await asyncio.wait_for(ws.receive_text(), timeout=2.0)
                if message.strip().lower() == "ping":
                    await ws.send_json({"type": "pong", "timestamp": datetime.now(timezone.utc).isoformat()})
            except asyncio.TimeoutError:
                await ws.send_json({"type": "telemetry", "data": twin.step()})
    except WebSocketDisconnect:
        pass
    finally:
        clients.discard(ws)


@app.on_event("startup")
async def startup_task() -> None:
    async def loop() -> None:
        while True:
            await asyncio.sleep(0.5)
            if clients:
                await broadcast_state()
            else:
                twin.step()
    asyncio.create_task(loop())


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=os.getenv("FASTAPI_HOST", "0.0.0.0"),
        port=int(os.getenv("FASTAPI_PORT", "8000")),
        reload=False,
    )
