from engine import GridTwin


def test_high_fidelity_state():
    twin = GridTwin()
    for scenario in [
        "NORMAL", "SOLAR_SURPLUS", "TRANSFORMER_OVERLOAD", "HIGH_HARMONICS",
        "GRID_OUTAGE", "NORMAL", "UNPLANNED_ISLANDING", "NORMAL",
    ]:
        twin.apply_scenario(scenario)
        state = twin.step(force=True)
        advanced = state["advanced"]
        assert "transformer_health" in advanced
        assert "battery_health" in advanced
        assert "harmonics" in advanced
        assert "microgrid" in advanced
