from __future__ import annotations

import copy
import math
import re
import time
import hashlib
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    from .high_fidelity import HighFidelitySuite
except ImportError:
    from high_fidelity import HighFidelitySuite


# Optional industry engines. The backend remains runnable without them.
try:  # pragma: no cover - depends on deployment environment
    import pandapower as pp  # type: ignore
    PANDAPOWER_AVAILABLE = True
except Exception:  # pragma: no cover
    pp = None
    PANDAPOWER_AVAILABLE = False

try:  # pragma: no cover - depends on deployment environment
    import opendssdirect as dss  # type: ignore
    OPENDSS_AVAILABLE = True
except Exception:  # pragma: no cover
    dss = None
    OPENDSS_AVAILABLE = False


@dataclass
class DispatchResult:
    power_kw: float
    objective: float
    reason: str
    projected_soc: float
    projected_import_kw: float
    projected_export_kw: float
    transformer_loading: float


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def rainflow_damage(soc_history: Iterable[float]) -> Dict[str, float]:
    """Lightweight engineering approximation of Rainflow damage.

    It intentionally avoids an external dependency so the SIH demo stays offline.
    The algorithm extracts turning points, counts half/full excursions, and uses a
    Miner-style damage proxy weighted by cycle depth.
    """
    series = [clamp(safe_float(x), 0.0, 100.0) for x in soc_history]
    if len(series) < 3:
        return {"equivalent_full_cycles": 0.0, "damage_fraction": 0.0, "life_percent": 100.0}

    # Compress flat segments and extract turning points.
    cleaned = [series[0]]
    for v in series[1:]:
        if abs(v - cleaned[-1]) >= 0.05:
            cleaned.append(v)
    if len(cleaned) < 3:
        return {"equivalent_full_cycles": 0.0, "damage_fraction": 0.0, "life_percent": 100.0}

    points: List[float] = [cleaned[0]]
    last_sign = 0
    for i in range(1, len(cleaned)):
        delta = cleaned[i] - cleaned[i - 1]
        sign = 1 if delta > 0 else -1
        if last_sign == 0:
            last_sign = sign
        elif sign != last_sign:
            points.append(cleaned[i - 1])
            last_sign = sign
    points.append(cleaned[-1])

    # Stack-based turning-point cycle counting.
    stack: List[float] = []
    full_cycles = 0.0
    damage = 0.0
    cycle_depths: List[float] = []

    for p in points:
        stack.append(p)
        while len(stack) >= 3:
            x = abs(stack[-2] - stack[-3])
            y = abs(stack[-1] - stack[-2])
            if y < x:
                break
            depth = x / 100.0
            # One closed excursion is a half cycle in classic rainflow counting;
            # converting to equivalent full cycles gives a convenient SIH metric.
            increment = 0.5 if len(stack) == 3 else 1.0
            full_cycles += depth * increment
            damage += (depth ** 2.2) * increment
            cycle_depths.append(depth * 100.0)
            del stack[-3:-2]

    # Residual stack excursions count as half cycles.
    for i in range(1, len(stack)):
        depth = abs(stack[i] - stack[i - 1]) / 100.0
        full_cycles += depth * 0.5
        damage += (depth ** 2.2) * 0.5
        cycle_depths.append(depth * 100.0)

    # Normalize so a nominal 100%-depth equivalent full cycle causes ~1/4000
    # battery-life fraction to be consumed in the simulation.
    damage_fraction = min(1.0, damage / 4000.0)
    life_percent = max(0.0, 100.0 * (1.0 - damage_fraction))
    avg_depth = sum(cycle_depths) / len(cycle_depths) if cycle_depths else 0.0
    return {
        "equivalent_full_cycles": round(full_cycles, 4),
        "damage_fraction": round(damage_fraction, 6),
        "life_percent": round(life_percent, 3),
        "average_cycle_depth_percent": round(avg_depth, 2),
    }


class TemporalFusionForecaster:
    """Offline, deterministic temporal-fusion style forecaster.

    This is intentionally a lightweight local surrogate rather than a dependency on
    a heavyweight forecasting package. It keeps the architecture compatible with a
    trained TFT checkpoint later: variable selection, static covariates, gated
    residual weighting, and multi-horizon attention are represented explicitly.
    """

    def __init__(self) -> None:
        self.variable_weights = {
            "solar": 1.00,
            "load": 0.95,
            "hour_sin": 0.35,
            "hour_cos": 0.35,
            "price": 0.15,
            "soc": 0.10,
            "weather": 0.25,
        }

    def forecast(
        self,
        history: List[Dict[str, float]],
        horizon: int = 12,
        static: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Any]:
        static = static or {}
        if not history:
            history = [{"solar_kw": 20.0, "load_kw": 25.0, "battery_soc": 60.0, "price": 6.0}]

        solar = [safe_float(x.get("solar_kw")) for x in history[-96:]]
        load = [safe_float(x.get("load_kw")) for x in history[-96:]]
        soc = [safe_float(x.get("battery_soc"), 60.0) for x in history[-96:]]
        price = [safe_float(x.get("price"), 6.0) for x in history[-96:]]
        now = datetime.now(timezone.utc)

        def seasonal(hour: float) -> float:
            # daylight bell curve, zero outside the usable solar window
            angle = (hour - 6.0) / 12.0 * math.pi
            return max(0.0, math.sin(angle))

        out: List[Dict[str, Any]] = []
        for step in range(1, horizon + 1):
            t = now + timedelta(minutes=15 * step)
            hour = t.hour + t.minute / 60.0
            hsin = math.sin(2 * math.pi * hour / 24.0)
            hcos = math.cos(2 * math.pi * hour / 24.0)

            # Attention-like lag weighting: recent history gets more weight, while
            # the same time-of-day profile provides a stable seasonal prior.
            recent_window = min(16, len(solar))
            recent_solar = sum(solar[-recent_window:]) / recent_window
            recent_load = sum(load[-recent_window:]) / recent_window
            seasonal_solar = max(solar) * seasonal(hour) if solar else 0.0

            # Variable-selection gates emulate TFT VSN behavior.
            gate_solar = self.variable_weights["solar"] * (0.65 + 0.25 * seasonal(hour))
            gate_load = self.variable_weights["load"] * (0.75 + 0.10 * (1.0 if 17 <= hour <= 22 else 0.0))
            gate_price = self.variable_weights["price"]
            denom = gate_solar + gate_load + gate_price + 1e-6
            gate_solar /= denom
            gate_load /= denom

            cloud_factor = 0.92 + 0.05 * math.sin(step / 2.7)
            solar_pred = max(0.0, cloud_factor * (gate_solar * seasonal_solar + (1 - gate_solar) * recent_solar))
            peak_bias = 1.15 if 18 <= hour <= 21 else 0.98
            load_pred = max(0.2, peak_bias * (gate_load * recent_load + (1 - gate_load) * max(recent_load, 1.0) * (1.0 + 0.04 * hsin)))

            price_pred = (sum(price[-12:]) / min(12, len(price))) if price else 6.0
            if 18 <= hour <= 22:
                price_pred *= 1.18

            out.append({
                "timestamp": t.isoformat(),
                "solar_kw": round(solar_pred, 3),
                "load_kw": round(load_pred, 3),
                "net_kw": round(load_pred - solar_pred, 3),
                "price": round(price_pred, 3),
                "confidence": round(clamp(0.96 - 0.02 * step, 0.62, 0.96), 3),
                "attention": {
                    "solar": round(gate_solar, 3),
                    "load": round(gate_load, 3),
                    "price": round(gate_price / denom, 3),
                    "static_bess": round(0.12 + 0.01 * (static.get("bess_capacity_kwh", 200.0) / 200.0), 3),
                },
            })
        return {
            "model": "TFT-style local surrogate",
            "horizon_steps": horizon,
            "step_minutes": 15,
            "forecast": out,
            "static_covariates": static,
            "explanation": "Variable selection + static covariates + gated residual weighting + temporal attention, fully offline.",
        }


class GridTwin:
    def __init__(self) -> None:
        self.network: Dict[str, Any] = {}
        self.sequence = 0
        self.history: deque[Dict[str, float]] = deque(maxlen=2880)
        self.soc_history: deque[float] = deque(maxlen=5000)
        self.command_log: deque[Dict[str, Any]] = deque(maxlen=1000)
        self.alarms: deque[Dict[str, Any]] = deque(maxlen=100)
        self.active_alarms: List[Dict[str, Any]] = []
        self.acknowledged_alarms: set[str] = set()
        self.control = {
            "battery_mode": "AUTO",
            "battery_target_soc": 65.0,
            "battery_manual_power_kw": 0.0,
            "grid_enabled": True,
            "import_tariff": 6.25,
            "export_tariff": 2.75,
            "current_period": "DAY",
            "reactive_power_kvar": 0.0,
            "volt_var_enabled": True,
            "volt_watt_enabled": True,
        }
        self.active_scenario = "NORMAL"
        self._scenario_flags: Dict[str, Any] = {}
        self._last_step = time.monotonic()
        self.forecaster = TemporalFusionForecaster()
        self.high_fidelity = HighFidelitySuite()
        self.state = self._build_initial_state()

    def _build_initial_state(self) -> Dict[str, Any]:
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "sequence": 0,
            "frequency": 50.0,
            "grid": {"voltage_kv": 11.0, "import_kw": 0.0, "export_kw": 0.0, "export_limit_kw": 100.0},
            "transformer": {
                "id": "TX-01", "rating_kva": 500.0, "primary_voltage_kv": 11.0, "secondary_voltage_v": 415.0,
                "loading_percent": 0.0, "temperature_c": 35.0, "efficiency": 98.2, "health": "Healthy",
            },
            "buses": [{"id": "BUS-415V", "voltage_kv": 0.415, "voltage_v": 415.0, "type": "pq"}],
            "houses": [{"id": "H01", "load_kw": 5.0, "pv_kw": 2.0, "net_kw": 3.0, "voltage_v": 415.0}],
            "community": {"id": "COMMUNITY", "load_kw": 18.0, "pv_kw": 25.0, "net_kw": -7.0},
            "battery": {
                "id": "BESS-01", "capacity_kwh": 200.0, "soc_percent": 62.0, "power_kw": 0.0,
                "state": "idle", "mode": "auto", "target_soc": 65.0, "min_soc": 20.0, "max_soc": 95.0,
            },
            "pcs": {
                "id": "PCS-01", "enabled": True, "pwm_frequency_hz": 10000.0,
                "duty_cycle": 0.0, "power_kw": 0.0, "efficiency": 96.0,
                "max_power_kw": 50.0, "carrier_period_ms": 0.1,
                "pulse_on_ms": 0.0, "pulse_off_ms": 0.1,
                "pulses_per_second": 10000.0, "pulse_energy_wh": 0.0,
                "waveform": [0]*20, "transfer_model": "SIMULATED_PWM_AVERAGE_VALUE",
            },
            "scenario": {"id": "NORMAL", "name": "Normal Operation", "active": True},
            "ems_mode": "AUTO",
            "pricing": {"import_tariff": 6.25, "export_tariff": 2.75, "current_period": "DAY"},
            "alarms": [],
            "history": [],
            "advanced": {
                "co_simulation": {}, "transformer_health": {}, "harmonics": {}, "battery_health": {},
                "smart_inverter": {}, "microgrid": {}, "dga": {}, "standards": {}, "edge": {},
            },
        }

    def set_network(self, network: Dict[str, Any]) -> None:
        self.network = copy.deepcopy(network or {})
        self._sync_network_static_fields()
        self.step(force=True)

    def _sync_network_static_fields(self) -> None:
        comps = (self.network or {}).get("components", {}) or {}
        tx = next((c for c in comps.values() if c.get("type") == "transformer"), None)
        bess = next((c for c in comps.values() if c.get("type") == "bess"), None)
        if tx:
            self.state["transformer"]["id"] = tx.get("id", "TX-01")
            self.state["transformer"]["rating_kva"] = safe_float(tx.get("rating_kva"), 500.0)
            self.state["transformer"]["primary_voltage_kv"] = safe_float(tx.get("hv_voltage_kv"), 11.0)
            self.state["transformer"]["secondary_voltage_v"] = safe_float(tx.get("lv_voltage_v"), 415.0)
        if bess:
            self.state["battery"]["id"] = bess.get("id", "BESS-01")
            self.state["battery"]["capacity_kwh"] = safe_float(bess.get("capacity_kwh"), 200.0)
            self.state["battery"]["soc_percent"] = clamp(safe_float(bess.get("soc_percent"), self.state["battery"]["soc_percent"]), 0.0, 100.0)
            self.state["battery"]["min_soc"] = safe_float(bess.get("min_soc_percent"), 20.0)
            self.state["battery"]["max_soc"] = safe_float(bess.get("max_soc_percent"), 95.0)

    SCENARIOS: Dict[str, Dict[str, Any]] = {
        "NORMAL": {"name": "Normal Operation", "description": "Normal mixed solar/load operation."},
        "SOLAR_DEFICIT": {"name": "Solar < Load", "description": "Solar generation is below local demand; grid/BESS compensate."},
        "SOLAR_MATCH": {"name": "Solar = Load", "description": "Solar generation approximately matches local demand."},
        "SOLAR_SURPLUS": {"name": "Solar > Load", "description": "Solar surplus charges BESS and/or exports to grid."},
        "EVENING_PEAK": {"name": "Evening Peak", "description": "High evening demand drives BESS peak shaving."},
        "HIGH_SOLAR": {"name": "High Solar", "description": "High midday PV output creates surplus energy."},
        "HIGH_LOAD": {"name": "High Load", "description": "Large demand stresses grid and transformer."},
        "TRANSFORMER_OVERLOAD": {"name": "Transformer Overload", "description": "Demand drives the transformer beyond 85%/100% loading thresholds."},
        "GRID_OUTAGE": {"name": "Grid Outage", "description": "Utility feed is unavailable; BESS supports local load where possible."},
        "VOLTAGE_SAG": {"name": "Voltage Sag", "description": "Simulated PCC undervoltage event."},
        "VOLTAGE_SWELL": {"name": "Voltage Swell", "description": "Simulated PCC overvoltage event."},
        "BATTERY_CHARGE": {"name": "BESS Charging", "description": "Force BESS charging from available surplus/grid."},
        "BATTERY_DISCHARGE": {"name": "BESS Discharge", "description": "Force BESS discharge to support the load."},
        "BATTERY_LOW": {"name": "BESS Low SOC", "description": "Move BESS near its configured minimum SOC boundary."},
        "PV_TRIP": {"name": "PV Trip", "description": "Solar inverter/PV is unavailable."},
        "PCS_TRIP": {"name": "PCS Trip", "description": "BESS power converter unavailable."},
        "FEEDER_OUTAGE": {"name": "Feeder Outage", "description": "Part of the locality is isolated from the feeder."},
        "FDIA": {"name": "False Data Injection", "description": "Telemetry is intentionally perturbed to exercise physics-based cyber detection."},
        "HIGH_HARMONICS": {"name": "High Harmonics", "description": "Power-electronic harmonic stress tests THD and transformer K-factor derating."},
        "UNPLANNED_ISLANDING": {"name": "Unplanned Islanding", "description": "Grid loss initiates autonomous microgrid transition, load prioritization, and resynchronization."},
    }

    def list_scenarios(self) -> List[Dict[str, Any]]:
        return [{"id": k, **v, "active": k == self.active_scenario} for k, v in self.SCENARIOS.items()]

    def apply_scenario(self, scenario_id: str) -> Dict[str, Any]:
        scenario_id = str(scenario_id or "NORMAL").upper()
        if scenario_id not in self.SCENARIOS:
            raise ValueError(f"Unknown scenario: {scenario_id}")
        previous = self.active_scenario
        self.active_scenario = scenario_id
        self._scenario_flags = {}
        # Keep scenario demonstrations independently triggerable after a low-SOC test.
        if previous == "BATTERY_LOW" and scenario_id != "BATTERY_LOW":
            self.state["battery"]["soc_percent"] = 62.0
        # Restore control defaults before applying scenario-specific behavior.
        self.control["grid_enabled"] = True
        self.control["battery_mode"] = "AUTO"
        if scenario_id == "GRID_OUTAGE":
            self.control["grid_enabled"] = False
            self.control["battery_mode"] = "DISCHARGE"
        elif scenario_id in {"SOLAR_DEFICIT", "EVENING_PEAK", "HIGH_LOAD", "TRANSFORMER_OVERLOAD", "BATTERY_DISCHARGE"}:
            self.control["battery_mode"] = "DISCHARGE"
        elif scenario_id in {"SOLAR_MATCH"}:
            self.control["battery_mode"] = "IDLE"
        elif scenario_id in {"SOLAR_SURPLUS", "HIGH_SOLAR", "BATTERY_CHARGE", "VOLTAGE_SWELL"}:
            self.control["battery_mode"] = "CHARGE"
        elif scenario_id == "BATTERY_LOW":
            self.control["battery_mode"] = "IDLE"
            self.state["battery"]["soc_percent"] = max(self.state["battery"].get("min_soc", 20.0) + 0.2, 20.2)
        elif scenario_id == "PCS_TRIP":
            self._scenario_flags["pcs_trip"] = True
        elif scenario_id == "PV_TRIP":
            self._scenario_flags["pv_trip"] = True
        elif scenario_id == "FDIA":
            self._scenario_flags["fdia"] = True
        elif scenario_id == "FEEDER_OUTAGE":
            self._scenario_flags["feeder_outage"] = True
        elif scenario_id == "HIGH_HARMONICS":
            self.control["grid_enabled"] = True
        elif scenario_id == "UNPLANNED_ISLANDING":
            self.control["grid_enabled"] = False
            self.control["battery_mode"] = "DISCHARGE"
        return self.step(force=True)

    def scenario_status(self) -> Dict[str, Any]:
        return {"active": self.active_scenario, "definition": self.SCENARIOS[self.active_scenario], "scenarios": self.list_scenarios()}

    def _scenario_profile(self) -> Dict[str, Any]:
        sid = self.active_scenario
        profiles = {
            "NORMAL": (1.0, 1.0, None),
            "SOLAR_DEFICIT": (2.2, 0.55, None),
            "SOLAR_MATCH": (4.0, 2.85, "match"),
            "SOLAR_SURPLUS": (3.4, 8.0, "surplus"),
            "EVENING_PEAK": (15.0, 0.35, None),
            "HIGH_SOLAR": (2.2, 11.0, "surplus"),
            "HIGH_LOAD": (17.0, 0.7, None),
            "TRANSFORMER_OVERLOAD": (24.0, 0.25, None),
            "GRID_OUTAGE": (8.0, 0.55, None),
            "VOLTAGE_SAG": (8.0, 0.7, None),
            "VOLTAGE_SWELL": (2.0, 10.0, "surplus"),
            "BATTERY_CHARGE": (2.0, 10.0, "surplus"),
            "BATTERY_DISCHARGE": (12.0, 0.45, None),
            "BATTERY_LOW": (2.0, 1.0, None),
            "PV_TRIP": (2.0, 0.0, None),
            "PCS_TRIP": (9.0, 0.4, None),
            "FEEDER_OUTAGE": (8.0, 0.5, None),
            "FDIA": (2.0, 1.0, None),
            "HIGH_HARMONICS": (12.0, 2.0, None),
            "UNPLANNED_ISLANDING": (10.0, 1.0, None),
        }
        return {"load_mult": profiles.get(sid, (1.0, 1.0, None))[0], "solar_mult": profiles.get(sid, (1.0, 1.0, None))[1], "balance": profiles.get(sid, (1.0, 1.0, None))[2]}

    def _extract_assets(self) -> Tuple[float, float, float, float]:
        comps = (self.network or {}).get("components", {}) or {}
        load_kw = 0.0
        reactive_kvar = 0.0
        pv_kw = 0.0
        bess_capacity = self.state["battery"]["capacity_kwh"]
        for c in comps.values():
            typ = c.get("type")
            if typ in {"load", "motor_load", "community_load", "ev_charger"}:
                p = safe_float(c.get("active_power_kw", c.get("rating_kw", 0.0)))
                load_kw += max(0.0, p)
                reactive_kvar += safe_float(c.get("reactive_power_kvar"), 0.0)
            elif typ == "pv_array":
                cap = max(0.0, safe_float(c.get("capacity_kw"), 0.0))
                irr = clamp(safe_float(c.get("irradiance_w_m2"), 800.0), 0.0, 1200.0) / 1000.0
                eff = clamp(safe_float(c.get("efficiency"), 0.95), 0.0, 1.0)
                curtail = clamp(safe_float(c.get("curtailment_percent"), 0.0), 0.0, 100.0) / 100.0
                state = c.get("operating_state", "online")
                available = cap * irr * eff * (1.0 - curtail)
                pv_kw += available if state != "offline" else 0.0
            elif typ == "bess":
                bess_capacity = max(1.0, safe_float(c.get("capacity_kwh"), bess_capacity))
        if load_kw <= 0:
            load_kw = 24.0
        if pv_kw <= 0:
            hour = datetime.now().hour + datetime.now().minute / 60.0
            solar_factor = max(0.0, math.sin((hour - 6) / 12 * math.pi))
            pv_kw = 35.0 * solar_factor

        profile = self._scenario_profile()
        load_kw *= profile["load_mult"]
        pv_kw *= profile["solar_mult"]

        if profile.get("balance") == "match":
            pv_kw = load_kw
        elif profile.get("balance") == "surplus":
            pv_kw = max(pv_kw, load_kw * 1.8)

        # A grid-interruption or feeder outage is represented as a control/state event;
        # feeder outage also disconnects a portion of the load from the served network.
        if self.active_scenario == "FEEDER_OUTAGE":
            load_kw *= 0.65

        return load_kw, pv_kw, reactive_kvar, bess_capacity

    def volt_var(self, voltage_pu: float, apparent_power_kva: float) -> Dict[str, float]:
        q_limit = 0.44 * max(apparent_power_kva, 1.0)
        v = voltage_pu
        if v <= 0.92:
            q = q_limit
        elif v < 0.98:
            q = q_limit * (0.98 - v) / 0.06
        elif v <= 1.02:
            q = 0.0
        elif v < 1.08:
            q = -q_limit * (v - 1.02) / 0.06
        else:
            q = -q_limit
        return {"q_kvar": round(q, 3), "enabled": bool(self.control["volt_var_enabled"])}

    def volt_watt(self, voltage_pu: float, available_kw: float) -> Dict[str, float]:
        if not self.control["volt_watt_enabled"]:
            return {"curtail_percent": 0.0, "output_kw": available_kw}
        if voltage_pu <= 1.05:
            return {"curtail_percent": 0.0, "output_kw": available_kw}
        if voltage_pu >= 1.10:
            curtail = 100.0
        else:
            curtail = 100.0 * (voltage_pu - 1.05) / 0.05
        return {"curtail_percent": round(clamp(curtail, 0.0, 100.0), 3), "output_kw": available_kw * (1 - curtail / 100.0)}

    def optimize_dispatch(self, load_kw: float, pv_kw: float) -> DispatchResult:
        batt = self.state["battery"]
        capacity = max(1.0, safe_float(batt.get("capacity_kwh"), 200.0))
        soc = safe_float(batt.get("soc_percent"), 50.0)
        min_soc = safe_float(batt.get("min_soc"), 20.0)
        max_soc = safe_float(batt.get("max_soc"), 95.0)
        max_charge = 50.0
        max_discharge = 50.0
        buy = self.control["import_tariff"]
        sell = self.control["export_tariff"]
        tx_rating = max(1.0, safe_float(self.state["transformer"]["rating_kva"], 500.0))

        if self.control["battery_mode"] == "CHARGE":
            candidates = [-(max_charge * i / 10.0) for i in range(0, 11)]
        elif self.control["battery_mode"] == "DISCHARGE":
            candidates = [(max_discharge * i / 10.0) for i in range(0, 11)]
        elif self.control["battery_mode"] == "IDLE":
            candidates = [0.0]
        else:
            candidates = [(-max_charge + (max_charge + max_discharge) * i / 40.0) for i in range(41)]

        best: Optional[DispatchResult] = None
        for p in candidates:
            # p > 0 = discharge to grid/load, p < 0 = charging.
            soc_delta = -(p / max(capacity, 1.0)) * 100.0 * 0.25 / 0.95
            projected_soc = clamp(soc + soc_delta, 0.0, 100.0)
            if projected_soc < min_soc - 0.1 or projected_soc > max_soc + 0.1:
                continue
            net = load_kw - pv_kw - p
            imp = max(0.0, net)
            exp = max(0.0, -net)
            tx_loading = 100.0 * abs(net) / tx_rating
            degradation = abs(p) * 0.018
            overload_penalty = max(0.0, tx_loading - 85.0) ** 2 * 0.05
            soc_penalty = abs(projected_soc - self.control["battery_target_soc"]) * 0.004
            objective = imp * buy - exp * sell + degradation + overload_penalty + soc_penalty
            candidate = DispatchResult(
                power_kw=p,
                objective=objective,
                reason="economic + degradation + transformer constraints",
                projected_soc=projected_soc,
                projected_import_kw=imp,
                projected_export_kw=exp,
                transformer_loading=tx_loading,
            )
            if best is None or candidate.objective < best.objective:
                best = candidate

        return best or DispatchResult(0.0, 0.0, "safe idle fallback", soc, max(0, load_kw - pv_kw), max(0, pv_kw - load_kw), 0.0)

    def _make_alarm(self, severity: str, source: str, message: str) -> Dict[str, Any]:
        # Stable fingerprint prevents a new alarm record on every telemetry tick.
        # Numeric measurements are normalized so "112%" and "113%" represent the
        # same underlying alarm condition while the live message retains the latest value.
        fingerprint_text = re.sub(r"[-+]?\d+(?:\.\d+)?", "#", f"{severity}|{source}|{message}").upper()
        digest = hashlib.sha1(fingerprint_text.encode()).hexdigest()[:10]
        alarm_id = f"AL-{digest}"
        return {
            "id": alarm_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "severity": severity,
            "source": source,
            "message": message,
            "active": True,
            "acknowledged": alarm_id in self.acknowledged_alarms,
        }

    def _physics_anomaly(self, voltage_pu: float, load_kw: float, pv_kw: float, battery_power: float) -> Optional[Dict[str, Any]]:
        apparent = math.sqrt(max(load_kw - pv_kw - battery_power, 0.0) ** 2 + safe_float(self.state["transformer"].get("loading_percent"), 0.0) ** 2)
        if voltage_pu < 0.82 or voltage_pu > 1.15:
            return self._make_alarm("CRITICAL", "PINN-CYBER", f"Telemetry violates physical voltage bounds: {voltage_pu:.3f} p.u.")
        if apparent > 0 and abs(battery_power) > 2 * self.state["battery"].get("capacity_kwh", 200.0):
            return self._make_alarm("CRITICAL", "PINN-CYBER", "BESS command exceeds physically plausible power bound.")
        return None

    def step(self, force: bool = False) -> Dict[str, Any]:
        now_mono = time.monotonic()
        dt = clamp(now_mono - self._last_step, 0.2, 2.0) if not force else 1.0
        self._last_step = now_mono

        load_kw, pv_kw, reactive_kvar, bess_capacity = self._extract_assets()
        self._sync_network_static_fields()

        voltage_pu_base = 1.0
        # Recent net demand produces a simple radial voltage-drop proxy.
        pre_batt = load_kw - pv_kw
        voltage_pu = clamp(1.0 - 0.0035 * abs(pre_batt) - 0.00001 * max(reactive_kvar, 0.0), 0.90, 1.10)

        inverter = self.volt_var(voltage_pu, max(1.0, abs(pre_batt) * 1.05))
        reactive = reactive_kvar + inverter["q_kvar"]
        apparent_pre = math.sqrt(pre_batt * pre_batt + reactive * reactive)
        vw = self.volt_watt(voltage_pu, pv_kw)
        pv_kw = vw["output_kw"]

        dispatch = self.optimize_dispatch(load_kw, pv_kw)
        if self.control["battery_mode"] == "MANUAL":
            manual = safe_float(self.control["battery_manual_power_kw"])
            manual = clamp(manual, -50.0, 50.0)
            dispatch = DispatchResult(
                manual, 0.0, "manual operator command", self.state["battery"]["soc_percent"],
                max(0.0, load_kw - pv_kw - manual), max(0.0, pv_kw + manual - load_kw),
                100.0 * abs(load_kw - pv_kw - manual) / max(1.0, safe_float(self.state["transformer"]["rating_kva"], 500.0)),
            )

        battery_power = 0.0 if self._scenario_flags.get("pcs_trip") else dispatch.power_kw
        current_soc = safe_float(self.state["battery"].get("soc_percent"), 50.0)
        if self.active_scenario == "BATTERY_LOW":
            battery_power = 0.0
        elif self.active_scenario in {"SOLAR_SURPLUS", "HIGH_SOLAR", "BATTERY_CHARGE", "VOLTAGE_SWELL"}:
            available_charge = max(0.0, pv_kw - load_kw)
            battery_power = -min(50.0, max(available_charge, 10.0)) if current_soc > self.state["battery"]["min_soc"] + 0.2 else 0.0
        elif self.active_scenario in {"SOLAR_DEFICIT", "EVENING_PEAK", "HIGH_LOAD", "TRANSFORMER_OVERLOAD", "BATTERY_DISCHARGE", "GRID_OUTAGE"}:
            deficit = max(0.0, load_kw - pv_kw)
            if current_soc <= self.state["battery"]["min_soc"] + 0.2:
                battery_power = 0.0
            elif self.active_scenario == "SOLAR_DEFICIT":
                battery_power = min(25.0, max(0.0, deficit * 0.60))
            else:
                battery_power = min(50.0, max(deficit, 20.0))
        # Battery SOC update; positive power is discharge.
        soc = safe_float(self.state["battery"]["soc_percent"], 50.0)
        if battery_power >= 0:
            soc -= (battery_power * dt / 3600.0) / max(1.0, bess_capacity) * 100.0 / 0.95
        else:
            soc += (-battery_power * dt / 3600.0) / max(1.0, bess_capacity) * 100.0 * 0.95
        soc = clamp(soc, safe_float(self.state["battery"]["min_soc"], 20.0), safe_float(self.state["battery"]["max_soc"], 95.0))

        net_grid = load_kw - pv_kw - battery_power
        grid_import = max(0.0, net_grid) if self.control["grid_enabled"] else 0.0
        grid_export = max(0.0, -net_grid) if self.control["grid_enabled"] else 0.0
        rating = max(1.0, safe_float(self.state["transformer"]["rating_kva"], 500.0))
        loading = 100.0 * math.sqrt(net_grid**2 + reactive**2) / rating
        losses = 0.018 * abs(net_grid) + 0.007 * rating * (loading / 100.0) ** 2
        efficiency = clamp(100.0 * abs(net_grid) / max(abs(net_grid) + losses, 1.0), 90.0, 99.7)
        temperature = 34.0 + 46.0 * (loading / 100.0) ** 1.65
        health = clamp(100.0 - 0.014 * max(0.0, temperature - 35.0) - 0.025 * max(0.0, loading - 80.0), 40.0, 100.0)

        # Frequency responds slightly to sudden net changes, while staying in a realistic range.
        frequency = clamp(50.0 - 0.015 * (net_grid / max(rating, 1.0)) + 0.006 * math.sin(time.time() / 11.0), 49.5, 50.5)
        voltage_pu = clamp(1.0 - 0.0025 * (loading - 40.0) / 40.0 - 0.0007 * (reactive / max(rating, 1.0)), 0.90, 1.08)
        if self.active_scenario == "VOLTAGE_SAG":
            voltage_pu = min(voltage_pu, 0.935)
        elif self.active_scenario == "VOLTAGE_SWELL":
            voltage_pu = max(voltage_pu, 1.065)
        voltage_v = 415.0 * voltage_pu

        self.sequence += 1
        timestamp = datetime.now(timezone.utc).isoformat()
        self.soc_history.append(soc)
        degradation = rainflow_damage(self.soc_history)

        history_point = {
            "timestamp": timestamp,
            "solar_kw": round(pv_kw, 3),
            "load_kw": round(load_kw, 3),
            "grid_import_kw": round(grid_import, 3),
            "grid_export_kw": round(grid_export, 3),
            "battery_soc": round(soc, 3),
            "battery_power_kw": round(battery_power, 3),
            "transformer_loading": round(loading, 3),
            "price": self.control["import_tariff"],
        }
        self.history.append(history_point)

        alarms: List[Dict[str, Any]] = []
        if loading > 100:
            alarms.append(self._make_alarm("CRITICAL", "TRANSFORMER", f"Transformer overload: {loading:.1f}%"))
        elif loading > 85:
            alarms.append(self._make_alarm("WARNING", "TRANSFORMER", f"High transformer loading: {loading:.1f}%"))
        if voltage_pu < 0.95:
            alarms.append(self._make_alarm("WARNING", "INVERTER", f"Undervoltage at PCC: {voltage_pu:.3f} p.u."))
        if voltage_pu > 1.05:
            alarms.append(self._make_alarm("WARNING", "INVERTER", f"Overvoltage at PCC: {voltage_pu:.3f} p.u."))
        if soc <= self.state["battery"]["min_soc"] + 0.1:
            alarms.append(self._make_alarm("INFO", "BESS", "Battery at minimum configured SOC boundary."))
        phys = self._physics_anomaly(voltage_pu, load_kw, pv_kw, battery_power)
        if phys:
            alarms.append(phys)
        if self.active_scenario == "GRID_OUTAGE":
            alarms.append(self._make_alarm("CRITICAL", "GRID", "Utility feed unavailable: microgrid operating in outage mode."))
        if self.active_scenario == "PV_TRIP":
            alarms.append(self._make_alarm("WARNING", "PV-INVERTER", "PV generation unavailable: inverter trip scenario active."))
        if self.active_scenario == "PCS_TRIP":
            alarms.append(self._make_alarm("CRITICAL", "PCS", "BESS PCS unavailable: stored energy cannot be transferred."))
        if self.active_scenario == "FEEDER_OUTAGE":
            alarms.append(self._make_alarm("CRITICAL", "FEEDER", "Feeder outage scenario active: affected load isolated."))
        if self.active_scenario == "FDIA":
            alarms.append(self._make_alarm("CRITICAL", "CYBER", "Simulated false-data injection detected by physics consistency gate."))

        self.active_alarms = alarms
        active_ids = {alarm["id"] for alarm in alarms}
        # Mark previously active conditions as cleared when they disappear.
        for previous in self.alarms:
            if previous.get("active", True) and previous.get("id") not in active_ids:
                previous["active"] = False
        # Forget acknowledgements after a condition has genuinely cleared.
        self.acknowledged_alarms.intersection_update(active_ids)
        for alarm in alarms:
            # Keep a compact history: append only the first active instance or a new
            # occurrence after the previous condition cleared.
            previous = next((a for a in reversed(self.alarms) if a.get("id") == alarm.get("id")), None)
            if previous is None or not previous.get("active", True):
                self.alarms.append(copy.deepcopy(alarm))
            elif previous.get("message") != alarm.get("message"):
                # Refresh the current record in-place rather than creating a duplicate.
                previous.update(copy.deepcopy(alarm))

        display_history = list(self.history)[-240:]
        state = self.state
        state["timestamp"] = timestamp
        state["sequence"] = self.sequence
        state["frequency"] = frequency
        state["grid"] = {
            "voltage_kv": round(11.0, 4),
            "import_kw": round(grid_import, 3),
            "export_kw": round(grid_export, 3),
            "export_limit_kw": self.state["grid"].get("export_limit_kw", 100.0),
        }
        state["transformer"] = {
            **state["transformer"],
            "loading_percent": round(loading, 3),
            "temperature_c": round(temperature, 2),
            "efficiency": round(efficiency, 3),
            "health": "Critical" if health < 60 else ("Warning" if health < 80 else "Healthy"),
        }
        reported_voltage_v = voltage_v
        if self.active_scenario == "FDIA":
            reported_voltage_v = voltage_v + 32.0
        state["buses"] = [{
            "id": "BUS-415V", "voltage_kv": 0.415, "voltage_v": round(reported_voltage_v, 3), "type": "pq"
        }]
        state["houses"] = [{
            "id": "H01", "load_kw": round(min(load_kw, 5.0), 3), "pv_kw": round(min(pv_kw, 3.0), 3),
            "net_kw": round(min(load_kw, 5.0) - min(pv_kw, 3.0), 3), "voltage_v": round(voltage_v, 3)
        }]
        state["community"] = {
            "id": "COMMUNITY", "load_kw": round(max(0.0, load_kw - state["houses"][0]["load_kw"]), 3),
            "pv_kw": round(max(0.0, pv_kw - state["houses"][0]["pv_kw"]), 3),
            "net_kw": round((load_kw - pv_kw) - state["houses"][0]["net_kw"], 3),
        }
        stored_energy_kwh = max(0.0, bess_capacity * soc / 100.0)
        discharging = battery_power > 0.2
        charging = battery_power < -0.2
        local_support_kw = min(max(0.0, battery_power), max(0.0, load_kw - pv_kw))
        grid_export_from_bess_kw = max(0.0, battery_power - local_support_kw)
        solar_surplus_kw = max(0.0, pv_kw - load_kw)
        solar_charge_kw = min(max(0.0, -battery_power), solar_surplus_kw)
        grid_charge_kw = max(0.0, -battery_power - solar_charge_kw)
        state["battery"] = {
            **state["battery"],
            "soc_percent": round(soc, 3),
            "power_kw": round(battery_power, 3),
            "state": "discharging" if discharging else ("charging" if charging else "idle"),
            "mode": self.control["battery_mode"].lower(),
            "target_soc": self.control["battery_target_soc"],
            "stored_energy_kwh": round(stored_energy_kwh, 3),
            "flow_direction": "BESS_TO_BUS" if discharging else ("BUS_TO_BESS" if charging else "IDLE"),
            "energy_flow": {
                "stored_energy_kwh": round(stored_energy_kwh, 3),
                "pcs_power_kw": round(abs(battery_power), 3),
                "to_local_load_kw": round(local_support_kw, 3),
                "to_grid_kw": round(grid_export_from_bess_kw, 3),
                "from_solar_kw": round(solar_charge_kw, 3),
                "from_grid_kw": round(grid_charge_kw, 3),
                "efficiency_percent": round(state["pcs"].get("efficiency", 96.0), 2),
            },
        }
        # Simulated PWM power-stage model: the average battery power is represented as
        # a high-frequency pulse train.  duty = P_avg / P_max, so energy per pulse is
        # P_max * t_on.  This is an averaged converter model for the digital twin, not
        # a transistor-level switching simulation.
        pwm_frequency = 10000.0
        pwm_max_power = 100.0
        duty = clamp(abs(battery_power) / max(pwm_max_power, 1e-6), 0.0, 1.0)
        period_ms = 1000.0 / pwm_frequency
        on_ms = period_ms * duty
        off_ms = period_ms - on_ms
        pulse_energy_wh = pwm_max_power * on_ms / 3600.0
        waveform = [1 if duty > 0 and (i / 20.0) < duty else 0 for i in range(20)]
        state["pcs"] = {
            **state["pcs"],
            "power_kw": round(battery_power, 3),
            "duty_cycle": round(duty, 5),
            "pwm_frequency_hz": pwm_frequency,
            "max_power_kw": pwm_max_power,
            "carrier_period_ms": round(period_ms, 5),
            "pulse_on_ms": round(on_ms, 5),
            "pulse_off_ms": round(off_ms, 5),
            "pulses_per_second": pwm_frequency,
            "pulse_energy_wh": round(pulse_energy_wh, 8),
            "average_power_kw": round(pwm_max_power * duty * (1 if battery_power >= 0 else -1), 3),
            "direction": "DISCHARGE" if battery_power > 0.2 else ("CHARGE" if battery_power < -0.2 else "IDLE"),
            "waveform": waveform,
            "transfer_model": "SIMULATED_PWM_AVERAGE_VALUE",
        }
        # High-fidelity engineering layer: transformer thermal ageing, harmonics,
        # battery degradation, smart-inverter response, microgrid state machine,
        # DGA diagnostic and co-simulation federation status.
        rainflow = degradation
        advanced = self.high_fidelity.update(
            load_kw=load_kw,
            pv_kw=pv_kw,
            battery_kw=battery_power,
            soc_percent=soc,
            voltage_pu=voltage_pu,
            frequency_hz=frequency,
            loading_percent=loading,
            capacity_kwh=bess_capacity,
            ambient_c=27.0 + 2.0 * math.sin(time.time() / 900.0),
            dt_s=dt,
            rainflow=rainflow,
            import_tariff=self.control["import_tariff"],
            export_tariff=self.control["export_tariff"],
            grid_available=bool(self.control["grid_enabled"]),
            scenario=self.active_scenario,
            wind_mps=2.2 + 1.1 * math.sin(time.time() / 180.0),
            solar_w_m2=max(150.0, min(950.0, 180.0 + pv_kw * 42.0)),
        )
        # Advanced protection alarms. These are state-derived and de-duplicated by
        # the same alarm fingerprint mechanism as the core alarms.
        tx_adv = advanced["transformer_health"]
        h_adv = advanced["harmonics"]
        dga_adv = advanced["dga"]
        mg_adv = advanced["microgrid"]
        if tx_adv["hotspot_temperature_c"] >= 120:
            alarms.append(self._make_alarm("CRITICAL", "TX-THERMAL", f"Transformer hot-spot temperature: {tx_adv['hotspot_temperature_c']:.1f} °C"))
        elif tx_adv["hotspot_temperature_c"] >= 105:
            alarms.append(self._make_alarm("WARNING", "TX-THERMAL", f"Elevated transformer hot-spot temperature: {tx_adv['hotspot_temperature_c']:.1f} °C"))
        if h_adv["status"] == "CRITICAL":
            alarms.append(self._make_alarm("CRITICAL", "POWER-QUALITY", f"THD-V above limit: {h_adv['thd_voltage_percent']:.1f}%"))
        elif h_adv["status"] == "WARNING":
            alarms.append(self._make_alarm("WARNING", "POWER-QUALITY", f"THD-V elevated: {h_adv['thd_voltage_percent']:.1f}%"))
        if dga_adv["severity"] == "CRITICAL":
            alarms.append(self._make_alarm("CRITICAL", "DGA", dga_adv["duval_region"]))
        elif dga_adv["severity"] == "WARNING":
            alarms.append(self._make_alarm("WARNING", "DGA", dga_adv["duval_region"]))
        if mg_adv["mode"] == "ISLANDED":
            alarms.append(self._make_alarm("CRITICAL", "MICROGRID", "Microgrid operating in islanded/grid-forming mode."))
        if mg_adv.get("load_shed_kw", 0.0) > 0.1:
            alarms.append(self._make_alarm("WARNING", "LOAD-SHEDDING", f"Non-critical load shed: {mg_adv['load_shed_kw']:.1f} kW"))

        state["advanced"] = advanced
        state["scenario"] = {"id": self.active_scenario, "name": self.SCENARIOS[self.active_scenario]["name"], "active": True}
        state["ems_mode"] = self.control["battery_mode"]
        state["pricing"] = {
            "import_tariff": self.control["import_tariff"],
            "export_tariff": self.control["export_tariff"],
            "current_period": self.control["current_period"],
        }
        state["alarms"] = copy.deepcopy(self.active_alarms)
        state["alarm_history"] = list(self.alarms)[-50:]
        state["history"] = display_history
        self.state = state
        return copy.deepcopy(state)

    def apply_command(self, command: str, target: str, value: Any = None) -> Dict[str, Any]:
        command = command.upper()
        target = target.upper()
        entry = {"timestamp": datetime.now(timezone.utc).isoformat(), "command": command, "target": target, "value": value}
        self.command_log.append(entry)

        if command in {"BATTERY_MODE", "SET_BATTERY_MODE"}:
            mode = str(value or "AUTO").upper()
            if mode not in {"AUTO", "CHARGE", "DISCHARGE", "IDLE", "MANUAL"}:
                raise ValueError("Unsupported battery mode")
            self.control["battery_mode"] = mode
        elif command in {"BATTERY_POWER", "SET_BATTERY_POWER"}:
            self.control["battery_manual_power_kw"] = clamp(safe_float(value), -50.0, 50.0)
            self.control["battery_mode"] = "MANUAL"
        elif command in {"BATTERY_CHARGE", "CHARGE_BATTERY"}:
            self.control["battery_manual_power_kw"] = -abs(clamp(safe_float(value, 50.0), 0.0, 50.0))
            self.control["battery_mode"] = "MANUAL"
        elif command in {"BATTERY_DISCHARGE", "DISCHARGE_BATTERY"}:
            self.control["battery_manual_power_kw"] = abs(clamp(safe_float(value, 50.0), 0.0, 50.0))
            self.control["battery_mode"] = "MANUAL"
        elif command in {"BATTERY_STOP", "STOP_BATTERY"}:
            self.control["battery_manual_power_kw"] = 0.0
            self.control["battery_mode"] = "IDLE"
        elif command == "SET_TARGET_SOC":
            self.control["battery_target_soc"] = clamp(safe_float(value, 65.0), 20.0, 95.0)
        elif command == "GRID_ENABLE":
            self.control["grid_enabled"] = bool(value)
        elif command == "IMPORT_TARIFF":
            self.control["import_tariff"] = max(0.0, safe_float(value, 6.25))
        elif command == "EXPORT_TARIFF":
            self.control["export_tariff"] = max(0.0, safe_float(value, 2.75))
        elif command == "VOLT_VAR":
            self.control["volt_var_enabled"] = bool(value)
        elif command == "VOLT_WATT":
            self.control["volt_watt_enabled"] = bool(value)
        elif command in {"SCENARIO", "SET_SCENARIO"}:
            return self.apply_scenario(str(value or "NORMAL")) | {"accepted": True, "safe": True}
        elif command == "TRIP_GRID":
            self.control["grid_enabled"] = False
        elif command == "RESTORE_GRID":
            self.control["grid_enabled"] = True
        else:
            # Preserve compatibility with existing UI commands. Unknown commands are
            # logged but do not mutate electrical state unsafely.
            return {"accepted": True, "safe": True, "message": f"Command {command} logged for target {target}."}

        self.step(force=True)
        return {"accepted": True, "safe": True, "message": f"Command {command} applied to {target}.", "state": self.state}

    def forecast(self, horizon: int = 12) -> Dict[str, Any]:
        static = {
            "bess_capacity_kwh": self.state["battery"]["capacity_kwh"],
            "transformer_rating_kva": self.state["transformer"]["rating_kva"],
            "roof_size_m2": 80.0,
        }
        return self.forecaster.forecast(list(self.history), horizon=horizon, static=static)

    def advanced_intelligence(self) -> Dict[str, Any]:
        forecast = self.forecast(12)
        dispatch = self.optimize_dispatch(
            sum(h.get("load_kw", 0) for h in list(self.history)[-1:]) or 0.0,
            sum(h.get("solar_kw", 0) for h in list(self.history)[-1:]) or 0.0,
        )
        degradation = rainflow_damage(self.soc_history)
        voltage_pu = self.state["buses"][0].get("voltage_v", 415.0) / 415.0
        vv = self.volt_var(voltage_pu, self.state["transformer"]["rating_kva"])
        vw = self.volt_watt(voltage_pu, self.history[-1]["solar_kw"] if self.history else 0.0)
        return {
            "engines": {
                "pandapower": {"installed": PANDAPOWER_AVAILABLE, "role": "fast topology / balanced verification"},
                "opendss": {"installed": OPENDSS_AVAILABLE, "role": "unbalanced QSTS / annual studies"},
                "fallback": {"installed": True, "role": "offline deterministic distribution twin"},
            },
            "forecast": forecast,
            "dispatch": {
                "recommended_battery_power_kw": round(dispatch.power_kw, 3),
                "objective": round(dispatch.objective, 4),
                "reason": dispatch.reason,
                "projected_soc": round(dispatch.projected_soc, 3),
                "projected_import_kw": round(dispatch.projected_import_kw, 3),
                "projected_export_kw": round(dispatch.projected_export_kw, 3),
                "projected_transformer_loading": round(dispatch.transformer_loading, 3),
            },
            "battery_degradation": degradation,
            "inverter": {
                "voltage_pu": round(voltage_pu, 4),
                "volt_var_q_kvar": vv["q_kvar"],
                "volt_watt_curtail_percent": vw["curtail_percent"],
                "standards_profile": "IEEE 1547-inspired Category B demo curve",
            },
            "protocol": self.protocol_status(),
            "cyber": self.cyber_status(),
            "high_fidelity": copy.deepcopy(self.state.get("advanced", {})),
        }

    def protocol_status(self) -> Dict[str, Any]:
        soc = self.state["battery"]["soc_percent"]
        return {
            "ieee_2030_5": {
                "enabled": True,
                "transport": "HTTP/TLS-ready local adapter",
                "role_a": "DER Client",
                "role_b": "Utility Aggregator",
                "function_sets": ["DER Control", "Metering", "Mirrored Metering", "Pricing"],
            },
            "modbus_tcp": {
                "enabled": True,
                "registers": {
                    "40001": round(soc, 2),
                    "40002": round(self.state["battery"]["power_kw"], 2),
                    "40003": round(100.0, 2),
                    "40004": round(self.state["transformer"]["temperature_c"], 2),
                    "40005": round(self.state["battery"]["min_soc"], 2),
                    "40006": round(self.state["battery"]["max_soc"], 2),
                },
            },
        }

    def cyber_status(self) -> Dict[str, Any]:
        voltage_pu = self.state["buses"][0].get("voltage_v", 415.0) / 415.0
        last = self.history[-1] if self.history else {}
        expected = clamp(1.0 - 0.0025 * (self.state["transformer"]["loading_percent"] - 40.0) / 40.0, 0.90, 1.08)
        residual = abs(voltage_pu - expected)
        risk = clamp(residual * 650.0, 0.0, 100.0)
        if self.active_scenario == "FDIA":
            residual = max(residual, 0.08)
            risk = max(risk, 72.0)
        return {
            "tls13_ready": True,
            "pki_ready": True,
            "physics_residual": round(residual, 5),
            "fdia_risk_percent": round(risk, 2),
            "status": "BLOCK" if risk > 60 else ("REVIEW" if risk > 25 else "PASS"),
            "last_command": self.command_log[-1] if self.command_log else None,
            "verified_measurements": ["voltage", "power_balance", "transformer_loading", "BESS_power"],
            "note": "Physics-based verification is a local safety gate; TLS/PKI hooks are ready for deployment.",
        }

    def ndz_test(self, mismatch_kw: float = 0.0, mismatch_kvar: float = 0.0) -> Dict[str, Any]:
        q_f = math.sqrt(max(0.0, mismatch_kw ** 2 + mismatch_kvar ** 2)) / max(abs(mismatch_kw) + abs(mismatch_kvar), 1e-6)
        # Q_f ~= 1 when the real/reactive balance is closely matched.
        ndz = abs(q_f - 0.707) < 0.04 and abs(mismatch_kw) < 0.5 and abs(mismatch_kvar) < 0.5
        return {
            "test": "anti-islanding NDZ emulation",
            "quality_factor_proxy": round(q_f, 4),
            "mismatch_kw": mismatch_kw,
            "mismatch_kvar": mismatch_kvar,
            "inside_ndz": ndz,
            "ride_through_required": ndz,
            "expected_trip_time_s": 2.0,
        }
