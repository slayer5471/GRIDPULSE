# Wokwi edge model

Use an ESP32 project with MQTT/WebSockets to publish:

- `gridpulse/telemetry/irradiance`
- `gridpulse/telemetry/ambient_c`
- `gridpulse/telemetry/transformer_oil_c`
- `gridpulse/control/#`

The JSON diagram is an input topology; add the ESP32 firmware from the integration guide before connecting to a live broker.
