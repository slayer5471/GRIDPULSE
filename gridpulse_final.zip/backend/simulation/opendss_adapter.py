from __future__ import annotations
from pathlib import Path
from typing import Any, Dict

try:
    import opendssdirect as dss
except Exception:
    dss = None


class OpenDSSAdapter:
    def __init__(self, model_path: str | None = None) -> None:
        self.model_path = Path(model_path) if model_path else Path(__file__).with_name("opendss_master.dss")
        self.available = dss is not None
        self.last_result: Dict[str, Any] = {"available": self.available}

    def solve_qsts(self, steps: int = 1) -> Dict[str, Any]:
        if not self.available:
            return {"available": False, "status": "FALLBACK", "message": "Install opendssdirect.py to execute the OpenDSS model."}
        dss.Basic.ClearAll()
        dss.Text.Command(f'Compile [{self.model_path}]')
        vals=[]
        for _ in range(max(1, int(steps))):
            dss.Solution.Solve()
            vals.append({
                "converged": bool(dss.Solution.Converged()),
                "total_kw": float(dss.Circuit.TotalPower()[0]) * -1.0,
                "total_kvar": float(dss.Circuit.TotalPower()[1]) * -1.0,
            })
            try:
                dss.Solution.IncStep()
            except Exception:
                pass
        self.last_result={"available":True,"status":"SOLVED","steps":len(vals),"results":vals[-1] if vals else None}
        return self.last_result
