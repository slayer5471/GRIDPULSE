from __future__ import annotations
from typing import Any, Dict
try:
    import paho.mqtt.client as mqtt
except Exception:
    mqtt = None

class MQTTBridge:
    def __init__(self, broker: str = "localhost", port: int = 1883) -> None:
        self.broker=broker
        self.port=port
        self.available=mqtt is not None
        self.connected=False
        self.topics=["gridpulse/telemetry/#","gridpulse/control/#","gridpulse/events/#"]

    def status(self) -> Dict[str, Any]:
        return {"available": self.available, "connected": self.connected, "broker": self.broker, "port": self.port, "topics": self.topics}

    def connect(self) -> Dict[str, Any]:
        if mqtt is None:
            return {"accepted": False, "status": "FALLBACK", "message": "Install paho-mqtt for an external broker connection."}
        client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="gridpulse-backend")
        client.connect(self.broker,self.port,60)
        client.loop_start()
        self.connected=True
        return {"accepted": True, **self.status()}
