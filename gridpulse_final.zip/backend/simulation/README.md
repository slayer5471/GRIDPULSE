# GRIDPULSE high-fidelity simulation adapters

Optional integrations sit behind the same telemetry contract used by the deterministic digital twin.

- `opendss_adapter.py`: OpenDSS / QSTS adapter.
- `pandapower_adapter.py`: balanced verification and time-series adapter.
- `helics_adapter.py`: HELICS federation interface when `helics` is installed.
- `mqtt_bridge.py`: MQTT topic bridge.
- `wokwi/diagram.json`: virtual ESP32 sensor topology for demo/HIL.

The base GRIDPULSE backend does not require these external runtimes; it exposes a deterministic fallback so SIH demonstrations remain repeatable.
