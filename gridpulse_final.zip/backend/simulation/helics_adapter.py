from __future__ import annotations
from typing import Any, Dict
try:
    import helics as h
except Exception:
    h = None


def availability() -> Dict[str, Any]:
    return {"available": h is not None, "package": "helics", "role": "co-simulation time and message synchronization"}


def federation_contract() -> Dict[str, Any]:
    return {
        "federates": ["OpenDSS", "GRIDPULSE Controller", "Communication", "Wokwi/ESP32"],
        "time_resolution_s": 1.0,
        "interfaces": {"telemetry": "value subscriptions", "controls": "message endpoints"},
        "availability": availability(),
    }
