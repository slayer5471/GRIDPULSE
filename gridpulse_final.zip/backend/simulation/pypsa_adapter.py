from __future__ import annotations
from typing import Any, Dict
try:
    import pypsa
except Exception:
    pypsa = None


def solve_reference() -> Dict[str, Any]:
    if pypsa is None:
        return {"available": False, "status": "FALLBACK", "message": "Install pypsa for optimization/economic-dispatch studies."}
    n = pypsa.Network()
    n.add("Bus", "LV", v_nom=0.415)
    n.add("Generator", "Solar", bus="LV", p_nom=0.050, p_set=0.035, marginal_cost=0.0)
    n.add("Load", "Community", bus="LV", p_set=0.024)
    n.add("StorageUnit", "BESS", bus="LV", p_nom=0.050, max_hours=4, state_of_charge_initial=0.62, marginal_cost=0.03)
    try:
        n.optimize(solver_name="highs")
        return {"available": True, "status": "SOLVED", "objective": float(n.objective) if n.objective is not None else None}
    except Exception as exc:
        return {"available": True, "status": "MODEL_READY", "message": str(exc)}
