from __future__ import annotations
from typing import Any, Dict

try:
    import pandapower as pp
except Exception:
    pp = None


def build_reference_network() -> Dict[str, Any]:
    if pp is None:
        return {"available": False, "status": "FALLBACK"}
    net = pp.create_empty_network(sn_mva=1.0)
    b_hv = pp.create_bus(net, vn_kv=11.0, name="GRID-BUS")
    b_lv = pp.create_bus(net, vn_kv=0.415, name="LV-BUS")
    pp.create_ext_grid(net, b_hv, vm_pu=1.0)
    pp.create_transformer_from_parameters(net, b_hv, b_lv, sn_mva=0.5, vn_hv_kv=11.0, vn_lv_kv=0.415,
        vk_percent=4.0, vkr_percent=1.0, pfe_kw=0.8, i0_percent=0.2)
    pp.create_load(net, b_lv, p_mw=0.024, q_mvar=0.008, name="COMMUNITY-LOAD")
    pp.create_sgen(net, b_lv, p_mw=0.035, q_mvar=0.0, name="COMMUNITY-PV")
    return {"available": True, "status": "BUILT", "network": net}


def solve_reference() -> Dict[str, Any]:
    built = build_reference_network()
    if not built.get("available"):
        return built
    net = built["network"]
    pp.runpp(net)
    return {"available": True, "status": "SOLVED", "bus_vm_pu": [float(x) for x in net.res_bus.vm_pu.tolist()],
            "line_loading_pct": [float(x) for x in net.res_line.loading_percent.tolist()]}
