# GRIDPULSE Digital Twin Backend

Laptop A runs the electrical twin and exposes this FastAPI service locally. Laptop B connects to Laptop A over the LAN.

## Run

```bash
cd backend
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The backend works in an **offline deterministic fallback mode** when Pandapower/OpenDSS are not installed. If those packages are available, their presence is exposed through `/api/intelligence/summary` so a deployment can route higher-fidelity studies to them.

## Key endpoints

- `/api/state`
- `/api/history`
- `/api/commands`
- `/api/network`
- `/api/forecast`
- `/api/intelligence/summary`
- `/api/protocol/status`
- `/api/cyber/status`
- `/api/studies/ndz`
- `/ws/telemetry`

The implementation includes an offline distribution twin, tariff-aware battery dispatch, battery degradation analytics, Volt-VAR / Volt-Watt behavior, IEEE 2030.5-style function-set mapping, Modbus register emulation, FDIA/physics validation hooks, and a temporal-fusion-style local forecaster.
