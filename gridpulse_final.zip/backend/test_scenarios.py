from engine import GridTwin


SCENARIO_CHECKS = {
    "SOLAR_DEFICIT": lambda s: s["battery"]["power_kw"] > 0 and s["grid"]["import_kw"] > 0,
    "SOLAR_MATCH": lambda s: abs(s["battery"]["power_kw"]) < 1e-6,
    "SOLAR_SURPLUS": lambda s: s["battery"]["power_kw"] < 0 and s["grid"]["export_kw"] > 0,
    "EVENING_PEAK": lambda s: s["battery"]["power_kw"] > 0 and s["transformer"]["loading_percent"] > 50,
    "TRANSFORMER_OVERLOAD": lambda s: s["transformer"]["loading_percent"] > 100 and any(a["severity"] == "CRITICAL" for a in s["alarms"]),
    "GRID_OUTAGE": lambda s: s["grid"]["import_kw"] == 0 and any(a["source"] == "GRID" for a in s["alarms"]),
    "VOLTAGE_SAG": lambda s: s["buses"][0]["voltage_v"] / 415 < 0.95,
    "VOLTAGE_SWELL": lambda s: s["buses"][0]["voltage_v"] / 415 > 1.05,
    "BATTERY_CHARGE": lambda s: s["battery"]["power_kw"] < 0 and s["pcs"]["duty_cycle"] > 0,
    "BATTERY_DISCHARGE": lambda s: s["battery"]["power_kw"] > 0 and s["pcs"]["duty_cycle"] > 0,
    "BATTERY_LOW": lambda s: s["battery"]["soc_percent"] <= s["battery"]["min_soc"] + 0.5,
    "PV_TRIP": lambda s: s["community"]["pv_kw"] + sum(h["pv_kw"] for h in s["houses"]) == 0 and any(a["source"] == "PV-INVERTER" for a in s["alarms"]),
    "PCS_TRIP": lambda s: s["battery"]["power_kw"] == 0 and any(a["source"] == "PCS" for a in s["alarms"]),
    "FEEDER_OUTAGE": lambda s: any(a["source"] == "FEEDER" for a in s["alarms"]),
    "FDIA": lambda s: any(a["source"] == "CYBER" for a in s["alarms"]) and s["buses"][0].get("voltage_v", 0) > 415,
}


def test_all_declared_scenarios():
    twin = GridTwin()
    for name, check in SCENARIO_CHECKS.items():
        state = twin.apply_scenario(name)
        assert check(state), f"Scenario failed: {name}"


def test_state_invariants():
    twin = GridTwin()
    state = twin.step(force=True)
    assert state["transformer"]["rating_kva"] > 0
    assert state["battery"]["capacity_kwh"] > 0
    assert 0 <= state["battery"]["soc_percent"] <= 100
    assert state["frequency"] > 0
