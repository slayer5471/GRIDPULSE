# GRIDPULSE on Windows

## 1. Install prerequisites

- Python 3.11+
- Node.js 20+
- npm

## 2. Install frontend dependencies

From the GRIDPULSE root:

```powershell
npm install
```

## 3. Start everything

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-gridpulse.ps1
```

This opens:

- Laptop A: `http://localhost:3000`
- Laptop B: `http://localhost:3001`
- FastAPI: `http://localhost:8000/docs`

## 4. Credentials

- Admin: `admin` / `admin123`
- Operator: `operator` / `operator123`
- Viewer: `viewer` / `viewer123`

## 5. Two-laptop mode

Run the backend on Laptop A (or the designated backend host). Set Laptop B's `VITE_API_URL` and `VITE_WS_URL` to the LAN address of the backend host, then run Laptop B with a LAN bind.

Laptop A remains the authoritative circuit host. Laptop B remains the control/monitoring client.
