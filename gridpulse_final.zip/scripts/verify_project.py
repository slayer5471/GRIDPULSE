from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

for path in (ROOT / "backend").rglob("*.py"):
    py_compile.compile(str(path), doraise=True)

cmd = [sys.executable, "-m", "pytest", "-q", "backend"]
proc = subprocess.run(cmd, cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "backend")})
raise SystemExit(proc.returncode)
