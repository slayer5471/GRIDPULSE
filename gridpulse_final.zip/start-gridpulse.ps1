$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'Starting GRIDPULSE backend, Laptop A and Laptop B...' -ForegroundColor Cyan

Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\backend'; python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload"
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\laptop-a'; npm run dev -- --host 0.0.0.0 --port 3001"
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot\laptop-b'; npm run dev -- --host 0.0.0.0 --port 3002"

Write-Host 'Laptop A: http://localhost:3001' -ForegroundColor Green
Write-Host 'Laptop B: http://localhost:3002' -ForegroundColor Green
Write-Host 'Backend:  http://localhost:8000/docs' -ForegroundColor Green
