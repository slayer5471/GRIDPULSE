# GRIDPULSE Graphs Fixed — Run Now

The ZIP is packaged so `package.json` is at the project root.

## Laptop B
```bash
cd ~/Downloads/GRIDPULSE_GRAPHS_FIXED_ROOT_2026-09-29
rm -rf node_modules/.vite
npm install
npm run dev:laptop-b -- --force
```
Open http://localhost:3002

## Laptop A (second terminal)
```bash
cd ~/Downloads/GRIDPULSE_GRAPHS_FIXED_ROOT_2026-09-29
npm run dev:laptop-a
```
Open http://localhost:3001

## Backend (third terminal, optional for demo mode)
```bash
cd ~/Downloads/GRIDPULSE_GRAPHS_FIXED_ROOT_2026-09-29/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
