# GRIDPULSE — Engineering Upgrade (2026-09-29)

This package keeps the existing GRIDPULSE engineering core and upgrades the operator experience around it.

## Laptop A — Circuit Host

- Preserved the editable electrical circuit/digital-twin engine.
- Preserved component library, property editor, topology validation, power balance, anomaly detection, energy provenance, What-If, N-1, scenarios, undo/redo, save/load, and FastAPI network publishing.
- Refreshed the outer workstation shell so Laptop A clearly reads as the engineering authoring/simulation environment.

## Laptop B — Control Centre

Reorganized the operator application around a professional light SCADA/control-centre information architecture:

- Overview
- Live Data
- Live Community
- Analytics
- Battery
- Protection
- AI Insights
- Alerts
- History
- Reports
- Engineering Studio

The previous engineering features remain accessible under Engineering Studio rather than being deleted.

## BESS + PWM

The existing BESS and PWM implementation is retained and surfaced prominently:

- SOC / stored energy
- charge / discharge / idle state
- PCS power
- PWM duty cycle
- PWM frequency
- period / ON / OFF time
- pulse energy
- average transfer power
- energy path to load/grid or into storage

## Alarms

- Alert Centre presentation redesigned.
- Active alerts are deduplicated in the UI.
- Backend alarm IDs are now stable across telemetry ticks.
- Added acknowledgement endpoint and acknowledgement state.
- Alarm history no longer grows with an identical new record every telemetry tick.

## Operator Controls

Battery charge, discharge and stop commands now map to real backend control modes:

- `BATTERY_CHARGE`
- `BATTERY_DISCHARGE`
- `BATTERY_STOP`

These execute through Laptop B → FastAPI → GridTwin.

## Demo / Scenarios

The existing scenario engine remains the source of truth for:

- Solar deficit / match / surplus
- high solar / high load
- evening peak
- transformer overload
- grid outage
- voltage sag / swell
- BESS charge / discharge / low SOC
- PV trip
- PCS trip
- feeder outage
- false-data injection

Scenario changes update the shared state and therefore feed the UI, alarms, charts, BESS and PWM views.

## Windows

Added PowerShell launchers:

- `start-gridpulse.ps1`
- `run_backend.ps1`

## Validation completed in this environment

- Python backend modules compile successfully.
- Existing backend scenario smoke test passes for 15 scenarios.
- Additional BESS charge/discharge command smoke tests pass.
- All 28 Laptop B TypeScript/TSX source files pass TypeScript syntax transpilation diagnostics.

The environment could not complete a fresh npm dependency download because the package registry was unreachable from the execution environment. The source tree itself was syntax-checked; dependency installation/build should be run on the target machine with network access.
