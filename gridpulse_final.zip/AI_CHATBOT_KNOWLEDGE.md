# GRIDPULSE AI Knowledge Engine

The Laptop B assistant now combines two sources:
1. Live authoritative telemetry from the GRIDPULSE state.
2. An embedded engineering reference library covering GRIDPULSE architecture, SCADA, DERMS, digital twins, power flow, BESS/SOC/SOH/degradation, PCS/PWM, transformers/protection/thermal health, PV, zero export, forecasting, power quality/harmonics, reactive power, alarms, scenarios, N-1, dynamic line rating, topology, cybersecurity/FDIA, microgrids, Solarex, carbon accounting, dispatch copilot, operator controls, energy provenance and troubleshooting.

The assistant explicitly labels live values as live and uses the reference library for conceptual/engineering explanations. It does not invent telemetry values when a field is missing.

For a production external LLM integration, use a backend endpoint and keep API credentials server-side. Do not put private API keys in `VITE_*` client variables; Vite exposes `VITE_*` variables to client code at build time.
