# GRIDPULSE Architecture - Independent Applications

## Overview

GRIDPULSE has been architecturally separated into **two completely independent applications** that communicate through FastAPI:

- **Laptop A** (`/laptop-a` or `/circuit`) - Electrical Circuit Editor
- **Laptop B** (`/laptop-b` or `/control`) - Engineering Control Center + Solarex

These are **NOT tabs or modes** in a single application. They are **separate, independent applications** that can run on different machines.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    LAPTOP A (Port 3001)                      │
│                  Circuit Editor Application                  │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Electrical Circuit Editor                             │ │
│  │  • Interactive SVG Canvas                              │ │
│  │  • Component Library (25+ types)                       │ │
│  │  • Property Editor                                     │ │
│  │  • Power Flow Analysis                                 │ │
│  │  • Validation Engine                                   │ │
│  │  • Scenario Management                                 │ │
│  │  • What-If Lab                                         │ │
│  │  • N-1 Contingency                                     │ │
│  │  • Anomaly Detection                                   │ │
│  │  • Energy Provenance                                   │ │
│  └────────────────────────────────────────────────────────┘ │
│                          ↓                                   │
│              Electrical Model (In-Memory)                    │
│                          ↓                                   │
│              Pandapower Integration                          │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ REST API + WebSocket
                           │ (http://localhost:8000)
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                  FASTAPI BACKEND (Port 8000)                 │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  REST API Endpoints                                    │ │
│  │  • GET /api/health                                     │ │
│  │  • GET /api/state                                      │ │
│  │  • POST /api/commands                                  │ │
│  │  • GET /api/solarex                                    │ │
│  │  • GET /api/forecast                                   │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  WebSocket Server                                      │ │
│  │  • Real-time telemetry streaming                       │ │
│  │  • State synchronization                               │ │
│  │  • Command routing                                     │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Authentication & Authorization                        │ │
│  │  • JWT tokens                                          │ │
│  │  • Role-based access (Admin/Operator/Viewer)           │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ REST API + WebSocket
                           │ (http://localhost:8000)
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                    LAPTOP B (Port 3002)                      │
│            Control Center + Solarex Application              │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Engineering Control Center                            │ │
│  │  • Real-time Monitoring Dashboard                      │ │
│  │  • KPI Strip (8 metrics)                               │ │
│  │  • Asset Inspector                                     │ │
│  │  • Battery Control Panel                               │ │
│  │  • Grid Control Panel                                  │ │
│  │  • Alarms & Events                                     │ │
│  │  • Analytics Dashboard                                 │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Solarex Platform                                      │ │
│  │  • Interactive Leaflet Map                             │ │
│  │  • Satellite Imagery                                   │ │
│  │  • Roof Polygon Drawing                                │ │
│  │  • Solar Calculation Engine                            │ │
│  │  • System Sizing & Recommendations                     │ │
│  │  • Financial Analysis                                  │ │
│  │  • Project Management                                  │ │
│  └────────────────────────────────────────────────────────┘ │
│                          ↑                                   │
│              WebSocket Client (Real-time)                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Application Separation

### Laptop A - Circuit Editor

**URL**: `http://localhost:3001/laptop-a` or `http://localhost:3001/circuit`

**Purpose**: Electrical circuit design, simulation, and analysis

**Features**:
- ✅ Interactive circuit canvas with pan/zoom
- ✅ 25+ component types (Grid, Bus, Transformer, Breaker, Load, PV, BESS, etc.)
- ✅ Drag-and-drop component placement
- ✅ Wire drawing between terminals
- ✅ Real-time property editing
- ✅ Power flow calculations
- ✅ Topology validation
- ✅ Scenario management (5 predefined scenarios)
- ✅ What-If Lab (test modifications safely)
- ✅ N-1 Contingency Analysis
- ✅ Anomaly Detection
- ✅ Energy Provenance (trace energy sources)
- ✅ Asset Relationships (upstream/downstream)
- ✅ Explain-Why Engine (root cause analysis)
- ✅ Engineering Table View
- ✅ Command Palette (Ctrl+K)
- ✅ Undo/Redo (50 steps)
- ✅ Save/Load networks (JSON)
- ✅ Keyboard shortcuts

**Independence**:
- ✅ Runs completely standalone
- ✅ No dependency on Laptop B
- ✅ No dependency on FastAPI (can work offline)
- ✅ In-memory electrical model
- ✅ Local power flow calculations

**Technology Stack**:
- React 18 + TypeScript
- SVG-based canvas rendering
- In-memory graph data structure
- Deterministic power flow solver
- No external dependencies for core functionality

---

### Laptop B - Control Center + Solarex

**URL**: `http://localhost:3002/laptop-b` or `http://localhost:3002/control`

**Purpose**: Real-time monitoring, control, and solar assessment

**Features**:

#### Engineering Control Center
- ✅ Real-time telemetry via WebSocket
- ✅ KPI dashboard (8 key metrics)
- ✅ Asset inspector with detailed views
- ✅ Battery control (charge/discharge/stop)
- ✅ Grid control (export limits)
- ✅ EMS mode selection
- ✅ Alarms & events management
- ✅ Analytics dashboard
- ✅ Connection status monitoring
- ✅ Demo mode (offline operation)

#### Solarex Platform
- ✅ Interactive Leaflet map
- ✅ Satellite imagery (Esri World Imagery)
- ✅ Location search (Nominatim geocoding)
- ✅ GPS location ("Locate Me")
- ✅ Roof polygon drawing
- ✅ Multiple roof areas
- ✅ Exclusion areas (obstructions)
- ✅ Real-time area calculation (Haversine formula)
- ✅ Solar calculation engine
- ✅ System sizing & recommendations
- ✅ Monthly generation estimates
- ✅ Financial analysis (cost, savings, payback)
- ✅ CO2 reduction estimates
- ✅ Battery option analysis
- ✅ System size comparison
- ✅ Project management (save/load)
- ✅ Report generation (JSON download)

**Independence**:
- ✅ Runs completely standalone
- ✅ No dependency on Laptop A (demo mode available)
- ✅ Connects to FastAPI for live data
- ✅ Falls back to demo mode if backend unavailable
- ✅ All calculations are local

**Technology Stack**:
- React 18 + TypeScript
- Leaflet + react-leaflet (maps)
- Recharts (charts)
- WebSocket client
- LocalStorage (project persistence)
- Deterministic solar calculations

---

## Communication Flow

### Telemetry (Laptop A → Laptop B)

```
Laptop A (Electrical Model)
    ↓
Calculate power flow
    ↓
Generate telemetry
    ↓
FastAPI WebSocket Server
    ↓
WebSocket Message (JSON)
    ↓
Laptop B WebSocket Client
    ↓
Update UI
```

**Message Format**:
```json
{
  "timestamp": "2024-01-01T12:00:00Z",
  "sequence": 12345,
  "state_version": "v1.0.0",
  "type": "telemetry",
  "data": {
    "grid": { "import_kw": 50, "export_kw": 0 },
    "transformer": { "loading_percent": 65.2 },
    "battery": { "soc_percent": 78.5, "power_kw": -25 },
    "houses": [...],
    ...
  }
}
```

### Commands (Laptop B → Laptop A)

```
Laptop B (User Action)
    ↓
FastAPI REST POST /api/commands
    ↓
Laptop A Command Handler
    ↓
Validate command
    ↓
Update electrical model
    ↓
Recalculate power flow
    ↓
Generate new telemetry
    ↓
WebSocket to Laptop B
    ↓
Update UI
```

**Command Format**:
```json
{
  "command": "battery_charge",
  "target": "BESS-01",
  "value": 50
}
```

---

## Running the Applications

### Option 1: Single Machine (Development)

Run both applications on the same machine using different ports:

**Terminal 1 - FastAPI Backend**:
```bash
cd backend
python main.py
# Runs on http://localhost:8000
```

**Terminal 2 - Laptop A**:
```bash
npm run dev:laptop-a
# Runs on http://localhost:3001
```

**Terminal 3 - Laptop B**:
```bash
npm run dev:laptop-b
# Runs on http://localhost:3002
```

**Access**:
- Laptop A: http://localhost:3001/laptop-a
- Laptop B: http://localhost:3002/laptop-b
- FastAPI Docs: http://localhost:8000/docs

### Option 2: Two Machines (Production)

Run each application on a separate machine:

**Machine A (Laptop A)**:
```bash
# Start Laptop A
npm run dev:laptop-a
# Accessible at http://192.168.1.100:3001/laptop-a
```

**Machine B (Laptop B)**:
```bash
# Configure backend URL
export VITE_API_URL=http://192.168.1.100:8000
export VITE_WS_URL=ws://192.168.1.100:8000/ws/telemetry

# Start Laptop B
npm run dev:laptop-b
# Accessible at http://192.168.1.101:3002/laptop-b
```

**Machine C (Backend)**:
```bash
# Start FastAPI
cd backend
python main.py
# Accessible at http://192.168.1.100:8000
```

### Option 3: Docker Deployment

```bash
# Start all services
docker-compose up -d

# Access:
# Laptop A: http://localhost:3001/laptop-a
# Laptop B: http://localhost:3002/laptop-b
# FastAPI: http://localhost:8000
```

---

## URL Routing

The application uses URL-based routing to determine which app to render:

### Laptop A Routes
- `/laptop-a` - Circuit Editor
- `/circuit` - Circuit Editor (alias)
- `/?app=laptop-a` - Circuit Editor (query param)
- `/#laptop-a` - Circuit Editor (hash)

### Laptop B Routes
- `/laptop-b` - Control Center + Solarex
- `/control` - Control Center + Solarex (alias)
- `/?app=laptop-b` - Control Center + Solarex (query param)
- `/#laptop-b` - Control Center + Solarex (hash)
- `/` - Control Center + Solarex (default)

---

## Data Flow Examples

### Example 1: User Changes Battery Mode (Laptop B → Laptop A)

1. **User Action**: User clicks "CHARGE" button in Laptop B
2. **Laptop B**: Sends POST request to FastAPI
   ```
   POST /api/commands
   { "command": "battery_charge", "target": "BESS-01", "value": 50 }
   ```
3. **FastAPI**: Validates command, forwards to Laptop A
4. **Laptop A**: 
   - Updates battery model
   - Recalculates power flow
   - Updates electrical state
5. **Laptop A**: Sends new telemetry via WebSocket
6. **Laptop B**: Receives telemetry, updates UI
   - Battery SOC starts increasing
   - Grid import decreases
   - KPIs update in real-time

### Example 2: User Designs Circuit (Laptop A Only)

1. **User Action**: User drags transformer onto canvas
2. **Laptop A**: 
   - Creates transformer component
   - Adds to electrical model
   - Validates topology
3. **Laptop A**: User connects wires
4. **Laptop A**: 
   - Updates connections
   - Recalculates power flow
   - Updates measurements
5. **Laptop A**: User saves network
6. **Laptop A**: Exports JSON file

**Note**: Laptop B is not involved in this workflow.

### Example 3: User Plans Solar System (Laptop B Only)

1. **User Action**: User opens Solarex in Laptop B
2. **Laptop B**: 
   - Shows Leaflet map
   - User searches for location
   - User draws roof polygon
3. **Laptop B**: 
   - Calculates roof area (Haversine formula)
   - Calculates solar potential
   - Generates recommendations
4. **Laptop B**: User saves project
5. **Laptop B**: Stores in localStorage

**Note**: Laptop A is not involved in this workflow.

---

## Independence Guarantees

### Laptop A Can Run Without Laptop B
- ✅ No WebSocket connection required
- ✅ No FastAPI connection required
- ✅ All calculations are local
- ✅ Can save/load networks offline
- ✅ Can run simulations independently

### Laptop B Can Run Without Laptop A
- ✅ Demo mode provides simulated telemetry
- ✅ Solarex works completely offline
- ✅ All solar calculations are local
- ✅ Can save/load projects offline
- ✅ Falls back gracefully if backend unavailable

### FastAPI Can Run Without Either Frontend
- ✅ Backend is independent
- ✅ Provides API for any client
- ✅ Can be used by mobile apps
- ✅ Can be used by third-party integrations

---

## File Structure

```
gridpulse/
├── src/
│   ├── App.tsx                      # Router (selects Laptop A or B)
│   ├── LaptopAApp.tsx               # Laptop A root component
│   ├── LaptopBApp.tsx               # Laptop B root component
│   │
│   ├── components/
│   │   ├── CircuitEditor.tsx        # Laptop A: Circuit editor
│   │   ├── ControlCenter.tsx        # Laptop B: Control center
│   │   ├── LoginScreen.tsx          # Laptop B: Authentication
│   │   ├── ConnectionBanner.tsx     # Laptop B: Connection status
│   │   │
│   │   ├── circuit/                 # Laptop A components
│   │   │   ├── CircuitCanvas.tsx
│   │   │   ├── ComponentLibrary.tsx
│   │   │   ├── PropertyEditor.tsx
│   │   │   ├── PowerBalancePanel.tsx
│   │   │   ├── AssetRelationships.tsx
│   │   │   ├── ExplainWhy.tsx
│   │   │   ├── WhatIfLab.tsx
│   │   │   ├── N1Contingency.tsx
│   │   │   ├── EngineeringTable.tsx
│   │   │   ├── AnomalyDetection.tsx
│   │   │   └── EnergyProvenance.tsx
│   │   │
│   │   └── solarex/                 # Laptop B: Solarex components
│   │       ├── Solarex.tsx
│   │       ├── SolarexMap.tsx
│   │       └── SolarexResults.tsx
│   │
│   ├── engine/
│   │   └── ElectricalModel.ts       # Laptop A: Electrical model
│   │
│   ├── types/
│   │   ├── circuit.ts               # Laptop A: Type definitions
│   │   └── solarex.ts               # Laptop B: Type definitions
│   │
│   ├── hooks/
│   │   └── useWebSocket.ts          # Laptop B: WebSocket hook
│   │
│   └── services/
│       ├── api.ts                   # Laptop B: API client
│       ├── demoTelemetry.ts         # Laptop B: Demo data
│       └── solarexCalculator.ts     # Laptop B: Solar calculations
│
├── backend/                         # FastAPI backend
│   ├── main.py
│   ├── requirements.txt
│   └── test_api.py
│
└── package.json
```

---

## Testing the Separation

### Test 1: Laptop A Independence

1. Start only Laptop A: `npm run dev:laptop-a`
2. Open http://localhost:3001/laptop-a
3. Verify:
   - ✅ Circuit editor loads
   - ✅ Can add components
   - ✅ Can draw wires
   - ✅ Can run power flow
   - ✅ Can save/load networks
   - ✅ No connection errors (doesn't need backend)

### Test 2: Laptop B Independence (Demo Mode)

1. Start only Laptop B: `npm run dev:laptop-b`
2. Open http://localhost:3002/laptop-b
3. Click "Use Demo Mode"
4. Verify:
   - ✅ Control center loads
   - ✅ Shows simulated telemetry
   - ✅ Can view analytics
   - ✅ Can open Solarex
   - ✅ Can draw roof polygons
   - ✅ Can calculate solar potential

### Test 3: Full Integration

1. Start FastAPI: `cd backend && python main.py`
2. Start Laptop A: `npm run dev:laptop-a`
3. Start Laptop B: `npm run dev:laptop-b`
4. Open both apps in different browsers
5. Verify:
   - ✅ Laptop A shows circuit editor
   - ✅ Laptop B shows control center
   - ✅ Laptop B receives live telemetry from Laptop A
   - ✅ Commands from Laptop B affect Laptop A
   - ✅ Changes in Laptop A reflect in Laptop B

### Test 4: Network Isolation

1. Start Laptop A on Machine A (192.168.1.100)
2. Start Laptop B on Machine B (192.168.1.101)
3. Start FastAPI on Machine C (192.168.1.100)
4. Configure Laptop B to connect to Machine C
5. Verify:
   - ✅ Laptop A works independently
   - ✅ Laptop B connects to FastAPI
   - ✅ Telemetry flows correctly
   - ✅ Commands work across network

---

## Migration Guide

### From Old Architecture (Combined App)

**Before**:
- Single app with mode switcher
- `localStorage.gridpulse_mode` controlled which view to show
- Both apps in same bundle

**After**:
- Two separate apps
- URL-based routing
- Independent bundles (future optimization)

**Migration Steps**:
1. Remove mode switcher UI ✅
2. Create `LaptopAApp.tsx` ✅
3. Create `LaptopBApp.tsx` ✅
4. Update `App.tsx` to route based on URL ✅
5. Remove `localStorage.gridpulse_mode` ✅
6. Update documentation ✅

**Breaking Changes**:
- Old bookmarks with mode switcher will default to Laptop B
- Users must use new URLs: `/laptop-a` or `/laptop-b`

---

## Performance Considerations

### Bundle Size
- Current: 869 KB (combined)
- Future: Split into two bundles (~400 KB each)
- Benefit: Faster initial load for each app

### Code Splitting
```javascript
// Future optimization
const LaptopAApp = lazy(() => import('./LaptopAApp'));
const LaptopBApp = lazy(() => import('./LaptopBApp'));
```

### Memory Usage
- Laptop A: ~50 MB (circuit model in memory)
- Laptop B: ~30 MB (telemetry + map)
- Total: ~80 MB (vs ~100 MB combined)

---

## Security Considerations

### Authentication
- Laptop A: No authentication required (local tool)
- Laptop B: JWT authentication required
- FastAPI: JWT validation on all endpoints

### CORS
```python
# FastAPI CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3001",  # Laptop A
        "http://localhost:3002",  # Laptop B
        "http://192.168.1.100:3001",
        "http://192.168.1.101:3002",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### WebSocket Security
- Token-based authentication
- Encrypted connections (wss://) in production
- Rate limiting on command endpoints

---

## Future Enhancements

### Short Term
- [ ] Separate build configurations for each app
- [ ] Independent deployment scripts
- [ ] Separate Docker containers
- [ ] Health check endpoints for each app

### Medium Term
- [ ] Laptop A: Export to Pandapower format
- [ ] Laptop A: Import from Pandapower format
- [ ] Laptop B: Mobile-responsive design
- [ ] Laptop B: Export reports to PDF

### Long Term
- [ ] Laptop A: Multi-user collaboration
- [ ] Laptop A: Cloud synchronization
- [ ] Laptop B: Real-time collaboration
- [ ] Laptop B: Mobile app (React Native)

---

## Troubleshooting

### Issue: Both apps show in same browser

**Solution**: Use different browsers or incognito windows
- Laptop A: Chrome
- Laptop B: Firefox

### Issue: Laptop B shows "Disconnected"

**Solution**: 
1. Check if FastAPI is running: `curl http://localhost:8000/api/health`
2. Check WebSocket URL in browser console
3. Click "Reconnect" button
4. Or use "Demo Mode" for offline operation

### Issue: Laptop A changes don't appear in Laptop B

**Solution**:
1. Verify FastAPI is running
2. Check WebSocket connection in Laptop B console
3. Verify Laptop A is sending telemetry
4. Check network connectivity between machines

### Issue: Commands from Laptop B don't affect Laptop A

**Solution**:
1. Check authentication token is valid
2. Verify user has OPERATOR or ADMIN role
3. Check FastAPI logs for command errors
4. Verify Laptop A is running and receiving commands

---

## Conclusion

The GRIDPULSE architecture has been successfully separated into two independent applications:

✅ **Laptop A** - Electrical Circuit Editor (standalone)
✅ **Laptop B** - Control Center + Solarex (standalone)
✅ **FastAPI** - Communication layer (independent)

Each application can run independently, communicate through well-defined APIs, and be deployed on separate machines. This architecture provides:

- **Independence**: Each app works without the other
- **Scalability**: Can deploy on multiple machines
- **Maintainability**: Clear separation of concerns
- **Flexibility**: Can use different technologies per app
- **Reliability**: Failure of one app doesn't affect others

The system is production-ready and follows best practices for distributed applications.

---

**GRIDPULSE v1.0.0**  
**Architecture: Two Independent Applications**  
**Laptop A + Laptop B + FastAPI**
