# GRIDPULSE Co-Simulation Architecture

```text
OpenDSS / pandapower  <-- physical distribution
        |
        v
     HELICS  <-- time barrier / messages
     /   \
    v     v
Control  Communication
  |         |
  v         v
BESS/DER   MQTT / protocol bridge
              |
              v
         Wokwi / ESP32

Laptop A = circuit host / authoritative editor
FastAPI   = telemetry + control backbone
Laptop B = operator SCADA / intelligence view
```

The deterministic fallback mirrors the same federate contract so the SIH demo remains stable when optional external engines are unavailable.
