# GRIDPULSE — PDF Expansion Implemented

This build turns the existing two-laptop frontend architecture into a working local digital-twin stack.

## Implemented now

### Laptop A
- Remains the editable circuit host and local source of truth.
- Pushes the current circuit/network JSON to the local FastAPI digital twin every second while running.
- Existing editable circuit, scenarios, validation, N-1, what-if, and power-flow UI remain intact.
- Header now identifies the host as a Dual-Engine Digital Twin.

### FastAPI digital twin
- Real-time `/api/state` and `/ws/telemetry` streaming.
- Login endpoint matching the existing demo credentials.
- Load/PV/BESS/transformer electrical balance model.
- Economic battery dispatch with import/export price, transformer loading, and degradation penalty terms.
- Battery SOC propagation and cycle/degradation analytics.
- Volt-VAR and Volt-Watt response logic using the PDF's Category-B-inspired curve values.
- Physics-based telemetry sanity gate for FDIA/anomaly screening.
- IEEE-2030.5-style DER Control, Metering/Mirrored Metering and Pricing XML representations.
- Modbus-TCP-style BESS register map endpoint.
- Anti-islanding / NDZ study endpoint.
- Solarex planning endpoint remains fully local.
- Pandapower/OpenDSS adapter detection is present; the backend has a deterministic offline fallback so the SIH demo does not depend on external packages.

### Laptop B
- New **Grid Intelligence** engineering page.
- Live multi-horizon temporal-fusion-style forecast.
- Battery dispatch recommendation and projected transformer loading.
- Volt-VAR / Volt-Watt visibility.
- Battery life / equivalent full-cycle analytics.
- IEEE 2030.5-style + Modbus communication readiness.
- TLS/PKI readiness indicators and physics-based FDIA risk view.

## Important engineering note

The PDF describes research/utility-grade components such as a fully trained Temporal Fusion Transformer, PPO/SAC reinforcement learning, production IEEE 2030.5 security, and physical-device interoperability. This build implements a **functional offline SIH engineering version** of those layers: temporal-fusion-style forecasting, constrained economic dispatch, protocol-shaped XML/register adapters, and local physics verification. A production deployment would still replace the surrogate forecast with a trained checkpoint, replace the dispatch optimizer with a trained PPO/SAC policy, and harden the protocol layer with real certificates/TLS and certified device conformance testing.

## Run

### Laptop A

Terminal 1:

```bash
./run_backend.sh
```

Terminal 2:

```bash
npm install
npm run dev:laptop-a
```

Open `http://localhost:3001`.

### Laptop B

Set Laptop A's LAN IP before starting Vite:

```bash
export VITE_API_URL=http://<LAPTOP_A_IP>:8000
export VITE_WS_URL=ws://<LAPTOP_A_IP>:8000/ws/telemetry
npm install
npm run dev:laptop-b
```

Open `http://localhost:3002`.

The backend must listen on `0.0.0.0:8000` on Laptop A, and the LAN/firewall must allow TCP 8000.
